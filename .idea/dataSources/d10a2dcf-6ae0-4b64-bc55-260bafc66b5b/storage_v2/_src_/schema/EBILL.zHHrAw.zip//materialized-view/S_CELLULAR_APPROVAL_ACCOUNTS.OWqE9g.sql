create materialized view S_CELLULAR_APPROVAL_ACCOUNTS
refresh complete on demand
  as
    select * from (
SELECT CAA_ACC_ID,
       CAA_CLU_CELLULAR_NUMBER,
       CAA_END_DATE,
       CAA_END_USER,
       CAA_ID,
       CAA_START_DATE,
       CAA_START_USER
  FROM CELLULAR_APPROVAL_ACCOUNTS@PROD
 WHERE NVL (CAA_END_DATE, TO_DATE ('01-04-2015', 'DD-MM-YYYY') + 1) >
          TO_DATE ('01-04-2015', 'DD-MM-YYYY'))
/

