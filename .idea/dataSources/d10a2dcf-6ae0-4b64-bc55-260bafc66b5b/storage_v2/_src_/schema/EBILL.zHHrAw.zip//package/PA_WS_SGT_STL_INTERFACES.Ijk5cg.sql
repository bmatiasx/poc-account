create PACKAGE PA_WS_SGT_STL_INTERFACES IS

FUNCTION f_update_material_ot(sds_id      IN VARCHAR2,
                                nim         IN VARCHAR2,
                                pro_id      IN VARCHAR2,
                                nse_id      IN VARCHAR2,
                                mac_address IN VARCHAR2,
                                guid_id     IN VARCHAR2,
                                nodo        IN VARCHAR2 DEFAULT NULL,--PC135022
                                p_ent_id    IN VARCHAR2 DEFAULT NULL,
                                pout_msg    OUT VARCHAR2) RETURN NUMBER;
  FUNCTION f_get_type_ot(pin_sds_id    IN ag_sds_details.agd_asd_id_sds%TYPE,
                         pout_sds_type OUT VARCHAR2,
                         pout_message  OUT VARCHAR2) RETURN NUMBER;

  FUNCTION f_update_new_material(pin_sds_id        IN ag_sds_details.agd_asd_id_sds%TYPE,
                                 pin_nim           IN ag_sds_details.agd_clu_cellular_number%TYPE,
                                 pin_cbt_id        IN ag_sds_details.agd_cbt_id%TYPE,
                                 pin_pro_id        IN ag_sds_details.agd_pro_id%TYPE,
                                 pin_nse_id        IN ag_sds_details.agd_nse_id%TYPE,
                                 pin_macadd        IN ag_sds_details.agd_mac_address%TYPE,
                                 pin_guid          IN ag_sds_details.agd_guid%TYPE,
                                 pin_status        IN ag_sds_details.agd_status%TYPE,
                                 pin_nodo          IN ag_sds_details.agd_nodo%TYPE DEFAULT NULL,--PC135022
                                 pout_pro_id_conex OUT VARCHAR2,
                                 pout_msg          OUT VARCHAR2)
    RETURN NUMBER;

END PA_WS_SGT_STL_INTERFACES;
/

