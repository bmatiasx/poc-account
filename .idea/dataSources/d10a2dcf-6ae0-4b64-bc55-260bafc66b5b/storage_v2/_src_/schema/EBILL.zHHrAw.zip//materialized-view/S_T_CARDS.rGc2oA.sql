create materialized view S_T_CARDS
refresh force on demand
  as
    SELECT crd_id, crd_ems_id, crd_description, crd_status, crd_auth_amount, crd_coe_id,
 crd_security_code_return, crd_security_code_pay, crd_card_number_format,       crd_send_identification_number, crd_pin_send, crd_debits, crd_credits,      crd_exp_date_validation, crd_additional_validation, crd_coupon_request_flag,       crd_flag_manual_input
 from t_cards@PROD


/

