create PACKAGE PA_CONSUMPTION_INFORMATION IS
  -- Author  : EXB23639
  -- Created : 07/07/2016
  -- Purpose : Funcionalidades de TURBO 252 en Ebill
  -----------------------------------------------------------------------------------------------------------------
  /*     Fecha               Desarrollador                Pedido de Cambio                 */
  /*     07/07/2016          EXB23639                     WMASIVO-1639                     */
  /*     19/09/2017          EXB23639                     WMASIVO-4727                     */
  ------------------------------------------------------------------------------------------------------------------
  /***************************************************************************************************************/
  /*Entrada Principal para obtener toda la informacion                                                           */
  /***************************************************************************************************************/
  FUNCTION F_GET_CONSUMPTION_INFORMATION(p_nim                   IN VARCHAR2,
                                         P_KEYWORD               IN VARCHAR2,
                                         P_PACKAGE               OUT VARCHAR2,
                                         P_MAIN_QUOTA_NAME       OUT VARCHAR2,
                                         P_DAILY_QUOTA_NAME      OUT VARCHAR2,
                                         P_ADDITIONAL_QUOTA_NAME OUT VARCHAR2,
                                         P_SIZE_MAIN             OUT NUMBER,
                                         P_SIZE_DAILY            OUT NUMBER,
                                         P_SIZE_ADDITIONAL       OUT NUMBER,
                                         P_PKT_CYCLIC            OUT VARCHAR2,
                                         P_LIMIT_CYCLE           OUT NUMBER,
                                         P_LIMIT_DAY             OUT NUMBER,
                                         P_COUNT_CYCLE           OUT NUMBER,
                                         P_COUNT_DAY             OUT NUMBER,
                                         P_BUY_COST              OUT NUMBER,
                                         P_VIEW_PACK_WEB         OUT VARCHAR2,
                                         P_BUY_PACK_WEB          OUT VARCHAR2,
                                         P_BUY_REASON            OUT VARCHAR2,
                                         P_ERR_TEXT              OUT VARCHAR2,
                                         P_ERR_NUM               OUT NUMBER)
    RETURN NUMBER;

  /***************************************************************************************************************/
  /*Entrada Principal para obtener toda la informacion recompra multiple                                                     */
  /***************************************************************************************************************/
  FUNCTION F_GPRS_INFORMATION_COMPLETE(P_NIM                   IN VARCHAR2,
                                       P_KEYWORD               IN VARCHAR2,
                                       P_CHANNEL               IN VARCHAR2,
                                       P_PACKAGE               OUT VARCHAR2,
                                       P_FEATURE_ID            OUT VARCHAR2,
                                       P_SPECIAL_SERVICE_DATA  OUT VARCHAR2,
                                       P_ACTION_SERVICE_ID     OUT VARCHAR2,
                                       P_MAIN_QUOTA_NAME       OUT VARCHAR2,
                                       P_DAILY_QUOTA_NAME      OUT VARCHAR2,
                                       P_ADDITIONAL_QUOTA_NAME OUT VARCHAR2,
                                       P_SIZE_MAIN             OUT NUMBER,
                                       P_SIZE_DAILY            OUT NUMBER,
                                       P_SIZE_ADDITIONAL       OUT NUMBER,
                                       P_REPURCHASED_SIZE      OUT NUMBER,
                                       P_REPURCHASED_UNIT      OUT VARCHAR2,
                                       P_PKT_CYCLIC            OUT VARCHAR2,
                                       P_COUNT_CYCLE           OUT NUMBER,
                                       P_COUNT_DAY             OUT NUMBER,
                                       P_OPTION_EXCHANGE_RATE  OUT VARCHAR2,
                                       P_BUY_COST              OUT VARCHAR2,
                                       P_OPTION_LIMIT_CYCLE    OUT VARCHAR2,
                                       P_OPTION_LIMIT_DAY      OUT VARCHAR2,
                                       P_OPTION_ROAMING_GROUPS OUT VARCHAR2,
                                       P_OPTION_CAPACITY_ID    OUT VARCHAR2,
                                       P_OPTION_VOLUME         OUT VARCHAR2,
                                       P_OPTION_VOLUME_UNITY   OUT VARCHAR2,
                                       P_OPTION_CHANNEL        OUT VARCHAR2,
                                       P_VIEW_PACK_WEB         OUT VARCHAR2,
                                       P_BUY_PACK_WEB          OUT VARCHAR2,
                                       P_BUY_REASON            OUT VARCHAR2,
                                       P_ERR_TEXT              OUT VARCHAR2,
                                       P_ERR_NUM               OUT NUMBER)
    RETURN NUMBER;

  /***************************************************************************************************************/
  /*Se obtienen todos los datos que se necesitan de un Linea para trabajar                                       */
  /***************************************************************************************************************/
  PROCEDURE P_GET_DATA_CELLULAR(P_BILL_NUMBER            IN S_CELLULARS.Clu_Bill_Number%TYPE,
                                POUT_CELLULAR_NUMBER     OUT S_CELLULARS.clu_cellular_number%TYPE,
                                POUT_CELLULAR_CATEGORY   OUT S_CLIENT.Clt_Category%TYPE,
                                POUT_CELLULAR_TYPE       OUT S_CLIENT.Clt_Type%TYPE,
                                POUT_CELLULAR_CBT_ID     OUT S_CELLULARS.Clu_Cbt_Id%TYPE,
                                POUT_CELLULAR_RPL_ID     OUT S_RATE_PLANS.RPL_RPL_ID%TYPE,
                                POUT_CELLULAR_RPL_RTY_ID OUT S_RATE_PLANS.RPL_RTY_ID%TYPE,
                                POUT_SMS_ID              OUT VARCHAR2,
                                POUT_ERROR_TEXT          OUT VARCHAR2,
                                POUT_ERROR_CODE          OUT NUMBER);
  /***************************************************************************************************************/
  /*Se busca toda la informacion referida al paquete de internet e info necesaria para PCRF                      */
  /***************************************************************************************************************/

  PROCEDURE P_INTERNET_WEB_NAMES(P_CELLULAR_NUMBER          IN S_CELLULARS.clu_cellular_number%TYPE,
                                 POUT_FEATURE_ID            OUT S_FEATURES.ftr_id%TYPE,
                                 POUT_PACKAGE_ID            OUT S_PACKAGES.pkt_id%TYPE,
                                 POUT_PACKAGE_CYCLIC        OUT S_PACKAGES.Pkt_Cyclic%TYPE,
                                 POUT_MAIN_QUOTA_NAME       OUT VW_AUT_FEATURES_ASSOCIATIONS.CUSTOM2%TYPE,
                                 POUT_DAILY_QUOTA_NAME      OUT VW_AUT_FEATURES_ASSOCIATIONS.CUSTOM7%TYPE,
                                 POUT_ADDITIONAL_QUOTA_NAME OUT VW_AUT_FEATURES_ASSOCIATIONS.CUSTOM10%TYPE,
                                 POUT_VIEW_WEB              OUT VARCHAR2,
                                 POUT_SMS_ID                OUT VARCHAR2,
                                 POUT_ERROR_TEXT            OUT VARCHAR2,
                                 POUT_ERROR_CODE            OUT NUMBER);
  /***************************************************************************************************************/
  /*Se busca el total de las quotas a partir del feature ID                                                      */
  /***************************************************************************************************************/

  PROCEDURE P_INTERNET_WEB_SIZES(P_FEATURE_ID         IN S_FEATURES.ftr_id%TYPE,
                                 POUT_SIZE_MAIN       OUT AUT_QUOTA_SIZE.QTS_SIZE_MB%TYPE,
                                 POUT_SIZE_DAILY      OUT AUT_QUOTA_SIZE.QTS_SIZE_MB%TYPE,
                                 POUT_SIZE_ADDITIONAL OUT AUT_QUOTA_SIZE.QTS_SIZE_MB%TYPE,
                                 POUT_ERROR_TEXT      OUT VARCHAR2,
                                 POUT_ERROR_CODE      OUT NUMBER);

  /***************************************************************************************************************/
  /*Busca el SERVICIO ESPECIAL asociado a la Linea Por Package, Por Plan o Por Tipo Plan.                        */
  /*  dentro de P_GET_SPECIAL_SERVICE_DATA                                                                       */
  /***************************************************************************************************************/

  PROCEDURE P_GET_SPEC_SERV_ASSOCIATE(P_CELLULAR_NUMBER       IN S_CELLULARS.clu_cellular_number%TYPE,
                                      P_RPL_ID                IN S_RATE_PLANS.RPL_RPL_ID%TYPE,
                                      P_RPL_RTY_ID            IN S_RATE_PLANS.RPL_RTY_ID%TYPE,
                                      P_TYPE_SERVICE_STR      IN S_SS_ACTION_SPECIAL_SERVICE.ase_type_of_service%TYPE,
                                      POUT_SPECIAL_SERVICE_ID OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_SPECIAL_SERVICE_ID%TYPE,
                                      POUT_SMS_ID             OUT VARCHAR2,
                                      POUT_ERROR_TEXT         OUT VARCHAR2,
                                      POUT_ERROR_CODE         OUT NUMBER);

  /***************************************************************************************************************/
  /*Ejecuta el Select que busca el Perfil del SERVICIO ESPECIAL */
  /***************************************************************************************************************/

  PROCEDURE P_EXEC_SPEC_SERV_PARAMETERS(P_SPECIAL_SERVICE_ID         IN S_SS_SPECIAL_SERVICE_PROFILE.SSP_SPECIAL_SERVICE_ID%TYPE,
                                        P_ACTION_SERVICE_ID          IN S_SS_ACTION_SPECIAL_SERVICE.ASE_ACTION_SERVICE_ID%TYPE,
                                        P_CATEGORY_SEARCH            IN S_CLIENT.Clt_Category%TYPE,
                                        P_TYPE_SEARCH                IN S_CLIENT.Clt_Type%TYPE,
                                        P_CBT_ID_SEARCH              IN S_CELLULARS.Clu_Cbt_Id%TYPE,
                                        P_SSP_EXCHANGE_RATE          OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_EXCHANGE_RATE%TYPE,
                                        P_CHARGE_VALUE_W_OUT_TAXES   OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_CHARGE_VALUE_WITHOUT_TAXES%TYPE,
                                        P_CHARGE_VALUE_W_TAXES       OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_CHARGE_VALUE_WITH_TAXES%TYPE,
                                        P_SSP_LIMIT_AMOUNT_PER_CYCLE OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_LIMIT_AMOUNT_PER_CYCLE%TYPE,
                                        P_SSP_LIMIT_AMOUNT_PER_DAY   OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_LIMIT_AMOUNT_PER_DAY%TYPE,
                                        P_SSP_APPLIES_ROAMING_GROUPS OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_APPLIES_ROAMING_GROUPS%TYPE,
                                        P_SSP_CLT_TYPE               OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_CLT_TYPE%TYPE,
                                        P_SSP_CLT_CATEGORY           OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_CLT_CATEGORY%TYPE,
                                        POUT_FIND_DATA               OUT VARCHAR2,
                                        POUT_SMS_ID                  OUT VARCHAR2,
                                        POUT_ERROR_TEXT              OUT VARCHAR2,
                                        POUT_ERROR_CODE              OUT NUMBER);

  /***************************************************************************************************************/
  /*Busca la cotizacion del dolar                                                                                 */
  /***************************************************************************************************************/

  PROCEDURE P_GET_PESOS_DOLAR(POUT_CHARGE_VALUE_WITH_TAXES IN OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_CHARGE_VALUE_WITH_TAXES%TYPE,
                              POUT_CHARGE_VALUE_WITHOUT_T  IN OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_CHARGE_VALUE_WITHOUT_TAXES%TYPE,
                              POUT_SMS_ID                  OUT VARCHAR2,
                              POUT_ERROR_TEXT              OUT VARCHAR2,
                              POUT_ERROR_CODE              OUT NUMBER);

  /***************************************************************************************************************/
  /* Obtiene la informacion correspondiente a la recompra (PADRE)                                                */
  /***************************************************************************************************************/

  PROCEDURE P_GET_SPECIAL_SERVICE_DATA(P_CELLULAR_NUMBER            IN S_CELLULARS.CLU_CELLULAR_NUMBER%TYPE,
                                       P_CELLULAR_CATEGORY          IN S_CLIENT.Clt_Category%TYPE,
                                       P_CELLULAR_TYPE              IN S_CLIENT.Clt_Type%TYPE,
                                       P_CELLULAR_CBT_ID            IN S_CELLULARS.Clu_Cbt_Id%TYPE,
                                       P_CELLULAR_RPL_ID            IN S_RATE_PLANS.RPL_RPL_ID%TYPE,
                                       P_CELLULAR_RPL_RTY_ID        IN S_RATE_PLANS.RPL_RTY_ID%TYPE,
                                       P_MCC                        IN S_SS_ROAMING_GROUPS.SRG_COP_MCC_ID%TYPE,
                                       P_MNC                        IN S_SS_ROAMING_GROUPS.SRG_COP_MNC_ID%TYPE,
                                       P_TYPE_SERVICE_STR           IN S_SS_ACTION_SPECIAL_SERVICE.ase_type_of_service%TYPE, -- Siempre es DATOS
                                       P_KEYWORD                    IN VARCHAR2,
                                       P_BUY_COST                   OUT VARCHAR2,
                                       P_SSP_LIMIT_AMOUNT_PER_CYCLE OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_LIMIT_AMOUNT_PER_CYCLE%TYPE,
                                       P_SSP_LIMIT_AMOUNT_PER_DAY   OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_LIMIT_AMOUNT_PER_DAY%TYPE,
                                       P_SPECIAL_SERVICE_ID         OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_SPECIAL_SERVICE_ID%TYPE,
                                       POUT_ACTION_SERVICE_ID       OUT S_SS_ACTION_SPECIAL_SERVICE.ASE_ACTION_SERVICE_ID%TYPE,
                                       POUT_SMS_ID                  OUT VARCHAR2,
                                       POUT_ERROR_TEXT              OUT VARCHAR2,
                                       POUT_ERROR_CODE              OUT NUMBER);

  /***************************************************************************************************************/
  /* si el valor esta en otra moneda lo pasa a pesos                                                             */
  /*  dentro de P_GET_SPECIAL_SERVICE_DATA                                                                       */
  /***************************************************************************************************************/

  PROCEDURE P_GET_RE_CHARGE_SPEC_SERV_G(P_MCC                      IN S_SS_ROAMING_GROUPS.SRG_COP_MCC_ID%TYPE,
                                        P_MNC                      IN S_SS_ROAMING_GROUPS.SRG_COP_MNC_ID%TYPE,
                                        P_SPECIAL_SERVICE_ID       IN S_SS_SPECIAL_SERVICE_PROFILE.SSP_SPECIAL_SERVICE_ID%TYPE,
                                        P_ASE_ACTION_SERVICE_ID    IN S_SS_ACTION_SPECIAL_SERVICE.ASE_ACTION_SERVICE_ID%TYPE,
                                        P_SSP_CLT_TYPE             IN S_SS_SPECIAL_SERVICE_PROFILE.SSP_CLT_TYPE%TYPE,
                                        P_CELLULAR_CBT_ID          IN S_CELLULARS.Clu_Cbt_Id%TYPE,
                                        P_SSP_EXCHANGE_RATE        IN OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_EXCHANGE_RATE%TYPE,
                                        P_CHARGE_VALUE_W_OUT_TAXES IN OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_CHARGE_VALUE_WITHOUT_TAXES%TYPE,
                                        P_CHARGE_VALUE_W_TAXES     IN OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_CHARGE_VALUE_WITH_TAXES%TYPE,
                                        POUT_SMS_ID                OUT VARCHAR2,
                                        POUT_ERROR_TEXT            OUT VARCHAR2,
                                        POUT_ERROR_CODE            OUT NUMBER);

  /***************************************************************************************************************/
  /* Busca la informacion correspondiente a la recompra                                                          */
  /*  dentro de P_GET_SPECIAL_SERVICE_DATA                                                                       */
  /***************************************************************************************************************/
  PROCEDURE P_GET_SPEC_SERV_PARAMETERS(P_SPECIAL_SERVICE_ID         IN S_SS_SPECIAL_SERVICE_PROFILE.SSP_SPECIAL_SERVICE_ID%TYPE,
                                       P_ACTION_SERVICE_ID          IN S_SS_ACTION_SPECIAL_SERVICE.ASE_ACTION_SERVICE_ID%TYPE,
                                       P_CATEGORY_REAL              IN S_CLIENT.Clt_Category%TYPE,
                                       P_TYPE_REAL                  IN S_CLIENT.Clt_Type%TYPE,
                                       P_CBT_ID_REAL                IN S_CELLULARS.Clu_Cbt_Id%TYPE,
                                       P_SSP_EXCHANGE_RATE          OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_EXCHANGE_RATE%TYPE,
                                       P_CHARGE_VALUE_W_OUT_TAXES   OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_CHARGE_VALUE_WITHOUT_TAXES%TYPE,
                                       P_CHARGE_VALUE_W_TAXES       OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_CHARGE_VALUE_WITH_TAXES%TYPE,
                                       P_SSP_LIMIT_AMOUNT_PER_CYCLE OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_LIMIT_AMOUNT_PER_CYCLE%TYPE,
                                       P_SSP_LIMIT_AMOUNT_PER_DAY   OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_LIMIT_AMOUNT_PER_DAY%TYPE,
                                       P_SSP_APPLIES_ROAMING_GROUPS OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_APPLIES_ROAMING_GROUPS%TYPE,
                                       P_SSP_CLT_TYPE               OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_CLT_TYPE%TYPE,
                                       P_SSP_CLT_CATEGORY           OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_CLT_CATEGORY%TYPE,
                                       POUT_SMS_ID                  OUT VARCHAR2,
                                       POUT_ERROR_TEXT              OUT VARCHAR2,
                                       POUT_ERROR_CODE              OUT NUMBER);

  /***************************************************************************************************************/
  /* identifica ti tiene cargo por roaming                                                                       */
  /***************************************************************************************************************/

  PROCEDURE P_EXCE_PAYMENT_ROAMING(P_MCC                      IN S_SS_ROAMING_GROUPS.SRG_COP_MCC_ID%TYPE,
                                   P_MNC                      IN S_SS_ROAMING_GROUPS.SRG_COP_MNC_ID%TYPE,
                                   P_SPECIAL_SERVICE_ID       IN S_SS_SPECIAL_SERVICE_PROFILE.SSP_SPECIAL_SERVICE_ID%TYPE,
                                   P_ASE_ACTION_SERVICE_ID    IN S_SS_ACTION_SPECIAL_SERVICE.ASE_ACTION_SERVICE_ID%TYPE,
                                   P_SSP_CLT_TYPE             IN S_SS_SPECIAL_SERVICE_PROFILE.SSP_CLT_TYPE%TYPE,
                                   P_SSP_CLT_CATEGORY         IN S_SS_SPECIAL_SERVICE_PROFILE.SSP_CLT_CATEGORY%TYPE,
                                   P_CELLULAR_CBT_ID          IN S_CELLULARS.Clu_Cbt_Id%TYPE,
                                   P_SSP_EXCHANGE_RATE        IN OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_EXCHANGE_RATE%TYPE,
                                   P_CHARGE_VALUE_W_OUT_TAXES IN OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_CHARGE_VALUE_WITHOUT_TAXES%TYPE,
                                   P_CHARGE_VALUE_W_TAXES     IN OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_CHARGE_VALUE_WITH_TAXES%TYPE,
                                   POUT_FIND_DATA             OUT VARCHAR2,
                                   POUT_SMS_ID                OUT VARCHAR2,
                                   POUT_ERROR_TEXT            OUT VARCHAR2,
                                   POUT_ERROR_CODE            OUT NUMBER);

  /**************************************************************************************************************/
  /* Obtiene y valida la cantidad de recompras hechas por la linea                                               */
  /***************************************************************************************************************/

  PROCEDURE P_VALIDATE_LIMIT_ACTION_SS(P_CELLULAR_NUMBER    IN S_CELLULARS.clu_cellular_number%TYPE,
                                       P_SPECIAL_SERVICE_ID IN S_SS_SPECIAL_SERVICE_PROFILE.ssp_special_service_id%TYPE,
                                       P_ACTION_SERVICE_ID  IN S_SS_ACTION_SPECIAL_SERVICE.ase_action_service_id%TYPE,
                                       P_LIMIT_AMOUNT_CYCLE IN S_SS_SPECIAL_SERVICE_PROFILE.ssp_limit_amount_per_cycle%TYPE,
                                       P_LIMIT_AMOUNT_DAY   IN S_SS_SPECIAL_SERVICE_PROFILE.ssp_limit_amount_per_day%TYPE,
                                       P_COUNT_LIMIT_DAY    OUT NUMBER,
                                       P_COUNT_LIMIT_CYCLE  OUT NUMBER,
                                       POUT_SMS_ID          OUT VARCHAR2,
                                       POUT_ERROR_TEXT      OUT VARCHAR2,
                                       POUT_ERROR_CODE      OUT NUMBER);

  /****************************************************************************************************************/
  /* Se utiliza para obtener el total del paquete contratado y de su recompra para lineas !CO                     */
  /****************************************************************************************************************/

  PROCEDURE P_GET_TN3_SIZE(P_CELLULAR_NUMBER    IN S_CELLULARS.clu_cellular_number%TYPE,
                           POUT_REPURCHASE_SIZE OUT S_SERVICE_PACK_PARAMETERS.sep_units_in%TYPE,
                           POUT_MAIN_SIZE       OUT S_SERVICE_PACK_PARAMETERS.sep_units_in%TYPE,
                           POUT_SMS_ID          OUT VARCHAR2,
                           POUT_ERROR_TEXT      OUT VARCHAR2,
                           POUT_ERROR_CODE      OUT NUMBER);

  /***************************************************************************************************************/
  /*Obtiene el Cliclo de la cuenta*/
  /***************************************************************************************************************/
  PROCEDURE P_GET_CYCLE_ACCOUNT(P_CELLULAR_NUMBER IN S_CELLULARS.clu_cellular_number%TYPE,
                                P_START_CYCLE     OUT DATE,
                                P_END_CYCLE       OUT DATE,
                                POUT_SMS_ID       OUT VARCHAR2,
                                POUT_ERROR_TEXT   OUT VARCHAR2,
                                POUT_ERROR_CODE   OUT NUMBER);

  /***************************************************************************************************************/
  /*Obtiene Las cantidad de acciones realizadas */
  /***************************************************************************************************************/
  PROCEDURE P_GET_COUNT_LIMIT_ACTION_SS(P_CELLULAR_NUMBER      IN S_CELLULARS.clu_cellular_number%TYPE,
                                        P_SPECIAL_SERVICE_ID   IN S_SS_SPECIAL_SERVICE_PROFILE.ssp_special_service_id%TYPE,
                                        P_ACTION_SERVICE_ID    IN S_SS_ACTION_SPECIAL_SERVICE.ase_action_service_id%TYPE,
                                        POUT_FIND_DATA         OUT VARCHAR2,
                                        POUT_ROWID             OUT ROWID,
                                        POUT_COUNT_LIMIT_DAY   OUT S_SS_COUNT_LIMIT_ACTION.cla_count_limit_day%TYPE,
                                        POUT_COUNT_LIMIT_CYCLE OUT S_SS_COUNT_LIMIT_ACTION.cla_count_limit_cycle%TYPE,
                                        POUT_LAST_ACTION_DATE  OUT S_SS_COUNT_LIMIT_ACTION.cla_last_action_date%TYPE,
                                        POUT_SIZE_BUYED        OUT VARCHAR2,
                                        POUT_UNIT_BUYED        OUT S_SS_COUNT_LIMIT_ACTION.cla_volume_unit%TYPE,
                                        POUT_DIA_HOY           OUT NUMBER,
                                        POUT_DIA_LAST_UPDATE   OUT NUMBER,
                                        POUT_SMS_ID            OUT VARCHAR2,
                                        POUT_ERROR_TEXT        OUT VARCHAR2,
                                        POUT_ERROR_CODE        OUT NUMBER);

  /**************************************************************************************************************/
  /* Obtiene y valida la cantidad de recompras hechas por la linea, mas el tamano de la ultima recompra realizada                                       */
  /***************************************************************************************************************/

  PROCEDURE P_LIMIT_ACTION_INFORMATION(P_CELLULAR_NUMBER    IN S_CELLULARS.clu_cellular_number%TYPE,
                                       P_SPECIAL_SERVICE_ID IN S_SS_SPECIAL_SERVICE_PROFILE.ssp_special_service_id%TYPE,
                                       P_ACTION_SERVICE_ID  IN S_SS_ACTION_SPECIAL_SERVICE.ase_action_service_id%TYPE,
                                       P_LIMIT_AMOUNT_CYCLE IN S_SS_SPECIAL_SERVICE_PROFILE.ssp_limit_amount_per_cycle%TYPE,
                                       P_LIMIT_AMOUNT_DAY   IN S_SS_SPECIAL_SERVICE_PROFILE.ssp_limit_amount_per_day%TYPE,
                                       P_COUNT_LIMIT_DAY    OUT NUMBER,
                                       P_COUNT_LIMIT_CYCLE  OUT NUMBER,
                                       P_SIZE_BUYED         OUT NUMBER,
                                       P_UNIT_BUYED         OUT VARCHAR2,
                                       POUT_SMS_ID          OUT VARCHAR2,
                                       POUT_ERROR_TEXT      OUT VARCHAR2,
                                       POUT_ERROR_CODE      OUT NUMBER);

  /**************************************************************************************************************/
  /* NUEVA FUNCION PARA OBTENER LAS OPCIONES DE RECOMPRA MULTIPLE*/
  /***************************************************************************************************************/

  PROCEDURE P_GET_SERVICE_DATA_MULT(P_CELLULAR_NUMBER            IN S_CELLULARS.CLU_CELLULAR_NUMBER%TYPE,
                                    P_CELLULAR_CATEGORY          IN S_CLIENT.Clt_Category%TYPE,
                                    P_CELLULAR_TYPE              IN S_CLIENT.Clt_Type%TYPE,
                                    P_CELLULAR_CBT_ID            IN S_CELLULARS.Clu_Cbt_Id%TYPE,
                                    P_CELLULAR_RPL_ID            IN S_RATE_PLANS.RPL_RPL_ID%TYPE,
                                    P_CELLULAR_RPL_RTY_ID        IN S_RATE_PLANS.RPL_RTY_ID%TYPE,
                                    P_MCC                        IN S_SS_ROAMING_GROUPS.SRG_COP_MCC_ID%TYPE,
                                    P_MNC                        IN S_SS_ROAMING_GROUPS.SRG_COP_MNC_ID%TYPE,
                                    P_TYPE_SERVICE_STR           IN S_SS_ACTION_SPECIAL_SERVICE.ase_type_of_service%TYPE, -- Siempre es DATOS
                                    P_KEYWORD                    IN VARCHAR2,
                                    P_CHANNEL                    IN VARCHAR2,
                                    P_SPECIAL_SERVICE_ID         OUT VARCHAR2,
                                    P_ACTION_SERVICE_ID          OUT VARCHAR2,
                                    P_SSP_EXCHANGE_RATE          OUT VARCHAR2,
                                    P_BUY_COST                   OUT VARCHAR2,
                                    P_SSP_LIMIT_AMOUNT_PER_CYCLE OUT VARCHAR2,
                                    P_SSP_LIMIT_AMOUNT_PER_DAY   OUT VARCHAR2,
                                    P_SSP_APPLIES_ROAMING_GROUPS OUT VARCHAR2,
                                    P_SSP_CAPACITY_OPTION_ID     OUT VARCHAR2,
                                    P_SSP_VOLUME                 OUT VARCHAR2,
                                    P_SSP_VOLUME_UNITY           OUT VARCHAR2,
                                    P_SSP_ORIGEN_CHANNEL         OUT VARCHAR2,
                                    POUT_SMS_ID                  OUT VARCHAR2,
                                    POUT_ERROR_TEXT              OUT VARCHAR2,
                                    POUT_ERROR_CODE              OUT NUMBER);

  /**************************************************************************************************************/
  /* NUEVA FUNCION PARA OBTENER LAS OPCIONES DE RECOMPRA MULTIPLE, SE CARGA EL CURSOR CON LA OPCIONES */
  /*  Y SE PROCESAN DEPENDIENDO SI TIENEN ROAMING O COTIZADAS EN DOLARES                                */
  /***************************************************************************************************************/

  PROCEDURE P_GET_SPEC_MULT(P_SPECIAL_SERVICE_ID         IN S_SS_SPECIAL_SERVICE_PROFILE.SSP_SPECIAL_SERVICE_ID%TYPE,
                            P_ACTION_SERVICE_ID          IN S_SS_ACTION_SPECIAL_SERVICE.ASE_ACTION_SERVICE_ID%TYPE,
                            P_CATEGORY_REAL              IN S_CLIENT.Clt_Category%TYPE,
                            P_TYPE_REAL                  IN S_CLIENT.Clt_Type%TYPE,
                            P_CBT_ID_REAL                IN S_CELLULARS.Clu_Cbt_Id%TYPE,
                            P_MCC                        IN VARCHAR2,
                            P_MNC                        IN VARCHAR2,
                            P_CHANNEL                    IN VARCHAR2,
                            P_SSP_EXCHANGE_RATE          OUT VARCHAR2,
                            P_BUY_COST                   OUT VARCHAR2,
                            P_SSP_LIMIT_AMOUNT_PER_CYCLE OUT VARCHAR2,
                            P_SSP_LIMIT_AMOUNT_PER_DAY   OUT VARCHAR2,
                            P_SSP_APPLIES_ROAMING_GROUPS OUT VARCHAR2,
                            P_SSP_CAPACITY_OPTION_ID     OUT VARCHAR2,
                            P_SSP_VOLUME                 OUT VARCHAR2,
                            P_SSP_VOLUME_UNITY           OUT VARCHAR2,
                            P_SSP_ORIGEN_CHANNEL         OUT VARCHAR2,
                            POUT_SMS_ID                  OUT VARCHAR2,
                            POUT_ERROR_TEXT              OUT VARCHAR2,
                            POUT_ERROR_CODE              OUT NUMBER);
  /**************************************************************************************************************/
  /* NUEVA FUNCION CONSULTA SI LA OPERACION ES DE ROAMING DE SER CORRECTO ACTUALIZA LOS MONTOS DEL MISMO   */
  /***************************************************************************************************************/

  PROCEDURE P_GET_RE_CHARGE_MULT(P_MCC                      IN S_SS_ROAMING_GROUPS.SRG_COP_MCC_ID%TYPE,
                                 P_MNC                      IN S_SS_ROAMING_GROUPS.SRG_COP_MNC_ID%TYPE,
                                 P_SPECIAL_SERVICE_ID       IN S_SS_SPECIAL_SERVICE_PROFILE.SSP_SPECIAL_SERVICE_ID%TYPE,
                                 P_ASE_ACTION_SERVICE_ID    IN S_SS_ACTION_SPECIAL_SERVICE.ASE_ACTION_SERVICE_ID%TYPE,
                                 P_SSP_CLT_TYPE             IN S_SS_SPECIAL_SERVICE_PROFILE.SSP_CLT_TYPE%TYPE,
                                 P_CELLULAR_CBT_ID          IN S_CELLULARS.Clu_Cbt_Id%TYPE,
                                 P_SSP_EXCHANGE_RATE        IN OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_EXCHANGE_RATE%TYPE,
                                 P_CHARGE_VALUE_W_OUT_TAXES IN OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_CHARGE_VALUE_WITHOUT_TAXES%TYPE,
                                 P_CHARGE_VALUE_W_TAXES     IN OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_CHARGE_VALUE_WITH_TAXES%TYPE,
                                 POUT_SMS_ID                OUT VARCHAR2,
                                 POUT_ERROR_TEXT            OUT VARCHAR2,
                                 POUT_ERROR_CODE            OUT NUMBER);

  /**************************************************************************************************************/
  /* SE MODIFICA EL PROCEDURE PARA QUE NO REALIZE LA VALIDACION CON LA STL_PARAMETERS YA QUE LA VALIDACION QUEDO OBSOLETA*/
  /***************************************************************************************************************/

  PROCEDURE P_INTERNET_WEB_NAMES_MULT(P_CELLULAR_NUMBER          IN S_CELLULARS.clu_cellular_number%TYPE,
                                      POUT_FEATURE_ID            OUT S_FEATURES.ftr_id%TYPE,
                                      POUT_PACKAGE_ID            OUT S_PACKAGES.pkt_id%TYPE,
                                      POUT_PACKAGE_CYCLIC        OUT S_PACKAGES.Pkt_Cyclic%TYPE,
                                      POUT_MAIN_QUOTA_NAME       OUT VW_AUT_FEATURES_ASSOCIATIONS.CUSTOM2%TYPE,
                                      POUT_DAILY_QUOTA_NAME      OUT VW_AUT_FEATURES_ASSOCIATIONS.CUSTOM7%TYPE,
                                      POUT_ADDITIONAL_QUOTA_NAME OUT VW_AUT_FEATURES_ASSOCIATIONS.CUSTOM10%TYPE,
                                      POUT_SMS_ID                OUT VARCHAR2,
                                      POUT_ERROR_TEXT            OUT VARCHAR2,
                                      POUT_ERROR_CODE            OUT NUMBER);
END PA_CONSUMPTION_INFORMATION;

/

