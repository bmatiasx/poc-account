create FUNCTION       F_LOGIN_AWC
  (   P_ACCOUNT      IN  VARCHAR2
    , P_PASSWORD     IN  VARCHAR2
    , P_PROFILE_USER OUT VARCHAR2
    , P_SEGMENT      OUT VARCHAR2
    , P_ERR_NUMBER   OUT NUMBER
    , P_ERR_MESSAGE  OUT VARCHAR2
  )
  RETURN NUMBER
IS
/**************************************************************************/
/*Descripci¿n: Funcion Login Autogestion Web Corporativo                  */
/*Parametros:  P_ACCOUNT   (IN): Id. de Cuenta                            */
/*             P_PASSWORD   (IN): Password de la cuenta                   */
/*             P_PROFILE_USER   (OUT): Perfil del usuario                 */
/*             P_SEGMENT   (OUT): Segmento al que pertenece               */
/*             P_ERR_NUMBER   (OUT): Numero de error                      */
/*             P_ERRMSG   (OUT): Mensaje de error                         */
/*Retorno:     0 = Exito, -1 = Fracaso, Otro valor = Error en la funci¿n. */
/***************************************************************************
   FECHA      VERSION   DESARROLLO         AUTOR
   -----      -------   ----------------    -----
  30/12/2014  1.0       PC111501_CD111868   NICOLAS FERRETTI
  04/10/2016  1.0       Wcorpo-2217         NICOLAS FERRETTI
  21/09/2018  1.4       CORPO-2034          ISAAC NASSAR
*/


  v_cloud        s_accounts.acc_aty_id%TYPE;
  v_fija         s_accounts.acc_abt_id%TYPE;
  v_active_lines s_accounts.acc_active_lines%TYPE;
  v_password     s_client.clt_password%TYPE;
  v_password_ok  VARCHAR2(1) := 'N';
  v_abt_fija     s_stl_parameters.stl_char_value%TYPE;
  v_lcpenc       s_stl_parameters.stl_char_value%TYPE;
  v_pasmax       s_stl_parameters.stl_value%TYPE;
  v_acprex       s_stl_parameters.stl_value%TYPE;
  v_acprat       s_stl_parameters.stl_value%TYPE;
  v_acprbk                s_stl_parameters.stl_value%TYPE;
  v_acpcld                s_stl_parameters.stl_value%TYPE;
  v_acpa                  s_stl_parameters.stl_value%TYPE;
  v_acprlk                s_stl_parameters.stl_value%TYPE;
  v_acpfij                s_stl_parameters.stl_value%TYPE;
  v_acp_prf_id            account_profiles.acp_prf_id%TYPE;
  v_acp_pass_last_updated NUMBER;
  v_acp_try_failed        account_profiles.acp_try_failed%TYPE;
  v_account_transaction   NUMBER;
  v_err_transaction       NUMBER;
  v_err_msg_transaction VARCHAR2(250);


  FUNCTION f_properties(p_filter IN VARCHAR2)
    RETURN VARCHAR2
  AS
    str_sql   VARCHAR2(255);
    parameter s_stl_parameters.stl_value%TYPE;
    BEGIN
      str_sql := 'SELECT STL_VALUE FROM S_STL_PARAMETERS WHERE STL_ID = :STL_ID';
      EXECUTE IMMEDIATE str_sql INTO parameter USING p_filter;
      RETURN parameter;
      EXCEPTION WHEN NO_DATA_FOUND
      THEN
        RAISE_APPLICATION_ERROR(-20001, 'Error al consultar la tabla S_STL_PARAMETERS por parametro ' || p_filter);
    END f_properties;
  BEGIN

    /******************* Inicializo variables *************************/
    -- obtengo perfil de cuenta tipo A
    v_acpa := f_properties('ACPA');

    --   obtengo perfil de password expirado
    v_acprex := f_properties('ACPREX');

    -- obtengo perfil de activacion
    v_acprat := f_properties('ACPRAT');

    -- obtengo perfil de usuario locked
    v_acprbk := f_properties('ACPRBK');

    -- obtengo perfil CLOUD
    v_acpcld := f_properties('ACPCLD');

    --obtengo la cantidad de dias de expiracion de contrase¿a
    v_pasmax := f_properties('PASMAX');

    --obtiene perfil de bloqueo
    v_acprlk := f_properties('ACPRLK');

    --obtiene perfil de FIJA
    v_acpfij := f_properties('ACPFIJ');

    /******************* Comienza proceso *************************/

    -- Valida si la cuenta existe.
    BEGIN
      SELECT
        acc_aty_id,
        acc_active_lines,
        acc_abt_id
      INTO v_cloud, v_active_lines, v_fija
      FROM s_accounts
      WHERE acc_id = p_account;

      -- Recupero los Tipos de negocio para las Cuentas Fijas Puras
      SELECT stl_char_value
      INTO v_abt_fija
      FROM s_stl_parameters
      WHERE stl_id = 'FIJPUR';

      --Si no es cloud y no tiene lineas activas
      IF v_cloud <> 'AS' AND v_active_lines < 1
      THEN
        p_err_message := 'LA CUENTA NO POSEE LINEAS ACTIVAS.';
        p_err_number := -20020;
        RETURN 1;
      END IF;

      EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
        p_err_message := 'LA CUENTA NO EXISTE.';
        p_err_number := -20021;
        RETURN 1;
    END;

    BEGIN
      -- Obtengo semilla de encriptacion
      SELECT stl_char_value
      INTO v_lcpenc
      FROM s_stl_parameters
      WHERE stl_id = 'LCPENC';

      -- Encripta contrase¿a
      v_password := pa_crypto.encriptar3des@prod(p_password, v_lcpenc);

      -- Valida si la contrase¿a pertenece a la cuenta y obtengo segmento
      SELECT
        'Y',
        clt_type
      INTO v_password_ok, p_segment
      FROM s_client, s_accounts
      WHERE clt_id = acc_clt_id
            AND acc_id = p_account
            AND clt_password = v_password
            AND clt_category = 'C';

      EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
        v_password_ok := 'N';
        p_err_message := 'PASSWORD INCORRECTO.';
        p_err_number := -20022;
    END;

    BEGIN
      -- Valida si la cuenta ya habia ingresado
      SELECT acp_prf_id
      INTO v_acp_prf_id
      FROM account_profiles
      WHERE acp_acc_id = p_account;

      --SE AGREGA VALIDACION PARA CORRECCION DE CUENTAS TIPO A
      IF v_cloud = 'A' AND v_acp_prf_id <> v_acpa AND v_acp_prf_id <> v_acprlk
      THEN
        UPDATE ACCOUNT_PROFILES
        SET acp_prf_id = v_acpa
        WHERE acp_acc_id = p_account;
        v_acp_prf_id := v_acpa;
      END IF;

      --SE AGREGA VALIDACI¿N PARA CORRECCI¿N DE CUENTAS CLOUD
      IF v_cloud = 'AS' AND v_acp_prf_id <> v_acpcld AND v_acp_prf_id <> v_acprlk
      THEN
        UPDATE ACCOUNT_PROFILES
        SET acp_prf_id = v_acpcld
        WHERE acp_acc_id = p_account;
        v_acp_prf_id := v_acpcld;
      END IF;

      --SE AGREGA VALIDACI¿N PARA CORRECCI¿N DE CUENTAS FIJAS
      IF INSTR(v_abt_fija, v_fija || '##') > 0 AND v_acp_prf_id <> v_acpfij
      THEN
        UPDATE ACCOUNT_PROFILES
        SET acp_prf_id = v_acpfij
        WHERE acp_acc_id = p_account;
        v_acp_prf_id := v_acpfij;
      END IF;

      EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
        -- Si no existe registro en la account_profile (por que nunca ingreso)

        IF v_cloud = 'AS'
        THEN
          --se cambia a perfil v_acpcld. antes v_acprat
          INSERT INTO account_profiles (acp_id, acp_acc_id, acp_prf_id, acp_start_date, acp_end_date, acp_try_failed, acp_pass_last_updated, acp_prf_hst)
          VALUES (seq_acp_id.NEXTVAL, p_account, v_acpcld, SYSDATE, NULL, 0, SYSDATE, 'C'); --ACA PONER CINCO
          v_acp_prf_id := v_acpcld;
        ELSIF INSTR(v_abt_fija, v_fija || '##') > 0
          THEN
            INSERT INTO account_profiles (acp_id, acp_acc_id, acp_prf_id, acp_start_date, acp_end_date, acp_try_failed, acp_pass_last_updated, acp_prf_hst)
            VALUES (seq_acp_id.NEXTVAL, p_account, v_acpa, SYSDATE, NULL, 0, SYSDATE, 'C');
            v_acp_prf_id := v_acpa;
        ELSIF v_cloud = 'A'
          THEN
            INSERT INTO ACCOUNT_PROFILES (ACP_ID, ACP_ACC_ID, ACP_PRF_ID, ACP_START_DATE, ACP_END_DATE, ACP_TRY_FAILED, ACP_PASS_LAST_UPDATED, ACP_PRF_HST)
            VALUES (SEQ_ACP_ID.nextval, P_ACCOUNT, v_acpcld, SYSDATE, NULL, 0, SYSDATE, 'C');
            v_acp_prf_id := v_acpa;
        ELSE
          INSERT INTO account_profiles (acp_id, acp_acc_id, acp_prf_id, acp_start_date, acp_end_date, acp_try_failed, acp_pass_last_updated)
          VALUES (seq_acp_id.NEXTVAL, p_account, v_acprat, SYSDATE, NULL, 0, SYSDATE);
          v_acp_prf_id := v_acprat;
        END IF;
    END;

    -- Si la contrase¿a es correcta
    IF v_password_ok = 'Y'
    THEN

      IF v_acp_prf_id = v_acprlk
      THEN
        p_err_message := 'LA CUENTA SE ENCUENTRA BLOQUEADA.';
        p_err_number := -20030;
        RETURN 1;
      END IF;

      BEGIN
        -- Obtiene el perfil de usuario
        SELECT prf_user
        INTO p_profile_user
        FROM profiles
        WHERE prf_id = v_acp_prf_id;
        EXCEPTION
        WHEN OTHERS
        THEN
          p_err_number := -20040;
          p_err_message := 'ERROR AL CONSULTAR LA TABLA PROFILES ';
      END;

    -- Si el password no es correcto
    ELSE
      -- Actualiza la cantidad de intentos fallidos
      UPDATE account_profiles
      SET acp_try_failed = acp_try_failed + 1
      WHERE acp_acc_id = p_account;

      BEGIN
        -- Recupera la cantidad fallido de la cuenta
        SELECT acp_try_failed
        INTO v_acp_try_failed
        FROM account_profiles
        WHERE acp_acc_id = p_account;
        EXCEPTION
        WHEN OTHERS
        THEN
          p_err_number := -20050;
          p_err_message := 'ERROR AL CONSULTAR LA TABLA ACCOUNT_PROFILES ';
      END;

      -- Obtiene la cantidad de intentos fallidos maximos permitidos y los compara con la cantidad de intentos fallidos de la cuenta
      IF f_properties('ACMXTF') = v_acp_try_failed
      THEN
        -- Actualiza el perfil a bloqueo y el historial de la tabla ACCOUNT_PROFILES
        UPDATE ACCOUNT_PROFILES
        SET acp_prf_id = v_acprlk, acp_prf_hst = DECODE(v_acp_prf_id, v_acprbk, 'N', v_acprat, '', v_acpcld, 'C', 'Y')
        WHERE acp_acc_id = p_account;
        v_acp_prf_id := v_acprex;

        -- Obtiene perfil de usuario bloqueado
        BEGIN
          SELECT prf_user
          INTO p_profile_user
          FROM profiles
          WHERE prf_id = v_acprlk;

          p_err_number := -20060;
          RETURN 1;
          EXCEPTION
          WHEN OTHERS
          THEN
            p_err_number := -20070;
            p_err_message := 'ERROR AL CONSULTAR LA TABLA PROFILES ';
        END;
      END IF;

      p_err_number := -20080;
      RETURN 1;
    END IF;

    -- Actualiza los intentos fallidos
    UPDATE account_profiles
    SET acp_try_failed = 0
    WHERE acp_acc_id = p_account;

    -- Registra un log de transaccion
    BEGIN
      v_account_transaction := f_insert_account_transactions(p_acc_id => p_account,
                                                             p_tra_id => '2015',
                                                             p_parameters => '',
                                                             p_message => 'Ingreso a la Autogesti¿n',
                                                             p_tck_id => '',
                                                             p_status => 'O',
                                                             p_start_date => sysdate,
                                                             p_delimiter => '',
                                                             p_err_number => v_err_transaction,
                                                             p_err_message => v_err_msg_transaction);
      EXCEPTION
      WHEN OTHERS
      THEN
        p_err_number := -20090;
        p_err_message := 'ERROR AL REGISTRAR EN EL LOG DE TRANSACCIONES ';
    END;

    RETURN 0;

    EXCEPTION
    WHEN OTHERS
    THEN
      p_err_number := -20100;
      p_err_message := sqlerrm;
      RETURN 1;
  END f_login_awc;
/

