create materialized view S_RATE_PLAN_CLIENT_CLASS
refresh complete on demand
  as
    SELECT apc_rpl_id,
apc_ccl_id,
apc_start_date,
apc_end_date
FROM STL.rate_plan_client_class@PROD
  WHERE apc_start_date <  GET_DATE
AND NVL(apc_end_date,GET_DATE+1) > GET_DATE

/

