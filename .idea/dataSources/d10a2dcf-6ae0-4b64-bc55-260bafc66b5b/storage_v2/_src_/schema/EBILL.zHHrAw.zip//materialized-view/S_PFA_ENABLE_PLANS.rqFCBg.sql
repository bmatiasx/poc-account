create materialized view S_PFA_ENABLE_PLANS
refresh complete on demand
  as
    SELECT pep_rpl_source,
  pep_rpl_destiny,
  pep_start_date,
  pep_end_date,
  pep_user,
  pep_message,
  pep_antiq,
  pep_antiq_hasta,
  pep_recarga,
  pep_periodo
FROM STL.pfa_enable_plans@PROD
  WHERE pep_start_date <  GET_DATE
AND NVL(pep_end_date,GET_DATE+1) > GET_DATE

/

