create materialized view GET_AUTOSTOPINFO
refresh force on demand
  as
    SELECT aut_id, aut_description, aut_stop_flag
FROM autostop_types@prod
 
/

