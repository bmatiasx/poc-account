create materialized view S_STL_PARAMETERS
refresh force on demand
  as
    SELECT stl_id,
stl_start_date,
stl_description,
stl_value,
stl_end_date,
stl_char_value
FROM stl.stl_parameters@PROD
/

