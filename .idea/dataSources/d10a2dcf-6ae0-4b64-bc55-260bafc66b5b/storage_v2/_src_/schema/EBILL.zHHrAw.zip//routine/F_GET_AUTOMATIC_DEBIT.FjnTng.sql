create FUNCTION F_GET_AUTOMATIC_DEBIT
 (P_CLU_CELLULAR_NUMBER IN VARCHAR2
 ,P_ACC_ID IN VARCHAR2
 ,P_BIM_NUMBER OUT VARCHAR2
 ,P_TIPO_DEBITO OUT VARCHAR2
 ,P_START_DATE OUT DATE
 ,P_INFO_BIM_NUMBER OUT VARCHAR
 ,P_ENTITY OUT VARCHAR2
 ,P_ERR_NUMBER OUT NUMBER
 ,P_ERR_MESSAGE OUT VARCHAR2
 )
 RETURN NUMERIC
 IS
v_return NUMBER;
BEGIN
    
    v_return := PA_IVR_COB.consulta_debito_automatico(p_clu_cellular_number,
                                               p_bim_number,
                                               p_tipo_debito,
                                               p_err_message);

  IF v_return = 0 THEN
    BEGIN
      SELECT  bim_start_Date,
              pkg_prince_funci.t_card_number_format(bim_coe_id, pkg_prince_funci.t_desencriptar(bim_number)),
              coe_name                                     
      INTO    p_start_date,
              p_info_bim_number,
              p_entity
      FROM    billing_methods, 
              collection_entities
      WHERE   bim_acc_id = p_acc_id
      AND     SYSDATE BETWEEN bim_start_date AND NVL(bim_end_date, SYSDATE)
      AND     bim_coe_cet_id IN('V', 'D')
      AND     bim_coe_id = coe_id
      AND     bim_coe_cet_id = coe_cet_id;

      RETURN 0;
    EXCEPTION
      WHEN no_data_found THEN
        p_err_number := SQLERRM;
        p_err_message := 'No existe la cuenta en billing_methods';
        RETURN - 1;
      WHEN OTHERS THEN
        p_err_number := SQLERRM;
        p_err_message := SQLCODE;
        RETURN - 1;
    END;
  ELSIF V_RETURN = 1 THEN
    RETURN V_RETURN;
  ELSE
    RETURN -1;
  END IF;
EXCEPTION
  WHEN OTHERS THEN
        p_err_number := SQLERRM;
        P_ERR_MESSAGE := SQLCODE;
        RETURN - 1;
END;
/

