create materialized view S_SWP_FEATURE_SERVICES1
refresh force on demand
  as
    SELECT sfs_crm_service,
sfs_description,
sfs_start_date,
sfs_end_date,
sfs_ftr_id,
sfs_cbt_id,
sfs_service,
sfs_separator,
sfs_technology,
sfs_rsn_id,
sfs_status
FROM SWP_FEATURE_SERVICES@PROD
/

