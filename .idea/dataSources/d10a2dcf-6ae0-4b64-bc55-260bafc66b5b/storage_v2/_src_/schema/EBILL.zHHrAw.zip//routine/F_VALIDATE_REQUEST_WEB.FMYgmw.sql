create FUNCTION F_VALIDATE_REQUEST_WEB
 (P_CLT_ID IN VARCHAR2
 ,P_ACC_ID IN VARCHAR2
 ,P_CELLULAR_REQUEST IN VARCHAR2 := 'NULL'
 ,P_OPERATION_CODE IN VARCHAR2
 ,P_OPERATION_ID OUT VARCHAR2
 ,P_FLAG_CTA OUT VARCHAR2
 ,P_MODALIDAD_PIN OUT VARCHAR2
 ,P_MESSAGE OUT VARCHAR2
 ,P_ERR_NUMBER OUT NUMBER
 ,P_ERR_MSG OUT VARCHAR2
 )
 RETURN NUMBER
 IS
V_RESULT    NUMBER;
BEGIN

    V_RESULT := PA_OPERATION_CODE.f_validate_request_web(p_clt_id => p_clt_id,
                                                         p_acc_id => p_acc_id,
                                                         p_cellular_request => p_cellular_request,
                                                         p_operation_code => p_operation_code,
                                                         p_operation_id => p_operation_id,
                                                         p_flag_cta => p_flag_cta,
                                                         p_modalidad_pin => p_modalidad_pin,
                                                         p_message => p_message,
                                                         p_err_number => p_err_number,
                                                         p_err_msg => p_err_msg);

    IF V_RESULT <> 0 THEN
      RETURN V_RESULT;
    END IF;


  RETURN 0;


EXCEPTION
  WHEN OTHERS THEN
    P_ERR_NUMBER := -1001;
    p_err_msg := 'Error al ejecutar la función';
    RETURN - 1;
END;
/

