create PACKAGE WS_AG_STH_IFACES IS

TYPE Refcur IS REF CURSOR;
  --****************************
  PROCEDURE Getprovincias(P_cursor  OUT Refcur,
                          P_id_pais IN VARCHAR2 DEFAULT 'PY',
                          P_error   OUT VARCHAR2);
  --****************************
  PROCEDURE Getlocalidades(P_cursor       OUT Refcur,
                           P_id_provincia IN VARCHAR2,
                           P_error        OUT VARCHAR2);
  --****************************
  PROCEDURE Getcontratistas(P_cursor OUT Refcur, P_error OUT VARCHAR2);
  --****************************
  PROCEDURE Get_detalle_sds(P_id_sds           NUMBER,
                            P_cellular_number  OUT VARCHAR2,
                            P_ent_id           OUT NUMBER,
                            P_status_sds       OUT VARCHAR2, --A Asigna, otra letra desasigna
                            P_id_localidad     OUT NUMBER,
                            P_type_sds         OUT VARCHAR2,
                            P_id_provincia     OUT VARCHAR2,
                            P_calle            OUT VARCHAR2,
                            P_nro              OUT VARCHAR2,
                            P_torre            OUT VARCHAR2, --CFI-23
                            P_piso             OUT VARCHAR2,
                            P_dpto             OUT VARCHAR2,
                            P_cp               OUT VARCHAR2,
                            P_cliente          OUT VARCHAR2,
                            P_cuenta           OUT VARCHAR2,
                            P_id_cliente       OUT NUMBER,
                            P_observaciones    OUT VARCHAR2,
                            P_entre_calles     OUT VARCHAR2, --CFI-23
                            P_scard            OUT VARCHAR2,
                            P_scard_number     OUT VARCHAR2,
                            P_deco             OUT VARCHAR2,
                            P_deco_number      OUT VARCHAR2,
                            p_dni_number       OUT VARCHAR2,
                            p_type_dni         OUT VARCHAR2,
                            p_tel_contacto     OUT VARCHAR2,
                            p_REASON_START     OUT VARCHAR2,
                            P_REASON_FINISH    OUT VARCHAR2,
                            p_ASD_TCK_ID       OUT NUMBER,
                            p_ASD_SWF_ID       OUT NUMBER,
                            p_REASON_INTERRUPT OUT VARCHAR2, --ultimo motivo de interrupcion
                            p_reason_closed    OUT VARCHAR2,
                            p_provincia        OUT VARCHAR2,
                            p_departamento     OUT VARCHAR2, --CFI-23
                            p_localidad        OUT VARCHAR2,
                            P_err_number       OUT NUMBER,
                            p_technology       OUT VARCHAR2,
                            p_rate_plan_des    OUT VARCHAR2,
                            P_docu_tipo        NUMBER := NULL,
                            P_docu_tipo_nro    NUMBER := NULL,
                            p_usr_id           OUT varchar2,
                            P_err_message      OUT VARCHAR2,
                            p_segmento         OUT VARCHAR2,
                            p_form_number      OUT VARCHAR2,
                            p_obs_tck          OUT VARCHAR2, --PC91707
                            p_dir_lat          OUT NUMBER, --PC91707
                            p_dir_long         OUT NUMBER, --PC91707
                            p_ent_asig         OUT NUMBER, --PC91707
                            p_instalador       OUT NUMBER, --PC91707
                            p_tecnico          OUT NUMBER, --PC91707
                            p_asing_date       OUT DATE, --PC91707
                            p_inst_date        OUT DATE, --PC91707
                            p_vitec_date       OUT DATE, --PC91707
                            p_inst_warranty    OUT VARCHAR2, --PC91707
                            p_tec_warranty     OUT VARCHAR2, --PC91707
                            p_have_det         OUT VARCHAR2, --PC123967
                            p_int_prev         OUT VARCHAR2, --CFI-11
                            p_cant_tv          OUT NUMBER, --CFI-11
                            p_create_date      OUT DATE --CFI-11
                            );
  --****************************
  PROCEDURE Change_status_sds(P_SDS_ID          NUMBER,
                              P_STATUS          VARCHAR2,
                              P_USER            VARCHAR2,
                              P_OBSERVATION     VARCHAR2,
                              P_ID_CONTRATISTA  NUMBER := NULL,
                              P_SCHEDULE_DATE   DATE := NULL,
                              P_REASON_FINISH   VARCHAR2 := NULL,
                              p_REASON_STATE_ID VARCHAR2 := NULL, --Motivo cambio de estado
                              p_TYPE_SDS        VARCHAR2 := NULL, --Tipo de Tramite
                              P_ERR_NUMBER      OUT NUMBER,
                              P_ERR_MESSAGE     OUT VARCHAR2,
                              P_RESULT          OUT NUMBER);
  --****************************
  PROCEDURE Getsdssactives(P_cursor         OUT Refcur,
                           P_docu_tipo      NUMBER := NULL,
                           P_docu_tipo_nro  NUMBER := NULL,
                           P_id_contratista NUMBER,
                           p_technology_Id  VARCHAR2 := NULL,
                           p_REASON_ID      VARCHAR2 := NULL,
                           P_operacion_id   VARCHAR2 := NULL,
                           P_estado_id      VARCHAR2 := NULL,
                           p_without_reason VARCHAR2 := NULL,
                           P_error          OUT VARCHAR2,
                           p_segmento       VARCHAR2 := null); --RESIDENCIAL, PYME, CORPORATIVO
  --****************************
  PROCEDURE Getsdssfordiary(P_cursor        OUT Refcur,
                            P_docu_tipo     NUMBER := NULL,
                            P_docu_tipo_nro NUMBER := NULL,
                            P_operacion_id  VARCHAR2 := NULL, --'INST','VITEC'
                            P_estado_id     VARCHAR2 := NULL, --'D,C,A,S..'
                            p_reason_id     IN VARCHAR2 := NULL,
                            P_linea_dth     IN VARCHAR2,
                            P_fecha_desde   IN DATE,
                            P_fecha_hasta   IN DATE,
                            P_error         OUT VARCHAR2,
                            P_segmento      VARCHAR2 := null);
  -- ********************************
  PROCEDURE Getstatusdesc(P_cursor OUT Refcur,
                          P_aplic  IN VARCHAR2,
                          P_error  OUT VARCHAR2);
  -- ********************************
  PROCEDURE Getsdstype(P_APLIC_VIEW IN VARCHAR2,
                       P_cursor     OUT Refcur,
                       P_error      OUT VARCHAR2);
  -- ********************************
  PROCEDURE Getreason_state(P_cursor   OUT Refcur,
                            P_STATE    IN VARCHAR2 := NULL,
                            p_rsn_type IN VARCHAR2 := NULL,
                            P_error    OUT VARCHAR2);
  -- ********************************
  PROCEDURE Udpreason_state(P_cursor      OUT Refcur,
                            p_reason_id   IN VARCHAR2 := NULL,
                            p_description IN VARCHAR2 := NULL,
                            P_error       OUT VARCHAR2);
  PROCEDURE geTtecnologias(P_cursor OUT Refcur, P_error OUT VARCHAR2);
  PROCEDURE Set_AsignarA(p_sds_id IN NUMBER,
                         p_usr_id IN VARCHAR2,
                         P_error  OUT VARCHAR2);
  PROCEDURE GetSegmento(P_cursor OUT Refcur, P_error OUT VARCHAR2);
  --PC101555
  PROCEDURE get_last_reason(p_sds_id      IN NUMBER,
                            p_reason_id   OUT VARCHAR2,
                            p_reason      OUT VARCHAR2,
                            p_reason_type OUT VARCHAR2,
                            p_error       OUT VARCHAR2);
  --FINPC101555
  --INICIO PC110203
  procedure abm_reason(p_reason_id    in varchar2 := null,
                       p_descripcion  in varchar2 := null,
                       p_type         in varchar2 := null,
                       p_rss_update   in varchar2 := null,
                       p_rss_permited in varchar2 := null,
                       p_modo         in varchar2, /*a=alta,b=baja, m=modificacion*/
                       p_rsn_id_out   out varchar2,
                       p_error        out varchar2);
  PROCEDURE ab_interruption_closed_reasons(p_reason_id  IN VARCHAR2,
                                           p_state      IN VARCHAR2,
                                           p_start_date IN DATE := SYSDATE,
                                           p_end_date   IN DATE := NULL,
                                           p_ot_type    IN VARCHAR2 := NULL,
                                           p_state_next IN VARCHAR2,
                                           p_cbt_id     IN VARCHAR2,
                                           p_enabled    IN VARCHAR2 := 'Y',
                                           p_modo       IN VARCHAR2, /*A=ALTA,B=BAJA*/
                                           p_error      OUT VARCHAR2);
  --FIN PC110203
  --INICIO PC121204
  PROCEDURE getreason_state_full(p_cursor     OUT refcur,
                                 p_state      IN VARCHAR2 := NULL, --Estado inicial que filtra los motivos
                                 p_rsn_type   IN VARCHAR2 := NULL, --Tipo de los motivos (I=Interrupcion, C=Cierre)
                                 p_reasons_id IN VARCHAR2 := NULL, --IdMotivo
                                 p_tipo_ot    IN VARCHAR2 := NULL, --Tipo de Tramite asociada a los motivos
                                 p_cbt_id     IN VARCHAR2 := NULL, --Tipo de Negocio asociada a los motivos
                                 p_error      OUT VARCHAR2);
  --FIN PC121204
  --INICIO PC123967
  PROCEDURE getdetalle_OT(p_ot_id  IN NUMBER,
                          P_cursor OUT Refcur,
                          p_error  OUT VARCHAR2);
  --FIN PC123967
  --INICIO PC136134
  PROCEDURE change_equipment(P_OT_ID       NUMBER,
                             P_RSN_ID      VARCHAR2,
                             P_ERR_NUMBER  OUT NUMBER,
                             P_ERR_MESSAGE OUT VARCHAR);
  --FIN PC136134
  --CFI-360
 --****************************
  PROCEDURE getsdssfordiary_2(P_cursor        OUT refcur,
                            P_docu_tipo     NUMBER := NULL,
                            P_docu_tipo_nro NUMBER := NULL,
                            P_operacion_id  VARCHAR2 := NULL, --'INST','VITEC'
                            P_estado_id     VARCHAR2 := NULL, --'D,C,A,S..'
                            p_reason_id     IN VARCHAR2 := NULL,
                            P_linea_dth     IN VARCHAR2,
                            P_fecha_desde   IN DATE,
                            P_fecha_hasta   IN DATE,
                            P_error         OUT VARCHAR2,
                            P_segmento      VARCHAR2 := null);

 --****************************
  PROCEDURE Getsdssactives_2(P_cursor         OUT Refcur,
                           P_docu_tipo      NUMBER := NULL,
                           P_docu_tipo_nro  NUMBER := NULL,
                           P_id_contratista NUMBER,
                           p_technology_Id  VARCHAR2 := NULL,
                           p_REASON_ID      VARCHAR2 := NULL,
                           P_operacion_id   VARCHAR2 := NULL,
                           P_estado_id      VARCHAR2 := NULL,
                           p_without_reason VARCHAR2 := NULL,
                           P_error          OUT VARCHAR2,
                           p_segmento       VARCHAR2 := null); --RESIDENCIAL, PYME, CORPORATIVO


   --****************************
  PROCEDURE Get_detalle_sds_2(P_id_sds           NUMBER,
                            P_cellular_number  OUT VARCHAR2,
                            P_ent_id           OUT NUMBER,
                            P_status_sds       OUT VARCHAR2, --A Asigna, otra letra desasigna
                            P_id_localidad     OUT NUMBER,
                            P_type_sds         OUT VARCHAR2,
                            P_id_provincia     OUT VARCHAR2,
                            P_calle            OUT VARCHAR2,
                            P_nro              OUT VARCHAR2,
                            P_torre            OUT VARCHAR2, --CFI-23
                            P_piso             OUT VARCHAR2,
                            P_dpto             OUT VARCHAR2,
                            P_cp               OUT VARCHAR2,
                            P_cliente          OUT VARCHAR2,
                            P_cuenta           OUT VARCHAR2,
                            P_id_cliente       OUT NUMBER,
                            P_observaciones    OUT VARCHAR2,
                            P_entre_calles     OUT VARCHAR2, --CFI-23
                            p_REASON_START     OUT VARCHAR2,
                            P_REASON_FINISH    OUT VARCHAR2,
                            p_ASD_TCK_ID       OUT NUMBER,
                            p_REASON_INTERRUPT OUT VARCHAR2, --ultimo motivo de interrupcion
                            p_reason_closed    OUT VARCHAR2,
                            p_provincia        OUT VARCHAR2,
                            p_departamento     OUT VARCHAR2, --CFI-23
                            p_localidad        OUT VARCHAR2,
                            P_err_number       OUT NUMBER,
                            p_technology       OUT VARCHAR2,
                            p_rate_plan_des    OUT VARCHAR2,
                            P_err_message      OUT VARCHAR2,
                            p_segmento         OUT VARCHAR2,
                            p_form_number      OUT VARCHAR2,
                            p_obs_tck          OUT VARCHAR2, --PC91707
                            p_instalador       OUT NUMBER, --PC91707
                            p_have_det         OUT VARCHAR2, --PC123967
                            p_int_prev         OUT VARCHAR2, --CFI-11
                            p_cant_tv          OUT NUMBER, --CFI-11
                            p_create_date      OUT DATE --CFI-11
                            );
  --CFI-360
END WS_AG_STH_IFACES;
/

