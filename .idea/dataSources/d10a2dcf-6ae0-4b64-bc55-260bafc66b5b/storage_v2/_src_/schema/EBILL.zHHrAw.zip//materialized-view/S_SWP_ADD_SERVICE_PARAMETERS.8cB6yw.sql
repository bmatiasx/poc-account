create materialized view S_SWP_ADD_SERVICE_PARAMETERS
refresh force on demand
  as
    SELECT asp_service,
asp_ne_service,
asp_param_name,
asp_param_value,
asp_additional_data
FROM SWP_ADD_SERVICE_PARAMETERS@PROD
 
/

