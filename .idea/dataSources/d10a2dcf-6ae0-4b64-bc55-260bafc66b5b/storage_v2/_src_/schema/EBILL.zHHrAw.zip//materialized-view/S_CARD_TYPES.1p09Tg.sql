create materialized view S_CARD_TYPES
refresh force on demand
  as
    SELECT cty_id, cty_nominal_value, cty_last_serial_number, cty_description, cty_last_pba_id,         cty_ccl_id, cty_min_stock, cty_pba_size, cty_sys_code_id, cty_start_date, cty_end_date,
cty_initial_charge, cty_journal_flag, cty_replace_flag, cty_ctm_id, cty_first_tpp_flag,       cty_general_tpp_flag, cty_pfa_flag
from card_types@ccard


/

