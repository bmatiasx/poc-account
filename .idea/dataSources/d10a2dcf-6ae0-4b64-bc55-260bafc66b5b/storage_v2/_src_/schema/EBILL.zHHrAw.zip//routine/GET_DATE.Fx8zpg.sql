create FUNCTION GET_DATE

 RETURN DATE DETERMINISTIC
 IS
begin

return sysdate;

end;
/

