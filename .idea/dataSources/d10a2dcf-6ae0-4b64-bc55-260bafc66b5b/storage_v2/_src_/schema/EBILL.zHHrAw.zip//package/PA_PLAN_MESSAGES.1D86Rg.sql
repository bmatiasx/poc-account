create PACKAGE PA_PLAN_MESSAGES IS
  FUNCTION F_GET_MGE_PLAN_PAYMENT(P_CELLULAR_NUMBER    IN VARCHAR2,
                                  P_CBT_ID             IN VARCHAR2 DEFAULT NULL,
                                  P_CANAL              IN VARCHAR2 DEFAULT NULL,
                                  P_CALC_UNID_INTERNET IN NUMBER,
                                  P_FUNC_ON_OFF        IN VARCHAR2 DEFAULT NULL,
                                  P_SALIDA             OUT VARCHAR2,
                                  P_CICLO_CORTE_1      OUT INTEGER,
                                  P_P                  OUT VARCHAR2,
                                  P_X                  OUT VARCHAR2,
                                  P_S                  OUT VARCHAR2,
                                  P_Y                  OUT VARCHAR2,
                                  P_UNIDAD             OUT VARCHAR2,
                                  P_INTERNET_ILIMITADO OUT INTEGER,
                                  P_D                  OUT VARCHAR2,
                                  P_A                  OUT VARCHAR2,
                                  P_ERROR_NUMBER       OUT NUMBER,
                                  P_ERROR_MESSAGE      OUT VARCHAR2)
    RETURN NUMBER;
END PA_PLAN_MESSAGES;
/

