create materialized view S_PERIODS
refresh complete on demand
  as
    SELECT "PERIODS"."PER_ID", 
       "PERIODS"."PER_DESCRIPTION",
       "PERIODS"."PER_INC_UNIT"
  FROM "TEST"."PERIODS"@PROD.WORLD "PERIODS"
/

