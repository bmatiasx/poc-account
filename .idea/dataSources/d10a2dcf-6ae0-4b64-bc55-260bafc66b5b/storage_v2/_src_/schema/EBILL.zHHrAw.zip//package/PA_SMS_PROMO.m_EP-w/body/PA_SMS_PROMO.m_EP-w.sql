create PACKAGE BODY       PA_SMS_PROMO
IS
-------------------------------------------------------------------------------
-- Procesa Mensajes SMS para las distintas aplicaciones SMS
-- PUBLIC
-- PARAMS:
--    p_cellular_number : Identificacion del cellular
--    p_message : mensaje enviado desde el handset SMS-MO
--    p_short_number : short number desde el que se envia el mensaje
--    p_response : cuerpo del mensaje a enviar al handset SMS-MT
--    p_message_log : texto que se utiliza para loguear en el web service
--                    o la aplicacion que llame a esta funci"n
-- RETURN: 0 o valor < 0 si hubo error de datos
-------------------------------------------------------------------------------
FUNCTION PROCESS_MESSAGES (   P_CELLULAR_NUMBER  IN VARCHAR2,
                              P_MESSAGE          IN VARCHAR2,
                              P_SHORT_NUMBER     IN VARCHAR2,
                              P_RESPONSE         OUT VARCHAR2,
                              P_MESSAGE_LOG      OUT VARCHAR2
                          ) RETURN NUMBER IS
v_return NUMBER := 0;
-- Mensajes de error en la operacion de la package
SN_FUN     VARCHAR2(80);
SN_PROMO   VARCHAR2(80);

BEGIN

  IF (P_SHORT_NUMBER='77666') THEN
     v_return := PA_SMS_FUN.IS_FUN@prod(P_CLU_BILL_NUMBER => P_CELLULAR_NUMBER,
                                           P_MESSAGE_SMS => P_RESPONSE,
                                           P_MESSAGE_LOG => p_Message_Log);
  ELSIF (P_SHORT_NUMBER='386') THEN
      v_return := PA_SMS_FUN.BENEFITS_FUN@prod(P_BILL_NUMBER => P_CELLULAR_NUMBER,
                                         P_BENEFITS => p_Message,
                                         P_MESSAGE_SMS => P_RESPONSE,
                                         P_MESSAGE_LOG => P_MESSAGE_LOG);
  ELSE
      P_RESPONSE := 'ERROR 2';
      P_MESSAGE_LOG := 'ERROR 2';
      v_return := -10;
  END IF;


  commit;
  RETURN v_return;
EXCEPTION
  WHEN OTHERS THEN
    commit;
    RETURN SQLCODE;
END;
END;
/

