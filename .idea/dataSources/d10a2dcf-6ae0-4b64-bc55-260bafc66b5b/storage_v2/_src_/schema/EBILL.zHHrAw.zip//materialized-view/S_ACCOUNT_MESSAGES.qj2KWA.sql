create materialized view S_ACCOUNT_MESSAGES
refresh force on demand
  as
    select * from(
SELECT *  FROM account_messages@PROD
)
/

