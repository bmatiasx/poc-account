create PACKAGE BODY PA_PROV_OTT_AUTH IS

C_PKG_NAME                CONSTANT VARCHAR2(30) := 'PA_PROV_OTT_AUTH';
C_PARAM_CBT_FIJO          CONSTANT VARCHAR2(6)  := 'SWP180';
C_PARAM_STATUS            CONSTANT VARCHAR2(6)  := 'SWP187';
C_CATEGORY_CORPO          CONSTANT VARCHAR2(1)  := 'C';
C_CATEGORY_MASIVO         CONSTANT VARCHAR2(1)  := 'M';

FUNCTION f_ClaroOAuth ( p_country_id        VARCHAR2,
                        p_provider_id       VARCHAR2,
                        p_ott_id            VARCHAR2,
                        p_bill_number       VARCHAR2,
                        p_password          VARCHAR2,
                        p_msisdn        OUT VARCHAR2,
                        p_msg           OUT  VARCHAR2 ) RETURN NUMBER IS
  v_return        NUMBER(15)                            := 0;
  v_valida        NUMBER(1)                             := 0;
  v_texto         VARCHAR2(500)                         := NULL;
  v_cbt_id        s_cellulars.clu_cbt_id%TYPE           := NULL;
  v_status        s_cellulars.clu_status%TYPE           := NULL;
  v_clu_password  s_cellulars.clu_password%TYPE         := NULL;
  v_category      s_client.clt_category%TYPE            := NULL;
  v_clt_password  s_client.clt_password%TYPE            := NULL;
  v_stl_value     s_stl_parameters.stl_char_value%TYPE  := NULL;
  v_pass          VARCHAR2(15)                          := NULL;
BEGIN

  
  BEGIN
    v_texto := 'Validacion de parametros country_id['||p_country_id||'], provider_id['||p_provider_id||'], ott_id['||p_ott_id||'].';
    SELECT 1
    INTO v_valida
    FROM swp_ott_providers
    WHERE ottp_country_id = p_country_id
    AND ottp_provider_id = p_provider_id
    AND ottp_ott_id = p_ott_id;
  EXCEPTION 
    WHEN NO_DATA_FOUND THEN
      p_msg := 'Error al validar OTT, no existe. '||v_texto;
      RETURN 1001;
    WHEN OTHERS THEN
      p_msg := 'Error en '|| v_texto||' '||SQLCODE||' - '||SQLERRM;
      RETURN 1002;
  END;
  
  BEGIN
    v_texto := 'Obtencion de negocio, estado y categoria para bill_number['||p_bill_number||'].';
    SELECT clu.clu_cbt_id,
           clu.clu_status,
           clu.clu_password,
           clt.clt_category,
           clt.clt_password
    INTO v_cbt_id,
         v_status,
         v_clu_password,
         v_category,
         v_clt_password
    FROM s_cellulars clu,
         s_accounts acc,
         s_client clt
    WHERE clu.clu_bill_number = p_bill_number
      AND clu.clu_acc_id = acc.acc_id
      AND acc.acc_clt_id = clt.clt_id;
  EXCEPTION
    WHEN OTHERS THEN
      p_msg := 'Error en '||v_texto||' '||SQLCODE||' - '||SQLERRM;
      RETURN 1003;
  END;
  
  BEGIN
    v_texto := 'Validacion de negocio para bill_number['||p_bill_number||'].';
    SELECT 1
    INTO v_valida 
    FROM s_stl_parameters p
    WHERE p.stl_id = C_PARAM_CBT_FIJO
    AND INSTR(p.stl_char_value, v_cbt_id) > 0;
  EXCEPTION 
    WHEN NO_DATA_FOUND THEN
      p_msg := 'Error: el negocio['||v_cbt_id||'] de bill_number['||p_bill_number||'] no esta habilitado para este metodo.';
      RETURN 1004;
    WHEN OTHERS THEN
      p_msg := 'Error en '||v_texto||' '||SQLCODE||' - '||SQLERRM;
      RETURN 1005;
  END;
  
  BEGIN
    v_texto := 'Validacion del estado para bill_number['||p_bill_number||'].';
    SELECT 1
    INTO v_valida
    FROM s_stl_parameters p
    WHERE p.stl_id = C_PARAM_STATUS
    AND INSTR(p.stl_char_value, v_status) > 0;
  EXCEPTION 
    WHEN NO_DATA_FOUND THEN
      p_msg := 'Error: el estado['||v_status||'] de bill_number['||p_bill_number||'] no esta habilitado para este metodo.';
      RETURN 1006;
    WHEN OTHERS THEN
      p_msg := 'Error en '||v_texto||' '||SQLCODE||' - '||SQLERRM;
      RETURN 1007;
  END;

  BEGIN
    v_texto := 'Validacion de password para bill_number['||p_bill_number||'], categoria['||v_category||'].';
    IF v_category = C_CATEGORY_CORPO THEN
      v_pass := f_Encriptar3Des( p_password );
      
      IF v_clt_password = v_pass THEN
        p_msisdn := p_country_id || p_bill_number;
        p_msg := 'OK';
        RETURN 0;
      ELSIF v_clu_password = p_password THEN
        p_msg := 'Error: debe proporcionar la password del cliente.';
        RETURN 1008;
      ELSE
        p_msg := 'Wrong nim or password.';
        RETURN 1000;
      END IF;
    ELSIF v_category = C_CATEGORY_MASIVO THEN
      IF v_clu_password = p_password THEN
        p_msisdn := p_country_id || p_bill_number;
        p_msg := 'OK';
        RETURN 0;
      ELSE
        p_msg := 'Wrong nim or password.';
        RETURN 1000;
      END IF;
    END IF;

  EXCEPTION 
    WHEN NO_DATA_FOUND THEN
      p_msg := 'Error: el estado['||v_status||'] de bill_number['||p_bill_number||'] no esta habilitado para este metodo.';
      RETURN 1009;
    WHEN OTHERS THEN
      p_msg := 'Error en '||v_texto||' '||SQLCODE||' - '||SQLERRM;
      RETURN 1010;
  END;
    
  RETURN v_return;
  
END f_ClaroOAuth;


FUNCTION f_GetCellularData ( p_country_id         VARCHAR2,
                             p_provider_id        VARCHAR2,
                             p_ott_id             VARCHAR2,
                             p_bill_number        VARCHAR2,
                             p_category      OUT  VARCHAR2,
                             p_clu_password  OUT  VARCHAR2,
                             p_clt_password  OUT  VARCHAR2,
                             p_msisdn        OUT  VARCHAR2,
                             p_msg           OUT  VARCHAR2, 
                             p_log_msg       OUT  VARCHAR2 ) RETURN NUMBER IS
  v_return        NUMBER(15)                            := 0;
  v_valida        NUMBER(1)                             := 0;
  v_texto         VARCHAR2(500)                         := NULL;
  v_cbt_id        s_cellulars.clu_cbt_id%TYPE           := NULL;
  v_status        s_cellulars.clu_status%TYPE           := NULL;
  v_log           VARCHAR2(500) := NULL;
BEGIN
  
  v_log := 'PA_PROV_OTT_AUTH.f_GetCellularData ';
   
  BEGIN
    v_texto := 'Validacion de parametros country_id['||p_country_id||'], provider_id['||p_provider_id||'], ott_id['||p_ott_id||'].';
    SELECT 1
    INTO v_valida
    FROM swp_ott_providers
    WHERE ottp_country_id = p_country_id
    AND ottp_provider_id = p_provider_id
    AND ottp_ott_id = p_ott_id;
  EXCEPTION 
    WHEN NO_DATA_FOUND THEN
      p_msg := 'Error al validar OTT, no existe. '||v_texto;
      RETURN 1001;
    WHEN OTHERS THEN
      p_msg :=  'Error en '|| v_texto;
      p_log_msg := v_log || 'Error en '|| v_texto||' '||SQLCODE||' - '||SQLERRM;
      RETURN 1002;
  END;
  
  BEGIN
    v_texto := 'Obtencion de negocio, estado y categoria para bill_number['||p_bill_number||'].';
    SELECT clu.clu_cbt_id,
           clu.clu_status,
           clu.clu_password,
           clt.clt_category,
           clt.clt_password
    INTO v_cbt_id,
         v_status,
         p_clu_password,
         p_category,
         p_clt_password
    FROM s_cellulars clu,
         s_accounts acc,
         s_client clt
    WHERE clu.clu_bill_number = p_bill_number
      AND clu.clu_acc_id = acc.acc_id
      AND acc.acc_clt_id = clt.clt_id;
  EXCEPTION
    WHEN OTHERS THEN
      p_msg := 'Error en '||v_texto;
      p_log_msg := v_log || 'Error en '|| v_texto||' '||SQLCODE||' - '||SQLERRM;
      RETURN 1003;
  END;
  
  BEGIN
    v_texto := 'Validacion de negocio para bill_number['||p_bill_number||'].';
    SELECT 1
    INTO v_valida 
    FROM s_stl_parameters p
    WHERE p.stl_id = C_PARAM_CBT_FIJO
    AND INSTR(p.stl_char_value, v_cbt_id) > 0;
  EXCEPTION 
    WHEN NO_DATA_FOUND THEN
      p_msg := 'Error: el negocio['||v_cbt_id||'] de bill_number['||p_bill_number||'] no esta habilitado para este metodo.';
      p_log_msg := v_log ||' '|| p_msg;
      RETURN 1004;
    WHEN OTHERS THEN
      p_msg := 'Error en '||v_texto;      
      p_log_msg := v_log || 'Error en '|| v_texto||' '||SQLCODE||' - '||SQLERRM;
      RETURN 1005;
  END;
  
  BEGIN
    v_texto := 'Validacion del estado para bill_number['||p_bill_number||'].';
    SELECT 1
    INTO v_valida
    FROM s_stl_parameters p
    WHERE p.stl_id = C_PARAM_STATUS
    AND INSTR(p.stl_char_value, v_status) > 0;
  EXCEPTION 
    WHEN NO_DATA_FOUND THEN
      p_msg := 'Error: el estado['||v_status||'] de bill_number['||p_bill_number||'] no esta habilitado para este metodo.';
      p_log_msg := v_log ||' '|| p_msg;
      RETURN 1006;
    WHEN OTHERS THEN
      p_msg := 'Error en '||v_texto;      
      p_log_msg := v_log || 'Error en '|| v_texto||' '||SQLCODE||' - '||SQLERRM;
      RETURN 1007;
  END;
   
  p_msisdn := p_country_id || p_bill_number;
  p_msg := 'OK';
  p_log_msg := v_log ||' '|| p_msg;
  RETURN 0;
        
END f_GetCellularData;


FUNCTION f_Encriptar3Des ( p_password   VARCHAR2 ) RETURN VARCHAR2 IS
  v_msg           VARCHAR2(500) := NULL;
  v_texto         VARCHAR2(500)                         := NULL;
  v_stl_value     s_stl_parameters.stl_char_value%TYPE  := NULL;
  v_encrypted_string  VARCHAR2(2048) := NULL;
BEGIN
  v_msg    := C_PKG_NAME || '.f_Encriptar3Des: ';
  
  BEGIN
    v_texto := 'Encriptacion de password.';
    
    SELECT stl_char_value
    INTO v_stl_value
    FROM s_stl_parameters
    WHERE stl_id ='LCPENC';
    
    v_encrypted_string := PA_CRYPTO.ENCRIPTAR3DES(p_password, v_stl_value);
  EXCEPTION 
    WHEN OTHERS THEN
      v_msg := v_msg||'Error en '||v_texto||' '||SQLCODE||' - '||SQLERRM;
      RETURN NULL;
  END;
  
  RETURN v_encrypted_string;
  --RETURN 'TUKULITOSAkA';

END f_Encriptar3Des;

  
END PA_PROV_OTT_AUTH;
/

