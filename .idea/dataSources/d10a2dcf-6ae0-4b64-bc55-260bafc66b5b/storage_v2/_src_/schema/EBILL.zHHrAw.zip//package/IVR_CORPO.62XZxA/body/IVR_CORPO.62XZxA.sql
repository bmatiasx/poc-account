create PACKAGE BODY IVR_CORPO IS

 FUNCTION BUSCAR_DERIVACION_ECS(P_CELLULAR       IN S_CELLULARS.Clu_Cellular_Number%TYPE,
                                 P_NRO_DERIVACION OUT VARCHAR2,
                                 P_FLAGS          OUT NUMBER, --es 0 cuando tiene eject de servicio, 1 cuando no tiene eject de servicio
                                 P_ERROR_CODE     OUT NUMBER,
                                 P_ERROR_TEXT     OUT VARCHAR2) RETURN NUMBER IS
    V_ACC_ID VARCHAR2(10);
   
  BEGIN
  
    P_FLAGS      := 1;
    V_ACC_ID     := GET_CURRENT_ACCOUNT(P_CLU_ID => P_CELLULAR);
    P_ERROR_TEXT := 'validar si tiene ejecutivo de servicio asignado';
  
    SELECT AAR_LOGIN
      INTO P_NRO_DERIVACION
      FROM S_ACCOUNTS_ASESOR
     WHERE AAR_ACC_ID = V_ACC_ID
       AND SYSDATE BETWEEN AAR_FECHA_DESDE AND
           NVL(AAR_FECHA_HASTA, SYSDATE + 1);
    P_ERROR_TEXT := 'nro de derivacion: ' || P_NRO_DERIVACION;
    P_ERROR_CODE := 0;
    P_FLAGS      := 0;
    RETURN 0;
  
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      P_ERROR_TEXT := 'No tiene ejecutivo de servicio asignado';
      --P_FLAGS      := 1;
      P_ERROR_CODE := 0;
      RETURN 0;
    
    WHEN OTHERS THEN
      P_ERROR_CODE := SQLCODE;
      P_ERROR_TEXT := P_ERROR_TEXT || SQLERRM;
      RETURN - 1;
    
  END; --BUSCAR_DERIVACION_ECS

END IVR_CORPO;
/

