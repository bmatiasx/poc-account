create materialized view S_TIME_PERIODS
refresh complete on demand
  as
    SELECT "TIME_PERIODS"."TPE_ID",
"TIME_PERIODS"."TPE_DESCRIPTION"
FROM "TEST"."TIME_PERIODS"@PROD.WORLD "TIME_PERIODS"
 
/

