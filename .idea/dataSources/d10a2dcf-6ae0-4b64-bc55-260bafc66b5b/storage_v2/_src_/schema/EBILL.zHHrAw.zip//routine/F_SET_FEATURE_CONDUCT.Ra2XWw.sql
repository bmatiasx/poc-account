create FUNCTION       F_SET_FEATURE_CONDUCT

 (P_CELLULAR IN VARCHAR2
 ,P_PKT IN VARCHAR2
 ,P_FTR IN VARCHAR2
 ,P_CONDUCT IN VARCHAR2
 ,P_ACTION IN VARCHAR2
 ,P_ERR_TXT OUT VARCHAR2
 )
 RETURN NUMBER
 IS
 V_RESULT             NUMBER;
BEGIN

     V_RESULT := pa_features.set_feature_conduct@prod(p_cellular => p_cellular,
                                                 p_pkt => p_pkt,
                                                 p_ftr => p_ftr,
                                                 p_conduct => p_conduct,
                                                 p_action => p_action,
                                                 p_err_txt => p_err_txt);
     IF V_RESULT <> 0 THEN
       p_err_txt := p_err_txt;
       RETURN 1;
      end if;

 RETURN 0;
END;
/

