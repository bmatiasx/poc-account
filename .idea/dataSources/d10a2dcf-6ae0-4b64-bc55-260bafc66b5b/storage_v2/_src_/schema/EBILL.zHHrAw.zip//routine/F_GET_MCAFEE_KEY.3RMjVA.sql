create FUNCTION F_GET_MCAFEE_KEY

 (P_PKT_ID IN VARCHAR2
 ,P_CELLULAR IN VARCHAR2
 )
 RETURN VARCHAR2
 IS

  v_result        VARCHAR2(5);
  v_key           VARCHAR2(50);
  v_error_message VARCHAR2(200);
  feature         VARCHAR2(6);
  features        VARCHAR2(200);

  -- Cursor para features del package
  CURSOR cursorFeatures(p_pkt_id s_packages.pkt_id%TYPE) IS
    SELECT ftr.ftr_id
      FROM s_feature_packages pks, s_features ftr
     WHERE pks.pks_ftr_id = ftr.ftr_id
       AND pks.pks_pkt_id = p_pkt_id;
BEGIN
  BEGIN
    SELECT stl_char_value
      INTO features
      FROM s_stl_parameters
     WHERE stl_id = 'MCAFEE';
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN '';
  END;

  BEGIN
    OPEN cursorFeatures(p_pkt_id);
    LOOP
      FETCH cursorFeatures
        INTO feature;
      EXIT WHEN cursorFeatures%NOTFOUND;

      IF INSTR(features, '#' || feature || '#') <> 0 THEN
        v_result := pa_prov_mcafee.f_get_key(p_cellular,
                                             v_key,
                                             v_error_message);
        IF v_result <> 0 THEN
          RETURN '';
        END IF;

        RETURN 'Número de licencia: ' || v_key;

      END IF;
    END LOOP;
    CLOSE cursorFeatures;
  END;

  RETURN '';

EXCEPTION
  WHEN OTHERS THEN
    RETURN '';

END;
/

