create FUNCTION F_INSERT_ACCOUNT_TRANSACTIONS

 (P_ACC_ID IN VARCHAR2
 ,P_TRA_ID IN NUMBER
 ,P_PARAMETERS IN VARCHAR2
 ,P_MESSAGE IN VARCHAR2
 ,P_TCK_ID IN NUMBER
 ,P_STATUS IN VARCHAR2
 ,P_START_DATE IN DATE
 ,P_DELIMITER IN VARCHAR2
 ,P_ERR_NUMBER OUT NUMBER
 ,P_ERR_MESSAGE OUT VARCHAR2
 )
 RETURN INTEGER
 IS
    v_description VARCHAR2(2000);
    v_parameters VARCHAR2(2000);
    v_pos_d NUMBER;
    v_1 VARCHAR2(2000);
    v_2 VARCHAR2(2000);
    v_tra_available_trace VARCHAR2(1);
    v_tra_available_tck VARCHAR2(1);
    v_tck_id NUMBER(10);
BEGIN

    BEGIN
        SELECT tra_available_trace, tra_available_tck
        INTO v_tra_available_trace, v_tra_available_tck
        FROM transactions
        WHERE tra_id = p_tra_id;
    EXCEPTION
        WHEN OTHERS THEN
            p_err_number := SQLCODE;
            p_err_message := SQLERRM;
            RETURN -1;
    END;

    IF v_tra_available_trace = 'Y' THEN

        v_parameters := p_parameters;

        v_pos_d := instr(v_parameters, p_delimiter, 1, 1);
        v_1 := substr(v_parameters, 1, (v_pos_d - 1));
        v_parameters := substr(v_parameters, v_pos_d + 1);
        v_pos_d := instr(v_parameters, p_delimiter, 1, 1);
        v_2 := substr(v_parameters, 1, (v_pos_d- 1));

        v_description := p_message;

        IF v_1 IS NOT NULL THEN
            v_description := REPLACE(v_description,'#1#',v_1);
        END IF;

        IF v_2 IS NOT NULL THEN
            v_description := REPLACE(v_description,'#2#',v_2);
        END IF;

        IF v_tra_available_tck = 'Y' THEN
            IF p_tck_id IS NULL THEN
                BEGIN
                    SELECT  MAX(tck_id)
                    INTO    v_tck_id
                    FROM    ticklers
                    WHERE   tck_acc_id = p_acc_id;
                EXCEPTION
                    WHEN OTHERS THEN
                    p_err_number := SQLCODE;
                    p_err_message := 'Error al consultar los datos de la tabla TICKLERS.'||SQLERRM;
                    RETURN -1;
                END;
            ELSE
                v_tck_id := p_tck_id;
            END IF;
        END IF;

        INSERT INTO ACCOUNT_TRANSACTIONS
        (
          att_id,
          att_description,
          att_acc_id,
          att_tra_id,
          att_parameters,
          att_message,
          att_start_date,
          att_status,
          att_tck_id
        )
        VALUES
        (
          seq_att_id.nextval,
          v_description,
          p_acc_id,
          p_tra_id,
          p_parameters,
          p_message,
          p_start_date,
          p_status,
          v_tck_id
        );

    END IF;

    RETURN 0;

EXCEPTION
    WHEN OTHERS THEN
        p_err_number := SQLCODE;
        p_err_message := SQLERRM;
        RETURN -1;
END;
/

