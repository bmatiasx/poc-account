create FUNCTION F_GET_MILLAJE_HISTORIC

 (P_NIM IN OUT VARCHAR2
 ,P_BILL_NUMBER IN OUT VARCHAR2
 ,P_ACC_ID OUT VARCHAR2
 ,P_CLT_ID OUT NUMBER
 ,P_CLT_SURNAME OUT VARCHAR2
 ,P_CLT_NAME OUT VARCHAR2
 ,P_BALANCE OUT VARCHAR2
 ,P_OBTENIDOS OUT NUMBER
 ,P_CANJEADOS OUT NUMBER
 ,P_AVENCER OUT NUMBER
 ,P_CADENA OUT CLOB
 ,P_FECHA_PROX_VTO OUT DATE
 ,P_ERR_TXT OUT VARCHAR2
 ,CODIGO_ERROR OUT NUMBER
 )
 RETURN NUMBER
 IS
P_CEM_RECORD PKG_MILLAJE.REC_CELL_MIL;
V_IDX NUMBER;
V_CADENA_TEMP VARCHAR2(32767);
V_CADENA_CHAR VARCHAR2(32767);
V_FLAG NUMBER;
V_CADENA_CHAR_SIZE NUMBER;
V_CADENA_TEMP_SIZE NUMBER;
BEGIN
  V_CADENA_CHAR      := '';
  V_CADENA_TEMP      := '';
  V_CADENA_CHAR_SIZE := 0;
  V_CADENA_TEMP_SIZE := 0;
  V_IDX := 0;
  V_FLAG := 1;

	PA_WEB_MILLAJE.CONSULTA_GRAL_PUNTOS (
		p_nim	=>	p_nim,
		p_bill_number	=>	p_bill_number,
		p_acc_id	=>	p_acc_id,
		p_clt_id	=>	p_clt_id,
		p_clt_surname	=>	p_clt_surname,
		p_clt_name	=>	p_clt_name,
		p_balance	=>	p_balance,
		p_obtenidos	=>	p_obtenidos,
		p_canjeados	=>	p_canjeados,
		p_avencer	=>	p_avencer,
		p_cadena	=>	P_CEM_RECORD,
		p_fecha_prox_vto	=>	p_fecha_prox_vto,
		p_err_txt	=>	p_err_txt,
		codigo_error	=>	codigo_error
	);

  IF codigo_error NOT IN (0,1) THEN
    RETURN -1;
  ELSE
    IF codigo_error = 1 THEN
       p_err_txt := 'Tu línea no registra movimientos en los últimos 6 meses'; dbms_output.put_line(p_err_txt);
       RETURN codigo_error;
    END IF;
 END IF;

  P_ERR_TXT:='antes de leer';
  V_IDX := P_CEM_RECORD.FIRST;
  P_ERR_TXT := 'Verificamos si el cursor vino vacio o no.';
  IF NVL(V_IDX,-1) <> -1 THEN
  P_ERR_TXT := 'Antes de comenzar a recorrer el cursor.';
  FOR I IN P_CEM_RECORD.FIRST..P_CEM_RECORD.LAST LOOP
    P_ERR_TXT := 'Dentro del Loop - Asignando a P_CADENA los valores del cursor';

    V_CADENA_TEMP := P_CEM_RECORD(V_IDX).CEM_MIP_ID || '##'
                               || P_CEM_RECORD(V_IDX).CEM_MEC_MAP_ID || '##'
                                || P_CEM_RECORD(V_IDX).cem_mia_id|| '##'
                               || TO_CHAR(P_CEM_RECORD(V_IDX).CEM_MOVEMENT_DATE,'DD/MM/YY') || '##'
                               || P_CEM_RECORD(V_IDX).CEM_MOVEMENT_TYPE || '##'
                               || P_CEM_RECORD(V_IDX).CEM_QUANTITY || '##'
                               || P_CEM_RECORD(V_IDX).CEM_BALANCE || '##'
                               || P_CEM_RECORD(V_IDX).CEM_COMMENTS || '##'
                               || P_CEM_RECORD(V_IDX).CEM_MIP_DESC || '##'
                               || P_CEM_RECORD(V_IDX).CEM_PIN || '||';

    IF V_CADENA_CHAR IS NOT NULL THEN
        V_CADENA_CHAR_SIZE := LENGTH(V_CADENA_CHAR);
   END IF;
   IF V_CADENA_TEMP IS NOT NULL THEN
        V_CADENA_TEMP_SIZE := LENGTH(V_CADENA_TEMP);
   END IF;

    IF V_CADENA_CHAR_SIZE + V_CADENA_TEMP_SIZE<= 32767 THEN
      V_CADENA_CHAR := V_CADENA_CHAR || V_CADENA_TEMP;
      IF V_IDX = P_CEM_RECORD.LAST THEN
        P_CADENA := TO_CLOB(V_CADENA_CHAR);
      END IF;
    ELSE
    P_ERR_TXT := 'Dentro del Loop - Se empieza a trabajar en CLOB';
      IF V_FLAG = 1 THEN
        P_CADENA := TO_CLOB(V_CADENA_CHAR);
      END IF;

      P_CADENA := P_CADENA || TO_CLOB(V_CADENA_TEMP);
      V_FLAG := 0;
    END IF;

    V_IDX := V_IDX + 1;
    END LOOP;
	END IF;
 P_ERR_TXT := 'Finaliza OK';
RETURN 0;
EXCEPTION
	WHEN OTHERS THEN
        RETURN - 1;
END;
/

