create materialized view S_CARD_CHARGES
refresh force on demand
  as
    SELECT cad_cty_id, cad_start_date, cad_chr_id, cad_rsn_id, cad_act_id, cad_chr_id_annulled, cad_rsn_id_annulled, cad_transaction, cad_end_date, cad_type, cad_cbt_id
 from card_charges@PROD


/

