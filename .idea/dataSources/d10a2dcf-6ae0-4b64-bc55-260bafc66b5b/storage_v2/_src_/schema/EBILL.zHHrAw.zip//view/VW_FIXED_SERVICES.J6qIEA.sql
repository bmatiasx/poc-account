create view VW_FIXED_SERVICES as
  SELECT clt_id,
                 clt_name,
                 clt_surname,
                 clt_identification_type,
                 clt_identification_number,
                 clt_cuit,
                 acc_id,
                 clu_cellular_number,
                 cbt_id,
                 cbt_description,
                 aaa.aaa_address_street,
                 aaa.aaa_address_number,
                 aaa.aaa_address_tower,
                 aaa.aaa_address_floor,
                 aaa.aaa_address_flat,
                 aaa.aaa_address_within_streets,
                 aaa.aaa_address_city,
                 aaa.aaa_address_department,
                 aaa.aaa_cpa,
                 aaa_geu_id geu_id,
                 rpl_id || ' - ' || rpl.rpl_description rate_plan
        FROM accounts acc,
                 client clt,
                 account_alt_addresses aaa,
                 cellular_address cad,
                 cellulars clu,
                 cellular_business_types cbt,
                 cellular_plans cpl,
                 stl.rate_plans@prod rpl
     WHERE acc.acc_id = aaa.aaa_acc_id
         AND acc.acc_clt_id = clt.clt_id
         AND aaa.aaa_id = cad.cad_aaa_id
         AND cad.cad_clu_cellular_number = clu.clu_cellular_number
         AND SYSDATE BETWEEN cad.cad_start_date AND NVL(cad.cad_end_date, SYSDATE)
         AND SYSDATE BETWEEN aaa.aaa_start_date AND NVL(aaa.aaa_end_date, SYSDATE)
         AND cpl.cpl_clu_cellular_number = clu.clu_cellular_number
         AND SYSDATE BETWEEN cpl.cpl_start_date AND NVL(cpl.cpl_end_date, SYSDATE)
         AND clu_cbt_id = cbt_id
         AND clu.clu_stg_id = cpl.cpl_stg_id
         AND clu_cbt_id IN ('TF', 'IF', 'IPTV')
         AND cpl.cpl_rpl_id = rpl.rpl_id
         AND SYSDATE BETWEEN rpl.rpl_start_date AND NVL(rpl.rpl_end_date, SYSDATE)
/

