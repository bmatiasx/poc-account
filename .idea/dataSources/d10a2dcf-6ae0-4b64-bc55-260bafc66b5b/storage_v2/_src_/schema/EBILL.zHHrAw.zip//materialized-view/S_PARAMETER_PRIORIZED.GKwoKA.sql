create materialized view S_PARAMETER_PRIORIZED
refresh force on demand
  as
    SELECT ppp_id,
ppp_start_date,
ppp_description,
ppp_value,
ppp_end_date,
ppp_char_value
FROM TEST.parameter_priorized@PROD
 
/

