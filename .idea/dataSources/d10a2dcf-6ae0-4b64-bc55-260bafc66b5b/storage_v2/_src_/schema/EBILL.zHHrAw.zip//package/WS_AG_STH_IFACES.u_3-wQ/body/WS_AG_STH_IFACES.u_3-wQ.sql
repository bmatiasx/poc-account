create PACKAGE BODY WS_AG_STH_IFACES IS

/***********************************************************************************************************************************************************************
       NAME:       ws_ag_sth_ifaces
       PURPOSE:
       REVISIONS:
       Ver        Date           EVENTO               Author                                         Description
     ---------  ----------      ----------          ---------------             ------------------------------------------
      1.0        14/03/2011                                                      1. Created this package.
      1.16       03/04/2012                           Pablo Cura                 PC65543_Servicio_Tecnico_DTH
      1.19       19/03/2012                           lnamur                     Integracion Fijo/Movil
      1.20       05/07/2012                           lnamur                     Integracion Fijo/Movil CC01
      1.21       16/07/2012                           lnamur                     Integracion Fijo/Movil CC01
      1.23       02/08/2012    PC80691_CD80699        lnamur                     PC80691_CD80699_agenda_cc
      1.27       09/10/2012    PC80691_CD80699        lnamur                     PC80691_CD80699_agenda_cc_PO
      1.28       09/10/2012    PC77402                M. Herigert                PC77402 Agenda Pyme
      1.29       08/11/2012    PC77402                lnamur                     PC82904 visualizacion SDS
      1.30       15/11/2012    PC82904                Psantarrosa                PC82904- se agrega rollback en el change_status_sds x Reclamo TC)cnico de Fija pc81006
      1.31       02/05/2013                           lnamur                     unificacion Agenda UY
      1.34       06/06/2013    PC91087                lnamur                     PC91087_Correcion Sobre agenda
      1.37       09/09/2013    PC91087                pcura                      PC91022_PO
      1.38       01/10/2013    PC85176_CD85470_PO     Paula Santarrosa           Se deja p_err_message igual a null cuando no hay error por validacion de agenda EN CHANGE_STATUS_SDS.
      1.41       18/11/2013    PC85176_CD85470_PO2    Paula Santarrosa           Se cambia el CLT_KEYNAME por clt_name||clt_surname.
      1.46       03/12/2013    PC91707_CD92145        Pablo Cura                 Agregado de campos Agenda
      1.47       17/12/2013    PC91707_CD92145       Luciano Nitardi          Mostrar motivos de cierre
      1.48       27/12/2013    PC92054_CD97801       Luciano Nitardi          Cambio direccion de instalacion
      1.49       20/01/2014    PC91707_CD92145       Luciano Nitardi          Mostrar motivos de cierre
      1.57       10/03/2014    PC100056              Luciano Nitardi          Correcion Multiple Localidad Agenda
      1.62       26/05/2014    PC101555              PABLO CURA               Mostrar ult. mot cierre
      1.63       27/05/2014    PC92054_CD97801       Luciano Nitardi          Cambio direccion de instalacion
      1.64       10/06/2014    PC101348_CD101883     PABLO CURA               quitar los campo agregados del PC 91707 del procedura getsdssactives
      1.65       16/09/2014    PC107838              PABLO CURA               corregir procedure Getsdssactives, para que devuelva todas las OT al no ingresar algun motivo
      1.69       31/03/2015    PC112933              PABLO CURA               corregir consulta de OT de lineas canceladas.
      1.70       09/04/2015    PC108767              PABLO CURA               agregar el nuevo tratamiento del LOG de agenda.
      1.71       09/04/2015    PC110203              PABLO CURA               ABM de motivos de cierre e interrupcion de agenda
      1.72       17/09/2015    PC121204               PABLO CURA               Correcion ABM Motivos de cierre e interrupcion de agenda
      1.81       25/07/2016    PC123967               PABLO CURA               Activacion IPTV
      1.84       24/10/2016    PC130773              CARLOS GARELLO            Correccion vistas materializadas de planes.
      1.86       31/10/2016    PC131703              CARLOS GARELLO            Correcci¿n getcontratista - nombre comercial
      1.87       21/02/2017    PC123999              PABLO CURA              CAMBIO DE ESTADO IPTV
      1.88       29/03/2017    PC137118              PABLO CURA              Tunnnig getsdssactives
      1.90       18/07/2017    PC136134              PABLO CURA              Cambio de ONT desde Agenda(Esta es la valida, Se realizaron los cambios por afuera sobre la 1.89 en produccion)
      1.94       27/03/2018    PC144705              PABLO CURA              Agrandar variable v_sql
      1.95       27/04/2018    PC141796              PABLO CURA              Agregado del control de vigencia de la tabla ICR
      1.97       22/05/2018    PADI-8 CFI-11         PABLO CURA              Agregado de cantidad de Tv y servicio previo
      1.98       11/06/2018    PBA-152 CFI-23        LAURA COSTA             Mejoras Domicilio Instalacion Torre y Entre Calles
      1.99       04/07/2018    PCF-26 CFI-103        LAURA COSTA             Busqueda de Id de Localidad en STL con datos de Localidad y Provincia de XYGO
      1.100      14/08/2018    CFI-166               NOEL CELIZ              Correccion en la busqueda de servicios interrumpidos desde Agenda
      1.102      27/09/2018    CFI-234               CARLOS GARELLO          Cambio en el manejo de los segmentos en Agenda 
      1.105      30/11/2018    CFI-360               NOEL CELIZ              Reingenieria de conexión entre Agenda y Stealth
      1.106      12/12/2018    CFI-256               CARLOS GARELLO          Envio de la direccion destino en las OTs VIMUD ********************************************************************************************************************************************************************/
  
  PROCEDURE getprovincias(p_cursor  OUT refcur,
                          p_id_pais IN VARCHAR2 DEFAULT 'PY',
                          p_error   OUT VARCHAR2) IS
    vexec VARCHAR2(200);
  BEGIN
    vexec := 'ws_ag_sth_ifaces.GetProvincias';
    OPEN p_cursor FOR
      SELECT reg_id, reg_name provincia
        FROM cp_regions
       WHERE reg_ctr_id = p_id_pais;
  EXCEPTION
    WHEN OTHERS THEN
      p_error := SQLERRM || ' - ' || vexec;
  END getprovincias;
  --****************************
  PROCEDURE getlocalidades(p_cursor       OUT refcur,
                           p_id_provincia IN VARCHAR2,
                           p_error        OUT VARCHAR2) IS
    vexec VARCHAR2(200);
  BEGIN
    vexec := 'ws_ag_sth_ifaces.GetLocalidades';
    OPEN p_cursor FOR
      SELECT cit_id, cit_name localidad, cit_reg_name provincia
        FROM cp_cities, cp_regions
       WHERE cit_reg_name = reg_name
         AND reg_id = p_id_provincia;
  EXCEPTION
    WHEN OTHERS THEN
      p_error := SQLERRM || ' - ' || vexec;
  END getlocalidades;
  --****************************
  PROCEDURE getcontratistas(p_cursor OUT refcur, p_error OUT VARCHAR2) IS
    vexec VARCHAR2(200);
  BEGIN
    vexec := 'ws_ag_sth_ifaces.GetContratistasCRM';
    OPEN p_cursor FOR
      SELECT ee.ent_id,
             ee.ent_dealer_code,
             ee.ent_sub_dealer_code,
             ee.ent_nombre_comercial AS ent_nombre_oficial -- PC131703
        FROM a_ent_bus_comp bb, a_entidades ee
       WHERE bb.ent_id = ee.ent_id
         AND NVL(ent_fecha_baja, sysdate + 1) > sysdate --PC123967
         AND bb.bco_cbt_id IN ('DTH', 'IF', 'TF', 'IPTV')
         AND INSTR((SELECT STL_CHAR_VALUE
                     FROM STL_PARAMETERS -- PC131703
                    WHERE STL_ID = 'IPTV40'),
                   '#' || ee.tent_id || '#') > 0
       Group by ee.ent_id,
                ee.ent_dealer_code,
                ee.ent_sub_dealer_code,
                ee.ent_nombre_oficial,
                ee.ent_nombre_comercial;
  EXCEPTION
    WHEN OTHERS THEN
      p_error := SQLERRM || ' - ' || vexec;
  END getcontratistas;
  --****************************
  PROCEDURE get_detalle_sds(p_id_sds           NUMBER,
                            p_cellular_number  OUT VARCHAR2,
                            p_ent_id           OUT NUMBER,
                            p_status_sds       OUT VARCHAR2, --A Asigna, otra letra desasigna
                            p_id_localidad     OUT NUMBER,
                            p_type_sds         OUT VARCHAR2,
                            p_id_provincia     OUT VARCHAR2,
                            p_calle            OUT VARCHAR2,
                            p_nro              OUT VARCHAR2,
                            p_torre            OUT VARCHAR2, --CFI-23
                            p_piso             OUT VARCHAR2,
                            p_dpto             OUT VARCHAR2,
                            p_cp               OUT VARCHAR2,
                            p_cliente          OUT VARCHAR2,
                            p_cuenta           OUT VARCHAR2,
                            p_id_cliente       OUT NUMBER,
                            p_observaciones    OUT VARCHAR2,
                            p_entre_calles     OUT VARCHAR2, --CFI-23
                            p_scard            OUT VARCHAR2,
                            p_scard_number     OUT VARCHAR2,
                            p_deco             OUT VARCHAR2,
                            p_deco_number      OUT VARCHAR2,
                            p_dni_number       OUT VARCHAR2,
                            p_type_dni         OUT VARCHAR2,
                            p_tel_contacto     OUT VARCHAR2,
                            p_reason_start     OUT VARCHAR2,
                            p_reason_finish    OUT VARCHAR2,
                            p_asd_tck_id       OUT NUMBER,
                            p_asd_swf_id       OUT NUMBER,
                            p_reason_interrupt OUT VARCHAR2, --ultimo motivo de interrupcion
                            p_reason_closed    OUT VARCHAR2, --Motivo de cierre
                            p_provincia        OUT VARCHAR2,
                            p_departamento     OUT VARCHAR2, --CFI-23
                            p_localidad        OUT VARCHAR2,
                            p_err_number       OUT NUMBER,
                            p_technology       OUT VARCHAR2,
                            p_rate_plan_des    OUT VARCHAR2,
                            p_docu_tipo        NUMBER := NULL,
                            p_docu_tipo_nro    NUMBER := NULL,
                            p_usr_id           OUT VARCHAR2, --legajo
                            p_err_message      OUT VARCHAR2,
                            p_segmento         OUT VARCHAR2, -- PC77402 RESIDENCIAL, CORPORATIVO, PYMES
                            p_form_number      OUT VARCHAR2, --PC82904 visualizacion SDS
                            p_obs_tck          OUT VARCHAR2, --PC91707
                            p_dir_lat          OUT NUMBER, --PC91707
                            p_dir_long         OUT NUMBER, --PC91707
                            p_ent_asig         OUT NUMBER, --PC91707
                            p_instalador       OUT NUMBER, --PC91707
                            p_tecnico          OUT NUMBER, --PC91707
                            p_asing_date       OUT DATE, --PC91707
                            p_inst_date        OUT DATE, --PC91707
                            p_vitec_date       OUT DATE, --PC91707
                            p_inst_warranty    OUT VARCHAR2, --PC91707
                            p_tec_warranty     OUT VARCHAR2, --PC91707
                            p_have_det         OUT VARCHAR2, --PC123967
                            p_int_prev         OUT VARCHAR2, --CFI-11
                            p_cant_tv          OUT NUMBER, --CFI-11
                            p_create_date      OUT DATE --CFI-11
                            ) IS
    v_msg               VARCHAR2(4000); --PC144705VARCHAR2(255);
    v_max_hist        NUMBER;
    V_AAA_ID         NUMBER; --NUEVO
    v_flag_xygo        VARCHAR2(20); --CFI-103
    v_localidad         VARCHAR2(200); --CFI-103
    v_provincia         VARCHAR2(100); --CFI-103
    v_flg_agloc         VARCHAR2(10); --CFI-103
    v_clu_cbt_id        cellulars.clu_cbt_id%type; --CFI-256
    v_clu_acc_id        cellulars.clu_acc_id%type;
    v_mud_id            mud_process.mud_id%type;
  BEGIN
    v_msg := 'Buscando datos de la SDS.';
    /* IIF P_docu_tipo = 0 AND P_docu_tipo_nro IS NOT NULL
    THEN
       Vsql := Vsql || ' and Sds.ASD_ID_SDS=' || P_docu_tipo_nro;     ---SDS
    ELSIF P_docu_tipo = 1 AND P_docu_tipo_nro IS NOT NULL
    THEN
       Vsql := Vsql || ' and Sds.ASD_TCK_ID=' || P_docu_tipo_nro;   --TICKET
    ELSIF P_docu_tipo = 2 AND P_docu_tipo_nro IS NOT NULL
    THEN
       Vsql := Vsql || ' and Sds.ASD_CLU_CELLULAR_NUMBER=' || P_docu_tipo_nro; ---NB: Servicio
    ELSIF P_docu_tipo = 3 AND P_docu_tipo_nro IS NOT NULL
    THEN
       Vsql := Vsql || ' and Sds.ASD_SWF_ID=' || P_docu_tipo_nro; ---SOLICITUD WF
    END IF;  */
    --Campo motivo comienzo=asd_reason_start
    --Campo motivo comienzo=asd_reason_finish
    SELECT asd_status,
           asd_clu_cellular_number,
           asd_ast_type,
           asd_observation,
           asd_ent_id,
           asd_reason_start,
           asd_reason_finish,
           asd_tck_id,
           asd_swf_id,
           asd_usr_id,
           asd_clt_type,
           (SELECT srf_id
              FROM service_request_forms
             WHERE srf_form_number = asd_sds_id
               AND srf_srf_id IS NULL),
           asd_tck_obs, --PC91707
           asd_ent_id_inst, --PC91707
           asd_ent_id_tec, --PC91707
           asd_ent_id, --PC91707
           asd_inst_date, --PC91707
           asd_tec_date, --PC91707
           asd_schedule_date, --PC91707
           asd_inst_warranty,
           asd_tec_warranty,
           asd_create_date --CFI-11
      INTO p_status_sds,
           p_cellular_number,
           p_type_sds,
           p_observaciones,
           p_ent_id,
           p_reason_start,
           p_reason_finish,
           p_asd_tck_id,
           p_asd_swf_id,
           p_usr_id,
           p_segmento,
           p_form_number,
           p_obs_tck, --PC91707
           p_instalador, --PC91707
           p_tecnico, --PC91707
           p_ent_asig, --PC91707
           p_inst_date, --PC91707
           p_vitec_date, --PC91707
           p_asing_date, --PC91707
           p_inst_warranty, --PC91707
           p_tec_warranty, --PC91707
           p_create_date --CFI-11
      FROM ag_sds
     WHERE asd_id_sds = p_id_sds;
    --PC123967
    v_msg := 'Devolviendo el tipo de negocio de la linea ';
    BEGIN
      SELECT 'Y'
        INTO p_have_det
        FROM ag_sds_details
       WHERE agd_asd_id_sds = p_id_sds;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        p_have_det := 'N';
      WHEN TOO_MANY_ROWS THEN
        p_have_det := 'Y';
    END;
    --FIN PC123967
    v_msg := 'Verificando que el estado de la sds es de cierre ';
    BEGIN
      SELECT rss.rss_description
        INTO p_reason_closed
        FROM reason_sds_state rss, history_state_sds hss
       WHERE rss.rss_id = hss.hss_rss_id
         AND hss.hss_start_date < SYSDATE
         AND nvl(hss.hss_end_date, SYSDATE + 1) > SYSDATE
         AND hss.hss_asd_id_sds = p_id_sds
         AND rss.rss_type = 'C';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        p_reason_closed := 'No Tuvo motivos de cierre';
    END;
    v_msg := 'Obteniendo ultimo motivo de interrupcion';
    BEGIN
      SELECT hss.hss_id, rss.rss_description
        INTO v_max_hist, p_reason_interrupt
        FROM reason_sds_state            rss,
             history_state_sds           hss,
             interruption_closed_reasons,
             ag_sds                      ag
       WHERE rss.rss_id = hss.hss_rss_id
         AND rss.rss_id = icr_rss_id
         AND hss.hss_start_date < SYSDATE
         AND nvl(hss.hss_end_date, SYSDATE + 1) > SYSDATE
         AND NVL(ICR_START_DATE, SYSDATE - 1) <= SYSDATE --PC141796
         AND NVL(ICR_END_DATE, SYSDATE + 1) > SYSDATE --PC141796
         AND rss.rss_type = 'I'
         AND hss.hss_asd_id_sds = ag.asd_id_sds
         AND icr_ast_type = ag.asd_ast_type
         AND icr_state = ag.asd_status
         AND ag.asd_id_sds = p_id_sds;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        p_reason_interrupt := 'No Tuvo motivos de interrupciC3n';
    END;
  
    -- Comienzo CFI-256
    v_msg := 'Buscando tipo de negocio de la linea .'; 
    SELECT clu_cbt_id,clu_acc_id
      INTO v_clu_cbt_id,v_clu_acc_id
      FROM cellulars 
     WHERE clu_cellular_number=p_cellular_number;
      
 
  IF p_type_sds = 'VIMUD' AND v_clu_cbt_id <> 'DTH'THEN
   BEGIN
    BEGIN
     v_msg := 'Buscando ID del proceso .';
     SELECT mud.mud_id
       INTO v_mud_id
       FROM mud_process mud
      WHERE mud.mud_sds_id = p_id_sds;
    EXCEPTION
     WHEN NO_DATA_FOUND THEN
       SELECT mud.mud_id
         INTO v_mud_id
         FROM mud_process mud
        WHERE mud.mud_rsn_id IN ('VIMUD', 'VIMUB')
          AND mud.mud_status IN ('T', 'F', 'V', 'P')
          AND mud.mud_cellular_number = p_cellular_number
          AND mud.mud_acc_id = v_clu_acc_id;
    END; 
    v_msg := 'Buscando datos del nuevo domicilio .';
    SELECT   mad_aaa_id_old, --viejo
             mad_aaa_geu_id,
             mad_aaa_cit_id As cit_id, --PC100056 Luciano Nitardi
             mad_aaa_address_flat,
             mad_aaa_address_number,
             mad_aaa_address_floor,
             mad_aaa_address_street,
             mad_aaa_zip_code,
             mad_aaa_reg_name,
             mad_aaa_address_city,
             DECODE(mad_flag_cartografy,'XYGO',mad_latitude,mad_aaa_gps_lat) as aaa_latitud,  --CFI-23
             DECODE(mad_flag_cartografy,'XYGO',mad_longitude,mad_aaa_gps_long) as aaa_longitud, -- CFI-23
             mad_aaa_address_department,
             mad_aaa_address_tower, 
             mad_aaa_address_within_streets, 
             mad_flag_cartografy, 
             mud_acc_id
        INTO V_AAA_ID, --viejo
             p_id_provincia,
             p_id_localidad,
             p_dpto,
             p_nro,
             p_piso,
             p_calle,
             p_cp,
             p_provincia,
             p_localidad,
             p_dir_lat,
             p_dir_long,
             p_departamento, 
             p_torre, 
             p_entre_calles, 
             v_flag_xygo,  
             p_cuenta
       FROM mud_process mp,mud_address ma
      WHERE mp.mud_id=ma.mad_mud_id
        AND mp.mud_sds_id=p_id_sds;
      EXCEPTION
        WHEN OTHERS THEN
        p_err_number  := SQLCODE;
        p_err_message := v_msg || SQLERRM;
        RETURN;
        --Return -1;
       END;    
   -- Fin CFI-256   
   ELSE
    v_msg := 'Buscando datos del domicilio .';
    BEGIN
      SELECT aaa_id, --nuevo
             aaa_acc_id,
             aaa_geu_id,
             aaa_cit_id As cit_id, --PC100056 Luciano Nitardi
             aaa_address_flat,
             aaa_address_number,
             aaa_address_floor,
             aaa_address_street,
             aaa_zip_code,
             aaa_reg_name,
             aaa_address_city,
             DECODE(aaa_flag_cartografy,'XYGO',aaa_latitude,aaa_gps_lat) as aaa_latitud,  --CFI-23
             DECODE(aaa_flag_cartografy,'XYGO',aaa_longitude,aaa_gps_long) as aaa_longitud, -- CFI-23
             aaa_address_department, --CFI-23
             aaa_address_tower, --CFI-23
             aaa_address_within_streets, --CFI-23
             aaa_flag_cartografy --CFI-103
        INTO V_AAA_ID, --nuevo
             p_cuenta,
             p_id_provincia,
             p_id_localidad,
             p_dpto,
             p_nro,
             p_piso,
             p_calle,
             p_cp,
             p_provincia,
             p_localidad,
             p_dir_lat,
             p_dir_long,
             p_departamento, --CFI-23
             p_torre, --CFI-23
             p_entre_calles,  --CFI-23
             v_flag_xygo  -- CFI-103
       FROM cellular_address, account_alt_addresses
       WHERE cad_clu_cellular_number = p_cellular_number
         AND cad_aaa_id = aaa_id
         AND aaa_aat_id = 2
         AND NVL(AAA_START_DATE, SYSDATE - 1) <= SYSDATE --PC141796
         AND NVL(AAA_END_DATE, SYSDATE + 1) > SYSDATE --PC141796
         AND nvl(cad_start_date, sysdate - 1) <= sysdate --PC92054 - Para que traiga el Domicilio de Instalacion vigente aunque la linea posea una Mudanza DTH a corte de ciclo (Nuevo Dom de Instalacion a Corte de Ciclo)
         AND nvl(cad_end_date, sysdate + 1) > sysdate; --PC92054;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        --PC112933
        SELECT aaa_id, --nuevo
               aaa_acc_id,
               aaa_geu_id,
               aaa_cit_id As cit_id,
               aaa_address_flat,
               aaa_address_number,
               aaa_address_floor,
               aaa_address_street,
               aaa_zip_code,
               aaa_reg_name,
               aaa_address_city,
               DECODE(aaa_flag_cartografy,'XYGO',aaa_latitude,aaa_gps_lat) as aaa_latitud,  --CFI-23
               DECODE(aaa_flag_cartografy,'XYGO',aaa_longitude,aaa_gps_long) as aaa_longitud, -- CFI-23
               aaa_address_department, --CFI-23
               aaa_address_tower, --CFI-23
               aaa_address_within_streets, --CFI-23
               aaa_flag_cartografy --CFI-103
          INTO V_AAA_ID, --nuevo
               p_cuenta,
               p_id_provincia,
               p_id_localidad,
               p_dpto,
               p_nro,
               p_piso,
               p_calle,
               p_cp,
               p_provincia,
               p_localidad,
               p_dir_lat,
               p_dir_long,
               p_departamento, --CFI-23
               p_torre, --CFI-23
               p_entre_calles, --CFI-23
               v_flag_xygo  -- CFI-103
          FROM cellular_address, account_alt_addresses
         WHERE cad_clu_cellular_number = p_cellular_number
           AND cad_aaa_id = aaa_id
           AND aaa_aat_id = 2
           AND aaa_id = (SELECT MAX(aaa_id)
                           FROM cellular_address, account_alt_addresses
                          WHERE cad_clu_cellular_number = p_cellular_number
                            AND cad_aaa_id = aaa_id
                            AND aaa_aat_id = 2);
        --PC112933
      WHEN OTHERS THEN
        p_err_number  := SQLCODE;
        p_err_message := v_msg || SQLERRM;
        RETURN;
        --Return -1;
    END;
   END IF;
    --CFI-103
    IF nvl(v_flag_xygo,'SEMA') = 'XYGO' THEN
        --Se obtiene el valor de la flag para informar ID localidad a Agenda con datos de XYGO
        --Si el valor es 'Y' se informa el ID, caso contrario se informa 0 (cero).
        v_msg := 'El parametro AGDLOC no se encuentra definido o esta vencido. ';
        BEGIN
           SELECT stl_char_value
           INTO      v_flg_agloc
           FROM    stl_parameters
           WHERE stl_id = 'AGDLOC'
           AND       SYSDATE BETWEEN stl_start_date AND NVL(stl_end_date,SYSDATE);
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                p_err_number := SQLCODE;
                p_err_message := v_msg||SQLERRM;
                RETURN;
        END;
        IF v_flg_agloc = 'Y' THEN
            v_msg := 'Buscando id de localidad de Agenda-STL ';
            v_localidad := UPPER(p_localidad);
            v_provincia := UPPER(p_provincia);
            BEGIN
                SELECT cit_id
                INTO      p_id_localidad
                FROM    cp_cities
                WHERE UPPER(cit_reg_name) = v_provincia
                AND       UPPER(cit_name) = v_localidad
                AND       rownum = 1;
            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                     BEGIN
                          SELECT xac_stl_cit_id
                          INTO      p_id_localidad
                          FROM    xygo_agenda_cities
                          WHERE xac_city_name = v_localidad
                          AND       xac_stl_reg_id = p_id_provincia;
                     EXCEPTION
                          WHEN NO_DATA_FOUND THEN
                               p_id_localidad := 0;
                     END;
                WHEN OTHERS THEN
                    p_err_number  := SQLCODE;
                    p_err_message := v_msg || SQLERRM;
                    RETURN;
            END;
        END IF;
    ELSE
        IF p_id_localidad IS NULL THEN
            BEGIN
                SELECT cit_id
                INTO      p_id_localidad
                FROM    cp_cities
                WHERE UPPER(cit_reg_name) = UPPER(p_provincia)
                AND       UPPER(cit_name) = UPPER(p_localidad)
                AND       rownum = 1;
            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                   NULL;
            END;
        END IF;
    END IF; --CFI-103
    v_msg := 'Buscando datos del cliente .';
    BEGIN
      SELECT clt_id,
             CLT_NAME || ' ' || CLT_SURNAME CLT_KEYNAME, --clt_keyname,se comenta por PC85176_CD85470_PO2
             clt_bill_contact,
             clt_identification_number,
             clt_identification_type
        INTO p_id_cliente,
             p_cliente,
             p_tel_contacto,
             p_dni_number,
             p_type_dni
        FROM accounts, client
       WHERE acc_clt_id = clt_id
         AND acc_id = p_cuenta;
    EXCEPTION
      WHEN OTHERS THEN
        p_err_number  := SQLCODE;
        p_err_message := v_msg || SQLERRM;
        RETURN;
        --Return -1;
    END;
    v_msg := 'Buscando datos del deco .';
    begin
      select pro_description, cet_imei, pro_mode_type
        into p_deco, p_deco_number, p_technology
        FROM cellular_terminals, products
       WHERE cet_clu_cellular_number = p_cellular_number
         and nvl(cet_end_date, sysdate + 1) > sysdate
         AND pro_id = cet_pro_id;
    exception
      when no_data_found then
        ---PC91022_PO para que traiga el ultimo equipo antes de cancelarse
        select pro_description, cet_imei, pro_mode_type
          into p_deco, p_deco_number, p_technology
          FROM cellular_terminals, products
         WHERE pro_id = cet_pro_id
           and cet_id =
               (select max(cet_id)
                  from cellular_terminals
                 where cet_clu_cellular_number = p_cellular_number);
        --- fin PC91022_PO
      WHEN others THEN
        p_err_number  := SQLCODE;
        p_err_message := v_msg || SQLERRM;
        RETURN;
    end;
    v_msg := 'Buscando datos de la SCARD .';
    BEGIN
      SELECT pro_description, esc_esn_hexa
        INTO p_scard, p_scard_number
        FROM products, esn_cellulars, electronical_serial_numbers
       WHERE esc_clu_cellular_number = p_cellular_number
         AND esc_esn_hexa = esn_hexa
         AND pro_id = esn_pro_id
         and nvl(esc_end_date, sysdate + 1) > sysdate;
    EXCEPTION
      WHEN no_data_found THEN
        SELECT pro_description, esc_esn_hexa --PC123999
          INTO p_scard, p_scard_number
          FROM products, esn_cellulars, electronical_serial_numbers
         WHERE esc_clu_cellular_number = p_cellular_number
           AND esc_esn_hexa = esn_hexa
           AND pro_id = esn_pro_id
           AND esc_esn_hexa =
               (SELECT MAX(esc_esn_hexa)
                  FROM esn_cellulars
                 WHERE esc_clu_cellular_number = p_cellular_number);
      WHEN OTHERS THEN
        p_err_number  := SQLCODE;
        p_err_message := v_msg || SQLERRM;
        RETURN;
        --Return -1;
    END;
    v_msg := 'Buscando la descripcion del plan comercial .';
    BEGIN
      --Comienzo PC130773 -- Se ingresa directamente a las tablas de produccion
      -- mediante los sinonimos distribuidos de dichas tablas.
      SELECT rpl_description
        INTO p_rate_plan_des
        FROM cellular_plans, rate_plans
       WHERE cpl_clu_cellular_number = p_cellular_number
         AND cpl_rpl_id = rpl_id
         AND cpl_start_date < SYSDATE
         AND nvl(cpl_end_date, SYSDATE + 1) > SYSDATE
         AND ROWNUM = 1;
    EXCEPTION
      WHEN OTHERS THEN
        p_rate_plan_des := null;
    END;
    -- Fin PC130773
    --Inicio PC107768, setear en NULL el campo observaciones debido a que ya se tomo el registro en agenda.
    UPDATE ag_sds
       SET asd_observation = null --pc108767
     WHERE asd_id_sds = p_id_sds;
    --fin Pc107768
    --CFI-11
    v_msg := 'VERIFICANDO SI A¿ADE O ES NUEVO';
    BEGIN
      SELECT 'Y'
        INTO P_INT_PREV
        FROM CELLULAR_ADDRESS CA, CELLULARS
       WHERE CA.CAD_CLU_CELLULAR_NUMBER = CLU_CELLULAR_NUMBER
         AND NVL(CAD_START_DATE, SYSDATE - 1) <= SYSDATE
         AND NVL(CAD_END_DATE, SYSDATE + 1) > SYSDATE
         AND CLU_CBT_ID = 'IF'
         AND CLU_STATUS = 'A'
         and CA.CAD_AAA_ID = V_AAA_ID;
    EXCEPTION
      WHEN TOO_MANY_ROWS THEN
        P_INT_PREV := 'Y';
      WHEN NO_DATA_FOUND THEN
        P_INT_PREV := 'N';
      WHEN OTHERS THEN
        p_err_number  := SQLCODE;
        p_err_message := v_msg || SQLERRM;
        RETURN;
    END;
    v_msg := 'BUSCANDO CANTIDAD DE LINEAS IPTV';
    IF p_type_sds = 'INST' THEN
      SELECT COUNT(AGD_CLU_CELLULAR_NUMBER)
        INTO P_CANT_TV
        FROM AG_SDS_DETAILS
       WHERE AGD_CBT_ID = 'IPTV'
         AND AGD_ASD_ID_SDS = p_id_sds;
    ELSE
      SELECT COUNT(CLU_CELLULAR_NUMBER)
        INTO P_CANT_TV
        FROM CELLULARS C
       WHERE CLU_CBT_ID = 'IPTV'
         AND EXISTS
       (SELECT 1
                FROM CELLULAR_ADDRESS CA
               WHERE cad_clu_cellular_number = C.CLU_CELLULAR_NUMBER
                 AND CAD_AAA_ID = V_AAA_ID
                 AND NVL(CAD_END_DATE, SYSDATE + 1) > SYSDATE);
    END IF;
    --CFI-11
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      v_msg         := 'No existe esta SDS.Verifique.';
      p_err_message := v_msg;
      p_err_number  := -1;
      RETURN;
      --Return -1;
    WHEN OTHERS THEN
      p_err_number  := SQLCODE;
      p_err_message := v_msg || SQLERRM;
      RETURN;
      --Return -1;
  END get_detalle_sds;
  --****************************
  PROCEDURE change_status_sds(p_sds_id          NUMBER,
                              p_status          VARCHAR2,
                              p_user            VARCHAR2,
                              p_observation     VARCHAR2,
                              p_id_contratista  NUMBER := NULL,
                              p_schedule_date   DATE := NULL,
                              p_reason_finish   VARCHAR2 := NULL,
                              p_reason_state_id VARCHAR2 := NULL, --Motivo cambio de estado
                              p_type_sds        VARCHAR2 := NULL, --Tipo de Tramite
                              p_err_number      OUT NUMBER,
                              p_err_message     OUT VARCHAR2,
                              p_result          OUT NUMBER) IS
    v_result NUMBER;
  BEGIN
    v_result := f_dth_change_status_sds(p_sds_id          => p_sds_id,
                                        p_status          => p_status,
                                        p_user            => p_user,
                                        p_observation     => p_observation,
                                        p_type            => p_type_sds,
                                        p_ent_id          => p_id_contratista,
                                        p_schedule_date   => p_schedule_date,
                                        p_reason_finish   => p_reason_finish,
                                        p_reason_state_id => p_reason_state_id,
                                        p_err_number      => p_err_number,
                                        p_err_message     => p_err_message,
                                        p_result          => p_result);
    IF v_result != 0 THEN
      p_result := -1;
      ROLLBACK;
    ELSE
      /* !!!!importante!!!: --por post pc85176_cd85470
      Se pone en null el p_err_message cuando no hay error porque desde agenda validan este parametro  para saber si el proceso termino ok o no.
      ES decir ellos validan p_err_message is null --> ok si es distinto de null hubo error. Si bien esto no es lo correcto ya que ellos
      deberian validar el P_RESULT (por convenciC3n); hasta tanto desde agenda no hagan las modificaciones necesarias para validar el p_result
      debemos dejar este parametro p_err_message = null aqui para no tener problemas cuando desde PROD venga con un OK por ejemplo,ya que ellos
      informan esto como un error!! mas alla de que no lo sea. por eso OJO! no cambiar esto hasta que del lado de agenda no hagan las modificaciones
      correspondientes!!
      */
      p_err_message := NULL; --por post pc85176_cd85470
    END IF;
  END change_status_sds;
  --****************************
  PROCEDURE getsdssactives(p_cursor         OUT refcur,
                           p_docu_tipo      NUMBER := NULL,
                           p_docu_tipo_nro  NUMBER := NULL,
                           p_id_contratista NUMBER,
                           p_technology_id  VARCHAR2 := NULL,
                           p_reason_id      VARCHAR2 := NULL,
                           p_operacion_id   VARCHAR2 := NULL,
                           p_estado_id      VARCHAR2 := NULL,
                           p_without_reason VARCHAR2 := NULL,
                           p_error          OUT VARCHAR2,
                           p_segmento       VARCHAR2 := null -- PC77402 RESIDENCIAL, PYME, CORPORATIVO
                           ) IS
    vexec VARCHAR2(200);
    vsql  CLOB; --PC144705VARCHAR2(4000);
    v_segmento_res VARCHAR2(100); --CFI-234
    v_pais varchar2(10);--CFI-234
  BEGIN
    vexec := 'ws_ag_sth_ifaces.Getsdssactives';
    --Campo motivo comienzo=asd_reason_start
    --Campo motivo comienzo=asd_reason_finish
    --CLT_NAME ||' '||CLT_SURNAME,--clt_keyname,se comenta por PC85176_CD85470_PO2
    --Comienzo CFI-234
    BEGIN
      SELECT fsp.fsp_char_value
        INTO v_segmento_res
        FROM fixed_services_parameters fsp
       WHERE fsp.fsp_parameter = 'AGERES';
    EXCEPTION
      WHEN OTHERS THEN
        p_error:= 'No se encontro el parametro AGERES';
    END;
   --FIN CFI-234
    vsql := 'Select
              Sds.Asd_Id_Sds,
              sds.asd_status,
              sds.asd_ast_type,
              sds.asd_clu_cellular_number,
              sds.asd_num_scard,
              sds.asd_num_deco,
              sds.asd_observation,
              sds.asd_create_user,
              sds.asd_create_date,
              sds.asd_lastmodif_user,
              sds.asd_lastmodif_date,
              sds.asd_tck_id,
              sds.asd_swf_id,
              sds.asd_reason_start,
              sds.asd_reason_finish,
              sds.asd_deco_type,
              sds.asd_schedule_date,
              sds.asd_usr_id,
              sds.asd_clt_type,
              sds.asd_usr_assign,
              C.Clt_id,
          C.clt_name ||'' ''||C.clt_surname CLT_KEYNAME ,
          Aca.Aaa_address_street || '' ''  || Aca.Aaa_address_number ||
         '' piso:'' || NVL(Aca.Aaa_address_floor, ''-'') || '' depto:'' ||
          NVL(Aca.Aaa_address_flat, ''-'') || '' CP:'' ||
          NVL(Aca.Aaa_zip_code,''-'') Domicilio,
          (SELECT rss_description
            FROM history_state_sds hs1, reason_sds_state
           WHERE rss_type in (''I'',''R'')
             AND rss_id = hss_rss_id
             AND hs1.hss_id = (SELECT MAX (hss.hss_id)
                                 FROM history_state_sds hss
                                WHERE hss.hss_asd_id_sds = sds.asd_id_sds)
             AND hs1.hss_asd_id_sds = sds.asd_id_sds) motivocierre,
          Sds.asd_usr_assign Legajo,
         aaa_reg_name Provincia,
         aaa_address_city Localidad,
         pro_mode_type,
         rpl_description PLAN_COMERCIAL,
         asd_usr_id TOMADO_POR,
         (SELECT srf_id FROM service_request_forms WHERE srf_form_number = asd_sds_id AND srf_srf_id IS NULL) as formnumber,
          aaa_cit_id As cit_id, --PC100056 Luciano Nitardi-PC101348 Se quitaron los campos y se reformulo la consulta
          asd_tck_obs Obser_Ticket,
(select decode(count(1), 0, ''N'',''Y'')
from ag_sds_details
where agd_cbt_id=''IPTV''
and agd_asd_id_sds=asd_id_sds) tiene_iptv
     From Ag_sds                Sds,
          Cellular_address      Ca,
          Account_alt_addresses Aca,
          Accounts              Ac,
          Client                C,
          Cellular_terminals,
          Products,
          cellular_plans,
          rate_plans
    Where  Sds.Asd_clu_cellular_number = Ca.Cad_clu_cellular_number
      and cpl_clu_cellular_number = Cad_clu_cellular_number
      and cpl_stg_id in (''AH'',''FN'')
      and cpl_start_date < sysdate
      and nvl(cpl_end_date, sysdate+1) > sysdate
      and cpl_rpl_id = rpl_id
      And Cad_aaa_id = Aaa_id
      And Aaa_aat_id = 2
      And nvl(Ca.cad_start_date, sysdate -1) <= sysdate
      And nvl(Ca.cad_end_date, sysdate + 1) > sysdate
      And Acc_clt_id = Clt_id
      And Acc_id = Aaa_acc_id
      AND Cet_clu_cellular_number = Ca.Cad_clu_cellular_number
      AND Cet_end_date IS NULL
      AND Pro_id = Cet_pro_id';
    --Condicion Contratista
    IF p_id_contratista > 0 THEN
      vsql := vsql || '  AND asd_ent_id=' || p_id_contratista;
      ----Contratista
    END IF;
    --Condicion tipo operacion
    IF p_operacion_id IS NOT NULL THEN
      vsql := vsql || ' and Sds.asd_ast_type=''' || p_operacion_id || '''';
      ---Operacion o Tipo de SDS
    END IF;
    --Condicion Estado
    IF p_estado_id IS NOT NULL THEN
      vsql := vsql || ' and Sds.ASD_STATUS=''' || p_estado_id || '''';
      ---Estado SDS
    ELSE
      vsql := vsql || ' and Sds.ASD_STATUS IN (''A'',''EP'',''S'')';
      ---Estado SDS
    END IF;
    --Condicion tipo y nro de documento
    IF p_docu_tipo = 0 AND p_docu_tipo_nro IS NOT NULL THEN
      vsql := vsql || ' and Sds.ASD_ID_SDS=' || p_docu_tipo_nro; ---SDS
    ELSIF p_docu_tipo = 1 AND p_docu_tipo_nro IS NOT NULL THEN
      vsql := vsql || ' and Sds.ASD_TCK_ID=' || p_docu_tipo_nro; --TICKET
    ELSIF p_docu_tipo = 2 AND p_docu_tipo_nro IS NOT NULL THEN
      vsql := vsql || ' and Sds.ASD_CLU_CELLULAR_NUMBER=''' || '0' ||
              TO_CHAR(p_docu_tipo_nro) || ''''; ---NB: Servicio
    ELSIF p_docu_tipo = 3 AND p_docu_tipo_nro IS NOT NULL THEN
      vsql := vsql || ' and Sds.ASD_SWF_ID=' || p_docu_tipo_nro;
      ---SOLICITUD WF
    END IF;
    --Condicion motivo interrupcion
    --PC107838
    IF p_reason_id IS NOT NULL THEN
      /*vsql := vsql || ' and Sds.ASD_REASON_FINISH=''' || p_reason_id || '''';*/
      vsql := vsql ||
              ' and exists (select 1 from history_state_sds hs1,REASON_SDS_STATE where RSS_TYPE = ''I''
                                          and rss_id = hss_rss_id and hs1.hss_id =(
                                          select max(hss.hss_id) FROM history_state_sds hss
                                          where hss.hss_asd_id_sds = Sds.asd_id_sds) and hs1.hss_asd_id_sds = Sds.asd_id_sds and hs1.hss_rss_id = ''' ||
              p_reason_id || ''' ) ';
    END IF;
    vsql := vsql ||
            'and not exists (select 1 from history_state_sds hs1,REASON_SDS_STATE where RSS_TYPE =''C''
                                          and rss_id = hss_rss_id and hs1.hss_id =(
                                          select max(hss.hss_id) FROM history_state_sds hss
                                          where hss.hss_asd_id_sds = Sds.asd_id_sds) and hs1.hss_asd_id_sds = Sds.asd_id_sds) ';
    --fin PC107838
    --Condicion technology
    IF p_technology_id IS NOT NULL THEN
      vsql := vsql || ' and pro_mode_type=''' || p_technology_id || '''';
      ---Motivo Cierre
    END IF;
   --Inicio CFI-234
   IF p_segmento IS NOT NULL THEN
      SELECT stl_char_value
        INTO  v_pais
        FROM  stl_parameters stl
       WHERE  stl.stl_id = 'FCTRY';
     IF v_pais='AR' THEN
       IF p_segmento =  v_segmento_res THEN
         Vsql := Vsql || ' and asd_clt_type IN (SELECT FSP.FSP_CHAR_VALUE FROM FIXED_SERVICES_PARAMETERS FSP
         WHERE fsp.fsp_parameter = ''AGCLRE'' )';
         ELSE
         Vsql := Vsql || ' and asd_clt_type IN (SELECT FSP.FSP_CHAR_VALUE FROM FIXED_SERVICES_PARAMETERS FSP
         WHERE fsp.fsp_parameter = ''AGCLCO'' )';
       END IF;
     ELSE
       Vsql := Vsql || ' and asd_clt_type=''' || p_segmento || '''';
     END IF;
   END IF;
   --Fin CFI-234
    OPEN p_cursor FOR vsql;
  EXCEPTION
    WHEN OTHERS THEN
      p_error := SQLERRM || ' - ' || vexec;
  END getsdssactives;
  --****************************
  PROCEDURE getsdssfordiary(p_cursor        OUT refcur,
                            p_docu_tipo     NUMBER := NULL,
                            p_docu_tipo_nro NUMBER := NULL,
                            p_operacion_id  VARCHAR2 := NULL, --'INST','VITEC'
                            p_estado_id     VARCHAR2 := NULL, --'D,C,A,S..'
                            p_reason_id     IN VARCHAR2 := NULL,
                            p_linea_dth     IN VARCHAR2,
                            p_fecha_desde   IN DATE,
                            p_fecha_hasta   IN DATE,
                            p_error         OUT VARCHAR2,
                            P_segmento      VARCHAR2 := null -- PC77402
                            ) IS
    vexec          VARCHAR2(200);
    vsql           CLOB; --PC144705VARCHAR2(4000);
    v_operacion_id VARCHAR2(10);
    v_estado_id    VARCHAR2(2);
    v_segmento_res VARCHAR2(100);--CFI-234
    v_pais varchar2(10);--CFI-234
  BEGIN
    vexec := 'ws_ag_sth_ifaces.Getsdssfordiary';
    IF p_operacion_id IS NULL THEN
      v_operacion_id := 'INST';
    ELSE
      v_operacion_id := p_operacion_id;
    END IF;
    IF p_estado_id IS NULL THEN
      v_estado_id := 'D';
    ELSE
      v_estado_id := p_estado_id;
    END IF;
   --Comienzo CFI-234
    BEGIN
      SELECT fsp.fsp_char_value
        INTO v_segmento_res
        FROM fixed_services_parameters fsp
       WHERE fsp.fsp_parameter = 'AGERES';
    EXCEPTION
      WHEN OTHERS THEN
        p_error:= 'No se encontro el parametro AGERES';
    END;
   --FIN CFI-234
    --Campo Aca.aaa_gps_lat=Latitud
    --Campo Aca.aaa_gps_long=Longuitud
    --CLT_NAME ||' '||CLT_SURNAME,--clt_keyname,se comenta por PC85176_CD85470_PO2
    vsql := '
           WITH Tmp
                   AS (SELECT /*+ ordered
                                                                        full(sds) full(ca) use_hash(sds,ca)
                                                                        index(aca,AAA_PK)
                                                                        index(ac,ACC_PK)
                                                                        index(c,CLT_PK)
                                                                        index(cpc,CIT_PK)
                                                                        index(aes,PK_A_ENTIDADES)
                                                                        use_nl(ca,aca,ac,c,cpc,aes)*/
                             Sds.*,
                              c.Clt_Id,
                               C.clt_name ||'' ''||C.clt_surname CLT_KEYNAME,
  Aca.Aaa_address_street || '' ''  || Aca.Aaa_address_number ||
         '' piso:'' || NVL(Aca.Aaa_address_floor, ''-'') || '' depto:'' ||
          NVL(Aca.Aaa_address_flat, ''-'') || '' CP:'' ||
          NVL(Aca.Aaa_zip_code, ''-'') || ''Lat.:''||
          NVL(to_char(Aca.aaa_gps_lat), ''-'')|| ''Long.:''||
          NVL(to_char(Aca.aaa_gps_long), ''-'') Domicilio,
          Sds.ASD_REASON_START || ''|'' || Sds.ASD_REASON_FINISH motivo,
          aaa_reg_name Provincia,
         aaa_address_city Localidad,
         aaa_gps_lat Latitud,
         aaa_gps_long Longitud,
        (SELECT RSS.RSS_DESCRIPTION motivo_des
            FROM reason_sds_state rss, interruption_closed_reasons
           WHERE RSS.RSS_ID=(SELECT MAX(HSS_RSS_ID)
                               FROM HISTORY_STATE_SDS
                              WHERE HSS_ASD_ID_SDS=Sds.ASD_ID_SDS)
              and RSS.RSS_ID = icr_rss_id
             AND icr_STATE = sds.Asd_Status
          and ICR_AST_TYPE = Sds.asd_ast_type
          AND NVL(ICR_START_DATE, SYSDATE - 1) <= SYSDATE
          AND NVL(ICR_END_DATE, SYSDATE + 1) > SYSDATE
          ) AS motivointerrupcion,--PC141796
          asd_usr_id Legajo,
         (SELECT srf_id FROM service_request_forms WHERE srf_form_number = asd_sds_id AND srf_srf_id IS NULL) as formnumber,
         aaa_cit_id As cit_id,--PC100056 Luciano Nitardi
         asd_tck_obs Obser_Ticket,
          asd_ent_id_inst Ent_inst ,
          asd_ent_id_tec Ent_Serv_Tec,
          asd_inst_warranty Garantia_instalacion,
          asd_tec_warranty Garantia_Servicio_tecnico,
          asd_inst_date Fecha_Instalacion,
          asd_tec_date fecha_serv_tec
                           FROM Ag_Sds Sds,
                              Cellular_Address Ca,
                              Account_Alt_Addresses Aca,
                              Accounts Ac,
                              Client c
                          WHERE ';
    vsql := vsql || ' Sds.Asd_Status = ''' || v_estado_id || '''';
    vsql := vsql || ' AND Sds.asd_ast_type = ''' || v_operacion_id || '''';
    vsql := vsql ||
            ' AND Ca.Cad_Clu_Cellular_Number = Sds.Asd_Clu_Cellular_Number
                              AND Aca.Aaa_Id = Ca.Cad_Aaa_Id
                          AND Aca.Aaa_Aat_Id = 2
                          And nvl(Ca.cad_start_date, sysdate -1) <= sysdate
                          And nvl(Ca.cad_end_date, sysdate + 1) > sysdate
                              AND Ac.Acc_Id = Aca.Aaa_Acc_Id
                              AND c.Clt_Id = Ac.Acc_Clt_Id';
    IF p_linea_dth IS NOT NULL THEN
      vsql := vsql || ' and Sds.Asd_clu_cellular_number LIKE ''' ||
              p_linea_dth || '%''';
    END IF;
    IF p_operacion_id IS NOT NULL THEN
      vsql := vsql || ' AND Sds.asd_ast_type = ''' || p_operacion_id || '''';
    END IF;
    IF p_fecha_desde IS NOT NULL THEN
      vsql := vsql || ' and Sds.Asd_create_date >= to_date(''' ||
              TO_CHAR(p_fecha_desde, 'DD/MM/YYYY') || ''',''DD/MM/YYYY'')';
    END IF;
    IF p_fecha_hasta IS NOT NULL THEN
      vsql := vsql || ' and Sds.Asd_create_date <= to_date(''' ||
              TO_CHAR(p_fecha_hasta, 'DD/MM/YYYY') || ''',''DD/MM/YYYY'')';
    END IF;
   --Inicio CFI-234
   IF p_segmento IS NOT NULL THEN
    SELECT  stl_char_value
      INTO  v_pais
      FROM  stl_parameters stl
     WHERE  stl.stl_id = 'FCTRY';
     IF v_pais='AR' THEN
      IF p_segmento =  v_segmento_res THEN
        Vsql := Vsql || ' and asd_clt_type IN (SELECT FSP.FSP_CHAR_VALUE FROM FIXED_SERVICES_PARAMETERS FSP
        WHERE fsp.fsp_parameter = ''AGCLRE'' )';
        ELSE
        Vsql := Vsql || ' and asd_clt_type IN (SELECT FSP.FSP_CHAR_VALUE FROM FIXED_SERVICES_PARAMETERS FSP
        WHERE fsp.fsp_parameter = ''AGCLCO'' )';
      END IF;
      ELSE
       Vsql := Vsql || ' and asd_clt_type=''' || p_segmento || '''';
     END IF;
    END IF;
   --Fin CFI-234
    IF p_docu_tipo = 0 AND p_docu_tipo_nro IS NOT NULL THEN
      vsql := vsql || ' and Sds.ASD_ID_SDS=' || p_docu_tipo_nro; ---SDS
    ELSIF p_docu_tipo = 1 AND p_docu_tipo_nro IS NOT NULL THEN
      vsql := vsql || ' and Sds.ASD_TCK_ID=' || p_docu_tipo_nro; --TICKET
    ELSIF p_docu_tipo = 2 AND p_docu_tipo_nro IS NOT NULL THEN
      vsql := vsql || ' and Sds.ASD_CLU_CELLULAR_NUMBER=''' || '0' ||
              TO_CHAR(p_docu_tipo_nro) || ''''; ---NB: Servicio
    ELSIF p_docu_tipo = 3 AND p_docu_tipo_nro IS NOT NULL THEN
      vsql := vsql || ' and Sds.ASD_SWF_ID=' || p_docu_tipo_nro;
      ---SOLICITUD WF
    END IF;
    --no mostrar las SDS con motivo de cierre
    vsql := vsql ||
            ' and not exists (select 1 from history_state_sds hs1,REASON_SDS_STATE where RSS_TYPE = ''C''
                                          and rss_id = hss_rss_id and hs1.hss_id =(
                                          select max(hss.hss_id) FROM history_state_sds hss
                                          where hss.hss_asd_id_sds = Sds.asd_id_sds) and hs1.hss_asd_id_sds = Sds.asd_id_sds) ';
    IF p_reason_id IS NOT NULL THEN
      vsql := vsql || ')  SELECT T1.*, t1.Asd_Ent_Id || Aes.Ent_Nombre_Oficial Entidad
                                FROM Tmp T1, a_Entidades Aes,  history_state_sds hss, reason_sds_state rss
                               WHERE Aes.Ent_Id = T1.Asd_Ent_Id
                                 AND t1.asd_id_sds = hss.hss_asd_id_sds
                                 AND hss.hss_rss_id = rss.rss_id
                                 AND rss.rss_id = ''' ||
              p_reason_id || '''';
    ELSE
      vsql := vsql || ' )
           SELECT T1.*, t1.Asd_Ent_Id || Aes.Ent_Nombre_Oficial Entidad
             FROM Tmp T1, a_Entidades Aes
            WHERE Aes.Ent_Id = T1.Asd_Ent_Id
           UNION ALL
           SELECT T2.*, ''Sin Datos'' Entidad
             FROM Tmp T2
            WHERE T2.Asd_Ent_Id IS NULL';
    END IF;
    --P_error := Vsql;
    OPEN p_cursor FOR vsql;
  EXCEPTION
    WHEN OTHERS THEN
      p_error := SQLERRM || ' - ' || vexec;
  END getsdssfordiary;
  PROCEDURE getstatusdesc(p_cursor OUT refcur,
                          p_aplic  IN VARCHAR2,
                          p_error  OUT VARCHAR2) IS
    vexec VARCHAR2(200);
  BEGIN
    vexec := 'ws_ag_sth_ifaces.Getstatusdesc';
    BEGIN
      OPEN p_cursor FOR
        SELECT sds_status_cod codigo, sds_status_des descripcion
          FROM sds_dth_status
         WHERE sds_aplic_view = p_aplic;
    EXCEPTION
      WHEN OTHERS THEN
        p_error := SQLERRM || ' - ' || vexec;
    END;
  END getstatusdesc;
  PROCEDURE getsdstype(p_aplic_view IN VARCHAR2,
                       p_cursor     OUT refcur,
                       p_error      OUT VARCHAR2) IS
    vexec VARCHAR2(200);
  BEGIN
    vexec := 'ws_ag_sth_ifaces.Getsdstype';
    BEGIN
      OPEN p_cursor FOR
        SELECT DISTINCT ast_type, ast_description, ast_complete_reason
          FROM ag_sds_type ast, ag_sds_aplic asa
         WHERE ast_view_flag = 'Y'
              ---indica si los contratistas pueden ver ese tipo de tramites
           AND asa.asa_aplic_view = p_aplic_view
           AND ast_type = asa.asa_ast_type;
    EXCEPTION
      WHEN OTHERS THEN
        p_error := SQLERRM || ' - ' || vexec;
    END;
  END getsdstype;
  PROCEDURE getreason_state(p_cursor   OUT refcur,
                            p_state    IN VARCHAR2 := NULL, --Estado que filtra los motivos
                            p_rsn_type IN VARCHAR2 := NULL,
                            --Parametro para filtrar los motivos (I=Interrupcion, C=Cierre)
                            p_error OUT VARCHAR2) IS
    vexec VARCHAR2(200);
    vsql  CLOB; --PC144705VARCHAR2(4000);
  BEGIN
    vexec := 'ws_ag_sth_ifaces.Getreason_state';
    vsql  := 'SELECT rss_id,rss_description,icr_ast_type as RSS_AST_TYPE, icr_state as RSS_STATE,rss_update,icr_end_date,icr_start_date
              FROM REASON_SDS_STATE, INTERRUPTion_CLOSED_REASONS
             where rss_id = icr_rss_id
               and icr_start_date <= sysdate
               and nvl(icr_end_date, sysdate+1)>sysdate and icr_rss_enabled = ''' || 'Y' || '''';
    IF p_state IS NOT NULL AND p_rsn_type IS NOT NULL THEN
      vsql := vsql || ' and icr_state=''' || p_state ||
              ''' and rss_type=''' || p_rsn_type || '''';
    END IF;
    IF p_rsn_type IS NOT NULL AND p_state IS NULL THEN
      vsql := vsql || ' and rss_type=''' || p_rsn_type || '''';
    END IF;
    IF p_rsn_type IS NULL AND p_state IS NOT NULL THEN
      vsql := vsql || ' and icr_state=''' || p_state || '''';
    END IF;
    OPEN p_cursor FOR vsql;
  EXCEPTION
    WHEN OTHERS THEN
      p_error := SQLERRM || ' - ' || vexec;
  END getreason_state;
  PROCEDURE udpreason_state(p_cursor      OUT refcur,
                            p_reason_id   IN VARCHAR2 := NULL,
                            p_description IN VARCHAR2 := NULL,
                            p_error       OUT VARCHAR2) IS
  BEGIN
    UPDATE reason_sds_state
       SET rss_description = p_description
     WHERE rss_id = p_reason_id
       AND rss_update = 'Y';
    --Indica que se puede actualizar, sin cambiar el estado
  EXCEPTION
    WHEN OTHERS THEN
      p_error := 'Error al actualizar el motivo' || SQLERRM;
  END;
  PROCEDURE gettecnologias(p_cursor OUT refcur, p_error OUT VARCHAR2) IS
    vexec VARCHAR2(200);
    vsql  CLOB; --PC144705VARCHAR2(4000);
  BEGIN
    vexec := 'ws_ag_sth_ifaces.getTecnologias';
    vsql  := 'SELECT pro_mode_type, tec_description from technology where pro_mode_type IN (''HFC'',''GPON'',''WMAX'',''DTH'') ';
    OPEN p_cursor FOR vsql;
  EXCEPTION
    WHEN OTHERS THEN
      p_error := SQLERRM || ' - ' || vexec;
  END gettecnologias;
  PROCEDURE set_asignara(p_sds_id IN NUMBER,
                         p_usr_id IN VARCHAR2,
                         p_error  OUT VARCHAR2) IS
  BEGIN
    UPDATE ag_sds
       SET asd_usr_assign = p_usr_id
     WHERE asd_id_sds = p_sds_id;
  EXCEPTION
    WHEN OTHERS THEN
      p_error := 'Error la actualizar el usuario ' || SQLERRM;
  END set_asignara;
  -- Inicio PC77402
  PROCEDURE GetSegmento(P_cursor OUT Refcur, P_error OUT VARCHAR2) IS
    Vexec VARCHAR2(200);
    vsql  CLOB; --PC144705VARCHAR2(4000);
    v_pais varchar2(10);--CFI-234
  BEGIN
    Vexec := 'ws_ag_sth_ifaces.GetSegmento';
    SELECT  stl_char_value
      INTO  v_pais
      FROM  stl_parameters stl
     WHERE  stl.stl_id = 'FCTRY';
    IF v_pais='AR' THEN
     Vsql  := 'select fsp.fsp_char_value AS stl_char_value from fixed_services_parameters fsp where fsp.fsp_parameter in (''AGECOR'',''AGERES'')'; --CFI-234
    ELSE
     Vsql  := 'select sp.stl_char_value from stl_parameters sp where sp.stl_id in (''AGCLTM'', ''AGCLTC'', ''AGCLTP'',''AGCLCI'', ''AGCLRI'', ''AGCLPI'',''AGCLPD'',''AGCLRD'',''AGCLCD'')'; --PC123967
    END IF;
    OPEN P_cursor FOR Vsql;
  EXCEPTION
    WHEN OTHERS THEN
      P_error := SQLERRM || ' - ' || Vexec;
  END GetSegmento;
  -- Fin PC77402
  --inicio  PC101555
  PROCEDURE get_last_reason(p_sds_id      IN NUMBER,
                            p_reason_id   OUT VARCHAR2,
                            p_reason      OUT VARCHAR2,
                            p_reason_type OUT VARCHAR2,
                            p_error       OUT VARCHAR2) IS
    V_ERROR VARCHAR2(4000); --PC144705VARCHAR2(255);
  BEGIN
    V_ERROR := 'BUSCO EL ULTIMO MOTIVO INGRESADO DE LA OT';
    SELECT RSS_ID, RSS_DESCRIPTION, RSS_TYPE
      INTO P_REASON_ID, P_REASON, P_REASON_TYPE
      FROM REASON_SDS_STATE RSS, HISTORY_STATE_SDS HSS
     WHERE RSS.RSS_ID = HSS.HSS_RSS_ID
       AND NVL(HSS.HSS_END_DATE, SYSDATE + 1) > SYSDATE
       AND HSS.HSS_ASD_ID_SDS = P_SDS_ID;
    V_ERROR := 'VERIFICO SI CON EL ULTIMO MOTIVO INGRESADO';
    BEGIN
      SELECT RSS_ID, RSS_DESCRIPTION, RSS_TYPE
        INTO P_REASON_ID, P_REASON, P_REASON_TYPE
        FROM REASON_SDS_STATE
       WHERE RSS_ID = P_REASON_ID
         AND RSS_TYPE = P_REASON_TYPE;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_REASON_ID   := NULL;
        P_REASON      := NULL;
        P_REASON_TYPE := NULL;
    END;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      P_REASON_ID   := NULL;
      P_REASON      := NULL;
      P_REASON_TYPE := NULL;
    WHEN OTHERS THEN
      P_ERROR := 'ERROR AL BUSCAR EL ULTIMO MOTIVO INGRESADO ' || SQLERRM ||
                 V_ERROR;
  END Get_Last_Reason;
  --FINPC101555
  --INICIO PC110203
  PROCEDURE abm_reason(P_REASON_ID    IN VARCHAR2 := NULL,
                       P_DESCRIPCION  IN VARCHAR2 := NULL,
                       P_TYPE         IN VARCHAR2 := NULL,
                       P_RSS_UPDATE   IN VARCHAR2 := NULL,
                       P_RSS_PERMITED IN VARCHAR2 := NULL,
                       P_MODO         IN VARCHAR2, /*A=ALTA,B=BAJA, M=MODIFICACION*/
                       P_RSN_ID_OUT   OUT VARCHAR2,
                       P_ERROR        OUT VARCHAR2) IS
    V_RSS_ID      REASON_SDS_STATE.RSS_ID%TYPE;
    V_DESCRIPTION REASON_SDS_STATE.RSS_DESCRIPTION%TYPE;
  BEGIN
    IF P_MODO = 'A' THEN
      BEGIN
        SELECT RSS_SEC.NEXTVAL INTO P_RSN_ID_OUT FROM DUAL;
        INSERT INTO REASON_SDS_STATE
          (RSS_ID, RSS_DESCRIPTION, RSS_UPDATE, RSS_PERMITED, RSS_TYPE)
        VALUES
          (P_RSN_ID_OUT,
           P_DESCRIPCION,
           P_RSS_UPDATE,
           P_RSS_PERMITED,
           P_TYPE);
      EXCEPTION
        WHEN OTHERS THEN
          P_ERROR := 'ERROR AL QUERER REGISTRAR EL MOTIVO ' ||
                     P_DESCRIPCION || '.' || SQLERRM;
      END;
    END IF;
    IF P_MODO = 'M' THEN
      BEGIN
        SELECT RSS_ID, RSS_DESCRIPTION
          INTO V_RSS_ID, V_DESCRIPTION
          FROM REASON_SDS_STATE
         WHERE RSS_ID = P_REASON_ID;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          P_ERROR := 'EL MOTIVO QUE DESEA ACTUALIZAR NO EXISTE.';
      END;
      BEGIN
        UPDATE REASON_SDS_STATE
           SET RSS_DESCRIPTION = P_DESCRIPCION,
               RSS_UPDATE      = P_RSS_UPDATE,
               RSS_PERMITED    = P_RSS_PERMITED,
               RSS_TYPE        = P_TYPE
         WHERE RSS_ID = P_REASON_ID;
      EXCEPTION
        WHEN OTHERS THEN
          P_ERROR := 'ERROR AL QUERER ACTUALIZAR EL MOTIVO ' ||
                     V_DESCRIPTION || '.' || SQLERRM;
      END;
    END IF;
    IF P_MODO = 'B' THEN
      BEGIN
        SELECT RSS_ID, RSS_DESCRIPTION
          INTO V_RSS_ID, V_DESCRIPTION
          FROM REASON_SDS_STATE
         WHERE RSS_ID = P_REASON_ID;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          P_ERROR := 'EL MOTIVO QUE DESEA ELIMINAR NO EXISTE.';
      END;
      BEGIN
        UPDATE INTERRUPTION_CLOSED_REASONS
           SET ICR_END_DATE = SYSDATE
         WHERE ICR_RSS_ID = P_REASON_ID
           AND NVL(ICR_END_DATE, SYSDATE + 1) > SYSDATE;
      EXCEPTION
        WHEN OTHERS THEN
          P_ERROR := 'ERROR AL QUERER DAR DE BAJA EL MOTIVO' ||
                     V_DESCRIPTION || SQLERRM;
      END;
    END IF;
  END;
  PROCEDURE ab_interruption_closed_reasons(P_REASON_ID  IN VARCHAR2,
                                           P_STATE      IN VARCHAR2,
                                           P_START_DATE IN DATE := SYSDATE,
                                           P_END_DATE   IN DATE := NULL,
                                           P_OT_TYPE    IN VARCHAR2 := NULL,
                                           P_STATE_NEXT IN VARCHAR2,
                                           P_CBT_ID     IN VARCHAR2,
                                           P_ENABLED    IN VARCHAR2 := 'Y',
                                           P_MODO       IN VARCHAR2, /*A=ALTA,B=BAJA*/
                                           P_ERROR      OUT VARCHAR2) IS
    V_RSS_ID REASON_SDS_STATE.RSS_ID%TYPE;
  BEGIN
    IF P_MODO = 'A' THEN
      BEGIN
        SELECT ICR_RSS_ID
          INTO V_RSS_ID
          FROM INTERRUPTION_CLOSED_REASONS
         WHERE ICR_RSS_ID = P_REASON_ID
           AND ICR_STATE = P_STATE
           AND ICR_AST_TYPE = P_OT_TYPE
           AND ICR_STATE_NEXT = P_STATE_NEXT
           AND ICR_CBT_ID = P_CBT_ID
           AND NVL(ICR_END_DATE, SYSDATE + 1) > SYSDATE; --PC141796
        UPDATE INTERRUPTION_CLOSED_REASONS
           SET ICR_END_DATE = NULL, ICR_START_DATE = sysdate
         WHERE ICR_RSS_ID = P_REASON_ID
           AND ICR_STATE = P_STATE
           AND ICR_AST_TYPE = P_OT_TYPE
           AND ICR_STATE_NEXT = P_STATE_NEXT
           AND ICR_CBT_ID = P_CBT_ID
           AND NVL(ICR_END_DATE, SYSDATE + 1) > SYSDATE; --PC141796
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          BEGIN
            SELECT ICR_RSS_ID
              INTO V_RSS_ID
              FROM INTERRUPTION_CLOSED_REASONS
             WHERE ICR_RSS_ID = P_REASON_ID
               AND ICR_STATE = P_STATE
               AND ICR_AST_TYPE = P_OT_TYPE
               AND ICR_STATE_NEXT = P_STATE_NEXT
               AND ICR_CBT_ID = P_CBT_ID;
            P_ERROR := 'LA RELACION DEL MOTIVO/ESTADO/TYPO_DE_OT ' ||
                       P_REASON_ID || ' / ' || P_STATE || ' / ' ||
                       P_OT_TYPE || P_CBT_ID || ' YA EXISTE Y ESTA ACTIVA.';
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              BEGIN
                INSERT INTO INTERRUPTION_CLOSED_REASONS
                  (ICR_RSS_ID,
                   ICR_STATE,
                   ICR_START_DATE,
                   ICR_END_DATE,
                   ICR_AST_TYPE,
                   ICR_STATE_NEXT,
                   ICR_RSS_ENABLED,
                   ICR_CBT_ID)
                VALUES
                  (P_REASON_ID,
                   P_STATE,
                   P_START_DATE,
                   P_END_DATE,
                   P_OT_TYPE,
                   P_STATE_NEXT,
                   P_ENABLED,
                   P_CBT_ID);
              EXCEPTION
                WHEN OTHERS THEN
                  P_ERROR := 'ERROR AL QUERER REGISTRAR LA RELACION DEL MOTIVO/ESTADO/TYPO_DE_OT ' ||
                             P_REASON_ID || ' / ' || P_STATE || ' / ' ||
                             P_OT_TYPE || P_CBT_ID || SQLERRM;
              END;
          END;
      END;
    END IF;
    IF P_MODO = 'B' THEN
      BEGIN
        SELECT ICR_RSS_ID
          INTO V_RSS_ID
          FROM INTERRUPTION_CLOSED_REASONS
         WHERE ICR_RSS_ID = P_REASON_ID
           AND ICR_STATE = P_STATE
           AND ICR_AST_TYPE = P_OT_TYPE
           AND ICR_STATE_NEXT = P_STATE_NEXT
           AND ICR_CBT_ID = P_CBT_ID
           AND NVL(ICR_END_DATE, SYSDATE + 1) > SYSDATE; --PC141796
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          P_ERROR := 'LA RELACION MOTIVO/ESTADO/TYPO_DE_OT QUE DESEA ELIMINAR NO EXISTE.';
      END;
      BEGIN
        UPDATE INTERRUPTION_CLOSED_REASONS
           SET ICR_END_DATE = SYSDATE
         WHERE ICR_RSS_ID = P_REASON_ID
           AND ICR_STATE = P_STATE
           AND ICR_AST_TYPE = P_OT_TYPE
           AND ICR_STATE_NEXT = P_STATE_NEXT
           AND ICR_CBT_ID = P_CBT_ID
           AND NVL(ICR_END_DATE, SYSDATE + 1) > SYSDATE; --PC141796
      EXCEPTION
        WHEN OTHERS THEN
          P_ERROR := 'ERROR AL QUERER DAR DE BAJA LA RELACION DEL MOTIVO/ESTADO/TYPO_DE_OT/NUEVO_ESTADO ' ||
                     P_REASON_ID || ' / ' || P_STATE || ' / ' || P_OT_TYPE ||
                     ' / ' || P_STATE_NEXT || P_CBT_ID || '-' || SQLERRM;
      END;
    END IF;
  END;
  -- FIN PC110203
  --INICIO PC121204
  PROCEDURE getreason_state_full(p_cursor     OUT refcur,
                                 p_state      IN VARCHAR2 := NULL, --Estado inicial que filtra los motivos
                                 p_rsn_type   IN VARCHAR2 := NULL, --Tipo de los motivos (I=Interrupcion, C=Cierre)
                                 p_reasons_id IN VARCHAR2 := NULL, --IdMotivo
                                 p_tipo_ot    IN VARCHAR2 := NULL, --Tipo de Tramite asociada a los motivos
                                 p_cbt_id     IN VARCHAR2 := NULL, --Tipo de Negocio asociada a los motivos
                                 p_error      OUT VARCHAR2) IS
    vexec VARCHAR2(200);
    vsql  CLOB; --PC144705VARCHAR2(4000);
  BEGIN
    vexec := 'ws_ag_sth_ifaces.getreason_state_full';
    vsql  := 'SELECT rss_id AS ID_MOTIVO,rss_description as Descripcion , icr_ast_type as Tramite,rss_type as Tipo_Motivo, icr_state as Estado_Inicial,icr_state_next as Estado_Final,icr_cbt_id as Negocio,icr_start_date as Fecha_Inicio, icr_end_date as Fecha_fin
              FROM REASON_SDS_STATE, INTERRUPTION_CLOSED_REASONS
             where rss_id = icr_rss_id
             AND icr_rss_enabled = ''' || 'Y' || '''
             AND icr_end_date is null';---CFI-166
    IF p_rsn_type IS NOT NULL THEN
      vsql := vsql || ' and rss_type=''' || p_rsn_type || '''';
    END IF;
    IF p_state IS NOT NULL THEN
      vsql := vsql || ' and icr_state=''' || p_state || '''';
    END IF;
    IF p_reasons_id IS NOT NULL THEN
      vsql := vsql || ' and  rss_id=''' || p_reasons_id || '''';
    END IF;
    IF p_tipo_ot IS NOT NULL THEN
      vsql := vsql || ' and icr_ast_type=''' || p_tipo_ot || '''';
    END IF;
    IF p_cbt_id IS NOT NULL THEN
      vsql := vsql || ' and icr_cbt_id=''' || p_cbt_id || '''';
    END IF;
    OPEN p_cursor FOR vsql;
  EXCEPTION
    WHEN OTHERS THEN
      p_error := SQLERRM || ' - ' || vexec;
  END getreason_state_full;
  --FINPC121204
  --INICIO PC123967
  PROCEDURE getdetalle_OT(p_ot_id  IN NUMBER,
                          P_cursor OUT Refcur,
                          p_error  OUT VARCHAR2) IS
    vexec VARCHAR2(200);
    vsql  CLOB; --PC144705VARCHAR2(4000);
  BEGIN
    vexec := 'ws_ag_sth_ifaces.getdetalle_OT';
    vsql  := 'SELECT agd_aaa_id,
       agd_clu_cellular_number,
       agd_nse_id ,
       agd_mac_address  ,
       agd_pro_id,
       agd_pro_id_conex,
       agd_cbt_id,
       agd_guid,
       agd_lastmodif_usr,
       agd_lastmodif_date
  FROM ag_sds_details
  WHERE agd_asd_id_sds =' || p_ot_id;
    OPEN p_cursor FOR vsql;
  EXCEPTION
    WHEN OTHERS THEN
      p_error := SQLERRM || ' - ' || vexec;
  END getdetalle_OT;
  --FIN PC123967
  --INICIO PC136134
  PROCEDURE change_equipment(P_OT_ID       NUMBER,
                             P_RSN_ID      VARCHAR2,
                             P_ERR_NUMBER  OUT NUMBER,
                             P_ERR_MESSAGE OUT VARCHAR) IS
    V_RESULT NUMBER;
  BEGIN
    V_RESULT := F_TIF_AG_CHANGE_EQUIP(P_OT_ID       => P_OT_ID,
                                      P_RSN_ID      => P_RSN_ID,
                                      P_ERR_NUMBER  => P_ERR_NUMBER,
                                      P_ERR_MESSAGE => P_ERR_MESSAGE);
    IF V_RESULT != 0 THEN
      ROLLBACK;
    ELSE
      P_ERR_NUMBER  := 0;
      P_ERR_MESSAGE := NULL;
    END IF;
  END;
  
   PROCEDURE getsdssfordiary_2(p_cursor     OUT refcur,
                            p_docu_tipo     NUMBER := NULL,
                            p_docu_tipo_nro NUMBER := NULL,
                            p_operacion_id  VARCHAR2 := NULL, --'INST','VITEC'
                            p_estado_id     VARCHAR2 := NULL, --'D,C,A,S..'
                            p_reason_id     IN VARCHAR2 := NULL,
                            p_linea_dth     IN VARCHAR2,
                            p_fecha_desde   IN DATE,
                            p_fecha_hasta   IN DATE,
                            p_error         OUT VARCHAR2,
                            P_segmento      VARCHAR2 := NULL -- PC77402
                            ) IS
    vexec          VARCHAR2(200);
    vsql           CLOB; --PC144705VARCHAR2(4000);
    v_operacion_id VARCHAR2(10);
    v_estado_id    VARCHAR2(2);
    v_segmento_res VARCHAR2(100);--CFI-234
    v_pais varchar2(10);--CFI-234

  /* CFI-360 - NOEL CELIZ - Se agrega procedimiento getsdssfordiary_2 */

  BEGIN
    vexec := 'ws_ag_sth_ifaces.Getsdssfordiary_2';
    IF p_operacion_id IS NULL THEN
      v_operacion_id := 'INST';
    ELSE
      v_operacion_id := p_operacion_id;
    END IF;
    IF p_estado_id IS NULL THEN
      v_estado_id := 'D';
    ELSE
      v_estado_id := p_estado_id;
    END IF;

   --Comienzo CFI-234
    BEGIN
      SELECT fsp.fsp_char_value
        INTO v_segmento_res
        FROM fixed_services_parameters fsp
       WHERE fsp.fsp_parameter = 'AGERES';
    EXCEPTION
      WHEN OTHERS THEN
        p_error:= 'No se encontro el parametro AGERES';
    END;
   --FIN CFI-234
    --Campo Aca.aaa_gps_lat=Latitud
    --Campo Aca.aaa_gps_long=Longuitud
    --CLT_NAME ||' '||CLT_SURNAME,--clt_keyname,se comenta por PC85176_CD85470_PO2
    vsql :=  'Select         Sds.Asd_Id_Sds ot,
                             Sds.Asd_Tck_Id tickler,
                             Sds.Asd_Clu_Cellular_Number cellular,
                              c.Clt_Id cliente,
                               C.clt_name ||'' ''||C.clt_surname CLT_KEYNAME,
  Aca.Aaa_address_street || '' ''  || Aca.Aaa_address_number ||
         '' piso:'' || NVL(Aca.Aaa_address_floor, ''-'') || '' depto:'' ||
          NVL(Aca.Aaa_address_flat, ''-'') || '' CP:'' ||
          NVL(Aca.Aaa_zip_code, ''-'') || ''Lat.:''||
          NVL(to_char(Aca.aaa_gps_lat), ''-'')|| ''Long.:''||
          NVL(to_char(Aca.aaa_gps_long), ''-'') Domicilio,
          aaa_address_city Localidad,
          aaa_reg_name Provincia,
          Sds.Asd_Ast_Type tipotramite,
          Sds.Asd_Create_Date fechacre,
          Sds.Asd_Clt_Type segmento,
          Sds.Asd_Sds_Id nrosolic,
         (SELECT Asd_Ent_Id ||'' ''|| Ent_Nombre_Oficial from a_Entidades WHERE ent_id = asd_ent_id) as entidad,
          Sds.Asd_reason_start operc,
          Sds.Asd_reason_start motivO,
         (SELECT srf_id FROM service_request_forms WHERE srf_form_number = asd_sds_id AND srf_srf_id IS NULL) as formnumber
                           FROM Ag_Sds Sds,
                              Cellular_Address Ca,
                              Account_Alt_Addresses Aca,
                              Accounts Ac,
                              Client c
                          WHERE ';
    vsql := vsql || ' Sds.Asd_Status = ''' || v_estado_id || '''';
    vsql := vsql || ' AND Sds.asd_ast_type = ''' || v_operacion_id || '''';
    vsql := vsql ||
            ' AND Ca.Cad_Clu_Cellular_Number = Sds.Asd_Clu_Cellular_Number
                              AND Aca.Aaa_Id = Ca.Cad_Aaa_Id
                          AND Aca.Aaa_Aat_Id = 2
                          And nvl(Ca.cad_start_date, sysdate -1) <= sysdate
                          And nvl(Ca.cad_end_date, sysdate + 1) > sysdate
                              AND Ac.Acc_Id = Aca.Aaa_Acc_Id
                              AND c.Clt_Id = Ac.Acc_Clt_Id';
    IF p_linea_dth IS NOT NULL THEN
      vsql := vsql || ' and Sds.Asd_clu_cellular_number LIKE ''' ||
              p_linea_dth || '%''';
    END IF;
/*    IF p_operacion_id IS NOT NULL THEN
      vsql := vsql || ' AND Sds.asd_ast_type = ''' || p_operacion_id || '''';
    END IF;*/
    IF p_fecha_desde IS NOT NULL THEN
      vsql := vsql || ' and Sds.Asd_create_date >= to_date(''' ||
              TO_CHAR(p_fecha_desde, 'DD/MM/YYYY') || ''',''DD/MM/YYYY'')';
    END IF;
    IF p_fecha_hasta IS NOT NULL THEN
      vsql := vsql || ' and Sds.Asd_create_date <= to_date(''' ||
              TO_CHAR(p_fecha_hasta, 'DD/MM/YYYY') || ''',''DD/MM/YYYY'')';
    END IF;
   --Inicio CFI-234
   IF p_segmento IS NOT NULL THEN
    SELECT  stl_char_value
      INTO  v_pais
      FROM  stl_parameters stl
     WHERE  stl.stl_id = 'FCTRY';
     IF v_pais='AR' THEN
      IF p_segmento =  v_segmento_res THEN
        Vsql := Vsql || ' and asd_clt_type IN (SELECT FSP.FSP_CHAR_VALUE FROM FIXED_SERVICES_PARAMETERS FSP
        WHERE fsp.fsp_parameter = ''AGCLRE'' )';
        ELSE
        Vsql := Vsql || ' and asd_clt_type IN (SELECT FSP.FSP_CHAR_VALUE FROM FIXED_SERVICES_PARAMETERS FSP
        WHERE fsp.fsp_parameter = ''AGCLCO'' )';
      END IF;
      ELSE
       Vsql := Vsql || ' and asd_clt_type=''' || p_segmento || '''';
     END IF;
    END IF;
   --Fin CFI-234
    IF p_docu_tipo = 0 AND p_docu_tipo_nro IS NOT NULL THEN
      vsql := vsql || ' and Sds.ASD_ID_SDS=' || p_docu_tipo_nro; ---SDS
    ELSIF p_docu_tipo = 1 AND p_docu_tipo_nro IS NOT NULL THEN
      vsql := vsql || ' and Sds.ASD_TCK_ID=' || p_docu_tipo_nro; --TICKET
    ELSIF p_docu_tipo = 2 AND p_docu_tipo_nro IS NOT NULL THEN
      vsql := vsql || ' and Sds.ASD_CLU_CELLULAR_NUMBER=''' || '0' ||
              TO_CHAR(p_docu_tipo_nro) || ''''; ---NB: Servicio
    ELSIF p_docu_tipo = 3 AND p_docu_tipo_nro IS NOT NULL THEN
      vsql := vsql || ' and Sds.ASD_SWF_ID=' || p_docu_tipo_nro;
      ---SOLICITUD WF
    END IF;
    --no mostrar las SDS con motivo de cierre
    vsql := vsql ||
            ' and not exists (select 1 from history_state_sds hs1,REASON_SDS_STATE where RSS_TYPE = ''C''
                                          and rss_id = hss_rss_id and hs1.hss_id =(
                                          select max(hss.hss_id) FROM history_state_sds hss
                                          where hss.hss_asd_id_sds = Sds.asd_id_sds) and hs1.hss_asd_id_sds = Sds.asd_id_sds) ';
 /*   IF p_reason_id IS NOT NULL THEN
      vsql := vsql || ')  SELECT T1.*, t1.Asd_Ent_Id || Aes.Ent_Nombre_Oficial Entidad
                                FROM Tmp T1, a_Entidades Aes,  history_state_sds hss, reason_sds_state rss
                               WHERE Aes.Ent_Id = T1.Asd_Ent_Id
                                 AND t1.asd_id_sds = hss.hss_asd_id_sds
                                 AND hss.hss_rss_id = rss.rss_id
                                 AND rss.rss_id = ''' ||
              p_reason_id || '''';
    ELSE
      vsql := vsql || ' )
           SELECT T1.*, t1.Asd_Ent_Id || Aes.Ent_Nombre_Oficial Entidad
             FROM Tmp T1, a_Entidades Aes
            WHERE Aes.Ent_Id = T1.Asd_Ent_Id
           UNION ALL
           SELECT T2.*, ''Sin Datos'' Entidad
             FROM Tmp T2
            WHERE T2.Asd_Ent_Id IS NULL';
    END IF;*/
    --P_error := Vsql;
    OPEN p_cursor FOR vsql;
  EXCEPTION
    WHEN OTHERS THEN
      p_error := SQLERRM || ' - ' || vexec;
  END getsdssfordiary_2;

  PROCEDURE getsdssactives_2(p_cursor         OUT refcur,
                           p_docu_tipo      NUMBER := NULL,
                           p_docu_tipo_nro  NUMBER := NULL,
                           p_id_contratista NUMBER,
                           p_technology_id  VARCHAR2 := NULL,
                           p_reason_id      VARCHAR2 := NULL,
                           p_operacion_id   VARCHAR2 := NULL,
                           p_estado_id      VARCHAR2 := NULL,
                           p_without_reason VARCHAR2 := NULL,
                           p_error          OUT VARCHAR2,
                           p_segmento       VARCHAR2 := null -- PC77402 RESIDENCIAL, PYME, CORPORATIVO
                           ) IS
    vexec VARCHAR2(200);
    vsql  CLOB; --PC144705VARCHAR2(4000);
    v_segmento_res VARCHAR2(100); --CFI-234
    v_pais varchar2(10);--CFI-234

 /* CFI-360 - NOEL CELIZ - Se agrega procedimiento getsdssactives_2 */

  BEGIN
    vexec := 'ws_ag_sth_ifaces.Getsdssactives';
    --Campo motivo comienzo=asd_reason_start
    --Campo motivo comienzo=asd_reason_finish
    --CLT_NAME ||' '||CLT_SURNAME,--clt_keyname,se comenta por PC85176_CD85470_PO2

    --Comienzo CFI-234
    BEGIN
      SELECT fsp.fsp_char_value
        INTO v_segmento_res
        FROM fixed_services_parameters fsp
       WHERE fsp.fsp_parameter = 'AGERES';
    EXCEPTION
      WHEN OTHERS THEN
        p_error:= 'No se encontro el parametro AGERES';
    END;
   --FIN CFI-234

    vsql := ' Select
              sds.Asd_Id_Sds,
              sds.asd_create_date,
              sds.asd_clu_cellular_number,
              sds.asd_status,
              sds.asd_ast_type,
              sds.asd_deco_type,
              (SELECT rss_description
            FROM history_state_sds hs1, reason_sds_state
           WHERE rss_type in (''I'',''R'')
             AND rss_id = hss_rss_id
             AND hs1.hss_id = (SELECT MAX (hss.hss_id)
                                 FROM history_state_sds hss
                                WHERE hss.hss_asd_id_sds = sds.asd_id_sds)
             AND hs1.hss_asd_id_sds = sds.asd_id_sds) motivocierre,
          C.clt_name ||'' ''||C.clt_surname CLT_KEYNAME ,
          Aca.Aaa_address_street || '' ''  || Aca.Aaa_address_number ||
         '' piso:'' || NVL(Aca.Aaa_address_floor, ''-'') || '' depto:'' ||
          NVL(Aca.Aaa_address_flat, ''-'') || '' CP:'' ||
          NVL(Aca.Aaa_zip_code,''-'') Domicilio,
         aaa_address_city Localidad,
         aaa_reg_name Provincia,
         sds.asd_clt_type,
         pro_mode_type,
        (select decode(count(1), 0, ''N'',''Y'')
        from ag_sds_details
        where agd_cbt_id=''IPTV''
        and agd_asd_id_sds=asd_id_sds) tiene_iptv,
         aaa_cit_id As cit_id, --PC100056 Luciano Nitardi-PC101348 Se quitaron los campos y se reformulo la consulta
         rpl_description PLAN_COMERCIAL
     From Ag_sds                Sds,
          Cellular_address      Ca,
          Account_alt_addresses Aca,
          Accounts              Ac,
          Client                C,
          Cellular_terminals,
          Products,
          cellular_plans,
          rate_plans
    Where  Sds.Asd_clu_cellular_number = Ca.Cad_clu_cellular_number
      and cpl_clu_cellular_number = Cad_clu_cellular_number
      and cpl_stg_id in (''AH'',''FN'')
      and cpl_start_date < sysdate
      and nvl(cpl_end_date, sysdate+1) > sysdate
      and cpl_rpl_id = rpl_id
      And Cad_aaa_id = Aaa_id
      And Aaa_aat_id = 2
      And nvl(Ca.cad_start_date, sysdate -1) <= sysdate
      And nvl(Ca.cad_end_date, sysdate + 1) > sysdate
      And Acc_clt_id = Clt_id
      And Acc_id = Aaa_acc_id
      AND Cet_clu_cellular_number = Ca.Cad_clu_cellular_number
      AND Cet_end_date IS NULL
      AND Pro_id = Cet_pro_id';
    --Condicion Contratista
    IF p_id_contratista > 0 THEN
      vsql := vsql || '  AND asd_ent_id=' || p_id_contratista;
      ----Contratista
    END IF;
    --Condicion tipo operacion
    IF p_operacion_id IS NOT NULL THEN
      vsql := vsql || ' and Sds.asd_ast_type=''' || p_operacion_id || '''';
      ---Operacion o Tipo de SDS
    END IF;
    --Condicion Estado
    IF p_estado_id IS NOT NULL THEN
      vsql := vsql || ' and Sds.ASD_STATUS=''' || p_estado_id || '''';
      ---Estado SDS
    ELSE
      vsql := vsql || ' and Sds.ASD_STATUS IN (''A'',''EP'',''S'')';
      ---Estado SDS
    END IF;
    --Condicion tipo y nro de documento
    IF p_docu_tipo = 0 AND p_docu_tipo_nro IS NOT NULL THEN
      vsql := vsql || ' and Sds.ASD_ID_SDS=' || p_docu_tipo_nro; ---SDS
    ELSIF p_docu_tipo = 1 AND p_docu_tipo_nro IS NOT NULL THEN
      vsql := vsql || ' and Sds.ASD_TCK_ID=' || p_docu_tipo_nro; --TICKET
    ELSIF p_docu_tipo = 2 AND p_docu_tipo_nro IS NOT NULL THEN
      vsql := vsql || ' and Sds.ASD_CLU_CELLULAR_NUMBER=''' || '0' ||
              TO_CHAR(p_docu_tipo_nro) || ''''; ---NB: Servicio
    ELSIF p_docu_tipo = 3 AND p_docu_tipo_nro IS NOT NULL THEN
      vsql := vsql || ' and Sds.ASD_SWF_ID=' || p_docu_tipo_nro;
      ---SOLICITUD WF
    END IF;
    --Condicion motivo interrupcion
    --PC107838
    IF p_reason_id IS NOT NULL THEN
      /*vsql := vsql || ' and Sds.ASD_REASON_FINISH=''' || p_reason_id || '''';*/
      vsql := vsql ||
              ' and exists (select 1 from history_state_sds hs1,REASON_SDS_STATE where RSS_TYPE = ''I''
                                          and rss_id = hss_rss_id and hs1.hss_id =(
                                          select max(hss.hss_id) FROM history_state_sds hss
                                          where hss.hss_asd_id_sds = Sds.asd_id_sds) and hs1.hss_asd_id_sds = Sds.asd_id_sds and hs1.hss_rss_id = ''' ||
              p_reason_id || ''' ) ';
    END IF;
    vsql := vsql ||
            'and not exists (select 1 from history_state_sds hs1,REASON_SDS_STATE where RSS_TYPE =''C''
                                          and rss_id = hss_rss_id and hs1.hss_id =(
                                          select max(hss.hss_id) FROM history_state_sds hss
                                          where hss.hss_asd_id_sds = Sds.asd_id_sds) and hs1.hss_asd_id_sds = Sds.asd_id_sds) ';
    --fin PC107838
    --Condicion technology
    IF p_technology_id IS NOT NULL THEN
      vsql := vsql || ' and pro_mode_type=''' || p_technology_id || '''';
      ---Motivo Cierre
    END IF;
   --Inicio CFI-234
   IF p_segmento IS NOT NULL THEN
      SELECT stl_char_value
        INTO  v_pais
        FROM  stl_parameters stl
       WHERE  stl.stl_id = 'FCTRY';
     IF v_pais='AR' THEN
       IF p_segmento =  v_segmento_res THEN
         Vsql := Vsql || ' and asd_clt_type IN (SELECT FSP.FSP_CHAR_VALUE FROM FIXED_SERVICES_PARAMETERS FSP
         WHERE fsp.fsp_parameter = ''AGCLRE'' )';
         ELSE
         Vsql := Vsql || ' and asd_clt_type IN (SELECT FSP.FSP_CHAR_VALUE FROM FIXED_SERVICES_PARAMETERS FSP
         WHERE fsp.fsp_parameter = ''AGCLCO'' )';
       END IF;
     ELSE
       Vsql := Vsql || ' and asd_clt_type=''' || p_segmento || '''';
     END IF;
   END IF;
   --Fin CFI-234
    OPEN p_cursor FOR vsql;
  EXCEPTION
    WHEN OTHERS THEN
      p_error := SQLERRM || ' - ' || vexec;
  END getsdssactives_2;

   PROCEDURE get_detalle_sds_2(p_id_sds           NUMBER,
                            p_cellular_number  OUT VARCHAR2,
                            p_ent_id           OUT NUMBER,
                            p_status_sds       OUT VARCHAR2, --A Asigna, otra letra desasigna
                            p_id_localidad     OUT NUMBER,
                            p_type_sds         OUT VARCHAR2,
                            p_id_provincia     OUT VARCHAR2,
                            p_calle            OUT VARCHAR2,
                            p_nro              OUT VARCHAR2,
                            p_torre            OUT VARCHAR2, --CFI-23
                            p_piso             OUT VARCHAR2,
                            p_dpto             OUT VARCHAR2,
                            p_cp               OUT VARCHAR2,
                            p_cliente          OUT VARCHAR2,
                            p_cuenta           OUT VARCHAR2,
                            p_id_cliente       OUT NUMBER,
                            p_observaciones    OUT VARCHAR2,
                            p_entre_calles     OUT VARCHAR2, --CFI-23
                            p_reason_start     OUT VARCHAR2,
                            p_reason_finish    OUT VARCHAR2,
                            p_asd_tck_id       OUT NUMBER,
                            p_reason_interrupt OUT VARCHAR2, --ultimo motivo de interrupcion
                            p_reason_closed    OUT VARCHAR2, --Motivo de cierre
                            p_provincia        OUT VARCHAR2,
                            p_departamento     OUT VARCHAR2, --CFI-23
                            p_localidad        OUT VARCHAR2,
                            p_err_number       OUT NUMBER,
                            p_technology       OUT VARCHAR2,
                            p_rate_plan_des    OUT VARCHAR2,
                            p_err_message      OUT VARCHAR2,
                            p_segmento         OUT VARCHAR2, -- PC77402 RESIDENCIAL, CORPORATIVO, PYMES
                            p_form_number      OUT VARCHAR2, --PC82904 visualizacion SDS
                            p_obs_tck          OUT VARCHAR2, --PC91707
                            p_instalador       OUT NUMBER, --PC91707
                            p_have_det         OUT VARCHAR2, --PC123967
                            p_int_prev         OUT VARCHAR2, --CFI-11
                            p_cant_tv          OUT NUMBER, --CFI-11
                            p_create_date      OUT DATE --CFI-11
                            ) IS
    v_msg               VARCHAR2(4000); --PC144705VARCHAR2(255);
    v_max_hist        NUMBER;
    V_AAA_ID         NUMBER; --NUEVO
    v_flag_xygo        VARCHAR2(20); --CFI-103
    v_localidad         VARCHAR2(200); --CFI-103
    v_provincia         VARCHAR2(100); --CFI-103
    v_flg_agloc         VARCHAR2(10); --CFI-103

 /* CFI-360 - NOEL CELIZ - Se agrega procedimiento get_detalle_sds_2 */

  BEGIN
    v_msg := 'Buscando datos de la SDS.';
    --Campo motivo comienzo=asd_reason_start
    --Campo motivo comienzo=asd_reason_finish
    SELECT asd_status,
           asd_clu_cellular_number,
           asd_ast_type,
           asd_observation,
           asd_ent_id,
           asd_reason_start,
           asd_reason_finish,
           asd_tck_id,
           asd_clt_type,
           (SELECT srf_id
              FROM service_request_forms
             WHERE srf_form_number = asd_sds_id
               AND srf_srf_id IS NULL),
           asd_tck_obs, --PC91707
           asd_ent_id_inst, --PC91707
           asd_create_date --CFI-11
      INTO p_status_sds,
           p_cellular_number,
           p_type_sds,
           p_observaciones,
           p_ent_id,
           p_reason_start,
           p_reason_finish,
           p_asd_tck_id,
           p_segmento,
           p_form_number,
           p_obs_tck, --PC91707
           p_instalador, --PC91707
           p_create_date --CFI-11
      FROM ag_sds
     WHERE asd_id_sds = p_id_sds;

    --PC123967
    v_msg := 'Devolviendo el tipo de negocio de la linea ';
    BEGIN
      SELECT 'Y'
        INTO p_have_det
        FROM ag_sds_details
       WHERE agd_asd_id_sds = p_id_sds;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        p_have_det := 'N';
      WHEN TOO_MANY_ROWS THEN
        p_have_det := 'Y';
    END;
    --FIN PC123967
    v_msg := 'Verificando que el estado de la sds es de cierre ';
    BEGIN
      SELECT rss.rss_description
        INTO p_reason_closed
        FROM reason_sds_state rss, history_state_sds hss
       WHERE rss.rss_id = hss.hss_rss_id
         AND hss.hss_start_date < SYSDATE
         AND nvl(hss.hss_end_date, SYSDATE + 1) > SYSDATE
         AND hss.hss_asd_id_sds = p_id_sds
         AND rss.rss_type = 'C';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        p_reason_closed := 'No Tuvo motivos de cierre';
    END;
    v_msg := 'Obteniendo ultimo motivo de interrupcion';
    BEGIN
      SELECT hss.hss_id, rss.rss_description
        INTO v_max_hist, p_reason_interrupt
        FROM reason_sds_state            rss,
             history_state_sds           hss,
             interruption_closed_reasons,
             ag_sds                      ag
       WHERE rss.rss_id = hss.hss_rss_id
         AND rss.rss_id = icr_rss_id
         AND hss.hss_start_date < SYSDATE
         AND nvl(hss.hss_end_date, SYSDATE + 1) > SYSDATE
         AND NVL(ICR_START_DATE, SYSDATE - 1) <= SYSDATE --PC141796
         AND NVL(ICR_END_DATE, SYSDATE + 1) > SYSDATE --PC141796
         AND rss.rss_type = 'I'
         AND hss.hss_asd_id_sds = ag.asd_id_sds
         AND icr_ast_type = ag.asd_ast_type
         AND icr_state = ag.asd_status
         AND ag.asd_id_sds = p_id_sds;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        p_reason_interrupt := 'No Tuvo motivos de interrupciC3n';
    END;
-- Comienzo CFI-256
  IF p_type_sds = 'VIMUD' THEN
    BEGIN
    v_msg := 'Buscando datos del nuevo domicilio .';
    SELECT   mad_aaa_id_old, --viejo
             mad_aaa_geu_id,
             mad_aaa_cit_id As cit_id, --PC100056 Luciano Nitardi
             mad_aaa_address_flat,
             mad_aaa_address_number,
             mad_aaa_address_floor,
             mad_aaa_address_street,
             mad_aaa_zip_code,
             mad_aaa_reg_name,
             mad_aaa_address_city,
             mad_aaa_address_department,
             mad_aaa_address_tower,
             mad_aaa_address_within_streets,
             mad_flag_cartografy,
             mud_acc_id
        INTO V_AAA_ID, --viejo
             p_id_provincia,
             p_id_localidad,
             p_dpto,
             p_nro,
             p_piso,
             p_calle,
             p_cp,
             p_provincia,
             p_localidad,
             p_departamento,
             p_torre,
             p_entre_calles,
             v_flag_xygo,
             p_cuenta
       FROM mud_process mp,mud_address ma
      WHERE mp.mud_id=ma.mad_mud_id
        AND mp.mud_sds_id=p_id_sds;
      EXCEPTION
        WHEN OTHERS THEN
        p_err_number  := SQLCODE;
        p_err_message := v_msg || SQLERRM;
        RETURN;
        --Return -1;
       END;
   -- Fin CFI-256
    ELSE
    v_msg := 'Buscando datos del domicilio .';
    BEGIN
      SELECT aaa_id, --nuevo
             aaa_acc_id,
             aaa_geu_id,
             aaa_cit_id As cit_id, --PC100056 Luciano Nitardi
             aaa_address_flat,
             aaa_address_number,
             aaa_address_floor,
             aaa_address_street,
             aaa_zip_code,
             aaa_reg_name,
             aaa_address_city,
             aaa_address_department, --CFI-23
             aaa_address_tower, --CFI-23
             aaa_address_within_streets, --CFI-23
             aaa_flag_cartografy --CFI-103
        INTO V_AAA_ID, --nuevo
             p_cuenta,
             p_id_provincia,
             p_id_localidad,
             p_dpto,
             p_nro,
             p_piso,
             p_calle,
             p_cp,
             p_provincia,
             p_localidad,
             p_departamento, --CFI-23
             p_torre, --CFI-23
             p_entre_calles,  --CFI-23
             v_flag_xygo  -- CFI-103
       FROM cellular_address, account_alt_addresses
       WHERE cad_clu_cellular_number = p_cellular_number
         AND cad_aaa_id = aaa_id
         AND aaa_aat_id = 2
         AND NVL(AAA_START_DATE, SYSDATE - 1) <= SYSDATE --PC141796
         AND NVL(AAA_END_DATE, SYSDATE + 1) > SYSDATE --PC141796
         AND nvl(cad_start_date, sysdate - 1) <= sysdate --PC92054 - Para que traiga el Domicilio de Instalacion vigente aunque la linea posea una Mudanza DTH a corte de ciclo (Nuevo Dom de Instalacion a Corte de Ciclo)
         AND nvl(cad_end_date, sysdate + 1) > sysdate; --PC92054;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        --PC112933
        SELECT aaa_id, --nuevo
               aaa_acc_id,
               aaa_geu_id,
               aaa_cit_id As cit_id,
               aaa_address_flat,
               aaa_address_number,
               aaa_address_floor,
               aaa_address_street,
               aaa_zip_code,
               aaa_reg_name,
               aaa_address_city,
               aaa_address_department, --CFI-23
               aaa_address_tower, --CFI-23
               aaa_address_within_streets, --CFI-23
               aaa_flag_cartografy --CFI-103
          INTO V_AAA_ID, --nuevo
               p_cuenta,
               p_id_provincia,
               p_id_localidad,
               p_dpto,
               p_nro,
               p_piso,
               p_calle,
               p_cp,
               p_provincia,
               p_localidad,
               p_departamento, --CFI-23
               p_torre, --CFI-23
               p_entre_calles, --CFI-23
               v_flag_xygo  -- CFI-103
          FROM cellular_address, account_alt_addresses
         WHERE cad_clu_cellular_number = p_cellular_number
           AND cad_aaa_id = aaa_id
           AND aaa_aat_id = 2
           AND aaa_id = (SELECT MAX(aaa_id)
                           FROM cellular_address, account_alt_addresses
                          WHERE cad_clu_cellular_number = p_cellular_number
                            AND cad_aaa_id = aaa_id
                            AND aaa_aat_id = 2);
        --PC112933
      WHEN OTHERS THEN
        p_err_number  := SQLCODE;
        p_err_message := v_msg || SQLERRM;
        RETURN;
        --Return -1;
    END;
   END IF;
    --CFI-103
    IF nvl(v_flag_xygo,'SEMA') = 'XYGO' THEN
        --Se obtiene el valor de la flag para informar ID localidad a Agenda con datos de XYGO
        --Si el valor es 'Y' se informa el ID, caso contrario se informa 0 (cero).
        v_msg := 'El parametro AGDLOC no se encuentra definido o esta vencido. ';
        BEGIN
           SELECT stl_char_value
           INTO      v_flg_agloc
           FROM    stl_parameters
           WHERE stl_id = 'AGDLOC'
           AND       SYSDATE BETWEEN stl_start_date AND NVL(stl_end_date,SYSDATE);
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                p_err_number := SQLCODE;
                p_err_message := v_msg||SQLERRM;
                RETURN;
        END;

        IF v_flg_agloc = 'Y' THEN
            v_msg := 'Buscando id de localidad de Agenda-STL ';
            v_localidad := UPPER(p_localidad);
            v_provincia := UPPER(p_provincia);
            BEGIN
                SELECT cit_id
                INTO      p_id_localidad
                FROM    cp_cities
                WHERE UPPER(cit_reg_name) = v_provincia
                AND       UPPER(cit_name) = v_localidad
                AND       rownum = 1;
            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                     BEGIN
                          SELECT xac_stl_cit_id
                          INTO      p_id_localidad
                          FROM    xygo_agenda_cities
                          WHERE xac_city_name = v_localidad
                          AND       xac_stl_reg_id = p_id_provincia;
                     EXCEPTION
                          WHEN NO_DATA_FOUND THEN
                               p_id_localidad := 0;
                     END;
                WHEN OTHERS THEN
                    p_err_number  := SQLCODE;
                    p_err_message := v_msg || SQLERRM;
                    RETURN;
            END;
        END IF;
    ELSE
        IF p_id_localidad IS NULL THEN
            BEGIN
                SELECT cit_id
                INTO      p_id_localidad
                FROM    cp_cities
                WHERE UPPER(cit_reg_name) = UPPER(p_provincia)
                AND       UPPER(cit_name) = UPPER(p_localidad)
                AND       rownum = 1;
            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                   NULL;
            END;
        END IF;
    END IF; --CFI-103

    v_msg := 'Buscando datos del cliente .';
    BEGIN
      SELECT clt_id,
             CLT_NAME || ' ' || CLT_SURNAME CLT_KEYNAME
        INTO p_id_cliente,
             p_cliente
        FROM accounts, client
       WHERE acc_clt_id = clt_id
         AND acc_id = p_cuenta;
    EXCEPTION
      WHEN OTHERS THEN
        p_err_number  := SQLCODE;
        p_err_message := v_msg || SQLERRM;
        RETURN;
        --Return -1;
    END;
    v_msg := 'Buscando datos del deco .';
    begin
      select pro_mode_type
        into p_technology
        FROM cellular_terminals, products
       WHERE cet_clu_cellular_number = p_cellular_number
         and nvl(cet_end_date, sysdate + 1) > sysdate
         AND pro_id = cet_pro_id;
    exception
      when no_data_found then
        ---PC91022_PO para que traiga el ultimo equipo antes de cancelarse
        select pro_mode_type
          into p_technology
          FROM cellular_terminals, products
         WHERE pro_id = cet_pro_id
           and cet_id =
               (select max(cet_id)
                  from cellular_terminals
                 where cet_clu_cellular_number = p_cellular_number);
        --- fin PC91022_PO
      WHEN others THEN
        p_err_number  := SQLCODE;
        p_err_message := v_msg || SQLERRM;
        RETURN;
    end;
    v_msg := 'Buscando la descripcion del plan comercial .';
    BEGIN
      --Comienzo PC130773 -- Se ingresa directamente a las tablas de produccion
      -- mediante los sinonimos distribuidos de dichas tablas.
      SELECT rpl_description
        INTO p_rate_plan_des
        FROM cellular_plans, rate_plans
       WHERE cpl_clu_cellular_number = p_cellular_number
         AND cpl_rpl_id = rpl_id
         AND cpl_start_date < SYSDATE
         AND nvl(cpl_end_date, SYSDATE + 1) > SYSDATE
         AND ROWNUM = 1;
    EXCEPTION
      WHEN OTHERS THEN
        p_rate_plan_des := null;
    END;
    -- Fin PC130773
    --Inicio PC107768, setear en NULL el campo observaciones debido a que ya se tomo el registro en agenda.
    UPDATE ag_sds
       SET asd_observation = null --pc108767
     WHERE asd_id_sds = p_id_sds;
    --fin Pc107768
    --CFI-11
    v_msg := 'VERIFICANDO SI A¿ADE O ES NUEVO';
    BEGIN
      SELECT 'Y'
        INTO P_INT_PREV
        FROM CELLULAR_ADDRESS CA, CELLULARS
       WHERE CA.CAD_CLU_CELLULAR_NUMBER = CLU_CELLULAR_NUMBER
         AND NVL(CAD_START_DATE, SYSDATE - 1) <= SYSDATE
         AND NVL(CAD_END_DATE, SYSDATE + 1) > SYSDATE
         AND CLU_CBT_ID = 'IF'
         AND CLU_STATUS = 'A'
         and CA.CAD_AAA_ID = V_AAA_ID;
    EXCEPTION
      WHEN TOO_MANY_ROWS THEN
        P_INT_PREV := 'Y';
      WHEN NO_DATA_FOUND THEN
        P_INT_PREV := 'N';
      WHEN OTHERS THEN
        p_err_number  := SQLCODE;
        p_err_message := v_msg || SQLERRM;
        RETURN;
    END;

    v_msg := 'BUSCANDO CANTIDAD DE LINEAS IPTV';

    IF p_type_sds = 'INST' THEN

      SELECT COUNT(AGD_CLU_CELLULAR_NUMBER)
        INTO P_CANT_TV
        FROM AG_SDS_DETAILS
       WHERE AGD_CBT_ID = 'IPTV'
         AND AGD_ASD_ID_SDS = p_id_sds;
    ELSE
      SELECT COUNT(CLU_CELLULAR_NUMBER)
        INTO P_CANT_TV
        FROM CELLULARS C
       WHERE CLU_CBT_ID = 'IPTV'
         AND EXISTS
       (SELECT 1
                FROM CELLULAR_ADDRESS CA
               WHERE cad_clu_cellular_number = C.CLU_CELLULAR_NUMBER
                 AND CAD_AAA_ID = V_AAA_ID
                 AND NVL(CAD_END_DATE, SYSDATE + 1) > SYSDATE);
    END IF;
    --CFI-11

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      v_msg         := 'No existe esta SDS.Verifique.';
      p_err_message := v_msg;
      p_err_number  := -1;
      RETURN;
      --Return -1;
    WHEN OTHERS THEN
      p_err_number  := SQLCODE;
      p_err_message := v_msg || SQLERRM;
      RETURN;
      --Return -1;
  END get_detalle_sds_2;

END ws_ag_sth_ifaces;
/

