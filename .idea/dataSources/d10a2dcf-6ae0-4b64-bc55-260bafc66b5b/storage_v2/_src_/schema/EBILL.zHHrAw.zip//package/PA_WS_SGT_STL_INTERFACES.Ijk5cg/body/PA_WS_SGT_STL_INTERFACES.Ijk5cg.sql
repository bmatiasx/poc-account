create PACKAGE BODY PA_WS_SGT_STL_INTERFACES IS

/**************************************************************************************************************************************
       NAME:       pa_ws_sgt_stl_interfaces
       PURPOSE:    validar materiales con registros del stock en SAP
                   Registrar los datos identificatorios de los equipos instalados en el
                   detalle de la orden de trabajo.
       REVISIONS:
       Ver        Date           EVENTO               Author                              Description
     ---------  ----------      ----------          ---------------           ------------------------------------------
      1.9       28/06/2016     PC123969_CD124023   Laura Costa               Creacion y actualizaci¿n del package.
      1.11      11/10/2016     PC124004_CD126939   Laura Costa               Cambio de equipo por reclamo tecnico
      1.12      16/11/2016     PC123999            Pablo Cura                Cambio de estado IPTV
      1.13      28/12/2016     PC128981            Pablo Cura                Reingenieria de Mudanza FIJO
      1.18      30/08/2018     PC135022            Pablo Cura                Agregado de actualizacion de la linea TF en detalle de OT
  ***************************************************************************************************************************************/
  FUNCTION f_update_material_ot(sds_id      IN VARCHAR2,
                                nim         IN VARCHAR2,
                                pro_id      IN VARCHAR2,
                                nse_id      IN VARCHAR2,
                                mac_address IN VARCHAR2,
                                guid_id     IN VARCHAR2,
                                nodo        IN VARCHAR2 DEFAULT NULL,--PC135022
                                p_ent_id    IN VARCHAR2 DEFAULT NULL,
                                pout_msg    OUT VARCHAR2) RETURN NUMBER IS
    /******************************************************************************************************
    **    Esta funcion va a ser consumida x web-service, para validar el material que se conecto a la red
    **    en el domicilio del cliente.
    **
    **  Parameters         :
    **  ==========
    **    SDS_ID           IN VARCHAR2   Nro de Orden de Trabajo
    **    NIM              IN VARCHAR2   Nro de L¿nea (clu_cellular_number)
    **    PRO_ID           IN VARCHAR2   Id de Material (products.pro_id)
    **    NSE_ID           IN VARCHAR2   Nro de Serie del Material (iccid)
    **    MAC_ADDRESS      IN VARCHAR2   Id Mac-Address (imei)
    **    GUID_ID          IN VARCHAR2   Id GUID solo informar cuando es SET TOP BOX
    **    P_ENT_ID         IN VARCHAR2   Id Entidad Contratista
    **    POUT_MSG         OUT VARCHAR2  --> Mensaje de proceso.
    **
    **  Return             :
    **  ======
    **         0 El dato no es fraudulento.
    **        -1 El dato es fraudulento.
    **        -2 Hubo un error no controlado.
    **
    ** Nota: SGT envia todas las lineas vigentes en el domicilio, no solo las lineas vendidas.
    **       Si la linea NO esta asociada a la OT INST no se realiza ninguna actualizacion, se
    **       retorna al SGT el mensaje 'La actualizacion del material ha sido exitosa.'.
    **       En esta situacion la variable v_flg_cmbeq tiene el valor 'N'.
    ********************************************************************************************************/
    v_msg_error     VARCHAR2(250);
    v_result        NUMBER;
    v_cbt_id        cellulars.clu_cbt_id%TYPE;
    v_sds_type      ag_sds_type.ast_type%TYPE;
    v_nim           cellulars.clu_cellular_number%TYPE;
    v_linea         cellulars.clu_cellular_number%TYPE;
    v_flg_cmbeq     VARCHAR2(1) := NULL;
    v_pro_id_conex  products.pro_id%TYPE;
    v_can_total     NUMBER(3) := 0;
    v_can_process   NUMBER(3) := 0;
    v_pro_id        products.pro_id%TYPE;
    v_pro_type      products.pro_type%TYPE;
    v_agd_pro_id    ag_sds_details.agd_pro_id%TYPE;
    v_nse_id        cellular_terminals.cet_sim_iccid%TYPE;
    v_mac_address   cellular_terminals.cet_imei%TYPE;
    v_guid_id       ag_sds_details.agd_guid%TYPE;
    v_flg_entidad   NUMBER := 0;
    v_flg_actualizo VARCHAR2(1) := NULL;
    v_type          cellulars.clu_pro_mode_type%TYPE;
    v_prod_id       cellular_terminals.cet_pro_id%TYPE;---agregado
    v_existe        NUMBER;---agregado
    v_aaa_id        cellular_address.cad_aaa_id%TYPE;---agregado
    
  BEGIN
    IF sds_id IS NULL THEN
      v_msg_error := 'El numero de orden de trabajo no ha sido informado. Verifique por favor';
      pout_msg    := v_msg_error;
      RETURN - 1;
    ELSIF nim IS NULL THEN
      v_msg_error := 'La linea asociada al material a validar no ha sido informada. Verifique por favor';
      pout_msg    := v_msg_error;
      RETURN - 1;
    ELSIF pro_id IS NULL THEN
      v_msg_error := 'El Id del material no ha sido informado. Verifique por favor';
      pout_msg    := v_msg_error;
      RETURN - 1;
    ELSIF nse_id IS NULL THEN
    ---PC135022
     BEGIN
       select clu_pro_mode_type
       into v_type
       from cellulars
       where clu_cellular_number=LPAD(nim, 10, '0');
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
       v_msg_error := 'No se encontro el tipo de tecnologia de la linea. Verifique por favor';
       pout_msg    := v_msg_error;
       RETURN - 1;
     END;
     IF v_type <> 'GPON' THEN
       NULL;
     ELSE
      v_msg_error := 'El nro de serie del material no ha sido informado. Verifique por favor';
      pout_msg    := v_msg_error;
      RETURN - 1;
     END IF;
     ---PC135022
    ELSIF mac_address IS NULL THEN
      v_msg_error := 'Mac-Address del material no ha sido informado. Verifique por favor';
      pout_msg    := v_msg_error;
      RETURN - 1;
    ELSIF LENGTH(LTRIM(RTRIM(nse_id))) > 20 THEN
      v_msg_error := 'El nro de serie del material supera longitud para Stealth. Verifique por favor';
      pout_msg    := v_msg_error;
      RETURN - 1;
    ELSIF LENGTH(LTRIM(RTRIM(mac_address))) > 16 THEN
      v_msg_error := 'Mac-Address del material supera longitud para Stealth. Verifique por favor';
      pout_msg    := v_msg_error;
      RETURN - 1;
    END IF;
    --Se obtiene el tipo de OT
    v_result := f_get_type_ot(pin_sds_id    => SDS_ID,
                              pout_sds_type => v_sds_type,
                              pout_message  => v_msg_error);
    IF v_result <> 0 THEN
      pout_msg := v_msg_error;
      RETURN - 1;
    END IF;
    --Completo con ceros el parametro p_nim
    IF LENGTH(nim) < 9 THEN
      SELECT LPAD(nim, 10, '0') INTO v_nim FROM DUAL;
    ELSE
      v_nim := nim;
    END IF;
    --Se obtiene el tipo de negocio de la linea
    BEGIN
      SELECT c.clu_cbt_id, c.clu_cellular_number
        INTO v_cbt_id, v_linea
        FROM cellulars c
       WHERE c.clu_cellular_number = v_nim;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        --Busco la linea con 9 posiciones
        SELECT LPAD(nim, 9, '0') INTO v_nim FROM DUAL;
        BEGIN
          SELECT c.clu_cbt_id, c.clu_cellular_number
            INTO v_cbt_id, v_linea
            FROM cellulars c
           WHERE c.clu_cellular_number = v_nim;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            v_msg_error := 'La linea ' || NIM ||
                           ' no esta registrada en el Stealth.';
            pout_msg    := v_msg_error;
            RETURN - 1;
        END;
    END;
    --Verifico que la entidad este declarada en Stealth
    IF p_ent_id IS NULL THEN
      v_msg_error := 'La entidad no ha sido informada. Verifique por favor';
      pout_msg    := v_msg_error;
      RETURN - 1;
    END IF;
    SELECT COUNT(1)
      INTO v_flg_entidad
      FROM a_entidades e
     WHERE e.ent_id = p_ent_id;
    IF v_flg_entidad = 0 THEN
      v_msg_error := 'La entidad ' || p_ent_id ||
                     ' no esta definida en Stealth. Verifique por favor';
      pout_msg    := v_msg_error;
      RETURN - 1;
    END IF;
    /* SGT informar¿ los datos de los materiales instalados por OT y linea, en caso de BAJA los detalles de materiales NO se informan.
    -- Para una OT INST  SGT informara los datos del material instalado por OT y la linea.
    -- Para una OT VIBAJ SGT no informara los datos NSE, Mac_address, Guid corresponde actualizar el estado en B x OT y linea.
    -- Para una OT VITEC SGT informara los datos del nuevo material instalado por cambio de equipo, se actualizara el estado en M.
    */
    IF v_sds_type = 'INST' THEN
      --Se controla si la linea informada con la SDS se encuentra registrada en el detalle OT INST
      BEGIN
        SELECT 'Y'
          INTO v_flg_cmbeq
          FROM ag_sds_details
         WHERE agd_asd_id_sds = sds_id
           AND agd_clu_cellular_number = v_linea;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          v_flg_cmbeq := 'N';
      END;
      IF v_flg_cmbeq = 'N' THEN
        --       pout_msg := NULL; Se cambio para SGT no lo interprete como Error
        pout_msg := 'La actualizacion del material ha sido exitosa.';
        RETURN 0;
      END IF;
      --Registro la entidad que realizo la instalacion
      UPDATE ag_sds
         SET asd_ent_id_inst = p_ent_id, asd_inst_date = SYSDATE
       WHERE asd_id_sds = SDS_ID;
      --Se obtiene la cantidad de lineas que contiene la OT
      IF v_can_total = 0 THEN
        SELECT COUNT(1)
          INTO v_can_total
          FROM ag_sds_details agd
         WHERE agd.agd_asd_id_sds = SDS_ID;
      END IF;
      --Se registra los datos de los materiales por OT y linea.
      v_result := f_update_new_material(pin_sds_id        => SDS_ID,
                                        pin_nim           => v_linea,
                                        pin_cbt_id        => v_cbt_id,
                                        pin_pro_id        => PRO_ID,
                                        pin_nse_id        => NSE_ID,
                                        pin_macadd        => MAC_ADDRESS,
                                        pin_guid          => GUID_ID,
                                        pin_status        => 'A',
                                        pin_nodo          => nodo,--PC135022
                                        pout_pro_id_conex => v_pro_id_conex,
                                        pout_msg          => v_msg_error);
      IF v_result = 0 THEN
        SELECT COUNT(1)
          INTO v_can_process
          FROM ag_sds_details
         WHERE agd_asd_id_sds = SDS_ID
           AND agd_status = 'A';
        IF v_can_total = v_can_process THEN
          IF v_pro_id_conex IS NULL THEN
            SELECT agd.agd_pro_id
              INTO v_pro_id_conex
              FROM products pro, ag_sds_details agd
             WHERE agd.agd_asd_id_sds = SDS_ID
               AND pro.pro_id = agd.agd_pro_id
               AND agd.agd_clu_cellular_number = v_linea ---PC135022
               AND agd.agd_status IN ('A', 'M')
               AND EXISTS (SELECT 1
                             FROM fixed_services_parameters
                            WHERE fsp_parameter = 'IPTV08'
                              AND fsp_char_value = pro.pro_type
                              AND SYSDATE BETWEEN fsp_start_date
                              AND NVL(fsp_end_date, SYSDATE));
          END IF;
          IF v_pro_id_conex IS NOT NULL THEN
            UPDATE ag_sds_details
               SET agd_pro_id_conex = v_pro_id_conex
             WHERE agd_asd_id_sds = SDS_ID
               AND EXISTS
        (SELECT 1
                      FROM products, fixed_services_parameters
                     WHERE pro_id = agd_pro_id
                       AND fsp_parameter = 'IPTV09'
                       AND pro_type = fsp_char_value
                       AND SYSDATE BETWEEN fsp_start_date AND
                           NVL(fsp_end_date, SYSDATE));
            IF SQL%ROWCOUNT > 0 THEN
              COMMIT;
            END IF;
          END IF;
        END IF;
      END IF;
      pout_msg := v_msg_error;
      RETURN v_result;
    ELSIF v_sds_type in ('VITEC', 'VIMUD') /*PC128981*/
     THEN
      ---agregado 
   BEGIN
        SELECT ag.asd_id_sds
          INTO v_existe
          FROM ag_sds ag, ag_sds_details agd
         WHERE ag.asd_id_sds = agd.agd_asd_id_sds
           AND ag.asd_clu_cellular_number = agd.agd_clu_cellular_number
           AND ag.asd_id_sds = sds_id
           AND ag.asd_clu_cellular_number = v_linea
           AND ag.asd_ast_type = v_sds_type;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN                  
        BEGIN
            BEGIN
            SELECT cet_imei, cet_sim_iccid, cet_pro_id,cad_aaa_id
              INTO v_mac_address, v_nse_id, v_prod_id,v_aaa_id
              FROM cellular_terminals, cellular_address
             WHERE cet_clu_cellular_number = cad_clu_cellular_number
               AND cet_clu_cellular_number = v_linea
               AND cad_end_date is null
               AND NVL(cet_end_date, SYSDATE + 1) > SYSDATE;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
             /* V_MSG := 'ERROR AL OBTENER DATOS DEL TERMINAL DE LA LINEA ' ||
                       C.CAD_CLU_CELLULAR_NUMBER;
              RAISE FALLAR;*/
              NULL;
          END;
           
          INSERT INTO AG_SDS_DETAILS
            (agd_asd_id_sds,
             agd_aaa_id,
             agd_clu_cellular_number,
             agd_cbt_id,
             agd_lastmodif_date,
             agd_lastmodif_usr,
             agd_nse_id,
             agd_mac_address,
             agd_guid, 
             agd_pro_id)
          VALUES
            (sds_id,
             v_aaa_id,
             v_linea,
             v_cbt_id,
             sysdate,
             user,
             v_nse_id,
             v_mac_address,
             null /*v_iptv_guid*/,---ver
             v_prod_id);
             
             END;
      END;    
         ---agregado      
     
      SELECT LTRIM(RTRIM(PRO_ID)) INTO v_pro_id FROM DUAL;
      --Obtengo el tipo de material
      BEGIN
        SELECT pro_type
          INTO v_pro_type
          FROM products pp
         WHERE pp.pro_id = v_pro_id;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          v_msg_error := 'El Id del material ' || pro_id ||
                         ' no esta definido en Stealth. Verifique por favor';
          pout_msg    := v_msg_error;
          RETURN - 1;
        WHEN TOO_MANY_ROWS THEN
          pout_msg := 'Existe mas de un producto con ese ID ' || pro_id;
          RETURN - 2;
      END;
      --Busco la linea que ha cambiado el equipo para actualizar los datos
      BEGIN
        SELECT 'Y',
               cet.cet_pro_id,
               cet.cet_sim_iccid,
               cet.cet_imei,
               agd.agd_guid
          INTO v_flg_cmbeq,
               v_agd_pro_id,
               v_nse_id,
               v_mac_address,
               v_guid_id
          FROM products p, ag_sds_details agd, cellular_terminals cet
         WHERE cet.cet_clu_cellular_number = v_linea
           AND SYSDATE BETWEEN cet.cet_start_date AND
               NVL(cet.cet_end_date, SYSDATE)
           AND agd.agd_asd_id_sds = sds_id
           AND agd.agd_clu_cellular_number = cet.cet_clu_cellular_number
           AND p.pro_id = cet.cet_pro_id
           AND p.pro_type = v_pro_type;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          v_flg_cmbeq := 'N';
        WHEN TOO_MANY_ROWS THEN
          v_msg_error := 'En la OT ' || LTRIM(RTRIM(SDS_ID)) ||
                         ' recupera mas de un material para la linea ' ||
                         v_linea;
          pout_msg    := v_msg_error;
          RETURN - 1;
      END;
      IF v_flg_cmbeq = 'Y' THEN
        --Se verifica si los datos de los materiales han cambiado
        --Linea IF solo cambia id de material y mac-address
        --Linea IPTV cambia Id de material, nro de serie, mac-address, guid
        --Si se detacta cambios se activa la flag v_flg_actualizo en 'Y',
        --caso contrario la flag v_flg_actualizo se indica en 'N'.
        IF v_cbt_id = 'IPTV' THEN
          IF (v_pro_id <> v_agd_pro_id OR v_nse_id <> nse_id OR
             v_mac_address <> mac_address OR v_guid_id <> guid_id) THEN
            v_flg_actualizo := 'Y';
          ELSE
            v_flg_actualizo := 'N';
          END IF;
        ELSIF v_cbt_id = 'IF' OR v_cbt_id = 'TF' THEN
          IF (v_pro_id <> v_agd_pro_id OR v_mac_address <> mac_address) THEN
            v_flg_actualizo := 'Y';
          ELSE
            v_flg_actualizo := 'N';
          END IF;
        ELSE
          v_flg_actualizo := 'N';
        END IF;
        IF v_flg_actualizo = 'Y' THEN
          --Actualizo entidad contratista en la OT VITEC
          UPDATE ag_sds
             SET asd_ent_id_tec = p_ent_id, asd_tec_date = SYSDATE
           WHERE asd_id_sds = sds_id;
          IF SQL%ROWCOUNT = 0 THEN
            v_msg_error := 'ERROR: No se actualizo entidad tecnica ' ||
                           TO_CHAR(sqlcode);
            pout_msg    := v_msg_error;
            ROLLBACK;
            RETURN - 1;
          END IF;
          --Actualizo el estado de cambio de equipo en la tabla MUD_CET
          UPDATE mud_cet
             SET mce_produc_id = v_pro_id,
                 mce_cet_imei  = MAC_ADDRESS,
                 mce_status    = 'O'
           WHERE EXISTS (SELECT 1
                    FROM mud_process
                   WHERE mud_id = mce_mud_id
                     AND mud_sds_id = SDS_ID
                     AND mud_status = 'F')
             AND mce_cellular_number = v_linea;
          IF SQL%ROWCOUNT = 0 THEN
            v_msg_error := 'ERROR: No se actualizo estado O en MUD_CET ' ||
                           TO_CHAR(sqlcode);
            pout_msg    := v_msg_error;
            ROLLBACK;
            RETURN - 1;
          END IF;
          --Actualizo los datos del equipo de la linea en el detalle de OT
          v_result := f_update_new_material(pin_sds_id        => SDS_ID,
                                            pin_nim           => v_linea,
                                            pin_cbt_id        => v_cbt_id,
                                            pin_pro_id        => v_pro_id,
                                            pin_nse_id        => NSE_ID,
                                            pin_macadd        => MAC_ADDRESS,
                                            pin_guid          => GUID_ID,
                                            pin_status        => 'M',
                                            pin_nodo          => nodo,--PC135022
                                            pout_pro_id_conex => v_pro_id_conex,
                                            pout_msg          => v_msg_error);
          IF v_result = 0 THEN
            IF v_pro_id_conex IS NULL THEN
              BEGIN
                SELECT agd.agd_pro_id
                  INTO v_pro_id_conex
                  FROM products pro, ag_sds_details agd
                 WHERE agd.agd_asd_id_sds = SDS_ID
                   AND pro.pro_id = agd.agd_pro_id
                   AND agd.agd_clu_cellular_number = v_linea ---PC135022
                   AND agd.agd_status = 'M'
                   AND EXISTS
                       (SELECT 1
                          FROM fixed_services_parameters
                         WHERE fsp_parameter = 'IPTV08'
                           AND fsp_char_value = pro.pro_type
                           AND SYSDATE BETWEEN fsp_start_date
                           AND NVL(fsp_end_date, SYSDATE));
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
               v_pro_id_conex := NULL;
             END;
            END IF;
            IF v_pro_id_conex IS NOT NULL THEN
              UPDATE ag_sds_details
                 SET agd_pro_id_conex   = v_pro_id_conex,
                     agd_lastmodif_date = SYSDATE,
                     agd_lastmodif_usr  = USER
               WHERE agd_asd_id_sds = SDS_ID
          AND EXISTS (SELECT 1
                        FROM products, fixed_services_parameters
                       WHERE pro_id = agd_pro_id
                         AND fsp_parameter = 'IPTV09'
                         AND pro_type = fsp_char_value
                         AND SYSDATE BETWEEN fsp_start_date AND
                             NVL(fsp_end_date, SYSDATE));
              IF SQL%ROWCOUNT > 0 THEN
                COMMIT;
              END IF;
            END IF;
          END IF;
          pout_msg := v_msg_error;
          RETURN v_result;
        ELSE
          --Actualizo el estado de cambio de equipo en la tabla MUD_CET
          UPDATE mud_cet
             SET mce_status = 'X'
           WHERE EXISTS (SELECT 1
                    FROM mud_process
                   WHERE mud_id = mce_mud_id
                     AND mud_sds_id = SDS_ID
                     AND mud_status = 'F')
             AND mce_cellular_number = v_linea;
          IF SQL%ROWCOUNT = 0 THEN
            v_msg_error := 'ERROR: No se actualizo estado X en MUD_CET ' ||
                           TO_CHAR(sqlcode);
            pout_msg    := v_msg_error;
            ROLLBACK;
            RETURN - 1;
          END IF;
          --Actualizo el estado en NULL, en el detalle de OT
          UPDATE ag_sds_details
             SET agd_status = NULL
           WHERE agd_asd_id_sds = sds_id
             AND agd_clu_cellular_number = v_linea;
          IF SQL%ROWCOUNT = 0 THEN
            v_msg_error := 'ERROR: No se actualizo estado en AG_SDS_DETAILS ' ||
                           TO_CHAR(sqlcode);
            pout_msg    := v_msg_error;
            ROLLBACK;
            RETURN - 1;
          END IF;
          COMMIT;
          pout_msg := 'La actualizacion del material ha sido exitosa.';
          RETURN 0;
        END IF;
      ELSE
        v_msg_error := 'ERROR: La linea ' || v_linea ||
                       ' no se encuentra informada en el detalle de la OT. ' ||
                       TO_CHAR(sqlcode);
        pout_msg    := v_msg_error;
        ROLLBACK;
        RETURN - 1;
      END IF;
    END IF;
    pout_msg := 'La actualizacion del material ha sido exitosa.'; --PC123999
    RETURN 0;
  EXCEPTION
    WHEN OTHERS THEN
      pout_msg := 'Fallo actualizacion de materiales en PA_WS_SGT_STL_INTERFACES. ' ||
                  SQLERRM;
      ROLLBACK;
      RETURN - 2;
  END;
  FUNCTION f_get_type_ot(pin_sds_id    IN ag_sds_details.agd_asd_id_sds%TYPE,
                         pout_sds_type OUT VARCHAR2,
                         pout_message  OUT VARCHAR2) RETURN NUMBER IS
    /******************************************************************************************************
    **    Esta funcion devuelve el tipo de orden de trabajo
    **  Return   Un numero:  0 dato correcto, -1 dato con error, -2 Error de sistema
    ********************************************************************************************************/
    v_sds_type ag_sds.asd_ast_type%TYPE;
  BEGIN
    --Obtengo el tipo de orden de trabajo
    BEGIN
      SELECT ag.asd_ast_type
        INTO v_sds_type
        FROM ag_sds ag
       WHERE ag.asd_id_sds = pin_sds_id;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        pout_message := 'ERROR: La OT ' || TO_CHAR(pin_sds_id) ||
                        ' no esta registrada.';
        RETURN - 1;
    END;
    IF v_sds_type IS NOT NULL THEN
      pout_sds_type := v_sds_type;
      pout_message  := NULL;
      RETURN 0;
    ELSE
      pout_message := 'ERROR: El tipo de la OT ' || TO_CHAR(pin_sds_id) ||
                      ' esta en blanco.';
      RETURN - 1;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      pout_message := 'Fallo la captura del tipo de OT en PA_WS_SGT_STL_INTERFACES. ' ||
                      SQLERRM;
      RETURN - 2;
  END;
  FUNCTION f_update_new_material(pin_sds_id        IN ag_sds_details.agd_asd_id_sds%TYPE,
                                 pin_nim           IN ag_sds_details.agd_clu_cellular_number%TYPE,
                                 pin_cbt_id        IN ag_sds_details.agd_cbt_id%TYPE,
                                 pin_pro_id        IN ag_sds_details.agd_pro_id%TYPE,
                                 pin_nse_id        IN ag_sds_details.agd_nse_id%TYPE,
                                 pin_macadd        IN ag_sds_details.agd_mac_address%TYPE,
                                 pin_guid          IN ag_sds_details.agd_guid%TYPE,
                                 pin_status        IN ag_sds_details.agd_status%TYPE,
                                 pin_nodo          IN ag_sds_details.agd_nodo%TYPE DEFAULT NULL,--PC135022
                                 pout_pro_id_conex OUT VARCHAR2,
                                 pout_msg          OUT VARCHAR2)
    RETURN NUMBER IS
    /******************************************************************************************************
    **  Esta funcion actualiza los datos del nuevo equipo por orden de trabajo y linea
    **  Return   Un numero:  0 dato correcto, -1 dato con error, -2 Error de sistema
    ********************************************************************************************************/
    v_result        NUMBER;
    v_message       VARCHAR2(250);
    v_exec          VARCHAR2(200);
    v_pro_id        products.pro_id%TYPE;
    v_pro_type      products.pro_type%TYPE;
    v_pro_id_conex  products.pro_id%TYPE;
    v_group_ot      VARCHAR2(10);
    v_flg_eq        NUMBER(3);
    v_flg_eq_conect NUMBER(3);
    v_flg_if_iptv   VARCHAR2(1); --Si OT instalo Internet c/IPTV se informa 'Y', caso contrario se informa 'N'
    v_nim_if        cellular_terminals.cet_clu_cellular_number%TYPE;
  BEGIN
    --Se obtiene el tipo de material filtrando por Id de Producto
    BEGIN
      SELECT p.pro_type
        INTO v_pro_type
        FROM products p
       WHERE p.pro_id = pin_pro_id;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        v_message := 'El material ' || pin_pro_id ||
                     ' no esta registrado en Stealth.';
        pout_msg  := v_message;
        RETURN - 1;
    END;
    -- Decodificador para DTH - ONT para IF e IPTV
    BEGIN
       SELECT 1
        INTO v_flg_eq
        FROM fixed_services_parameters
       WHERE fsp_parameter = 'IPTV08'
         AND fsp_char_value = v_pro_type
         AND SYSDATE BETWEEN fsp_start_date AND NVL(fsp_end_date, SYSDATE);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        pout_msg := 'CONTROL: EL parametro IPTV08 no esta definido o esta vencido,';
        RETURN - 1;
    END;
    -- Tarjeta para DTH - STB para IPTV
    BEGIN
       SELECT 1
        INTO v_flg_eq_conect
        FROM fixed_services_parameters
       WHERE fsp_parameter = 'IPTV09'
         AND fsp_char_value = v_pro_type
         AND SYSDATE BETWEEN fsp_start_date AND NVL(fsp_end_date, SYSDATE);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        pout_msg := 'CONTROL: EL parametro IPTV09 no esta definido o esta vencido,';
        RETURN - 1;
    END;
    v_exec   := 'Obtengo grupo de negocios de OT ' || pin_sds_id;
    v_result := f_business_grouping_ot(pin_sds_id       => pin_sds_id,
                                       pout_group_ot    => v_group_ot,
                                       pout_flg_if_iptv => v_flg_if_iptv,
                                       pout_errmsg      => v_message);
    IF v_result <> 0 THEN
      v_message := v_message || ' al ' || v_exec;
      pout_msg  := v_message;
      RETURN - 1;
    END IF;
    v_pro_id       := pin_pro_id;
    v_pro_id_conex := NULL;
    IF v_group_ot = 'IPTV' THEN
      /* Si el eq es STB se debe informar a que ONT esta conectado.
      Si la flag FLG_IF_IPTV = 'Y' se informa ONT procesada en la misma OT.
      Si la flag FLG_IF_IPTV = 'N' se informa ONT vigente en Stealth.        */
      IF v_flg_if_iptv = 'N' THEN
        --ONT ya existe en el domicilio del cliente. Internet preexistente.
        --Flag en 'N' busco ONT vigente en Stealth solo si el equipo es STB
        IF nvl(v_flg_eq_conect, 0) > 0 THEN
          BEGIN
            SELECT cad_clu_cellular_number
              INTO v_nim_if
              FROM ag_sds_details agd, cellulars c, cellular_address cad
             WHERE agd.agd_asd_id_sds = pin_sds_id
               AND cad.cad_aaa_id = agd.agd_aaa_id
               AND c.clu_cellular_number = cad.cad_clu_cellular_number
               AND c.clu_cbt_id = 'IF'
               AND SYSDATE BETWEEN NVL(cad_start_date, SYSDATE) AND
                   NVL(cad_end_date, SYSDATE)
               AND ROWNUM < 2;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              v_nim_if := NULL;
          END;
          IF v_nim_if IS NOT NULL THEN
            BEGIN
              SELECT cet_pro_id
                INTO v_pro_id_conex
                FROM cellular_terminals cet
               WHERE cet.cet_clu_cellular_number = v_nim_if
                 AND cet.cet_start_date < SYSDATE
                 AND NVL(cet.cet_end_date, SYSDATE) >= SYSDATE;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                v_pro_id_conex := 'ERR-STB';
            END;
          ELSE
            v_pro_id_conex := 'ERR-STB';
          END IF;
        END IF;
      END IF;
    END IF;
    v_exec := 'Actualizando datos identificatorios de los materiales.';
    UPDATE ag_sds_details
       SET agd_pro_id         = v_pro_id,
           agd_mac_address    = pin_macadd,
           agd_nse_id         = pin_nse_id,
           agd_guid           = DECODE(pin_cbt_id, 'IPTV', pin_guid, NULL),
           agd_status         = pin_status,
           agd_lastmodif_date = SYSDATE,
           agd_lastmodif_usr  = USER
     WHERE agd_asd_id_sds = pin_sds_id
       AND agd_clu_cellular_number = pin_nim;
-- INCIO PC135022
    IF pin_cbt_id='IF' THEN
     UPDATE ag_sds_details
       SET agd_pro_id         = v_pro_id,
           agd_mac_address    = pin_macadd,
           agd_nse_id         = pin_nse_id,
           agd_guid           = NULL,
           agd_status         = pin_status,
           agd_nodo           = pin_nodo,
           agd_lastmodif_date = SYSDATE,
           agd_lastmodif_usr  = USER
     WHERE agd_asd_id_sds = pin_sds_id
     and agd_cbt_id ='IF';
    END IF;
-- FIN PC135022
    IF SQL%ROWCOUNT = 0 THEN
      pout_pro_id_conex := NULL;
      v_message         := 'ERROR: ' || v_exec || to_char(sqlcode);
      pout_msg          := v_message;
      ROLLBACK;
      RETURN - 1;
    ELSE
      pout_pro_id_conex := v_pro_id_conex;
      pout_msg          := 'La actualizacion del material ha sido exitosa.';
      COMMIT;
      RETURN 0;
    END IF;
  END;
END PA_WS_SGT_STL_INTERFACES;
/

