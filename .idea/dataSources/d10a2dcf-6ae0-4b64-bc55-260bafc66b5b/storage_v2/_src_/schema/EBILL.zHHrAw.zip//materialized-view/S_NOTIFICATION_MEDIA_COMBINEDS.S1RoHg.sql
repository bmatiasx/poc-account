create materialized view S_NOTIFICATION_MEDIA_COMBINEDS
refresh force on demand
  as
    SELECT nmc_id, nmc_description
FROM STL.notification_media_combineds@PROD

/

