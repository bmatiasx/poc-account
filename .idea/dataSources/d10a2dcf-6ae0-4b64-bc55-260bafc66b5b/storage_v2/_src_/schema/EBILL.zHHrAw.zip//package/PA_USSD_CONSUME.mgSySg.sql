create PACKAGE PA_USSD_CONSUME IS

/***************************************************************************************************************
  Package PA_USSD_CONSUME que permite validar el acceso a saldos y consumos ussd 
  y mostrar al cliente informacion relacionada.
*************************************************************************************************************** 
    FECHA             EVENTO           DESARROLLADOR      DESCRIPCION                                          
    19/06/2014        CTIU100104165    Jose M. Lascano     1.0 - Se agrego la funcion FOARMAT_NUMBER            
                                                                 y esta fue puesta en uso en las funciones  
                                                                 DAILY_CONSUMPTIONS y DETAIL_CONSUMPTIONS,    
                                                                 se cambio el tam?o para la variable del       
                                                                 simbolo de moneda pais.
                                                             
    23/10/2014        CTIU100109381   Mariano L. Giuga     1.1 - Se cambia la forma en que se obtiene 
                                                                 el precio del pack internet por dia a partir 
                                                                 del plan de la linea.  
                                                                 
    14/04/2016        USSD-271        Bertorello Pablo G.  1.2  - Se agrega la funcion USSD_SYC_GET_VOICE_CO 
                                                                  para el manejo de packs de voz 
                                                                      
    27/04/2016        USSD-291        Bertorello Pablo G.  1.3  - Se agrega el filtro rownum en VALIDATE_ENTRY para
                                                                  solucionar problemas en la funcion
    
    17/05/2016        USSD-291        Bertorello Pablo G.  1.34  - Se modifica la funcion VALIDATE_ENTRY para
                                                                  solucionar problemas en la misma, ademas se actualiza el historial de versiones que era incorrecto                                                                                                                                           
                                                                                                                                                                              
****************************************************************************************************************/


  /* Esta funcion valida que el cliente que ingresa est? activo y obtiene los datos necesarios para realizar la
  consulta de saldos y consumos.
   *    @param MSISDN : El MSISDN provisto por ATS
   *    @param PP_CELLULAR_NUMBER : El n?mero de l?nea sin c?digo de pa?s
   *    @param PP_LINETYPE : El tipo de l?nea
   *    @param PP_CATEGORY : Categor?a de la l?nea.
   *    @param PP_ACCOUNT_ID : Identificaci?n de la cuenta.
   *    @param PP_GEU_ID : Provincia a la cual pertenece la l?nea.
   *    @param PP_PLAN_ID : Identificaci?n del plan con el que cuenta la l?nea.
   *    @param PP_CICLO : Ciclo de la l?nea.
   *    @param PP_RTY_ID : Categor?a de la l?nea.
   *    @param PP_ERR_TEXT : Mensaje de error desplegado al cliente, en caso de haberlo.*/

  FUNCTION VALIDATE_ENTRY(MSISDN             IN S_CELLULARS.CLU_BILL_NUMBER%TYPE,
                          PP_CELLULAR_NUMBER OUT s_cellulars.clu_cellular_number%TYPE,
                          PP_LINETYPE        OUT s_cellulars.clu_cbt_id%TYPE,
                          PP_CATEGORY        OUT s_client.clt_category%TYPE,
                          PP_ACCOUNT_ID      OUT s_cellulars.clu_acc_id%TYPE,
                          PP_GEU_ID          OUT s_accounts.acc_geu_id%TYPE,
                          PP_PLAN_ID         OUT s_cellular_plans.cpl_rpl_id%TYPE,
                          PP_CICLO           OUT s_cycles.cyc_cyc_id%TYPE,
                          PP_RTY_ID          OUT s_rate_plans.rpl_rty_id%TYPE,
                          PP_STL_VALUE       OUT s_stl_parameters.stl_char_value%TYPE,
                          PP_PP_ERR_TEXT     OUT VARCHAR2,
                          PP_SQL_CODE        OUT VARCHAR2,
                          PP_ERR_CODE        OUT NUMBER) RETURN NUMBER;

  FUNCTION USSD_SYC_GET_USED_AMOUNT_CO(p_celular  s_cellulars.CLU_CELLULAR_NUMBER%TYPE,
                                       P_GEU_ID   STL_PARAMETERS.STL_CHAR_VALUE%TYPE,
                                       P_RESPONSE OUT VARCHAR2,
                                       P_ERR_TEXT OUT VARCHAR2,
                                       P_ERR_CODE OUT NUMBER,
                                       P_SQL_CODE OUT VARCHAR2) RETURN NUMBER;

  --

  FUNCTION USSD_SYC_GPRS_CO(P_CELLULAR IN s_cellulars.CLU_CELLULAR_NUMBER%TYPE,
                            p_acc_id   IN s_accounts.acc_id%TYPE,
                            P_CYCLE    IN s_cycles.cyc_cyc_id%TYPE,
                            P_RESPONSE OUT VARCHAR2,
                            P_ERR_TEXT OUT VARCHAR2,
                            P_ERR_CODE OUT NUMBER,
                            P_SQL_CODE OUT VARCHAR2) RETURN NUMBER;
  --

  FUNCTION USSD_SYC_GET_SMS_CO(P_CELLULAR IN s_cellulars.CLU_CELLULAR_NUMBER%TYPE,
                               P_CYCLE    IN s_cycles.cyc_cyc_id%TYPE,
                               P_RESPONSE OUT VARCHAR2,
                               P_ERR_TEXT OUT VARCHAR2,
                               P_ERR_CODE OUT NUMBER,
                               P_SQL_CODE OUT VARCHAR2) RETURN NUMBER;
  --

  FUNCTION USSD_SYC_GET_SURPLUS_CO(p_acc_id   IN s_accounts.acc_id%TYPE,
                                   p_cellular IN s_cellulars.clu_bill_number%TYPE,
                                   P_GEU_ID   s_STL_PARAMETERS.STL_CHAR_VALUE%TYPE,
                                   P_RESPONSE OUT VARCHAR2,
                                   P_ERR_TEXT OUT VARCHAR2,
                                   P_ERR_CODE OUT NUMBER,
                                   P_SQL_CODE OUT VARCHAR2) RETURN NUMBER;

  FUNCTION DAILY_CONSUMPTIONS(PP_CELLULAR VARCHAR2,
                              PP_DIA      IN NUMBER,
                              PP_RESPONSE OUT VARCHAR2,
                              PP_ERR_TEXT OUT VARCHAR2,
                              PP_ERR_CODE OUT NUMBER,
                              PP_SQL_CODE OUT VARCHAR2) RETURN NUMBER;

  --
  FUNCTION DETAIL_CONSUMPTIONS(PP_CELLULAR IN OUT VARCHAR2,
                               PP_DIA      IN VARCHAR2,
                               PP_SERV     IN VARCHAR2,
                               PP_RESPONSE OUT VARCHAR2,
                               PP_ERR_TEXT OUT VARCHAR2,
                               PP_ERR_CODE OUT NUMBER,
                               PP_SQL_CODE OUT VARCHAR2) RETURN NUMBER;
                               
                               
                               
FUNCTION USSD_SYC_GET_VOICE_CO(P_MSISDN IN VARCHAR2,
                            P_RESPONSE OUT VARCHAR2,
                            P_ERR_TEXT OUT VARCHAR2,
                            P_ERR_CODE OUT NUMBER,
                            P_SQL_CODE OUT VARCHAR2) RETURN NUMBER;
END PA_USSD_CONSUME;
/

