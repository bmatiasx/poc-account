create materialized view S_FEATURE_PACKAGES
refresh complete on demand
  as
    Select
  "FEATURE_PACKAGES"."PKS_FTR_ID",
  "FEATURE_PACKAGES"."PKS_PKT_ID"
FROM "FEATURE_PACKAGES"@PROD.WORLD "FEATURE_PACKAGES"
/

