create materialized view S_BORRAR
refresh force on demand
  as
    select * from 
(
SELECT * FROM account_messages@PROD
)
/

