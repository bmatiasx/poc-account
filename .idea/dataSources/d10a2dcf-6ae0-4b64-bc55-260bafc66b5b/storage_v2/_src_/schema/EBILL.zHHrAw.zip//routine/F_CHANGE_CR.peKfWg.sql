create FUNCTION F_CHANGE_CR

 (P_CELLULAR IN VARCHAR2
 ,P_DD_TYPE IN VARCHAR2
 ,P_DD_TYPE_NEW IN VARCHAR2
 ,P_REASON_CR IN VARCHAR2
 ,P_REASON_SI IN VARCHAR2
 ,P_CALL_DELIVERY IN VARCHAR2
 ,P_CALL_RESTRICTION OUT VARCHAR2
 ,P_ID OUT VARCHAR2
 ,P_DESCRIPTION OUT VARCHAR2
 ,P_VALUE OUT VARCHAR2
 ,P_ERR_NUM OUT VARCHAR2
 ,P_ERR_MSG OUT VARCHAR2
 )
 RETURN NUMBER
 IS
V_RESULT            VARCHAR2(10);
  V_ERR_MSG           VARCHAR2(500);
  V_STATUS            VARCHAR2(1) := '0';
  V_CCR_ID            VARCHAR2(15);
  V_CED_ID            VARCHAR2(15);
  V_APPROVAL_REQUIRED VARCHAR2(10);
  V_MSG_INFO          VARCHAR2(100);
  V_FLAG_APP_REQ      VARCHAR2(1);
BEGIN

  -- Le pasa el call restriction actual, para obtener el estado de las flags
  IF P_DD_TYPE = '1' OR P_DD_TYPE = '2' THEN
    -- Obtiene el estado de las flags
    BEGIN
      V_RESULT := F_GET_CELLULAR_FLAGS(P_CELLULAR,
                                       P_DD_TYPE,
                                       P_ID,
                                       P_VALUE,
                                       P_DESCRIPTION,
                                       P_ERR_MSG);
    EXCEPTION
      WHEN OTHERS THEN
        P_ERR_NUM := '1000';
        P_ERR_MSG := 'Error al intentar obtener el estado de las flags: ' ||
                     SQLCODE || ' ## ' || SQLERRM;
        RETURN - 1;
    END;

    BEGIN
      -- Obtiene el tipo de DDI que posee la línea (Común o Full)
      IF P_DD_TYPE = '1' THEN
        SELECT CED_DDI_TYPE
          INTO P_CALL_RESTRICTION
          FROM CELLULAR_DDI_TYPES
         WHERE CED_CLU_CELLULAR_NUMBER = P_CELLULAR
           AND CED_END_DATE IS NULL;
      END IF;

    EXCEPTION
      -- Si no está en CELLULAR_DDI_TYPES siendo DDI, es tipo 'DDI Común'
      WHEN NO_DATA_FOUND THEN
        P_CALL_RESTRICTION := 'C';
      WHEN OTHERS THEN
        P_ERR_NUM := '1001';
        P_ERR_MSG := 'Error al intentar consultar CELLULAR_DDI_TYPES: ' ||
                     SQLCODE || ' ## ' || SQLERRM;
        RETURN - 1;
    END;

    BEGIN
      -- Revisa si tiene alguna transacción pendiente de aprobación en CELLULAR_DDI_TYPES
      SELECT '1',
             'Tu transacción está siendo procesada. En las próximas 24 horas será ejecutada.'
        INTO V_STATUS, P_ERR_MSG
        FROM CELLULAR_DDI_TYPES
       WHERE CED_CLU_CELLULAR_NUMBER = P_CELLULAR
         AND CED_APPROVAL_REQUIRED = 'Y'
         AND CED_APPROVED_DATE IS NULL
         AND CED_END_DATE IS NULL;

      P_ERR_NUM := '1002';
      RETURN V_STATUS;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        BEGIN
          -- Revisa si tiene alguna transacción pendiente en SWITCH_INTERFACES_HP
          SELECT '1',
                 'El número ingresado tiene una transacción pendiente, con alta prioridad.'
            INTO V_STATUS, P_ERR_MSG
            FROM SWITCH_INTERFACES_HP
           WHERE SIS_ASSIGNED_NIM = P_CELLULAR
             AND SIS_STATUS LIKE 'P'
             AND SIS_REASON_CODE IN ('SIUSDO', 'CMBCED', 'PASWIN');

          P_ERR_NUM := '1003';
          RETURN V_STATUS;

        EXCEPTION
          -- Si no tiene pendientes en SWITCH_INTERFACES_HP, revisa en SWITCH_INTERFACES
          WHEN NO_DATA_FOUND THEN
            BEGIN
              SELECT '1',
                     'El número ingresado tiene una transacción pendiente.'
                INTO V_STATUS, P_ERR_MSG
                FROM SWITCH_INTERFACES
               WHERE SIS_ASSIGNED_NIM = P_CELLULAR
                 AND SIS_STATUS LIKE 'P'
                 AND SIS_REASON_CODE IN ('SIUSDO', 'CMBCED', 'PASWIN');

              P_ERR_NUM := '1004';
              RETURN V_STATUS;

            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                P_ERR_NUM := NULL;
                P_ERR_MSG := NULL;
                RETURN 0;

              WHEN OTHERS THEN
                P_ERR_NUM := '1005';
                P_ERR_MSG := 'Error al intentar consultar SWITCH_INTERFACES: ' ||
                             SQLCODE || ' ## ' || SQLERRM;
                RETURN - 1;
            END;
          WHEN OTHERS THEN
            P_ERR_NUM := '1006';
            P_ERR_MSG := 'Error al intentar consultar SWITCH_INTERFACES_HP: ' ||
                         SQLCODE || ' ## ' || SQLERRM;
            RETURN - 1;
        END;
      WHEN OTHERS THEN
        P_ERR_NUM := '1007';
        P_ERR_MSG := 'Error al intentar consultar CELLULAR_DDI_TYPES: ' ||
                     SQLCODE || ' ## ' || SQLERRM;
        RETURN - 1;
    END;

    --Si es DDN, DDI Común, DDI Full
  ELSIF P_DD_TYPE IN ('N', 'C', 'F') THEN

    -- Consigue flag para realizar o no la validación para aprobación de un supervisor
    BEGIN
      SELECT STL_CHAR_VALUE
        INTO V_FLAG_APP_REQ
        FROM STL_PARAMETERS
       WHERE STL_ID = 'APPREQ';
    EXCEPTION
      WHEN OTHERS THEN
        P_ERR_NUM := '1008';
        P_ERR_MSG := 'Error al intentar consultar STL_PARAMETERS: ' ||
                     SQLCODE || ' ## ' || SQLERRM;
        RETURN - 1;
    END;

    -- ## ENTRA CON P_DD_TYPE COMO DDN
    IF P_DD_TYPE = 'N' THEN
      -- Actualiza pasándolo a DDI
      BEGIN
        SELECT CCR_ID
          INTO V_CCR_ID
          FROM CELLULAR_CALL_RESTRICTIONS
         WHERE CCR_CLU_CELLULAR_NUMBER = P_CELLULAR
           AND CCR_END_DATE IS NULL;

        UPDATE CELLULAR_CALL_RESTRICTIONS
           SET CCR_LAST_UPDATED_DATE = SYSDATE, CCR_END_DATE = SYSDATE
         WHERE CCR_ID = V_CCR_ID;

        INSERT INTO CELLULAR_CALL_RESTRICTIONS
          (CCR_ID,
           CCR_CR_ID,
           CCR_START_DATE,
           CCR_CLU_CELLULAR_NUMBER,
           CCR_LAST_UPDATED_DATE,
           CCR_RSN_ID)
        VALUES
          (CCR_SEQ.NEXTVAL, '1', SYSDATE, P_CELLULAR, SYSDATE, P_REASON_CR);

      EXCEPTION
        WHEN OTHERS THEN
          P_ERR_NUM := '1009';
          P_ERR_MSG := 'Error al intentar actualizar CELLULAR_CALL_RESTRICTIONS: ' ||
                       SQLCODE || ' ## ' || SQLERRM;
          RETURN - 1;
      END;

      -- Validación de bandera de STL_PARAMETERS para validar si requierer aprobación de un supervisor.
      IF P_DD_TYPE_NEW = 'F' AND V_FLAG_APP_REQ = 'Y' THEN
        BEGIN
          V_RESULT := F_VALIDATE_DDI_PARAM(P_CELULLAR_NUMBER   => P_CELLULAR,
                                           P_APPROVAL_REQUIRED => V_APPROVAL_REQUIRED,
                                           P_APPROVAL_MSG      => V_MSG_INFO,
                                           P_ERROR_MSG         => V_ERR_MSG,
                                           P_ERROR_NUM         => P_ERR_NUM);

          IF V_RESULT <> 0 THEN
            V_APPROVAL_REQUIRED := 'Y';
            V_MSG_INFO          := 'Tu transacción está siendo procesada. En las próximas 24 horas será ejecutada.';
          END IF;

        EXCEPTION
          WHEN OTHERS THEN
            V_APPROVAL_REQUIRED := 'Y';
            V_MSG_INFO          := 'Tu transacción está siendo procesada. En las próximas 24 horas será ejecutada.';
        END;
      END IF;

      -- Actualiza en C o F el tipo de DDI
      BEGIN
        SELECT CED_ID
          INTO V_CED_ID
          FROM CELLULAR_DDI_TYPES
         WHERE CED_CLU_CELLULAR_NUMBER = P_CELLULAR
           AND CED_END_DATE IS NULL;

        UPDATE CELLULAR_DDI_TYPES
           SET CED_END_DATE = SYSDATE
         WHERE CED_ID = V_CED_ID;

        INSERT INTO CELLULAR_DDI_TYPES
          (CED_ID,
           CED_CLU_CELLULAR_NUMBER,
           CED_DDI_TYPE,
           CED_USER,
           CED_APPROVAL_REQUIRED,
           CED_START_DATE)
        VALUES
          (CED_SEQ.NEXTVAL,
           P_CELLULAR,
           P_DD_TYPE_NEW,
           USER,
           V_APPROVAL_REQUIRED,
           SYSDATE);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          --Lo carga en CELLULAR_DDI_TYPES en caso de ser la primera vez que tiene algún cambio a DDI
          INSERT INTO CELLULAR_DDI_TYPES
            (CED_ID,
             CED_CLU_CELLULAR_NUMBER,
             CED_DDI_TYPE,
             CED_USER,
             CED_APPROVAL_REQUIRED,
             CED_START_DATE)
          VALUES
            (CED_SEQ.NEXTVAL,
             P_CELLULAR,
             P_DD_TYPE_NEW,
             USER,
             V_APPROVAL_REQUIRED,
             SYSDATE);
        WHEN OTHERS THEN
          P_ERR_NUM := '1012';
          P_ERR_MSG := 'Error al intentar actualizar CELLULAR_DDI_TYPES: ' ||
                       SQLCODE || ' ## ' || SQLERRM;
          RETURN - 1;
      END;

      -- Si cambia a DDI Full y requiere aprobación, retorna 0 ya que el insert en SWITCH_INTERFACE se realizará cuando lo apruebe el supervisor
      IF P_DD_TYPE_NEW = 'F' AND V_APPROVAL_REQUIRED = 'Y' THEN
        P_ERR_NUM := '1013';
        P_ERR_MSG := V_MSG_INFO;
        RETURN 0;
      END IF;

      BEGIN
        DBMS_APPLICATION_INFO.SET_CLIENT_INFO('CAMBIO_DDI_DDN_VIA_WEB');
      END;

      BEGIN
        V_RESULT := PA_SWITCH_INTERFACES.INSERT_SWITCH_INTERFACE(P_CELULAR       => P_CELLULAR,
                                                                 P_ACTION        => 'U',
                                                                 P_ACTION_DATE   => SYSDATE,
                                                                 P_PRIORIDAD     => '4',
                                                                 P_ESTADO        => NULL,
                                                                 P_RSN           => P_REASON_SI,
                                                                 P_ESN           => NULL,
                                                                 P_CALL_DELIVERY => P_CALL_DELIVERY,
                                                                 P_DCL           => NULL,
                                                                 P_PRA           => NULL,
                                                                 P_PACK          => NULL,
                                                                 P_CALLR         => '1', --P_DD_TYPE_NEW,
                                                                 P_CHANGE_NIM    => NULL,
                                                                 MSG_ERR         => V_ERR_MSG,
                                                                 P_LIMITE_CONS   => NULL);

        IF V_RESULT <> 0 THEN
          P_ERR_NUM := '1014';
          P_ERR_MSG := 'Error al intentar actualizar SWITCH_INTERFACE: ' ||
                       V_ERR_MSG;
          RETURN - 1;
        END IF;

      EXCEPTION
        WHEN OTHERS THEN
          P_ERR_NUM := '1015';
          P_ERR_MSG := 'Error al intentar actualizar SWITCH_INTERFACE: ' ||
                       SQLCODE || ' ## ' || SQLERRM;
          RETURN - 1;
      END;

      RETURN 0; -- Final y resultado del P_DD_TYPE en N

      -- ## ENTRA CON P_DD_TYPE COMO DDI COMÚN
    ELSIF P_DD_TYPE = 'C' THEN

      -- Viene con DDI Común, se pasa a DDN
      IF P_DD_TYPE_NEW = 'N' THEN
        BEGIN
          SELECT CCR_ID
            INTO V_CCR_ID
            FROM CELLULAR_CALL_RESTRICTIONS
           WHERE CCR_CLU_CELLULAR_NUMBER = P_CELLULAR
             AND CCR_END_DATE IS NULL;

          UPDATE CELLULAR_CALL_RESTRICTIONS
             SET CCR_LAST_UPDATED_DATE = SYSDATE, CCR_END_DATE = SYSDATE
           WHERE CCR_ID = V_CCR_ID;

          INSERT INTO CELLULAR_CALL_RESTRICTIONS
            (CCR_ID,
             CCR_CR_ID,
             CCR_START_DATE,
             CCR_CLU_CELLULAR_NUMBER,
             CCR_LAST_UPDATED_DATE,
             CCR_RSN_ID)
          VALUES
            (CCR_SEQ.NEXTVAL,
             '2',
             SYSDATE,
             P_CELLULAR,
             SYSDATE,
             P_REASON_CR);
        EXCEPTION
          WHEN OTHERS THEN
            P_ERR_NUM := '1016';
            P_ERR_MSG := 'Error al intentar actualizar CELLULAR_CALL_RESTRICTIONS: ' ||
                         SQLCODE || ' ## ' || SQLERRM;
            RETURN - 1;
        END;

        BEGIN
          DBMS_APPLICATION_INFO.SET_CLIENT_INFO('CAMBIO_DDI_DDN_VIA_WEB');
        END;

        BEGIN
          V_RESULT := PA_SWITCH_INTERFACES.INSERT_SWITCH_INTERFACE(P_CELULAR       => P_CELLULAR,
                                                                   P_ACTION        => 'U',
                                                                   P_ACTION_DATE   => SYSDATE,
                                                                   P_PRIORIDAD     => '4',
                                                                   P_ESTADO        => NULL,
                                                                   P_RSN           => P_REASON_SI,
                                                                   P_ESN           => NULL,
                                                                   P_CALL_DELIVERY => P_CALL_DELIVERY,
                                                                   P_DCL           => NULL,
                                                                   P_PRA           => NULL,
                                                                   P_PACK          => NULL,
                                                                   P_CALLR         => '2', --P_DD_TYPE_NEW,
                                                                   P_CHANGE_NIM    => NULL,
                                                                   MSG_ERR         => V_ERR_MSG,
                                                                   P_LIMITE_CONS   => NULL);

          IF V_RESULT <> 0 THEN
            P_ERR_NUM := '1017';
            P_ERR_MSG := 'Error al intentar actualizar SWITCH_INTERFACE: ' ||
                         V_ERR_MSG;
            RETURN - 1;
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            P_ERR_NUM := '1018';
            P_ERR_MSG := 'Error al intentar actualizar SWITCH_INTERFACE: ' ||
                         SQLCODE || ' ## ' || SQLERRM;
            RETURN - 1;
        END;

        RETURN 0; -- Final y resultado del P_DD_TYPE en C, pasándose a DDN

        -- Viene con DDI Común, se pasa a DDI Full
      ELSIF P_DD_TYPE_NEW = 'F' THEN

        -- Validación de bandera de STL_PARAMETERS para validar si requierer aprobación de un supervisor.
        IF V_FLAG_APP_REQ = 'Y' THEN
          BEGIN
            V_RESULT := F_VALIDATE_DDI_PARAM(P_CELULLAR_NUMBER   => P_CELLULAR,
                                             P_APPROVAL_REQUIRED => V_APPROVAL_REQUIRED,
                                             P_APPROVAL_MSG      => V_MSG_INFO,
                                             P_ERROR_MSG         => V_ERR_MSG,
                                             P_ERROR_NUM         => P_ERR_NUM);

            IF V_RESULT <> 0 THEN
              V_APPROVAL_REQUIRED := 'Y';
              V_MSG_INFO          := 'Tu transacción está siendo procesada. En las próximas 24 horas será ejecutada.';
            END IF;

          EXCEPTION
            WHEN OTHERS THEN
              V_APPROVAL_REQUIRED := 'Y';
              V_MSG_INFO          := 'Tu transacción está siendo procesada. En las próximas 24 horas será ejecutada.';
          END;
        END IF;

        BEGIN
          SELECT CED_ID
            INTO V_CED_ID
            FROM CELLULAR_DDI_TYPES
           WHERE CED_CLU_CELLULAR_NUMBER = P_CELLULAR
             AND CED_END_DATE IS NULL;

          UPDATE CELLULAR_DDI_TYPES
             SET CED_END_DATE = SYSDATE
           WHERE CED_ID = V_CED_ID;

          INSERT INTO CELLULAR_DDI_TYPES
            (CED_ID,
             CED_CLU_CELLULAR_NUMBER,
             CED_DDI_TYPE,
             CED_USER,
             CED_APPROVAL_REQUIRED,
             CED_START_DATE)
          VALUES
            (CED_SEQ.NEXTVAL,
             P_CELLULAR,
             P_DD_TYPE_NEW,
             USER,
             V_APPROVAL_REQUIRED,
             SYSDATE);
        EXCEPTION
          -- Si no tiene registro en CELLULAR_DDI_TYPES, lo carga al ser la primera vez que cambia su DDI
          WHEN NO_DATA_FOUND THEN
            INSERT INTO CELLULAR_DDI_TYPES
              (CED_ID,
               CED_CLU_CELLULAR_NUMBER,
               CED_DDI_TYPE,
               CED_USER,
               CED_APPROVAL_REQUIRED,
               CED_START_DATE)
            VALUES
              (CED_SEQ.NEXTVAL,
               P_CELLULAR,
               P_DD_TYPE_NEW,
               USER,
               V_APPROVAL_REQUIRED,
               SYSDATE);
          WHEN OTHERS THEN
            P_ERR_NUM := '1021';
            P_ERR_MSG := 'Error al intentar actualizar CELLULAR_DDI_TYPES: ' ||
                         SQLCODE || ' ## ' || SQLERRM;
            RETURN - 1;
        END;

        -- Si cambia a DDI Full y requiere aprobación, retorna 0 ya que el insert en SWITCH_INTERFACE se realizará cuando lo apruebe el supervisor
        IF V_APPROVAL_REQUIRED = 'Y' THEN
          P_ERR_NUM := '1022';
          P_ERR_MSG := V_MSG_INFO;
          RETURN 0;
        END IF;

        BEGIN
          DBMS_APPLICATION_INFO.SET_CLIENT_INFO('CAMBIO_DDI_DDN_VIA_WEB');
        END;

        BEGIN
          V_RESULT := PA_SWITCH_INTERFACES.INSERT_SWITCH_INTERFACE(P_CELULAR       => P_CELLULAR,
                                                                   P_ACTION        => 'U',
                                                                   P_ACTION_DATE   => SYSDATE,
                                                                   P_PRIORIDAD     => '4',
                                                                   P_ESTADO        => NULL,
                                                                   P_RSN           => P_REASON_SI,
                                                                   P_ESN           => NULL,
                                                                   P_CALL_DELIVERY => P_CALL_DELIVERY,
                                                                   P_DCL           => NULL,
                                                                   P_PRA           => NULL,
                                                                   P_PACK          => NULL,
                                                                   P_CALLR         => '1', --P_DD_TYPE_NEW,
                                                                   P_CHANGE_NIM    => NULL,
                                                                   MSG_ERR         => V_ERR_MSG,
                                                                   P_LIMITE_CONS   => NULL);

          IF V_RESULT <> 0 THEN
            P_ERR_NUM := '1023';
            P_ERR_MSG := 'Error al intentar actualizar SWITCH_INTERFACE: ' ||
                         V_ERR_MSG;
            RETURN - 1;
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            P_ERR_NUM := '1024';
            P_ERR_MSG := 'Error al intentar actualizar SWITCH_INTERFACE: ' ||
                         SQLCODE || ' ## ' || SQLERRM;
            RETURN - 1;
        END;

        RETURN 0; -- Resultado del P_DD_TYPE en C, pasándose a DDI Full

      END IF; -- Fin del P_DD_TYPE en C,

      -- ## ENTRA CON P_DD_TYPE COMO DDI FULL
    ELSIF P_DD_TYPE = 'F' THEN

      -- Viene con DDI Full, se pasa a DDN
      IF P_DD_TYPE_NEW = 'N' THEN
        BEGIN
          SELECT CCR_ID
            INTO V_CCR_ID
            FROM CELLULAR_CALL_RESTRICTIONS
           WHERE CCR_CLU_CELLULAR_NUMBER = P_CELLULAR
             AND CCR_END_DATE IS NULL;

          UPDATE CELLULAR_CALL_RESTRICTIONS
             SET CCR_LAST_UPDATED_DATE = SYSDATE, CCR_END_DATE = SYSDATE
           WHERE CCR_ID = V_CCR_ID;

          INSERT INTO CELLULAR_CALL_RESTRICTIONS
            (CCR_ID,
             CCR_CR_ID,
             CCR_START_DATE,
             CCR_CLU_CELLULAR_NUMBER,
             CCR_LAST_UPDATED_DATE,
             CCR_RSN_ID)
          VALUES
            (CCR_SEQ.NEXTVAL,
             '2',
             SYSDATE,
             P_CELLULAR,
             SYSDATE,
             P_REASON_CR);
        EXCEPTION
          WHEN OTHERS THEN
            P_ERR_NUM := '1025';
            P_ERR_MSG := 'Error al intentar actualizar CELLULAR_CALL_RESTRICTIONS: ' ||
                         SQLCODE || ' ## ' || SQLERRM;
            RETURN - 1;
        END;

        BEGIN
          DBMS_APPLICATION_INFO.SET_CLIENT_INFO('CAMBIO_DDI_DDN_VIA_WEB');
        END;

        BEGIN
          V_RESULT := PA_SWITCH_INTERFACES.INSERT_SWITCH_INTERFACE(P_CELULAR       => P_CELLULAR,
                                                                   P_ACTION        => 'U',
                                                                   P_ACTION_DATE   => SYSDATE,
                                                                   P_PRIORIDAD     => '4',
                                                                   P_ESTADO        => NULL,
                                                                   P_RSN           => P_REASON_SI,
                                                                   P_ESN           => NULL,
                                                                   P_CALL_DELIVERY => P_CALL_DELIVERY,
                                                                   P_DCL           => NULL,
                                                                   P_PRA           => NULL,
                                                                   P_PACK          => NULL,
                                                                   P_CALLR         => '2', --P_DD_TYPE_NEW,
                                                                   P_CHANGE_NIM    => NULL,
                                                                   MSG_ERR         => V_ERR_MSG,
                                                                   P_LIMITE_CONS   => NULL);

          IF V_RESULT <> 0 THEN
            P_ERR_NUM := '1026';
            P_ERR_MSG := 'Error al intentar actualizar SWITCH_INTERFACE: ' ||
                         V_ERR_MSG;
            RETURN - 1;
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            P_ERR_NUM := '1027';
            P_ERR_MSG := 'Error al intentar actualizar SWITCH_INTERFACE: ' ||
                         SQLCODE || ' ## ' || SQLERRM;
            RETURN - 1;
        END;

        RETURN 0; -- Final y resultado del P_DD_TYPE en F, pasándose a DDN

        -- Viene con DDI Full, se pasa a DDI Común
      ELSIF P_DD_TYPE_NEW = 'C' THEN
        BEGIN
          SELECT CED_ID
            INTO V_CED_ID
            FROM CELLULAR_DDI_TYPES
           WHERE CED_CLU_CELLULAR_NUMBER = P_CELLULAR
             AND CED_END_DATE IS NULL;

          UPDATE CELLULAR_DDI_TYPES
             SET CED_END_DATE = SYSDATE
           WHERE CED_ID = V_CED_ID;

          INSERT INTO CELLULAR_DDI_TYPES
            (CED_ID,
             CED_CLU_CELLULAR_NUMBER,
             CED_DDI_TYPE,
             CED_USER,
             CED_APPROVAL_REQUIRED,
             CED_START_DATE)
          VALUES
            (CED_SEQ.NEXTVAL,
             P_CELLULAR,
             P_DD_TYPE_NEW,
             USER,
             'N',
             SYSDATE);
        EXCEPTION
          WHEN OTHERS THEN
            P_ERR_NUM := '1028';
            P_ERR_MSG := 'Error al intentar actualizar CELLULAR_DDI_TYPES: ' ||
                         SQLCODE || ' ## ' || SQLERRM;
            RETURN - 1;
        END;

        BEGIN
          DBMS_APPLICATION_INFO.SET_CLIENT_INFO('CAMBIO_DDI_DDN_VIA_WEB');
        END;

        BEGIN
          V_RESULT := PA_SWITCH_INTERFACES.INSERT_SWITCH_INTERFACE(P_CELULAR       => P_CELLULAR,
                                                                   P_ACTION        => 'U',
                                                                   P_ACTION_DATE   => SYSDATE,
                                                                   P_PRIORIDAD     => '4',
                                                                   P_ESTADO        => NULL,
                                                                   P_RSN           => P_REASON_SI,
                                                                   P_ESN           => NULL,
                                                                   P_CALL_DELIVERY => P_CALL_DELIVERY,
                                                                   P_DCL           => NULL,
                                                                   P_PRA           => NULL,
                                                                   P_PACK          => NULL,
                                                                   P_CALLR         => '1', --P_DD_TYPE_NEW,
                                                                   P_CHANGE_NIM    => NULL,
                                                                   MSG_ERR         => V_ERR_MSG,
                                                                   P_LIMITE_CONS   => NULL);

          IF V_RESULT <> 0 THEN
            P_ERR_NUM := '1029';
            P_ERR_MSG := 'Error al intentar actualizar SWITCH_INTERFACE: ' ||
                         V_ERR_MSG;
            RETURN - 1;
          END IF;

        EXCEPTION
          WHEN OTHERS THEN
            P_ERR_NUM := '1030';
            P_ERR_MSG := 'Error al intentar actualizar SWITCH_INTERFACE: ' ||
                         SQLCODE || ' ## ' || SQLERRM;
            RETURN - 1;
        END;

        RETURN 0; -- Resultado del P_DD_TYPE en C, pasándose a DDN

      END IF; -- Final del P_DD_TYPE_NEW en C

    END IF; -- Final del P_DD_TYPE en F

  ELSE
    --Fin validación P_DD_TYPE
    P_ERR_NUM := '1031';
    P_ERR_MSG := 'Las opciones posibles para P_DD_TYPE son 1, 2, N, C, F.';
    RETURN 1;
  END IF;

EXCEPTION
  WHEN OTHERS THEN
    P_ERR_NUM := '0000';
    P_ERR_MSG := 'Error en F_CHANGE_DD_TYPE: ' || SQLCODE || ' ## ' ||
                 SQLERRM;
    RETURN - 1;
END;
/

