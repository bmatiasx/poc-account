create view ED_PACKAGES_EDETAILS as
  select EPE_PKT_ID, EPE_START_DATE, EPE_END_DATE
  from ed_packages_edetails@prod

/

