create package PA_USSD_MAIN_MENU is

  -- Author  : BERTORELLO PABLO G. EXA00339
  -- Created : 29/12/2015
  -- Adaptacion de PA_LINE_PROFILE para menu principal dinamico de USSD
  -- Version 1.0

function Get_Basic_Profile(MSISDN in  varchar2,
                            
                             po_businessType    out varchar2,
                            
                             po_codigo_error    out varchar2,
                             po_mensaje_error   out varchar2,
                             po_mensaje_salida  out varchar2) return NUMBER;
  
end PA_USSD_MAIN_MENU;
/

