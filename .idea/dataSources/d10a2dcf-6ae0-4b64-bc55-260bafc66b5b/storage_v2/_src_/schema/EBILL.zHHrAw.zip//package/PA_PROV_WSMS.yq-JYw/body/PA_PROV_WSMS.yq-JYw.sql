create package body PA_PROV_WSMS is



FUNCTION  GET_DATA(pin_imsi VARCHAR2,
                  /* pout_cellular_number OUT VARCHAR2,
                   pout_msisdn          OUT VARCHAR2,
                   pout_iccid           OUT VARCHAR2
                   */
                   POUT_CURSOR_DATA OUT T_CURSOR,
                   Pinout_message       IN OUT  VARCHAR2) return NUMBER is

v_result                     NUMBER; 
v_cellular_number            S_CELLULARS.CLU_CELLULAR_NUMBER%TYPE;
v_msisdn                     SIMS.SIM_MSISDN%TYPE                          := NULL;
v_iccid                      SIMS.SIM_ICCID%TYPE                           := NULL;
v_imei                       CELLULAR_IMEI_TRACKINGS.CIM_IMEI%TYPE         := NULL;
v_action_date                DATE                                          := SYSDATE;
v_imsi                       SIMS.SIM_IMSI%TYPE                            := NULL;
v_cursor_cellular_info       T_CURSOR;  
v_cbt_id                     cellulars.clu_cbt_id%TYPE                     := NULL;
v_status                     cellulars.clu_status%TYPE                     := NULL;
v_category                   client.clt_category%TYPE                      := NULL;
v_clt_type                   client.clt_type%TYPE                          := NULL;
v_clt_id                     client.clt_id%TYPE                            := NULL;
v_acc_id                     accounts.acc_id%TYPE                          := NULL;
v_cr_description             CALL_RESTRICTIONS.cr_description%TYPE         := NULL;
v_imei_tracking              CELLULAR_IMEI_TRACKINGS.CIM_IMEI%TYPE         := NULL;
V_RPL_ID                     CELLULAR_PLANS.cpl_rpl_id%TYPE                := NULL;
v_old_as_client              VARCHAR2(5)                                   := NULL; 
V_credit_limit               VARCHAR2(100)                                 := NULL;  
v_aut_id                     CELLULARS.CLU_AUT_ID%TYPE                     := NULL;    
v_techonology                PRODUCTS.PRO_TECHNOLOGY%TYPE                  := NULL;     
v_flag_active_service_data   VARCHAR2(1)                                   := 'N';
v_flag_active_quota_internet VARCHAR2(1)                                   := 'N';
v_package                    VARCHAR2(500)                                 := NULL;   
v_feature_data               FEATURE_PACKAGES.PKS_FTR_ID%TYPE              := NULL;  
v_apn_igprs                  VARCHAR2(1)                                   := 'N';
BEGIN 
  v_imsi := pin_imsi;
  
  Pinout_message := null;
  
    BEGIN
 -- obteniendo CELLULAR_NUMBER y MSISDN a traves del numero de IMSI que envia la plataforma MOBILEUM 
         PA_PROV_GET_INFO.p_Get_Msisdn_Cellular_Imsi(
                   p_Imsi                => V_imsi,
                   p_Cellular_Number     => v_cellular_number,
                   p_Msisdn              => V_msisdn,
                   p_iccid               => V_iccid,
                   p_Imei           => V_imei,
                   p_Action_Date      => V_ACTION_DATE);
    EXCEPTION WHEN OTHERS THEN
         Pinout_message := 'Error en '|| c_package_name || c_function_name ||  ': Al tratar de obtener  CELLULAR_NUMBER y MSISDN' || ': ' || SQLERRM;
         RETURN -1;            
    END;
    
    
   
   IF v_cellular_number IS NULL THEN
      Pinout_message := 'Error en '|| c_package_name || c_function_name ||  ': no se pudo obtener el numero de Cellular, devuelve null' ;
      RETURN -1;
   END IF;
 
 
 
    BEGIN
     -- obteniendo datos basicos de la linea
     
         v_result := PA_PROV_GET_INFO.p_get_cellular_info(pin_cellular_number        => v_cellular_number,
                                                           pout_cursor_cellular_info => v_cursor_cellular_info,
                                                           p_action_date             => V_ACTION_DATE,
                                                           pout_message              => Pinout_message); 
    
        IF v_result = -1 THEN
            Pinout_message := 'Error en '|| c_package_name || c_function_name ||  Pinout_message;
            RETURN -1;
        END IF;
    
    
       BEGIN
        IF v_cursor_cellular_info%ISOPEN THEN
          LOOP
             FETCH v_cursor_cellular_info  INTO   v_cbt_id,
                                                  v_status,
                                                  v_category,
                                                  v_clt_type,
                                                  v_clt_id,
                                                  v_acc_id,
                                                  v_cr_description,
                                                  v_imei_tracking,
                                                  V_RPL_ID,
                                                  v_old_as_client,
                                                  V_credit_limit,
                                                  v_aut_id
                                                  ;
            EXIT WHEN v_cursor_cellular_info%NOTFOUND; 
           END LOOP;
         
         CLOSE v_cursor_cellular_info;
        END IF;
      EXCEPTION WHEN OTHERS THEN
         Pinout_message := 'Error en '|| c_package_name || c_function_name ||  ':ERROR - al armar el cursor con los datos basicos del Cellular, al llamar a PA_PROV_GET_INFO.p_get_cellular_info ' || SQLERRM;
      END;
    
    
    
    EXCEPTION WHEN OTHERS THEN
      Pinout_message := 'Error en '|| c_package_name || c_function_name ||  ':ERROR - no se pudo obtener los datos basicos del Cellular, al llamar a PA_PROV_GET_INFO.p_get_cellular_info ' || SQLERRM;
      RETURN -1;
    END;
 
  
 -- obtengo la tecnologia del cellular
  BEGIN
    
     v_result  := PA_PROV_GET_INFO.p_get_TECHNOLOGY(pin_cellular_number => v_cellular_number,
                                                    pin_action_date     => v_action_date,
                                                    pout_message        => Pinout_message,
                                                    pout_technology     => v_techonology);   
    
     IF v_techonology = 'LTE' THEN
        v_techonology := 'S';
     ELSE 
        v_techonology := 'N';   
     END IF;
    
    EXCEPTION WHEN OTHERS THEN
      Pinout_message := 'Error en '|| c_package_name || c_function_name ||  ':el armado del cursor POUT_CURSOR_DATA' || ' : ' ||SQLERRM;
      v_techonology := 'N';
   END;
   
   
   
 -- obtengo si tiene activo datos feature 21.
  BEGIN
     SELECT STL_CHAR_VALUE 
     INTO v_package
     FROM STL_PARAMETERS STL
     WHERE STL_ID = 'FDATOS';   
  
     PA_PROV_GET_INFO.GET_ACTIVATE_SERVICE(pin_action_date          => v_action_date,
                                           pin_cellular_number      => v_cellular_number,
                                           pin_feature              => v_feature_data,
                                           pin_package              => NULL,
                                           pout_flag_active_service => v_flag_active_service_data,
                                           pout_message             => Pinout_message);
    
    EXCEPTION WHEN OTHERS THEN
      Pinout_message := 'Error en '|| c_package_name || c_function_name ||  'al obtener si tiene activo datos feature 21' || ' : ' ||SQLERRM;
      v_flag_active_service_data := 'N';
   END;
   
  -- obtengo si tiene activo el paquete de CUOTA DE INTERNET.
  BEGIN
     SELECT STL_CHAR_VALUE 
     INTO v_package
     FROM STL_PARAMETERS STL
     WHERE STL_ID = 'QINTER';   
  
     PA_PROV_GET_INFO.GET_ACTIVATE_SERVICE(pin_action_date          => v_action_date,
                                           pin_cellular_number      => v_cellular_number,
                                           pin_feature              => NULL,
                                           pin_package              => v_package,
                                           pout_flag_active_service => v_flag_active_quota_internet,
                                           pout_message             => Pinout_message);
    
    
    EXCEPTION WHEN OTHERS THEN
      Pinout_message := 'Error en '|| c_package_name || c_function_name ||  ':al  obtener si tiene activo el package de Cuotas de Internet' || ' : ' ||SQLERRM;
      v_flag_active_quota_internet := 'N';
   END;
 
 
 
 -- Si la linea tiene datos activo, o es LTE deberia tener la apn igprs
 
 IF v_flag_active_service_data = 'Y' OR v_techonology = 'S' THEN
    v_apn_igprs := 'Y';
 END IF;
 
 
 --- completo el cursor con los datos para devolver la informacion
   BEGIN
         OPEN  POUT_CURSOR_DATA FOR 
              SELECT
                     v_cellular_number            CELLULAR_NUMBER,
                     V_msisdn                     MSISDN,
                     V_ICCID                      ICCID,
                     v_cbt_id                     CBT_ID,
                     v_status                     STATUS,
                     v_category                   CATEGORY,
                     v_clt_type                   CLT_TYPE,
                     v_clt_id                     CLT_ID,
                     v_acc_id                     ACC_ID,
                     v_cr_description             CR_DESCRIPTION,
                     v_imei_tracking              IMEI_TRACKING,
                     V_RPL_ID                     RPL_ID,
                     v_old_as_client              OLD_AS_CLIENT,
                     V_credit_limit               CREDIT_LIMIT,
                     v_aut_id                     AUT_ID,
                     v_techonology                LTE,
                     v_flag_active_service_data   DATA_ACTIVE,
                     v_flag_active_quota_internet QUOTA_INTERNET,
                     v_apn_igprs                  APN_IGPRS
              FROM DUAL;
   

 
        EXCEPTION
          WHEN OTHERS THEN
            Pinout_message := 'Error en '|| c_package_name || c_function_name ||  ':el armado del cursor POUT_CURSOR_DATA' || ' : ' ||SQLERRM;
            RETURN -1;
   END;                
 
 
 
  Pinout_message := c_package_name || c_function_name                   ||
                 '= CELLULAR_NUMBER: ' || V_Cellular_Number             || 
                 ' MSDN :'             || V_msisdn                      || 
                 ' ICCID: '            || V_iccid                       ||
                 ' CBT_ID:'            || V_cbt_id                      ||
                 ' STATUS:'            || v_status                      ||
                 ' CATEGORY:'          || v_category                    ||
                 ' CLT_TYPE:'          || v_clt_type                    ||
                 ' CLT_ID:'            || v_clt_id                      ||
                 ' ACC_ID:'            || v_acc_id                      ||
                 ' CR_DESCRIPTION:'    || v_cr_description              ||
                 ' IMEI_TRANCKING:'    || v_imei_tracking               ||
                 ' RPL_ID:'            || V_RPL_ID                      ||
                 ' OLD_AS_CLIENT:'     || v_old_as_client               ||
                 ' CREDIT_LIMIT:'      || V_credit_limit                ||
                 ' AUT_ID:'            || v_aut_id                      ||
                 ' LTE:'               || v_techonology                 ||
                 ' DATA_ACTIVE:'       || v_flag_active_service_data    ||
                 ' QUOTA_INTERNET:'    || v_flag_active_quota_internet  ||
                 ' APN_IGPRS: '        || v_apn_igprs               
                 
                   
                 ;   
  RETURN 0;           

EXCEPTION WHEN OTHERS THEN
         BEGIN  
           Pinout_message := c_package_name || c_function_name || pinout_message ||' - ' || sqlerrm;
           RETURN -1; 
         END;  
             
 END GET_DATA ;    





   END PA_PROV_WSMS;
/

