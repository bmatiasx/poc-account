create FUNCTION F_BAJA_ENVIO_FE
 (PP_ACCID IN VARCHAR2
 ,PP_NIM IN VARCHAR2
 ,PP_ERRTXT OUT VARCHAR2
 )
 RETURN NUMERIC
 IS
var_cell_number NUMBER;
var_end_date DATE;
v_cellular varchar2(10);
begin
---obtenemos cellular number--------
     begin
         select clu_cellular_number
         into v_cellular
         from cellulars
         where clu_bill_number = pp_nim;       
     exception
      	when no_data_found THEN
          	PP_ERRTXT:='No se encontró el bill number';
   		      RETURN 1;     
     end;              
-----------------------------------
     SELECT csf.cef_clu_cellular_number, csf.cef_end_date
     INTO var_cell_number, var_end_date
     FROM CELLULAR_SMS_FES CSF
     WHERE CSF.CEF_ACC_ID = PP_ACCID
     AND CSF.CEF_CLU_CELLULAR_NUMBER = v_cellular
     AND NVL(csf.cef_end_date, SYSDATE + 1) > sysdate;
     IF (NVL(var_end_date, sysdate - 1) < sysdate) THEN
        --end_date es nulo o menor a sysdate con lo cual lo actualizo con la fecha de baja
        UPDATE CELLULAR_SMS_FES CSF
        SET CSF.CEF_END_DATE = SYSDATE
        WHERE CSF.CEF_ACC_ID = PP_ACCID
        AND CSF.CEF_CLU_CELLULAR_NUMBER = v_cellular;
	      RETURN 0;
     ELSE
        --end_date es mayor a sysdate con lo cual no hago nada
        RETURN 0;
     END IF;
EXCEPTION
	WHEN OTHERS THEN
			PP_ERRTXT:= PP_ERRTXT || SQLCODE;
			RETURN -1;
end F_BAJA_ENVIO_FE;
/

