create materialized view S_SCHEDULERS
refresh fast on demand
  as
    SELECT sch_cyc_id,
       sch_due_days,
       sch_bst_id,
       sch_second_due_days,
       sch_bill_date,
       sch_start_date,
       sch_second_due_percent,
       sch_end_date,
       sch_id,
       sch_debit_date,
       sch_eqp_id
  FROM SCHEDULERS@PROD
/

