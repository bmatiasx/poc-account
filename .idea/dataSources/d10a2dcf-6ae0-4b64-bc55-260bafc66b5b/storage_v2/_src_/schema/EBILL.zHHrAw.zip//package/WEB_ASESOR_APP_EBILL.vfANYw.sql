create Package Web_Asesor_App_Ebill IS
	FUNCTION insert_aaf(p_clientId IN NUMBER,
		                       p_cuentaId IN VARCHAR2,
		                       p_frecuencia IN NUMBER)
	  RETURN NUMBER;

 	FUNCTION update_aaf(	   p_id IN NUMBER,
		                       p_frecuencia IN NUMBER)
	  RETURN NUMBER;

 	FUNCTION update_mail(	   p_cuentaId IN  VARCHAR2,
		                       p_mail IN VARCHAR2)
	  RETURN NUMBER;

 	FUNCTION upd(p_id IN NUMBER,
		                       p_frecuencia IN NUMBER,
							   p_cuentaId IN  VARCHAR2,
		                       p_mail IN VARCHAR2)
	  RETURN NUMBER;

	FUNCTION ins(p_clientId IN NUMBER,
		                       p_cuentaId IN VARCHAR2,
		                       p_frecuencia IN NUMBER,
		                       p_mail IN VARCHAR2)
	  RETURN NUMBER;


	FUNCTION getAccountByIdCuenta(
		p_CuentaId IN  VARCHAR2,
		p_Id OUT NUMBER,
		p_ClientId OUT NUMBER,
		p_FrequencyId OUT NUMBER,
		p_mail OUT VARCHAR2)
	  RETURN NUMBER;

 	FUNCTION insert_o_update(
		p_CuentaId IN VARCHAR2,
        p_Id OUT NUMBER)
	  RETURN NUMBER;


END;
/

