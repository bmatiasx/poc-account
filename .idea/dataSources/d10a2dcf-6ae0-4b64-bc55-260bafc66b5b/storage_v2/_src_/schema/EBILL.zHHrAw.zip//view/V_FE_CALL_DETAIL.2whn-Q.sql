create view V_FE_CALL_DETAIL as
  SELECT FCD_CLU_CELLULAR_NUMBER,
              FCD_CLU_BILL_NUMBER,
              FCD_CAL_ACC_ID,
              FCD_CLT_ID,
              FCD_CAL_DATE,
              FCD_CAL_LOCATION,
              FCD_CAL_DIALED_NUMBER,
              FCD_CAL_DIRECTION,
              FCD_CAL_EXTENDED_DURATION FCD_CAL_DURATION,
              FCD_CAL_FEATURES,
              DECODE(FCD_CAL_TPT_ID_AIR,'P','HP','OT','FF',FCD_CAL_TPT_ID_AIR) FCD_CAL_TPT_ID,
              FCD_SRT_ID_AIR,
              FCD_SRT_ID_LAND,
              FCD_CAL_LAND_PERIODS,
              FCD_CAL_AIR_CHARGE,
              FCD_CAL_LAND_CHARGE,
              (FCD_CAL_AIR_CHARGE+FCD_CAL_LAND_CHARGE) FCD_TOTAL_CHARGE,
              FCD_CAL_SCH_ID,
              FCD_SCH_CYC_ID,
              FCD_SCH_START_DATE,
              FCD_SCH_END_DATE,
              FCD_CIA_ID,
              FCD_CIA_DESCRIPTION,
              FCD_CALL_TYPE
       FROM FE_CALL_DETAIL
/

