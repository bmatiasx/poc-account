create FUNCTION F_GET_LINE_PROFILE

 (P_CELLULAR IN VARCHAR2
 ,P_CR_ID IN VARCHAR2 := 'R7'
 ,P_CALL_RESTRICTION OUT VARCHAR2
 ,P_FLAG_DESCRIPTION OUT VARCHAR2
 ,P_FLAG_VALUE OUT VARCHAR2
 ,P_ERR_NUM OUT NUMBER
 ,P_ERR_MSG OUT VARCHAR2
 )
 RETURN NUMBER
 IS
v_status VARCHAR2(1) := '0';
v_flag_error VARCHAR2(500);
v_flag_result      NUMBER;
v_flag_description VARCHAR2(500) := '';
v_flag_value       VARCHAR2(500) := '';
v_idx         NUMBER;
v_reg_flag pa_call_restrictions.v_rec_flag_rest;
x number := 0;
v_id_feature number := 0;
BEGIN

    BEGIN
      v_flag_result := pa_call_restrictions.cellular_flags(p_cellular,
                                                                              p_cr_id,
                                                                              v_reg_flag,
                                                                              v_flag_error,
                                                                              SYSDATE);
      v_idx := 0;
      LOOP
        p_flag_description := p_flag_description || v_reg_flag(v_idx).rfr_fcr_definition || '##';
        p_flag_value := p_flag_value || v_reg_flag(v_idx).rfr_fld_value || '##';
        v_idx := v_idx + 1;
        EXIT WHEN v_idx > 2;
      END LOOP;
    EXCEPTION WHEN OTHERS THEN
        v_flag_error := SQLERRM;
    END;

    BEGIN
      -- Obtiene el tipo de DDI que posee la línea (Común o Full)
        SELECT CED_DDI_TYPE
          INTO P_CALL_RESTRICTION
          FROM CELLULAR_DDI_TYPES
         WHERE CED_CLU_CELLULAR_NUMBER = P_CELLULAR
           AND CED_END_DATE IS NULL;
    EXCEPTION
      -- Si no está en CELLULAR_DDI_TYPES siendo DDI, es tipo 'DDI Común'
      WHEN NO_DATA_FOUND THEN
        P_CALL_RESTRICTION := 'C';
      WHEN OTHERS THEN
        P_ERR_NUM := '1001';
        P_ERR_MSG := 'Error al intentar consultar CELLULAR_DDI_TYPES: ' ||
                     SQLCODE || ' ## ' || SQLERRM;
        RETURN - 1;
    END;

    BEGIN
      -- Revisa si tiene alguna transacción pendiente de aprobación en CELLULAR_DDI_TYPES
      SELECT '1',
             'Tu transacción está siendo procesada. En las próximas 24 horas será ejecutada.'
        INTO V_STATUS, P_ERR_MSG
        FROM CELLULAR_DDI_TYPES
       WHERE CED_CLU_CELLULAR_NUMBER = P_CELLULAR
         AND CED_APPROVAL_REQUIRED = 'Y'
         AND CED_APPROVED_DATE IS NULL
         AND CED_END_DATE IS NULL;

      P_ERR_NUM := '1002';
      RETURN V_STATUS;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        BEGIN
          -- Revisa si tiene alguna transacción pendiente en SWITCH_INTERFACES_HP
          SELECT '1',
                 'El número ingresado tiene una transacción pendiente, con alta prioridad.'
            INTO V_STATUS, P_ERR_MSG
            FROM SWITCH_INTERFACES_HP
           WHERE SIS_ASSIGNED_NIM = P_CELLULAR
             AND SIS_STATUS LIKE 'P'
             AND SIS_REASON_CODE IN ('SIUSDO', 'CMBCED', 'PASWIN');

          P_ERR_NUM := '1003';
          RETURN V_STATUS;

        EXCEPTION
          -- Si no tiene pendientes en SWITCH_INTERFACES_HP, revisa en SWITCH_INTERFACES
          WHEN NO_DATA_FOUND THEN
            BEGIN
              SELECT '1',
                     'El número ingresado tiene una transacción pendiente.'
                INTO V_STATUS, P_ERR_MSG
                FROM SWITCH_INTERFACES
               WHERE SIS_ASSIGNED_NIM = P_CELLULAR
                 AND SIS_STATUS LIKE 'P'
                 AND SIS_REASON_CODE IN ('SIUSDO', 'CMBCED', 'PASWIN');

              P_ERR_NUM := '1004';
              RETURN V_STATUS;

            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                P_ERR_NUM := NULL;
                P_ERR_MSG := NULL;
                RETURN 0;

              WHEN OTHERS THEN
                P_ERR_NUM := '1005';
                P_ERR_MSG := 'Error al intentar consultar SWITCH_INTERFACES: ' ||
                             SQLCODE || ' ## ' || SQLERRM;
                RETURN - 1;
            END;
          WHEN OTHERS THEN
            P_ERR_NUM := '1006';
            P_ERR_MSG := 'Error al intentar consultar SWITCH_INTERFACES_HP: ' ||
                         SQLCODE || ' ## ' || SQLERRM;
            RETURN - 1;
        END;
      WHEN OTHERS THEN
        P_ERR_NUM := '1007';
        P_ERR_MSG := 'Error al intentar consultar CELLULAR_DDI_TYPES: ' ||
                     SQLCODE || ' ## ' || SQLERRM;
        RETURN - 1;
    END;

EXCEPTION
  WHEN OTHERS THEN
    P_ERR_NUM := '0000';
    P_ERR_MSG := 'Error en F_CHANGE_DD_TYPE: ' || SQLCODE || ' ## ' ||
                 SQLERRM;
    RETURN - 1;
END;
/

