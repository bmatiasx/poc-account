create view FE_PACKAGES as
  select "FEP_PKT_ID","FEP_START_DATE","FEP_END_DATE" from fe_packages@prod
/

