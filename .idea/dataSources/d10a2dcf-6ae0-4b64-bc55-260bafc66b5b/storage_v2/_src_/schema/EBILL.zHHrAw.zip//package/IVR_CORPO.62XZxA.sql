create PACKAGE IVR_CORPO IS


 FUNCTION BUSCAR_DERIVACION_ECS(P_CELLULAR       IN S_CELLULARS.Clu_Cellular_Number%TYPE,
                                 P_NRO_DERIVACION OUT VARCHAR2,
                                 P_FLAGS          OUT NUMBER,
                                 P_ERROR_CODE     OUT NUMBER,
                                 P_ERROR_TEXT     OUT VARCHAR2) RETURN NUMBER;
END IVR_CORPO;
/

