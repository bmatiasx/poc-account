create materialized view S_PARAMETERS
refresh complete on demand
  as
    SELECT PAR_NAME,
       PAR_VALUE,
       PAR_DESCRIPTION,
       PAR_TYPE
  FROM PARAMETERS@PROD
/

