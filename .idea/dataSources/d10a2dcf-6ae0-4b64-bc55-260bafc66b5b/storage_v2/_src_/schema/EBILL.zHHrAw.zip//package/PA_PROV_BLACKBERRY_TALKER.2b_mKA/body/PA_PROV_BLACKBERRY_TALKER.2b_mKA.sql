create package body PA_PROV_BLACKBERRY_TALKER is
-- Function and procedure implementations
function f_get_next_transaction_id
         return number is
begin
     return STL.PA_PROV_BLACKBERRY_TALKER.f_get_next_transaction_id@prod;
end;
procedure p_set_transaction_started(p_bbi_id number, p_transaction_id number) is
begin
     STL.PA_PROV_BLACKBERRY_TALKER.p_set_transaction_started@prod(p_bbi_id, p_transaction_id);
end;
procedure p_set_transaction_responsed(p_bbi_id number, p_status varchar2) is
  begin
       STL.PA_PROV_BLACKBERRY_TALKER.p_set_transaction_responsed@prod(p_bbi_id, p_status);
  end;
procedure p_save_ids_reply(p_bbi_id number, p_imei varchar2, p_msisdn varchar2) is
  begin
       STL.PA_PROV_BLACKBERRY_TALKER.p_save_ids_reply@prod(p_bbi_id, p_imei, p_msisdn);
  end;
procedure p_save_reply(p_bbi_id number, p_service varchar2, p_code number, p_description varchar2) is
  begin
       STL.PA_PROV_BLACKBERRY_TALKER.p_save_reply@prod(p_bbi_id, p_service, p_code, p_description);
  end;
procedure p_save_error_code(p_bbi_id number, p_code number, p_description varchar2) is
  begin
       STL.PA_PROV_BLACKBERRY_TALKER.p_save_error_code@prod(p_bbi_id, p_code, p_description);
  end;
function f_fetch_update_requests (p_max_fetch_size number)
         return ref_pending_services_cursor is
v_pending_cursor ref_pending_services_cursor;
begin
     open v_pending_cursor for
     select * from
              (select * from blackberry_interfaces@prod
               where bbi_status = c_PENDING
               and bbi_action <> c_REV
               --and bbi_action_date <= sysdate
               order by bbi_id)
               where rownum <= p_max_fetch_size;
      return v_pending_cursor;
end;
function f_fetch_review_requests (p_max_fetch_size number)
         return ref_pending_services_cursor is
v_pending_cursor ref_pending_services_cursor;
begin
     open v_pending_cursor for
     select * from
              (select * from blackberry_interfaces@prod
               where bbi_status = c_PENDING
               and bbi_action = c_REV
               --and bbi_action_date <= sysdate
               order by bbi_id)
               where rownum <= p_max_fetch_size;
      return v_pending_cursor;
end;
function f_fetch_assign_services (p_bbi_id number)
         return ref_assign_services_cursor is
v_assign_cursor ref_assign_services_cursor;
begin
     open v_assign_cursor for
     select * from blackberry_assign_params@prod
     where bap_bbi_id = p_bbi_id;
     return v_assign_cursor;
end;
procedure p_save_assign_reply(p_bap_id number, p_code number, p_description varchar2) is
begin
     STL.PA_PROV_BLACKBERRY_TALKER.p_save_assign_reply@prod(p_bap_id, p_code, p_description);
end;
function f_listen_update_bbi
  return number is
  begin
       return f_listen_bbi(c_PIPE_UPDATE , c_LOCK_UPDATE);
  end;
function f_listen_review_bbi
  return number is
  begin
       return f_listen_bbi(c_PIPE_REVIEW, c_LOCK_REVIEW);
  end;
function f_listen_bbi(p_pipe_name varchar2, p_lock_id number)
   return number is
data_avaiable boolean := false;
result number;
data number := 1;
action number := 0;
flag_value bb_locks@prod%ROWTYPE;
begin
     --escuchar si hay nuevos datos
     while not data_avaiable loop
           result := dbms_pipe.receive_message@prod(p_pipe_name, 30);
           if result = c_PIPE_MESSAGE_RECEIVED then
              dbms_pipe.unpack_message@prod(data);
              data_avaiable := true;
              --dbms_output.put_line( 'el mensaje recibido es:' || data);
              --limpiar el flag bbl_value del la tabla bb_locks con bbl_id = p_lock_id
              select * into flag_value from bb_locks@prod where bbl_id = p_lock_id for update;
              update bb_locks@prod set bbl_value = 0 where bbl_id = p_lock_id;
              commit;
           elsif result = c_PIPE_TIMEOUT then
                data_avaiable := false;
           else /* other */
               data_avaiable := true;
               action := 1;
           end if;
     end loop;
return action;
end;
function f_notify_update_bbi
         return number is
begin
     return f_notify_bbi(c_PIPE_UPDATE, c_LOCK_UPDATE);
end;
function f_notify_review_bbi
         return number is
begin
     return f_notify_bbi(c_PIPE_REVIEW, c_LOCK_REVIEW);
end;
function f_notify_bbi(p_pipe_name varchar2, p_lock_id number)
         return number is
result number;
action number := 0;
flag_value bb_locks@prod%ROWTYPE;
begin
      --lock register in table bb_locks
      select * into flag_value from bb_locks@prod where bbl_id = p_lock_id for update;
      --si hay un mensaje encolado en el pipe, salir sin hacer nada
      --sino, mandar mensaje al pipe y actualizar bb_locks
      if flag_value.bbl_value <> 1 then
         dbms_pipe.pack_message@prod(1);
         result := dbms_pipe.send_message@prod(p_pipe_name, 120, 10);
         if result = 0 then
                  update bb_locks@prod set bbl_value = 1 where bbl_id = p_lock_id;
         else
                  action := 1;
         end if;
      end if;
      commit;
return action;
end;
end PA_PROV_BLACKBERRY_TALKER;
----------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------
/

