create view V_CLIENT_ACCOUNT_LINE_PACKAGE as
  SELECT cl.clt_id as CLT_ID,
a.acc_id as ACC_ID,
c.clu_cellular_number as CELLULAR_NUMBER,
c.clu_bill_number as BILL_NUMBER,
p.pro_id PRO_ID,
p.pro_description as PRO_DESCRIPTION,
p.pro_model as PRO_MODEL,
p.pro_mark as PRO_MARK,
pk.pkt_id as PKT_ID,
pk.pkt_description as PKT_DESCRIPTION,
pf.pfa_id as PFA_ID,
pf.pfa_description AS PFA_DESCRIPTION
FROM s_cellulars c
JOIN s_accounts a
ON c.clu_acc_id = a.acc_id
JOIN s_client cl
ON a.acc_clt_id = cl.clt_id
LEFT JOIN s_cellular_terminals ct
ON c.clu_cellular_number = ct.cet_clu_cellular_number
AND NVL(ct.cet_end_date, SYSDATE + 1) > SYSDATE
AND ct.cet_start_date <= SYSDATE
LEFT JOIN s_products p
ON ct.cet_pro_id = p.pro_id
LEFT JOIN s_cellular_packages cp
ON c.clu_cellular_number = cp.cpk_clu_cellular_number
AND cp.cpk_canceled_date IS NULL
LEFT JOIN s_packages pk
ON cp.cpk_pkt_id = pk.pkt_id
LEFT JOIN s_package_families pf
ON pk.pkt_pfa_id = pf.pfa_id
WHERE c.clu_status = 'A' AND cl.clt_category = 'C'
 
/

