create FUNCTION F_CANCEL_SR
 (P_IMEI IN VARCHAR2
 ,P_CELLULAR_NUMBER IN VARCHAR2
 ,P_ACC_ID IN VARCHAR2
 ,P_AMMOUNT OUT NUMBER
 ,P_SIMLOCK OUT VARCHAR2
 ,P_ERR_NUMBER OUT NUMBER
 ,P_ERR_TXT OUT VARCHAR2
 )
 RETURN NUMBER
 IS
V_AMOUNT       NUMBER;
V_ERRMSG       VARCHAR2(1000);
V_RESULT      NUMBER;
V_FECHA_CICLO DATE;
V_MONTO NUMBER(14,2);
V_ACC_ID DELIVERY_SIMLOCKS.DSL_ACC_ID%TYPE;
V_CELULAR DELIVERY_SIMLOCKS.DSL_CLU_CELLULAR_NUMBER%TYPE;
V_PIN_BB VARCHAR2(20);
V_SCK VARCHAR2(30);
V_SPCK VARCHAR2(30);
V_SIMLOCK VARCHAR2(20);
BEGIN


    P_ERR_TXT:='Buscando el monto del SR. ';
    v_result:=pkg_surplus_subsidy.get_amount_sr
                        (p_clu_cellular_number => P_CELLULAR_NUMBER,
                         p_rsn_id              => NULL,
                         p_amount              => P_AMMOUNT,
                         p_err_txt              => v_errmsg,
                         p_module             => NULL);

    IF v_result != 0 THEN
      v_errmsg:='pkg_surplus_subsidy.get_amount_sr. '||v_errmsg;
     P_ERR_NUMBER:= 1001;
     RETURN 1;

    END IF;


     IF P_AMMOUNT > 0 THEN

     -- Cancelar el subsidio remanente generando cargo
      v_errmsg:='Llamando al pkg_surplus_subsidy.cancel_sr 2 . ';
      P_ERR_NUMBER:= 1002;

        V_RESULT := PKG_SURPLUS_SUBSIDY.CANCEL_SR(P_CLU_CELLULAR_NUMBER => P_CELLULAR_NUMBER,
                                                  P_ACC_ID              => P_ACC_ID,
                                                  P_IMEI                => P_IMEI,
                                                  P_RSN_ID              => NULL,
                                                  P_EXCEPTION            => 'N',
                                                  P_ERR_TXT             => V_ERRMSG);

    IF V_RESULT != 0 THEN
      V_ERRMSG:='PKG_SURPLUS_SUBSIDY.CANCEL_SR. '||V_ERRMSG;
      P_ERR_NUMBER:= 1003;
      RETURN 1;

    END IF;


     PA_SIMLOCK.DECRYPT(P_IMEI => P_IMEI,P_STR => P_SIMLOCK,P_PIN_BB => V_PIN_BB,P_SCK => V_SCK,P_SPCK => V_SPCK,P_MSG => P_ERR_TXT);

    IF P_SIMLOCK = NULL THEN
      v_errmsg:='NO SE ENCUENTRA EL SIMLOCK'||v_errmsg;
      P_ERR_NUMBER:= 1004;
      RETURN 1;

    END IF;

     P_ERR_TXT := 'SE CANCELO SUBSIDIO REMANENTE GENERANDO CARGO';
     P_ERR_NUMBER:= 1005;
     RETURN 0;


     ELSE

     IF P_AMMOUNT = 0 THEN

        PA_SIMLOCK.DECRYPT(P_IMEI => P_IMEI,P_STR => P_SIMLOCK,P_PIN_BB => V_PIN_BB,P_SCK => V_SCK,P_SPCK => V_SPCK,P_MSG => P_ERR_TXT);

     IF P_SIMLOCK = NULL THEN
      v_errmsg:='NO SE ENCUENTRA EL SIMLOCK'||v_errmsg;
      P_ERR_NUMBER:= 1006;
      RETURN 1;
    END IF;

        P_ERR_TXT := v_errmsg;
        P_ERR_NUMBER:= 1007;
        RETURN 1;
        END IF;
     END IF;

  EXCEPTION
  WHEN NO_DATA_FOUND THEN
      P_ERR_TXT:='ERROR: '||V_ERRMSG;
      P_ERR_NUMBER:= 1008;
      RETURN -1;
  WHEN OTHERS THEN
      P_ERR_TXT:='ERROR CANCELANDO EL SR: '||V_ERRMSG||SQLERRM;
      P_ERR_NUMBER:= 1009;
      RETURN 1;

END;
/

