create materialized view S_PRODUCTS
refresh force on demand
  as
    SELECT pro_id,
  pro_description,
  pro_model,
  pro_mark,
  pro_type,
  pro_chr_id,
  pro_end_date,
  pro_cdma_flag,
  pro_stock_movement,
  pro_canceled_stock,
  pro_franchise_chr_id,
  pro_type_delivery,
  pro_program_otaf,
  pro_exchange,
  pro_mode_type,
  pro_wbr_id,
  pro_quota_quantity,
  pro_mtg_id,
  pro_reacond_flag,
  pro_hlr,
  pro_class,
  pro_range_type,
  pro_homo_flag,
  pro_technology,
  pro_prom_flag,
  pro_tech_feature,
  pro_acme_flag,
  pro_supplier_code,
  pro_format_psn,
  pro_format_pro_code,
  pro_format_date_code,
  pro_range_comm_type
FROM PRODUCTS@PROD
/

