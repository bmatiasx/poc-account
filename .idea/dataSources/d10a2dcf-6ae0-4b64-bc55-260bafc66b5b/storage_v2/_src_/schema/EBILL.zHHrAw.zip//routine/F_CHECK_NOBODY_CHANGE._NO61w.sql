create FUNCTION F_CHECK_NOBODY_CHANGE

 (P_CELLULAR_NUMBER IN VARCHAR2
 ,P_FECHA_CYC OUT VARCHAR2
 ,P_ERROR_TEXT OUT VARCHAR2
 )
 RETURN NUMBER
 IS
V_RESULT    NUMBER;
BEGIN

    V_RESULT := F_CHECK_NOBODY_CHANGE@PROD(p_cellular_number => p_cellular_number,
                                           p_fecha_cyc => p_fecha_cyc,
                                           p_error_text => p_error_text);
    IF V_RESULT <> 0 THEN
      RETURN V_RESULT;
    END IF;


  RETURN 0;


EXCEPTION
  WHEN OTHERS THEN

    p_error_text := 'ERROR AL VERIFICAR SI SE PUEDE REALIZAR EL CAMBIO';
    RETURN - 1;
END;
/

