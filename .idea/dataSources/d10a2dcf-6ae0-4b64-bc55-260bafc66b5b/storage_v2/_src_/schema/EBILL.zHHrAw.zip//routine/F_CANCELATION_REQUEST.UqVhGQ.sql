create FUNCTION F_CANCELATION_REQUEST
 (P_ACC_ID IN VARCHAR2
 ,P_CELLULAR_NUMBER IN VARCHAR2
 ,P_SR OUT NUMBER
 ,P_COSTO_ACTIVACION OUT NUMBER
 ,P_ERR_NUMBER OUT NUMBER
 ,P_ERR_MESSAGE OUT VARCHAR2
 )
 RETURN NUMBER
 IS
V_RESULT             NUMBER;
V_MSG                VARCHAR2(2000);
BEGIN

      V_RESULT := F_CANCEL_LINE@PROD (P_ACC_ID          => P_ACC_ID,
                                      P_CELLULAR_NUMBER        => P_CELLULAR_NUMBER,
                                      P_SR       => P_SR,
                                      P_COSTO_ACTIVACION         => P_COSTO_ACTIVACION,
                                      P_ERR_NUMBER    => P_ERR_NUMBER,
                                      P_ERR_MESSAGE   => P_ERR_MESSAGE);
      IF V_RESULT <> 0 THEN
        P_ERR_NUMBER  := 1005;
        P_ERR_MESSAGE := 'ERROR AL CONSULTAR LA FUNCION F_CANCEL_LINE';
        RETURN 1;
      END IF;

   
  RETURN 0;

EXCEPTION
    WHEN NO_DATA_FOUND THEN

        P_ERR_MESSAGE := 'NO SE ENCONTRARON DATOS PARA LA CUENTA INGRESADA';
        RETURN 1;

      WHEN OTHERS THEN
        P_ERR_MESSAGE := V_MSG || SQLERRM;
        RETURN - 1;

END;
/

