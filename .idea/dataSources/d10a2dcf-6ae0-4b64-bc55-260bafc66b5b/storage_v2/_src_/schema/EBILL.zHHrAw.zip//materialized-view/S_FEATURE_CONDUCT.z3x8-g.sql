create materialized view S_FEATURE_CONDUCT
refresh complete on demand
  as
    SELECT FCT_CONDUCT,
       FCT_FTR_ID,
       FCT_OBSERVATION,
       FCT_SELECT_FLAG,
       FCT_WEB_VISIBILITY
  FROM STL.FEATURE_CONDUCT@PROD
/

