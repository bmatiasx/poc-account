create materialized view S_PRU_TAB
refresh fast on demand
  as
    select TAC_CBT_ID,TAC_CLT_ID from pru_tab
/

