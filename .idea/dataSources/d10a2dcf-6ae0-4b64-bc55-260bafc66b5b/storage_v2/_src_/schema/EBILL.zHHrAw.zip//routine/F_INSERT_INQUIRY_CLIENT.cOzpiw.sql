create FUNCTION F_INSERT_INQUIRY_CLIENT

 (P_TYPE_SURVEY IN VARCHAR2
 ,P_INQ_ID_INQUIRY IN NUMBER
 ,P_CLU_CELLULAR_NUMBER IN VARCHAR2
 ,P_ACC_ID IN VARCHAR2
 ,P_DATE_START IN DATE
 ,P_COMMENT IN VARCHAR2
 ,P_ID_ANSWER OUT NUMBER
 ,P_ERR_NUMBER OUT NUMBER
 ,P_ERR_MESSAGE OUT VARCHAR2
 )
 RETURN NUMBER
 IS
p_clt_id NUMBER;
BEGIN

  BEGIN
    select SEQ_INQUIRY_ID_ANSWER.nextval
    into  p_id_answer
    from dual;
  EXCEPTION
    WHEN OTHERS THEN
      p_err_number := SQLCODE;
      p_err_message := 'Error al generar el Id de la tabla INQUIRY_CLIENT. '||SQLERRM;
      RETURN -1;
  END;

  BEGIN
    select  ACC_CLT_ID
    into    p_clt_id
    from    accounts
    where   acc_id = p_acc_id;
  EXCEPTION
    WHEN OTHERS THEN
      p_err_number := SQLCODE;
      p_err_message := 'Error buscando la cuenta del cliente. '||SQLERRM;
      RETURN -1;
  END;

  BEGIN
    Insert into INQUIRY_CLIENT (
                    ICL_CLU_CELLULAR_NUMBER,
                    ICL_CLT_ID,
                    ICL_INQ_ID_INQUIRY,
                    ICL_DATE_START,
                    ICL_TYPE_SURVEY,
                    ICL_ID_ANSWER,
                    ICL_COMMENT)
    values (p_clu_cellular_number,
            p_clt_id,
            p_inq_id_inquiry,
            p_date_start,
            p_type_survey,
            p_id_answer,
            p_comment);


    RETURN 0;

    EXCEPTION
      WHEN OTHERS THEN
        p_err_number := SQLCODE;
        p_err_message := 'Error al guardar en la tabla INQUIRY_CLIENT.'||SQLERRM;
        RETURN -1;
      END;

END F_INSERT_INQUIRY_CLIENT;
/

