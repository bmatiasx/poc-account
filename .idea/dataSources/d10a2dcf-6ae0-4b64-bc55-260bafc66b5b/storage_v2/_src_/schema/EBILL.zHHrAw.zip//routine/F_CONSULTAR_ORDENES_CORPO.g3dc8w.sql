create FUNCTION F_CONSULTAR_ORDENES_CORPO
 (P_ACCOUNT IN VARCHAR2
 ,P_NRO_ORDEN OUT VARCHAR2
 ,P_DESC_ORDEN OUT VARCHAR2
 ,P_ESTADO OUT VARCHAR2
 ,P_ERROR OUT VARCHAR2
 ,P_CELLULAR OUT VARCHAR2
 ,P_BILL_NUMBER OUT VARCHAR2
 ,P_IMEI OUT VARCHAR2
 ,P_ERR_MESSAGE OUT VARCHAR2
 )
 RETURN NUMBER
 IS
V_RESULT    NUMBER;
BEGIN


    V_RESULT := pkg_servicio_tecnico.f_consulta_ordenes_corpo(P_ACCOUNT,
                                 P_NRO_ORDEN,
                                 P_DESC_ORDEN,
                                 P_ESTADO,
                                 P_ERROR,
                                 P_CELLULAR,
                                 P_BILL_NUMBER,
                                 P_IMEI,
                                 P_ERR_MESSAGE);
    IF V_RESULT <> 0 THEN
      RETURN V_RESULT;
    END IF;

   
  RETURN 0;


EXCEPTION
  WHEN OTHERS THEN
    
    P_ERROR := 'Error '; 
    RETURN - 1;
END;
/

