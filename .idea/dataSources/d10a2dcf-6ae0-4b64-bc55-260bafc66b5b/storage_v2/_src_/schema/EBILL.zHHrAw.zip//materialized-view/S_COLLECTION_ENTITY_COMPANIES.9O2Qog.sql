create materialized view S_COLLECTION_ENTITY_COMPANIES
refresh force on demand
  as
    SELECT coc_coe_id, coc_cmp_id, coc_start_date, coc_end_date, coc_coe_cet_id
FROM collection_entity_companies@PROD


/

