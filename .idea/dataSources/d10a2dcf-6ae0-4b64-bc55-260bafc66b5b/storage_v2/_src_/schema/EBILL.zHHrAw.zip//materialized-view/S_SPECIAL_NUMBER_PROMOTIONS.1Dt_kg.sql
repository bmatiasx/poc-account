create materialized view S_SPECIAL_NUMBER_PROMOTIONS
refresh fast on demand
  as
    SELECT snp_prm_id,
snp_plt_id,
snp_cat_id,
snp_rpl_id,
snp_grp_id_cellular,
snp_grp_id_dialed_number,
snp_start_date,
snp_end_date,
snp_priority,
snp_percentage_discount,
snp_rpl_id_esp,
snp_free_minutes,
snp_inc_id,
snp_location,
snp_description,
snp_quantity_numbers,
snp_checked_billing_flag,
snp_reassignment_rpl_flag,
snp_discount_bestfriend
FROM STL.special_number_promotions@PROD
  WHERE snp_start_date <  GET_DATE
AND NVL(snp_end_date,GET_DATE+1) > GET_DATE

/

