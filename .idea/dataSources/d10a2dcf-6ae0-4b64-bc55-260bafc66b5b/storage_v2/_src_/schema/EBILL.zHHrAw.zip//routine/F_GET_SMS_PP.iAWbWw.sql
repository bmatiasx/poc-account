create FUNCTION F_GET_SMS_PP

 (P_CELLULAR_NUMBER IN VARCHAR2
 ,P_PACK_SMS OUT VARCHAR2
 ,P_SMS_FREE OUT VARCHAR2
 ,P_SMS_USED OUT VARCHAR2
 ,P_EXPIRY_DATE OUT DATE
 ,P_USED_PROMO OUT VARCHAR2
 ,P_EXPIRY_PROMO OUT DATE
 ,P_ERR_NUMBER OUT NUMBER
 ,P_ERR_MESSAGE OUT VARCHAR2
 )
 RETURN NUMBER
 IS
  -- Variables Originales
  v_pkgDefIdB           NUMBER;
  v_operator_id         NUMBER := 1;
  v_sub_id              VARCHAR2(15);
  v_account_type        NUMBER := 1;
  v_pe_description      VARCHAR2(255);
  v_tariff_plan_id      NUMBER;
  v_balance_amount_0    NUMBER;
  v_balance_units_0     NUMBER;
  v_balance_expiry_0    DATE;
  v_pkg_defid_0         NUMBER;
  v_pkg_quantity_left_0 NUMBER;
  v_pkg_expiry_0        DATE;
  v_pkg_renewal_0       NUMBER;
  v_pkg_next_defid_0    NUMBER;
  v_pkg_defid_1         NUMBER;
  v_pkg_quantity_left_1 NUMBER;
  v_pkg_expiry_1        DATE;
  v_pkg_renewal_1       NUMBER;
  v_pkg_next_defid_1    NUMBER;
  v_pkg_defid_2         NUMBER;
  v_pkg_quantity_left_2 NUMBER;
  v_pkg_expiry_2        DATE;
  v_pkg_renewal_2       NUMBER;
  v_pkg_next_defid_2    NUMBER;
  v_pkg_defid_3         NUMBER;
  v_pkg_quantity_left_3 NUMBER;
  v_pkg_expiry_3        DATE;
  v_pkg_renewal_3       NUMBER;
  v_pkg_next_defid_3    NUMBER;
  p_sub_id              VARCHAR2(15);
  p_account_type        NUMBER;
  v_llamada             NUMBER;
  v_err_message         VARCHAR2(255);
  v_err_number          NUMBER;

  -- Variables ODCS
  v_trama_paq      VARCHAR2(32000);
  v_stl_char_value s_stl_parameters.stl_char_value %TYPE;
  v_aux_expiry_date  VARCHAR2(100);
  v_aux_expiry_promo VARCHAR2(100);

  -- Variables utilizadas para el SLOT 0 - ODCS
  v_slot_tipo_0     VARCHAR2(100);
  v_slot_nbr_0      VARCHAR2(100);
  v_pkt_id_0        VARCHAR2(100);
  v_cant_original_0 VARCHAR2(100);
  v_usados_0        VARCHAR2(100);
  v_disponibles_0   VARCHAR2(100);
  v_fecha_caducid_0 VARCHAR2(200);

  -- Variables utilizadas para el SLOT 1 - ODCS
  v_disponibles_1 VARCHAR2(100);

  -- Variables utilizadas para el SLOT 2 - ODCS
  v_pkt_id_2        VARCHAR2(100);
  v_cant_original_2 VARCHAR2(100);
  v_usados_2        VARCHAR2(100);

  -- Variables utilizadas para el SLOT 3 - ODCS
  v_slot_tipo_3     VARCHAR2(100);
  v_slot_nbr_3      VARCHAR2(100);
  v_pkt_id_3        VARCHAR2(100);
  v_cant_original_3 VARCHAR2(100);
  v_usados_3        VARCHAR2(100);
  v_disponibles_3   VARCHAR2(100);
  v_fecha_caducid_3 VARCHAR2(200);
BEGIN

  -- Controlamos si esta activa la funcionalidad de ODCS
  BEGIN
    SELECT stl_char_value
      INTO v_stl_char_value
      FROM s_stl_parameters
     WHERE stl_id = 'FODCS';
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      v_stl_char_value := 'N';
  END;

  -- Nueva funcionalidad cuando esta activo ODCS
  IF v_stl_char_value = 'Y' THEN

    v_err_message := 'Llamando a F_PP_GET_PACKS_BY_CELLULAR. ';
    v_trama_paq   := ccard.F_PP_GET_PACKS_BY_CELLULAR@ccard(P_CELLULAR_NUMBER => P_CELLULAR_NUMBER, /* VARCHAR2  IN */
                                                            /* P_PACK_TYPE:  1:SMS, 2:GPRS */
                                                            P_PACK_TYPE   => 1, /* NUMBER  IN */
                                                            P_ERR_NUMBER  => v_err_number, /* NUMBER  OUT */
                                                            P_ERR_MESSAGE => v_err_message /* VARCHAR2  OUT*/);

    IF v_trama_paq IS NULL OR v_err_number < 0 THEN
      p_err_number  := v_err_number;
      P_ERR_MESSAGE := v_err_message;
      RETURN v_err_number;
    END IF;

    v_err_message := 'Llamando a PKG_PAQUETES_BACK_END.f_Procesa_Paquete_SMS. ';
    v_llamada     := stl.PKG_PAQUETES_BACK_END.f_Procesa_Paquete_SMS@prod(p_stringEntrada   => v_trama_paq,
                                                                          p_pkt_id_0        => v_pkt_id_0,
                                                                          p_cant_original_0 => v_cant_original_0,
                                                                          p_usados_0        => v_usados_0,
                                                                          p_disponibles_0   => v_disponibles_0,
                                                                          p_fecha_caducid_0 => v_fecha_caducid_0,
                                                                          p_pkt_id_1        => P_PACK_SMS,
                                                                          p_cant_original_1 => P_SMS_FREE,
                                                                          p_usados_1        => P_SMS_USED,
                                                                          p_disponibles_1   => v_disponibles_1,
                                                                          p_fecha_caducid_1 => v_aux_expiry_date,
                                                                          p_pkt_id_2        => v_pkt_id_2,
                                                                          p_cant_original_2 => v_cant_original_2,
                                                                          p_usados_2        => v_usados_2,
                                                                          p_disponibles_2   => P_USED_PROMO,
                                                                          p_fecha_caducid_2 => v_aux_expiry_promo,
                                                                          p_pkt_id_3        => v_pkt_id_3,
                                                                          p_cant_original_3 => v_cant_original_3,
                                                                          p_usados_3        => v_usados_3,
                                                                          p_disponibles_3   => v_disponibles_3,
                                                                          p_fecha_caducid_3 => v_fecha_caducid_3);

    -- Convertimos la fecha porque el parámetro de salida es del tipo DATE
    P_EXPIRY_DATE  := TO_DATE(v_aux_expiry_date, 'DD/MM/YYYY HH24:MI:SS');
    P_EXPIRY_PROMO := TO_DATE(v_aux_expiry_promo, 'DD/MM/YYYY HH24:MI:SS');

    p_err_number  := null;
    p_err_message := 'OK';
    RETURN 0;

  ELSE
    -- Funcionalidad original sin ODCS

    v_err_message := 'Llamando f_get_msisdn';
    v_llamada     := stl.f_get_msisdn@prod(P_CELLULAR    => P_CELLULAR_NUMBER, /*  VARCHAR2  IN*/
                                           P_SUBID       => v_sub_id, /* VARCHAR2  OUT*/
                                           P_ERR_NUMBER  => v_err_number, /* NUMBER  OUT*/
                                           P_ERR_MESSAGE => v_err_message /* VARCHAR2  OUT*/);
    IF v_llamada <> 0 THEN
      p_err_number  := v_err_number;
      P_ERR_MESSAGE := v_err_message;
      RETURN - 1;
    END IF;
    v_err_message := 'Llamando GET_CANT_SMS';
    v_llamada     := ccard.PP_PP_SERVER.GET_SUBSCRIBER_ACCOUNT@ccard(OPERATORID       => v_operator_id, /*IN       NUMBER*/
                                                                     SUBID            => v_sub_id, /* IN OUT   VARCHAR2,*/
                                                                     ACCOUNTTYPE      => v_account_type, /* IN OUT   NUMBER,*/
                                                                     PEDESCRIPTION    => v_pe_description, /* OUT      VARCHAR2,*/
                                                                     TARIFFPLANID     => v_tariff_plan_id, /* OUT      NUMBER,*/
                                                                     BALANCEAMOUNT0   => v_balance_amount_0, /* OUT      NUMBER,*/
                                                                     BALANCEUNITS0    => v_balance_units_0, /* OUT      NUMBER,*/
                                                                     BALANCEEXPIRY0   => v_balance_expiry_0, /* OUT      DATE,*/
                                                                     PKGDEFID0        => v_pkg_defid_0, /* OUT      NUMBER,*/
                                                                     PKGQUANTITYLEFT0 => v_pkg_quantity_left_0, /* OUT      NUMBER,*/
                                                                     PKGEXPIRY0       => v_pkg_expiry_0, /* OUT      DATE,*/
                                                                     PKGRENEWAL0      => v_pkg_renewal_0, /* OUT      NUMBER,-- BOOLEAN,*/
                                                                     PKGNEXTDEFID0    => v_pkg_next_defid_0, /* OUT      NUMBER,*/
                                                                     PKGDEFID1        => v_pkg_defid_1, /* OUT      NUMBER,*/
                                                                     PKGQUANTITYLEFT1 => v_pkg_quantity_left_1, /* OUT      NUMBER,*/
                                                                     PKGEXPIRY1       => v_pkg_expiry_1, /* OUT      DATE,*/
                                                                     PKGRENEWAL1      => v_pkg_renewal_1, /* OUT      NUMBER,--BOOLEAN*/
                                                                     PKGNEXTDEFID1    => v_pkg_next_defid_1, /* OUT      NUMBER,*/
                                                                     PKGDEFID2        => v_pkg_defid_2, /* OUT      NUMBER,*/
                                                                     PKGQUANTITYLEFT2 => v_pkg_quantity_left_2, /* OUT      NUMBER,-- CANTIDAD DE SMS DE LA PROMO PLUS*/
                                                                     PKGEXPIRY2       => v_pkg_expiry_2, /* OUT      DATE,*/
                                                                     PKGRENEWAL2      => v_pkg_renewal_2, /* OUT      NUMBER,--BOOLEAN*/
                                                                     PKGNEXTDEFID2    => v_pkg_next_defid_2, /* OUT      NUMBER,*/
                                                                     PKGDEFID3        => v_pkg_defid_3, /* OUT      NUMBER,*/
                                                                     PKGQUANTITYLEFT3 => v_pkg_quantity_left_3, /*OUT      NUMBER,*/
                                                                     PKGEXPIRY3       => v_pkg_expiry_3, /* OUT      DATE,*/
                                                                     PKGRENEWAL3      => v_pkg_renewal_3, /* OUT      NUMBER,--BOOLEAN*/
                                                                     PKGNEXTDEFID3    => v_pkg_next_defid_3 /* OUT      NUMBER,*/);
    IF v_llamada <> 0 THEN
      P_ERR_NUMBER  := -1;
      P_ERR_MESSAGE := v_err_message;
      RETURN - 1;
    END IF;
    IF v_pkg_defid_1 <> 0 THEN
      BEGIN
        select sep_pkt_id,
               sep_units_in,
               sep_units_in - v_pkg_quantity_left_1
          into P_PACK_SMS, p_sms_free, P_SMS_USED
          from stl.service_pack_parameters@prod
         where SEP_PKT_TECNOMEN = v_pkg_defid_1
           and SYSDATE BETWEEN SEP_START_DATE AND SEP_END_DATE;
        P_EXPIRY_DATE := v_pkg_expiry_1;
      EXCEPTION
        WHEN no_data_found THEN
          begin
            select PPSF_QUANTITY_SMS,
                   PPSF_QUANTITY_SMS - v_pkg_quantity_left_1
              into p_sms_free, P_SMS_USED
              from PP_SMS_FREE@prod
             where PPSF_PKT_TECNOMEN = v_pkg_defid_1;
            P_EXPIRY_DATE := v_pkg_expiry_1;
          EXCEPTION
            WHEN no_data_found THEN
              P_ERR_NUMBER  := -1;
              P_ERR_MESSAGE := 'El DEF_ID_1 no existe en service_pack_parameters';
              RETURN - 1;
          END;
          P_ERR_NUMBER  := -1;
          P_ERR_MESSAGE := 'El DEF_ID_1 no existe en service_pack_parameters';
          RETURN - 1;
      END;
    END IF;
    IF v_pkg_defid_2 <> 0 THEN
      P_USED_PROMO   := v_pkg_quantity_left_2;
      P_EXPIRY_PROMO := v_pkg_expiry_2;
    END IF;
    p_err_number  := null;
    p_err_message := 'OK';
    RETURN 0;

  END IF;

EXCEPTION
  WHEN OTHERS THEN
    p_err_number  := SQLCODE;
    p_err_message := v_err_message || SQLERRM;
    return sqlcode;

END;
/

