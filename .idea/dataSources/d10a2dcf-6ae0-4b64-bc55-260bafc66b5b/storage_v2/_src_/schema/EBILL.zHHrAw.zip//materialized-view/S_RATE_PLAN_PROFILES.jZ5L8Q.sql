create materialized view S_RATE_PLAN_PROFILES
refresh fast on demand
  as
    SELECT rppr_gprf_id,
rppr_rpl_id,
rppr_start_date,
rppr_end_date,
rppr_gprf_id_out,
rppr_pp_offnet_flag,
rppr_trff_id_out,
rppr_migrada_tecnomen_flag,
rppr_rpl_id_intraprofile,
rppr_gprf_id_out_intraprofile
FROM STL.rate_plan_profiles@PROD
  WHERE rppr_start_date <  GET_DATE
AND NVL(rppr_end_date,GET_DATE+1) > GET_DATE

/

