create package body PA_ROV_WSMS is


  FUNCTION  GET_DATA(pin_imsi VARCHAR2) return NUMBER is
  v_Cellular_Number S_CELLULARS.CLU_CELLULAR_NUMBER%TYPE;
  v_msisdn          S_SIMS.SIM_MSISDN%TYPE;
  v_iccid           S_SIMS.SIM_ICCID%TYPE;
   
   BEGIN
  -- buscando obtener el numero de Celular
        SELECT Cellular_Number, Msisdn, iccid
            INTO v_Cellular_Number, v_Msisdn, v_iccid
            FROM (SELECT Nvl(v_Cellular_Number, Es.Esc_Clu_Cellular_Number) Cellular_Number,
                         Nvl(v_Msisdn, s.Sim_Msisdn) Msisdn,
                         Nvl(v_iccid, s.sim_iccid) iccid
                    FROM Sims s, Esn_Cellulars Es
                   WHERE Sim_Imsi = pin_imsi
                     AND Esc_Esn_Hexa = Substr(Sim_Iccid, 1, 19)
                     AND SYSDATE BETWEEN Es.Esc_Start_Date AND
                         Nvl(Es.Esc_End_Date, SYSDATE + 0.001)
                   ORDER BY Es.Esc_End_Date DESC)
           WHERE Rownum = 1;
        EXCEPTION
         WHEN No_Data_Found THEN
            BEGIN
              SELECT Cellular_Number, Msisdn, iccid
                INTO v_Cellular_Number, v_Msisdn, v_iccid
                FROM (SELECT Nvl(v_Cellular_Number, Es.Esc_Clu_Cellular_Number) Cellular_Number,
                             Nvl(v_Msisdn, s.Sim_Msisdn) Msisdn,
                             nvl(v_iccid, s.sim_iccid) iccid
                        FROM Sims s, Esn_Cellulars Es
                       WHERE Sim_Imsi = pin_imsi
                         AND Esc_Esn_Hexa = Substr(Sim_Iccid, 1, 19)
                         AND Es.Esc_End_Date =
                             (SELECT MAX(Es.Esc_End_Date)
                                FROM Sims s, Esn_Cellulars Es
                               WHERE Sim_Imsi = pin_imsi
                                 AND Esc_Esn_Hexa = Substr(Sim_Iccid, 1, 19))
                       ORDER BY Es.Esc_Start_Date DESC)
               WHERE Rownum = 1;

       

   END PA_ROV_WSMS;
     /

