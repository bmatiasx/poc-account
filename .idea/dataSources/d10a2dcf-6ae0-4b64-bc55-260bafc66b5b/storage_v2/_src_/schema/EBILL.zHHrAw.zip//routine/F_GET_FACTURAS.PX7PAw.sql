create FUNCTION F_GET_FACTURAS

 (P_DOC_ACC_ID IN VARCHAR2
 ,P_CADENA OUT VARCHAR2
 ,P_ERR_NUMBER OUT NUMBER
 ,P_ERR_MESSAGE OUT VARCHAR2
 )
 RETURN NUMBER
 IS
CURSOR c_datos_facturas IS
    SELECT  doc_cmp_id,
            doc_dct_id,
            doc_id,
            doc_letter,
            doc_document_date,
            doc_sch_id
    FROM    view_documents d
    WHERE   d.doc_acc_id = p_doc_acc_id
    AND     doc_dct_id IN ( SELECT dct_id
                              FROM document_types
                             WHERE dct_dct_id = 'FC') --FC y FCE
    ORDER BY 5 DESC;
BEGIN

    p_cadena := '';
    FOR cur_datos_factura IN c_datos_facturas
    LOOP
      p_cadena := p_cadena || cur_datos_factura.doc_cmp_id || '##' ||
                  to_char (cur_datos_factura.doc_dct_id) || '##' ||
                  to_char (cur_datos_factura.doc_id) || '##' ||
                  cur_datos_factura.doc_letter || '##' ||
                  to_char(cur_datos_factura.doc_document_date, 'DD/MM/YYYY') || '##' ||
                  cur_datos_factura.doc_sch_id || '||';
    END LOOP;
    IF nvl(p_cadena,'X') = 'X' THEN
        P_ERR_MESSAGE := 'No hay facturas.';
        P_ERR_NUMBER := 1;
        RETURN 1;
    ELSE
        P_ERR_MESSAGE := 'OK';
        P_ERR_NUMBER := 0;
        RETURN 0;
    END IF;
  EXCEPTION
      WHEN OTHERS THEN
          P_ERR_MESSAGE := SQLERRM;
          P_ERR_NUMBER := SQLCODE;
          RETURN -1;
  END;
/

