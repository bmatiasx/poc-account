create view GLOBALS_PACKAGES_SERVICES as
  select "GPS_ID","GPS_PKT_ID","GPS_SERVICE","GPS_START_DATE","GPS_END_DATE" from
stl.globals_packages_services@prod
/

