create PACKAGE PA_WEBSERVICES IS

FUNCTION getcertdataxdnf (dn       IN    VARCHAR2,
                ip       IN    VARCHAR2,
                servicio     IN    VARCHAR2,
                active      OUT VARCHAR2,
                maxconn      OUT VARCHAR2,
                checkcl      OUT VARCHAR2,
                bill        OUT VARCHAR2,
                p_mensaje     OUT VARCHAR2)
    RETURN NUMBER;

  FUNCTION getcelnumbertecno (bill_number      IN    VARCHAR2,
                celular         OUT VARCHAR2,
                tipo_tecnologia     OUT VARCHAR2)
    RETURN NUMBER;

  FUNCTION getlinesinfo (p_cltid         IN   VARCHAR2,
               p_billnumberslist   IN   VARCHAR2,
               p_separator       IN   VARCHAR2,
               p_cellsnumberslist    OUT VARCHAR2,
               p_ecplist        OUT VARCHAR2,
               p_statuslist       OUT VARCHAR2,
               p_error_message      OUT VARCHAR2)
    RETURN NUMBER;

  FUNCTION getlinesinfoforhub (p_billnumberslist     IN    VARCHAR2,
                 p_separator       IN    VARCHAR2,
                 p_cellsnumberslist     OUT VARCHAR2,
                 p_ecplist          OUT VARCHAR2,
                 p_statuslist        OUT VARCHAR2,
                 p_error_message      OUT VARCHAR2)
    RETURN NUMBER;

  FUNCTION getlocations (p_cellid_list    IN   VARCHAR2,
               p_lac_list      IN   VARCHAR2,
               p_mnc_list      IN   VARCHAR2,
               p_separator      IN   VARCHAR2,
               p_lat_list       OUT VARCHAR2,
               p_lon_list       OUT VARCHAR2,
               p_zone_list       OUT VARCHAR2,
               p_error_message     OUT VARCHAR2)
    RETURN NUMBER;
END PA_WEBSERVICES;

/

