create materialized view S_DESTINATION_TYPES
refresh complete on demand
  as
    SELECT dst_id,
dst_description
FROM test.destination_types@PROD
/

