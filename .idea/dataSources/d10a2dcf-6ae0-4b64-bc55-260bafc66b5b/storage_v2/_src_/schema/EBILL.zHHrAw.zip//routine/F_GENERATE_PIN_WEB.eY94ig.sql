create FUNCTION f_generate_pin_web(
                              P_CLT_TYPE         IN  VARCHAR2,
                              P_CLT_ID           IN  VARCHAR2,
                              P_ACC_ID           IN  VARCHAR2,
                              P_FLAG_CTA         IN  VARCHAR2 DEFAULT 'N',
                              P_CELLULAR_REQUEST IN  VARCHAR2,
                              P_SELECCION_LINEAS IN  TY_ARRAY_OBJ_MAP,
                              P_OPERATION_ID     IN  VARCHAR2,
                              P_MODALIDAD_PIN    IN  VARCHAR2,
                              P_APPROVAL_CODE    OUT NUMBER,  
                              P_CELLULAR_CHANGE  OUT PA_OPERATION_CODE.rec_cellular_change,
                              P_MESSAGE          OUT VARCHAR2,
                              P_ERR_NUMBER       OUT NUMBER, 
                              P_ERR_MSG          OUT VARCHAR2
                              ) 
RETURN NUMBER IS

    v_result    NUMBER;
    v_operation_id VARCHAR2(10);
    rf_seleccion_lineas SYS_REFCURSOR;
BEGIN

    OPEN rf_seleccion_lineas FOR SELECT clave AS seleccion_lineas
                                                    FROM TABLE(CAST(p_seleccion_lineas AS TY_ARRAY_OBJ_MAP));  

    v_result := pa_operation_code.f_generate_pin_web(p_clt_type => p_clt_type,
                                                      p_clt_id => p_clt_id,
                                                      p_acc_id => p_acc_id,
                                                      p_flag_cta =>p_flag_cta,
                                                      p_cellular_request => p_cellular_request,
                                                      p_seleccion_lineas => rf_seleccion_lineas,
                                                      p_operation_id => p_operation_id,
                                                      p_modalidad_pin => p_modalidad_pin,
                                                      p_approval_code => p_approval_code,
                                                      p_cellular_change => p_cellular_change,
                                                      p_message => p_message,
                                                      p_err_number => p_err_number,
                                                      p_err_msg => p_err_msg);
    
    IF v_result <> 0 THEN
      RETURN v_result;
    END IF;

  RETURN 0;

EXCEPTION
  WHEN OTHERS THEN
    p_err_number := -1001;
    p_err_msg := 'Error al ejecutar la función';
    RETURN - 1;
END f_generate_pin_web;
/

