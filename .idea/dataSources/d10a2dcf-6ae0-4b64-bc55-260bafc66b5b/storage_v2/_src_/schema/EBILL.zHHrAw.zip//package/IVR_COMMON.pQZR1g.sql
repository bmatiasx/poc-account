create PACKAGE IVR_COMMON
 AS
 /*
  11/10/2007: PC2336 - Msj Promo Dia. Agregado de funcion Validate_Promotion_Dia
              Autor: M.Bulgheroni.
  14/12/2007: PC7184 CD7834: Se agrega funciones validate_all_data y validate_date
     para ivr Infopago de Cobranzas
        Autor: M.Bulgheroni.
 Se agrega funcionalidad para Video Llamada 
  Fecha: 24/10/2007     
  Desarrollador: Gallardo Fabián 
  
  03/03/2015 PC108092: Se grega la funcion F_OBTENER_PRIORIDAD_CR_CO, nos permite ver si una linea es priorizada o no. (parametros acotados en comparacion con la f_get_clu_info)
  12/03/2015 PC108092: Se corrige la funcion F_GET_CLU_INFO y F_OBTENER_PRIORIDAD_CR_CO para que en caso de que la MILEAGE_CATEGORY no tenga datos
  */
 FUNCTION F_CHECK_DNI(P_DNI        IN VARCHAR2,
                       P_ERROR_CODE OUT NUMBER,
                       P_ERROR_TEXT OUT VARCHAR2) RETURN NUMBER;
Function VALIDATE_CUSTOMER_DATA(P_NUMBER     IN VARCHAR2,
                                  P_ERROR_CODE OUT NUMBER,
                                  P_ERROR_TEXT OUT VARCHAR2) RETURN NUMBER;
 
                                                          
END IVR_COMMON;
/

