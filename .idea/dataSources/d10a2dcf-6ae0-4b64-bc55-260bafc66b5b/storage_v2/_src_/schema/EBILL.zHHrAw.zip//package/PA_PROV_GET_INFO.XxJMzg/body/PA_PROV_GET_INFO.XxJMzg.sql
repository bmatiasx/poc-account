create package body PA_PROV_GET_INFO is


  PROCEDURE P_GET_MSISDN_CELLULAR_IMSI(p_Imsi            IN OUT S_SIMS.SIM_IMSI%TYPE,
                                       p_Msisdn          IN OUT S_SIMS.SIM_msisdn%TYPE,
                                       p_Cellular_Number IN OUT S_CELLULARS.CLU_CELLULAR_NUMBER%TYPE,
                                       p_Imei            IN CELLULAR_IMEI_TRACKINGS.CIM_IMEI%TYPE,
                                       p_Action_Date     IN DATE DEFAULT SYSDATE,
                                       p_Acc_Id          IN VARCHAR2 DEFAULT NULL) IS

    v_iccid sims.sim_iccid%TYPE;

  BEGIN
    p_Get_Msisdn_Cellular_Imsi(p_Imsi            => p_Imsi,
                               p_Msisdn          => p_Msisdn,
                               p_Cellular_Number => p_Cellular_Number,
                               P_iccid           => v_iccid,
                               p_Imei            => p_Imei,
                               p_Action_Date     => p_Action_Date,
                               p_Acc_Id          => p_Acc_Id);

  END;

  PROCEDURE P_GET_MSISDN_CELLULAR_IMSI(p_Imsi            IN OUT S_SIMS.SIM_IMSI%TYPE,
                                       p_Msisdn          IN OUT S_SIMS.SIM_msisdn%TYPE,
                                       p_Cellular_Number IN OUT S_CELLULARS.CLU_CELLULAR_NUMBER%TYPE,
                                       p_iccid           IN OUT sims.sim_iccid%TYPE,
                                       p_Imei            IN CELLULAR_IMEI_TRACKINGS.CIM_IMEI%TYPE,
                                       p_Action_Date     IN DATE DEFAULT SYSDATE,
                                       p_Acc_Id          IN VARCHAR2 DEFAULT NULL) IS
   
    v_Msisdn              S_SIMS.SIM_msisdn%TYPE DEFAULT NULL;
    v_Cellular_Number     S_CELLULARS.CLU_CELLULAR_NUMBER%TYPE DEFAULT NULL;
    v_Imsi                S_SIMS.SIM_IMSI%TYPE DEFAULT NULL;
    v_iccid               sims.sim_iccid%type;
  BEGIN
    IF p_Imsi IS NULL OR p_Msisdn IS NULL OR p_Cellular_Number IS NULL OR
       p_iccid IS NULL THEN
      IF p_Imsi IS NULL AND p_Msisdn IS NULL AND p_Cellular_Number IS NULL AND
         p_iccid IS NULL THEN
        BEGIN
          SELECT Vv.Cet_Clu_Cellular_Number
            INTO v_Cellular_Number
            FROM Cellular_Terminals Vv
           WHERE Vv.Cet_Imei = p_Imei
             AND Vv.Cet_Start_Date <= p_Action_Date
             AND Nvl(Vv.Cet_End_Date, p_Action_Date + 1) >= p_Action_Date;
        EXCEPTION
          WHEN No_Data_Found THEN
            NULL;
          WHEN too_many_rows THEN
            ----PC89930
            SELECT Vv.Cet_Clu_Cellular_Number
              INTO v_Cellular_Number
              FROM Cellular_Terminals Vv
             WHERE Vv.Cet_Imei = p_Imei
               AND Vv.Cet_Start_Date <= p_Action_Date
               AND Nvl(Vv.Cet_End_Date, p_Action_Date + 1) >= p_Action_Date
               AND cet_start_date =
                   (select max(cet_start_date)
                      from cellular_terminals
                     WHERE Cet_Imei = p_Imei
                       AND Cet_Start_Date <=  p_Action_Date 
                       AND Nvl(Cet_End_Date, p_Action_Date + 1) >= p_Action_Date );
        END;
      ELSE
        v_Cellular_Number := p_Cellular_Number;
        v_Msisdn          := p_Msisdn;
        v_Imsi            := p_Imsi;
        v_iccid           := p_iccid;
      END IF;
      -- TENGO EL IMSI PARA HACER LAS BUSQUEDAS
      IF v_Imsi IS NOT NULL THEN
        BEGIN
          ---  imsi
          --SELECT  es.esc_clu_cellular_number, s.sim_msisdn
          SELECT Cellular_Number, Msisdn, iccid
            INTO v_Cellular_Number, v_Msisdn, v_iccid
            FROM (SELECT Nvl(v_Cellular_Number, Es.Esc_Clu_Cellular_Number) Cellular_Number,
                         Nvl(v_Msisdn, s.Sim_Msisdn) Msisdn,
                         Nvl(v_iccid, s.sim_iccid) iccid
                    FROM Sims s, Esn_Cellulars Es
                   WHERE Sim_Imsi = v_Imsi
                     AND Esc_Esn_Hexa = Substr(Sim_Iccid, 1, 19)
                     AND Es.Esc_Start_Date <= p_Action_Date
                     AND Nvl(Es.Esc_End_Date, p_Action_Date + 0.001) >= p_Action_Date
                   ORDER BY Es.Esc_End_Date DESC)
           WHERE Rownum = 1;
        EXCEPTION
          WHEN No_Data_Found THEN
            BEGIN
              SELECT Cellular_Number, Msisdn, iccid
                INTO v_Cellular_Number, v_Msisdn, v_iccid
                FROM (SELECT Nvl(v_Cellular_Number,
                                 Es.Esc_Clu_Cellular_Number) Cellular_Number,
                             Nvl(v_Msisdn, s.Sim_Msisdn) Msisdn,
                             nvl(v_iccid, s.sim_iccid) iccid
                        FROM Sims s, Esn_Cellulars Es
                       WHERE Sim_Imsi = v_Imsi
                         AND Esc_Esn_Hexa = Substr(Sim_Iccid, 1, 19)
                         AND Es.Esc_End_Date =
                             (SELECT MAX(Es.Esc_End_Date)
                                FROM Sims s, Esn_Cellulars Es
                               WHERE Sim_Imsi = v_Imsi
                                 AND Esc_Esn_Hexa = Substr(Sim_Iccid, 1, 19))
                       ORDER BY Es.Esc_Start_Date DESC)
               WHERE Rownum = 1;
            EXCEPTION
              WHEN No_Data_Found THEN
                NULL;
            END;
        END;
      ELSE
        -- TENGO EL IMSI PARA HACER LAS BUSQUEDAS
        IF v_Cellular_Number IS NOT NULL THEN
          -- TENGO EL CELLULAR PARA HACER LAS BUSQUEDAS
          ----------PC89930
          begin
            BEGIN
              SELECT Imsi, Msisdn, iccid
                INTO v_Imsi, v_Msisdn, v_iccid
                FROM (SELECT Nvl(v_Imsi, Sim_Imsi) Imsi,
                             Nvl(v_Msisdn, s.Sim_Msisdn) Msisdn,
                             nvl(v_iccid, s.sim_iccid) iccid
                        FROM Sims s, Esn_Cellulars Es
                       WHERE Es.Esc_Clu_Cellular_Number = v_Cellular_Number
                         AND Sim_Iccid LIKE Esc_Esn_Hexa || '%'
                         AND  Es.Esc_Start_Date <= p_Action_Date
                         AND  Nvl(Es.Esc_End_Date, p_Action_Date + 0.001) >= p_Action_Date
                       ORDER BY Es.Esc_Start_Date DESC)
               WHERE Rownum = 1;
            EXCEPTION
              WHEN No_Data_Found THEN
                --cuando no encuenta una fecha fin nula
                BEGIN
                  SELECT Sim_Imsi, Msisdn, iccid --busca el sim_imsi y el sim_msisdn para esa fecha
                    INTO v_Imsi, v_Msisdn, v_iccid
                    FROM (SELECT Nvl(v_Imsi, Sim_Imsi) Sim_Imsi,
                                 Nvl(v_Msisdn, s.Sim_Msisdn) Msisdn, --busca el sim_imsi y el sim_msisdn para esa fecha
                                 nvl(v_iccid, s.sim_iccid) iccid
                            FROM Sims s, Esn_Cellulars Es
                           WHERE Es.Esc_Clu_Cellular_Number =
                                 v_Cellular_Number
                             AND Sim_Iccid LIKE Esc_Esn_Hexa || '%'
                             AND Es.Esc_End_Date =
                                 (SELECT MAX(Es.Esc_End_Date) --busca la maxima fecha
                                    FROM Sims s, Esn_Cellulars Es
                                   WHERE Es.Esc_Clu_Cellular_Number =
                                         v_Cellular_Number
                                     AND s.Sim_Iccid LIKE
                                         Es.Esc_Esn_Hexa || '%')
                           ORDER BY Es.Esc_Start_Date DESC)
                   WHERE Rownum = 1;
                EXCEPTION
                  WHEN No_Data_Found THEN
                    NULL;
                END;
            END;
          exception
            ---PC89930
            WHEN OTHERS THEN
              v_Cellular_Number := null;
          end;
        ELSE
          -- TENGO EL CELLULAR PARA HACER LAS BUSQUEDAS
          IF v_Msisdn IS NOT NULL THEN
            -- TENGO EL MSISDN PARA HACER LAS BUSQUEDAS
            --  PC89263_CD101997 EMBLACOM VPN GPRS SE cambia SYSDATE por p_action_date en el NVL
            -- porque trae problemas cuando se realiza una accion a futuro.
            BEGIN
              SELECT Sim_Imsi, Cellular_Number, iccid
                INTO v_Imsi, v_Cellular_Number, v_iccid
                FROM (SELECT nvl(v_Imsi, Sim_Imsi) sim_imsi,
                             nvl(v_Cellular_Number, Clu.Clu_Cellular_Number) Cellular_Number,
                             nvl(v_iccid, s.sim_iccid) iccid
                        FROM Sims s, Esn_Cellulars Es, Cellulars Clu
                       WHERE Clu.Clu_Bill_Number = Substr(v_Msisdn, 4)
                         AND Es.Esc_Clu_Cellular_Number =
                             Clu.Clu_Cellular_Number
                         AND Sim_Iccid = Esc_Esn_Hexa || 'F'
                         AND Es.Esc_Start_Date <= p_Action_Date
                         AND Nvl(Es.Esc_End_Date, p_action_date + 0.001) >= p_Action_Date
                       ORDER BY Es.Esc_Start_Date DESC)
               WHERE Rownum = 1;
            EXCEPTION
              WHEN No_Data_Found THEN
                BEGIN
                  --  PC89263_CD101997 EMBLACOM VPN GPRS SE cambia SYSDATE por p_action_date en el NVL
                  -- porque trae problemas cuando se realiza una accion a futuro.
                  SELECT Sim_Imsi, Cellular_Number
                    INTO v_Imsi, v_Cellular_Number
                    FROM (SELECT nvl(v_Imsi, Sim_Imsi) sim_imsi,
                                 nvl(v_Cellular_Number,
                                     Clu.Clu_Cellular_Number) Cellular_Number
                            FROM Sims s, Esn_Cellulars Es, Cellulars Clu
                           WHERE Clu.Clu_Bill_Number = Substr(v_Msisdn, 3)
                             AND Es.Esc_Clu_Cellular_Number =
                                 Clu.Clu_Cellular_Number
                             AND Sim_Iccid = Esc_Esn_Hexa || 'F'
                             AND Es.Esc_Start_Date <= p_Action_Date
                             AND Nvl(Es.Esc_End_Date, p_action_date + 0.001) >= p_Action_Date
                           ORDER BY Es.Esc_Start_Date DESC)
                   WHERE Rownum = 1;
                EXCEPTION
                  WHEN No_Data_Found THEN
                    NULL;
                END;
            END;
          END IF; -- TENGO EL MSISDN PARA HACER LAS BUSQUEDAS
        END IF; -- TENGO EL CELLULAR PARA HACER LAS BUSQUEDAS
      END IF; -- TENGO EL IMSI PARA HACER LAS BUSQUEDAS
   END IF;
   
  p_Imsi            := v_imsi;
  p_Msisdn          := v_msisdn;
  p_Cellular_Number := v_cellular_number;
  p_iccid           := v_iccid;
  END p_Get_Msisdn_Cellular_Imsi;
  
    FUNCTION P_GET_CELLULAR_INFO (pin_cellular_number       IN OUT S_CELLULARS.CLU_CELLULAR_NUMBER%TYPE,
                                  pout_cursor_cellular_info OUT T_CURSOR,
                                  p_Action_Date     IN DATE DEFAULT SYSDATE,
                                  pout_message              OUT VARCHAR2)
                                  RETURN NUMBER IS 
                                  
  v_function_name       VARCHAR2(50)  := 'P_GET_CELLULAR_INFO';
  v_cbt_id            cellulars.clu_cbt_id%TYPE                      := NULL;
  v_status            cellulars.clu_status%TYPE                      := NULL;
  v_category          client.clt_category%TYPE                       := NULL;
  v_clt_type          client.clt_type%TYPE                           := NULL;
  v_clt_id            client.clt_id%TYPE                             := NULL;
  v_acc_id            accounts.acc_id%TYPE                           := NULL;
  v_cr_description    CALL_RESTRICTIONS.cr_description%TYPE          := NULL;
  v_imei_tracking     CELLULAR_IMEI_TRACKINGS.CIM_IMEI%TYPE          := NULL;
  V_RPL_ID            CELLULAR_PLANS.cpl_rpl_id%TYPE                 := NULL;
  v_old_as_client     VARCHAR2(5)                                    := NULL;      
  V_credit_limit      VARCHAR2(100)                                  := NULL;  
  v_aut_id            CELLULARS.CLU_AUT_ID%TYPE                      := NULL;                
   
   BEGIN
      
      BEGIN
          pout_message := 'Obtencion datos varios de la linea: ['||pin_cellular_number||'].';
          SELECT clu.clu_cbt_id,
                 clu.clu_status,
                 clt.clt_category,
                 clt.clt_type,
                 clt.clt_id,
                 acc.acc_id,
                 cr.cr_description,
                 trunc((SYSDATE - clt.CLT_ADD_DATE)/365),
                 NVL(clu.CLU_CREDIT_LIMIT,'0'),
                 NVL(CLU_AUT_ID,'N')
                 
   
          INTO   v_cbt_id,
                 v_status,
                 v_category,
                 v_clt_type,
                 v_clt_id,
                 v_acc_id,
                 v_cr_description,
                 v_old_as_client,
                 V_credit_limit,
                 v_aut_id
                 
       FROM   cellulars clu,
                 accounts acc,
                 client clt,
                 CELLULAR_CALL_RESTRICTIONS CCR,
                 CALL_RESTRICTIONS CR
          WHERE clu.clu_cellular_number = pin_cellular_number
            AND CCR.CCR_CLU_CELLULAR_NUMBER = clu.clu_cellular_number
            AND NVL(CCR.CCR_END_DATE, p_Action_Date + 1) >= p_Action_Date    
            AND clu.clu_acc_id = acc.acc_id
            AND acc.acc_clt_id = clt.clt_id
            AND CCR.CCR_CR_ID = CR.CR_ID;
        EXCEPTION
          WHEN OTHERS THEN
            pout_message := c_package_name || v_function_name || ':Error en '||pout_message||' '||SQLCODE||' - '||SQLERRM;
            RETURN -1;
        END;
        
            pout_message := 'Obtencion IMAI TRACKING: ['||pin_cellular_number||'].';
        -- Buscando el IMAI TRACKING
        BEGIN
          SELECT NVL(CIM.CIM_IMEI,'N')
          INTO v_imei_tracking
          FROM CELLULAR_IMEI_TRACKINGS CIM
           WHERE CIM.CIM_CELLULAR = pin_cellular_number
           AND NVL(CIM.CIM_END_DATE, p_Action_Date + 1) >= p_Action_Date;

        EXCEPTION WHEN OTHERS THEN
          v_imei_tracking := 'N';
        END;
        
        
        -- Buscando el Plan de aire
        pout_message := 'Obtencion PLAN de AIRE: ['||pin_cellular_number||'].';
        BEGIN
            SELECT CPL_RPL_ID
            INTO V_RPL_ID
           FROM CELLULAR_PLANS CP
            WHERE CPL_START_DATE <= p_action_date 
            AND NVL(CPL_END_DATE, p_action_date + 1) >= p_action_date
            AND CP.CPL_CLU_CELLULAR_NUMBER = pin_cellular_number
             AND CPL_STG_ID = 'AH';

        EXCEPTION WHEN OTHERS THEN
          V_RPL_ID :='N';
        END;
        
        IF v_aut_id = 'N' OR v_credit_limit = 0 THEN
           V_credit_limit := 'N';
        END IF;
        
        
        
        
   BEGIN
         OPEN  pout_cursor_cellular_info FOR 
              SELECT
                     v_cbt_id                     CBT_ID,
                     v_status                     STATUS,
                     v_category                   CATEGORY,
                     v_clt_type                   CLT_TYPE,
                     v_clt_id                     CLT_ID,
                     v_acc_id                     ACC_ID,
                     v_cr_description             CR_DESCRIPTION,
                     v_imei_tracking              IMEI_TRACKING,
                     v_rpl_id                     RPL_ID,
                     v_old_as_client              OLD_AS_CLIENT,
                     v_credit_limit               CREDIT_LIMIT,
                     v_aut_id                     AUT_ID
               FROM DUAL;
   EXCEPTION
          WHEN OTHERS THEN
            pout_message := c_package_name || v_function_name || ':Error en '|| c_package_name || v_function_name ||  ':el armado del cursor pout_cursor_cellular_info' || ' : ' ||SQLERRM;
            RETURN -1;
   END;  

RETURN 0;    
      
EXCEPTION WHEN OTHERS THEN
     pout_message := 'Error en '|| c_package_name || v_function_name  || ' : ' || pout_message ||SQLERRM;
     RETURN -1;          
    END  p_get_cellular_info;  
    
    
    
 FUNCTION P_GET_TECHNOLOGY    ( pin_cellular_number    IN  CELLULARS.CLU_CELLULAR_NUMBER%TYPE,
                                pin_Action_Date        IN  DATE DEFAULT SYSDATE,
                                pout_technology       OUT PRODUCTS.PRO_TECHNOLOGY%TYPE,
                                pout_message          OUT VARCHAR2)
                                RETURN NUMBER IS 
 v_function_name       VARCHAR2(50)  := 'P_GET_TECHNOLOGY';                               
 BEGIN 
   pout_message:= 'Obteniendo la tecnologia';

   SELECT NVL(PRO_TECHNOLOGY, '2G')
    INTO  pout_technology
    FROM ESN_CELLULARS, ELECTRONICAL_SERIAL_NUMBERS, PRODUCTS
  WHERE ESC_CLU_CELLULAR_NUMBER = pin_cellular_number
     AND ESC_ESN_HEXA = ESN_HEXA
     AND ESN_PRO_ID = PRO_ID
     AND ESC_START_DATE <= pin_Action_Date
     AND NVL(ESC_END_DATE, pin_Action_Date + 1) >= pin_Action_Date;
 
 RETURN 0;
 EXCEPTION 
   WHEN OTHERS THEN
    pout_message := 'Error en '|| c_package_name || v_function_name  || ' : ' || pout_message ||SQLERRM;
     RETURN -1;  
     END p_get_TECHNOLOGY;  
     
PROCEDURE GET_ACTIVATE_SERVICE(pin_cellular_number          IN CELLULARS.CLU_CELLULAR_NUMBER%TYPE,
                               pin_feature                  IN VARCHAR2,
                               pin_package                  IN VARCHAR2,
                               pin_action_date              IN DATE,
                               pout_flag_active_service     OUT VARCHAR2,
                               pout_message                 OUT VARCHAR2) IS

sql_stmt           VARCHAR2(1500) := NULL;
v_feature          VARCHAR2(150);
v_package          VARCHAR2(150);
v_cellular_number  CELLULARS.CLU_CELLULAR_NUMBER%TYPE;
v_split            VARCHAR2(150);
v_package_aux      VARCHAR2(150);
v_where            VARCHAR2(400)                           := ' where ( fp.pks_pkt_id =  ';
v_contador         NUMBER                                  := 0;    
  BEGIN

  v_feature     := pin_feature;
  v_package     := pin_package;
  v_package_aux := v_package;
 
 IF pin_feature IS NULL THEN
    v_feature :=  'fp.pks_ftr_id';
 ELSE
   v_feature  := chr(39) ||   v_feature || chr(39);
 END IF;
 
 
 IF pin_package IS NULL THEN
    v_package := ' fp.pks_pkt_id ';
 ELSE
    
    
    IF instr(v_package,'#') >0  THEN 
     while length(v_package_aux) > 0 
     loop
       select regexp_substr(v_package_aux,'[^##]+')
         INTO v_split
         FROM DUAL;
         IF v_contador = 0 THEN 
            v_where := v_where || chr(39) ||   v_split || chr(39);
         ELSE
            v_where := v_where || ' OR fp.pks_pkt_id = '||  chr(39) ||   v_split || chr(39) ; 
         END IF;
         
         SELECT REPLACE(v_package_aux,v_split || '##','') 
            INTO v_package_aux
         FROM DUAL   ;
         v_contador := v_contador + 1;
     end loop;
     v_package := NULL;
    ELSE
        v_package :=  chr(39) ||   v_package || chr(39); 
    END IF;  
 END IF;

sql_stmt := 'SELECT cp.cpk_clu_cellular_number
   from cellular_packages cp, feature_packages fp ' ||
    v_where   || v_package || 
     ' )  and cp.cpk_clu_cellular_number = :1
     and fp.pks_ftr_id = ' || v_feature ||
     ' and cp.cpk_pkt_id = fp.pks_pkt_id
    and cp.cpk_activation_date <= :2  
    and nvl(cp.cpk_canceled_date, :3 +1) >= :4 
    and not exists
   (SELECT pif_ftr_id
                FROM cel_inactive_features cif
               WHERE cif.pif_clu_cellular_number = cp.cpk_clu_cellular_number
                 AND cif.pif_ftr_id = fp.pks_ftr_id
                 AND cif.pif_start_date <= :5
                 AND nvl(cif.pif_end_date, :6 + 1) > :7 ) 
                 AND rownum =1 ';


 
  EXECUTE IMMEDIATE sql_stmt 
  INTO  v_cellular_number
  USING pin_cellular_number,
        pin_action_date,
        pin_action_date,
        pin_action_date,
        pin_action_date,
        pin_action_date,
        pin_action_date;

    pout_flag_active_service := 'Y';
  EXCEPTION
    WHEN OTHERS THEN
    pout_flag_active_service := 'N';
    pout_message :=  sqlerrm;
END GET_ACTIVATE_SERVICE;     
                                      
end PA_PROV_GET_INFO;
/

