create FUNCTION F_GET_SURPLUS

 (P_ACC_ID IN VARCHAR2
 ,P_CELLULAR IN VARCHAR2
 ,P_DESCRIPTION OUT VARCHAR2
 ,P_CANTIDAD OUT VARCHAR2
 ,P_UNIDAD OUT VARCHAR2
 ,P_PRECIO_SIN_IVA OUT VARCHAR2
 ,P_PRECIO_CON_IVA OUT VARCHAR2
 ,P_ERR_NUMBER OUT NUMBER
 ,P_ERR_TXT OUT VARCHAR2
 )
 RETURN NUMBER
 IS
  v_printer_type   VARCHAR2(1);
  v_err_number     NUMBER;
  v_err_code       NUMBER;
  v_err_txt        VARCHAR2(255);
  v_description    VARCHAR2(100);
  v_cantidad       VARCHAR2(18);
  v_unidad         VARCHAR2(5);
  v_precio_sin_IVA VARCHAR2(18);
  v_precio_con_IVA VARCHAR2(18);

  --Cursor Corpo o Masivo Viejo
  CURSOR cursorCorpo(p_cellular s_cellulars.clu_bill_number%TYPE) IS
    SELECT inc_description,
           round(sum(inc_quantity), 2) "Cantidad",
           inc_unit "Unidad",
           round(sum(inc_amount), 2) "$(without IVA)",
           round(sum(inc_amount_tot), 2) "$(with IVA)"
      FROM consulta_consumo cco
     WHERE cco.inc_clu_cellular_number = p_cellular
     GROUP BY inc_description, inc_unit
     ORDER BY inc_description DESC;

  --Cursor Masivo Nuevo
  CURSOR cursorMasivo(p_cellular s_cellulars.clu_bill_number%TYPE) IS
    SELECT inc_description,
           round(sum(inc_quantity), 2) "Cantidad",
           inc_unit "Unidad",
           round(sum(inc_amount), 2) "$(without IVA)",
           round(sum(inc_amount_tot), 2) "$(with IVA)"
      FROM consulta_consumo_masivo cco
     WHERE cco.inc_clu_cellular_number = p_cellular and inc_invoice_type='M'
     GROUP BY inc_description, inc_unit
     ORDER BY inc_description DESC;
BEGIN

  v_err_number := f_get_printer_type(p_acc_id,
                                     v_printer_type,
                                     v_err_txt,
                                     v_err_code);

  IF v_err_number != 0 THEN
    p_err_txt    := 'Error en f_get_printer_type: ' || v_err_txt || SQLERRM;
    p_err_number := -1000;
    RETURN - 1;
  END IF;

  IF v_printer_type IN ('C', 'V') THEN
    -- C cuando el cliente es Corpo o Masivo Viejo
    OPEN cursorCorpo(p_cellular);
    LOOP
      FETCH cursorCorpo
        INTO v_description,
             v_cantidad,
             v_unidad,
             v_precio_sin_IVA,
             v_precio_con_IVA;

      EXIT WHEN cursorCorpo%NOTFOUND;

      IF v_description is null THEN
        v_description := ' ';
      END IF;
      p_description := p_description || v_description || '##';

      IF v_cantidad is null THEN
        v_cantidad := ' ';
      END IF;
      p_cantidad := p_cantidad || v_cantidad || '##';

      IF v_unidad is null THEN
        v_unidad := ' ';
      END IF;
      p_unidad := p_unidad || v_unidad || '##';

      IF v_precio_sin_IVA is null THEN
        v_precio_sin_IVA := ' ';
      END IF;
      p_precio_sin_IVA := p_precio_sin_IVA || v_precio_sin_IVA || '##';

      IF v_precio_con_IVA is null THEN
        v_precio_con_IVA := ' ';
      END IF;
      p_precio_con_IVA := p_precio_con_IVA || v_precio_con_IVA || '##';

    END LOOP;
    CLOSE cursorCorpo;

  ELSIF v_printer_type = 'M' THEN
    -- M cuando el cliente es Masivo Nuevo
    OPEN cursorMasivo(p_cellular);
    LOOP
      FETCH cursorMasivo
        INTO v_description,
             v_cantidad,
             v_unidad,
             v_precio_sin_IVA,
             v_precio_con_IVA;

      EXIT WHEN cursorMasivo%NOTFOUND;

      IF v_description is null THEN
        v_description := ' ';
      END IF;
      p_description := p_description || v_description || '##';

      IF v_cantidad is null THEN
        v_cantidad := ' ';
      END IF;
      p_cantidad := p_cantidad || v_cantidad || '##';

      IF v_unidad is null THEN
        v_unidad := ' ';
      END IF;
      p_unidad := p_unidad || v_unidad || '##';

      IF v_precio_sin_IVA is null THEN
        v_precio_sin_IVA := ' ';
      END IF;
      p_precio_sin_IVA := p_precio_sin_IVA || v_precio_sin_IVA || '##';

      IF v_precio_con_IVA is null THEN
        v_precio_con_IVA := ' ';
      END IF;
      p_precio_con_IVA := p_precio_con_IVA || v_precio_con_IVA || '##';

    END LOOP;
    CLOSE cursorMasivo;

  ELSE
    p_err_txt    := 'No existe consulta para el tipo de documento. ';
    p_err_number := -1001;
    RETURN 1;
  END IF;

  IF p_description IS NULL AND p_cantidad IS NULL AND p_unidad IS NULL AND
     p_precio_sin_IVA IS NULL AND p_precio_con_IVA IS NULL THEN
    p_err_txt    := 'Todos los parametros vienen null.';
    p_err_number := -1003;
    RETURN 1;
  ELSE
    p_err_txt    := 'OK';
    p_err_number := NULL;
    RETURN 0;
  END IF;

EXCEPTION
  WHEN OTHERS THEN
    p_err_txt    := 'Error: ' || p_err_txt || SQLERRM;
    p_err_number := SQLCODE;
    RETURN - 1;

END;
/

