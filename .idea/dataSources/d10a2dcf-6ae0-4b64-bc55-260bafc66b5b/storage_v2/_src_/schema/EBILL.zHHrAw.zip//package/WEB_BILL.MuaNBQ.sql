create PACKAGE Web_Bill
IS
TYPE T_CLU IS TABLE OF VARCHAR2(30)
	INDEX BY BINARY_INTEGER;
TYPE T_ACC IS TABLE OF ACCOUNTS.ACC_ID%TYPE
	INDEX BY BINARY_INTEGER;
TYPE T_DATE IS TABLE OF DATE
	INDEX BY BINARY_INTEGER;
TYPE T_DOC IS TABLE OF DOCUMENTS.DOC_ID%TYPE
	INDEX BY BINARY_INTEGER;
TYPE T_DOC_CMP IS TABLE OF DOCUMENTS.DOC_CMP_ID%TYPE
	INDEX BY BINARY_INTEGER;
TYPE T_DOC_LETTER IS TABLE OF DOCUMENTS.DOC_LETTER%TYPE
	INDEX BY BINARY_INTEGER;
TYPE T_SCH IS TABLE OF SCHEDULERS.SCH_ID%TYPE
	INDEX BY BINARY_INTEGER;

FUNCTION VALIDAPASSCLIENT(
		p_cellular_number IN VARCHAR2,
		p_password IN VARCHAR2,
		p_clt_id OUT client.clt_id%TYPE,
		p_client_name OUT VARCHAR2
		)
RETURN NUMBER;

PROCEDURE ObtenerCellularNumber(bill_number IN VARCHAR2,
                        celular OUT VARCHAR2,
                        codigo_error OUT NUMBER);

--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
--F_GET_ACC_CLU: Devuelve las cuentas y los celulares correspondientes
--		al cliente pasado como parametro.
--	Devuelve los resultados como tablas PL/SQL.
--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
FUNCTION F_GET_ACC_CLU(p_clt_id IN CLIENT.CLT_ID%TYPE,
						ACC_ID OUT T_ACC,
						CLU_ID OUT T_CLU)
	RETURN NUMBER;

PROCEDURE P_GET_ACC_CLU(p_clt_id IN CLIENT.CLT_ID%TYPE,
						ACC_ID OUT T_ACC,
						CLU_ID OUT T_CLU);

--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
--F_GET_DOC: Devuelve los datos de los documentos correspondientes
--		al cliente pasado como parametro, para los periodos
--		anteriores a la fecha requeridos.
--	Devuelve los resultados como tablas PL/SQL.
--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
FUNCTION F_GET_DOC(
			P_CLT_ID		IN CLIENT.CLT_ID%TYPE,
			P_PERIODOS		IN NUMBER,
			DOC_ID			OUT T_DOC,
			DOC_CMP_ID		OUT T_DOC_CMP,
			DOC_LETTER		OUT T_DOC_LETTER,
			SCH_START_DATE	OUT T_DATE,
			SCH_END_DATE	OUT T_DATE,
			DOC_ACC_ID		OUT T_ACC,
			SCH_ID		OUT T_SCH)
	RETURN NUMBER;

END;
/

