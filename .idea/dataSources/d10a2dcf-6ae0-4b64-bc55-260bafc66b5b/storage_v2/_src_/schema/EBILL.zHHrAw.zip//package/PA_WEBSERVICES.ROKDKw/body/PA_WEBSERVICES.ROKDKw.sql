create PACKAGE BODY PA_WEBSERVICES IS

FUNCTION getcertdataxdnf (dn       IN    VARCHAR2,
                ip       IN    VARCHAR2,
                servicio     IN    VARCHAR2,
                active      OUT VARCHAR2,
                maxconn      OUT VARCHAR2,
                checkcl      OUT VARCHAR2,
                bill        OUT VARCHAR2,
                p_mensaje     OUT VARCHAR2)
    RETURN NUMBER
  IS
  BEGIN
    p_mensaje := 'buscando en web_service_clients ';
    SELECT wsc_active,
         wsc_maxconn,
         wsc_checkcl,
         wsc_bill
    INTO   active,
         maxconn,
         checkcl,
         bill
    FROM   web_service_clients w
    WHERE  wsc_dn = dn
    AND    wsc_serv = servicio
    AND    wsc_ip = ip
    AND    SYSDATE BETWEEN wsc_start_date
               AND NVL (wsc_end_date, SYSDATE + 1)
    AND    ROWNUM < 2;
    p_mensaje := 'OK';
    RETURN 0;
  EXCEPTION
    WHEN OTHERS THEN
      p_mensaje := 'Error: ' || p_mensaje || SQLERRM;
      RETURN SQLCODE;
  END;


  FUNCTION getcelnumbertecno (bill_number      IN    VARCHAR2,
                celular         OUT VARCHAR2,
                tipo_tecnologia     OUT VARCHAR2)
    RETURN NUMBER
  IS
  BEGIN
    DBMS_OUTPUT.disable;
    SELECT clu_cellular_number, clu_pro_mode_type
    INTO   celular, tipo_tecnologia
    FROM   cellulars
    WHERE  clu_bill_number = bill_number;
    RETURN 0;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN 1;
    WHEN OTHERS THEN
      RETURN (SQLCODE);
  END;


  /*
     Recibe una lista de billNumbers, id de cliente y un separador de los datos de
     las listas.
     Los parametros de salida p_CellsNumbersList, p_EcpList y p_StatusList tambiin
     son listas de datos separadas por p_Separator.
     Retorna 0: si no hay errores
             9: si hay algun error
     Por cada linea retorna en p_CellsNumbersList el clu_cellular_number
     Por cada linea retorna en p_EcpList el ecp de la linea
     Por cada linea retorna en p_StatusList uno de los siguientes valores:
             0: si es valida
             1: si no es una lmnea CTI
             2: si no le pertenece al cliente p_CltId
             3: si no tiene el pack de geoloc
             4: si no encuentra el ECP
             5: si no es GSM
             6: si no esta activo
    */
  FUNCTION getlinesinfo (p_cltid         IN   VARCHAR2,
               p_billnumberslist   IN   VARCHAR2,
               p_separator       IN   VARCHAR2,
               p_cellsnumberslist    OUT VARCHAR2,
               p_ecplist        OUT VARCHAR2,
               p_statuslist       OUT VARCHAR2,
               p_error_message      OUT VARCHAR2)
    RETURN NUMBER
  IS
    v_line       VARCHAR2 (10);
    v_tech       VARCHAR2 (10);
    v_status     VARCHAR2 (10);
    v_index      NUMBER := 1;
    v_ecp       NUMBER;
    v_exists     NUMBER;
    v_errcode     NUMBER;
    v_exception    EXCEPTION;
    v_vout_swi_id   VARCHAR2 (3);
    v_vout_msisdn   VARCHAR2 (100);
    v_result     NUMBER (2);
  BEGIN
    LOOP
      EXIT WHEN v_index >= LENGTH (p_billnumberslist);
      v_line := SUBSTR (p_billnumberslist, v_index, 10);
      v_index := v_index + 10 + LENGTH (p_separator);
      BEGIN
        --obeniendo clu_cellular_number y tecnologia de la linea
        v_errcode := 1;
        SELECT clu_cellular_number, clu_pro_mode_type, clu_status
        INTO   v_line, v_tech, v_status
        FROM   cellulars
        WHERE  clu_bill_number = v_line;

        IF v_tech IS NULL
           OR v_tech != 'GSM' THEN
          v_errcode := 5;
          RAISE v_exception;
        END IF;

        IF v_status != 'A' THEN
          v_errcode := 6;
          RAISE v_exception;
        END IF;

        --chequeando cliente de la linea
        v_exists := 0;
        v_errcode := 2;
        SELECT COUNT (*)
        INTO   v_exists
        FROM   accounts, cellulars
        WHERE  acc_clt_id = p_cltid
        AND    clu_cellular_number = v_line
        AND    acc_id = clu_acc_id;

        IF v_exists <= 0 THEN
          RAISE v_exception;
        END IF;

        --verificando packs de la linea
        v_exists := 0;
        v_errcode := 3;

        SELECT COUNT (*)
        INTO   v_exists
        FROM   cellular_packages, packages_geoloc
        WHERE  cpk_clu_cellular_number = v_line
        AND    cpk_pkt_id = pag_pkt_id
        AND    SYSDATE BETWEEN cpk_activation_date
                   AND NVL (cpk_canceled_date, SYSDATE + 1)
        AND    SYSDATE BETWEEN pag_start_date
                   AND NVL (pag_end_date, SYSDATE + 1);
        IF v_exists <= 0 THEN
          RAISE v_exception;
        END IF;

        --obteniendo ECP de la linea
        v_errcode := 4;

        -- PC88707_CD89302_Mejora_Para_Portabilidad
        v_result := stl.get_talker_info@prod (p_clu_cellular_number   => v_line,
                                              vout_swi_id        => v_vout_swi_id,
                                              vout_msisdn        => v_vout_msisdn);

        IF v_result < 0 OR v_vout_swi_id IS NULL THEN
          RAISE v_exception;
        END IF;

        SELECT s.swi_asw_ecp_id
        INTO   v_ecp
        FROM   switches@prod s
        WHERE  s.swi_id = v_vout_swi_id;

        p_cellsnumberslist := p_cellsnumberslist || v_line || p_separator;
        p_ecplist := p_ecplist || v_ecp || p_separator;
        p_statuslist := p_statuslist || '0' || p_separator;

      EXCEPTION
        WHEN OTHERS THEN
          p_cellsnumberslist := p_cellsnumberslist || v_line || p_separator;
          p_ecplist := p_ecplist || '-' || p_separator;
          p_statuslist := p_statuslist || v_errcode || p_separator;
      END;
    END LOOP;
    p_error_message := 'OK';
    RETURN 0;
  EXCEPTION
    WHEN OTHERS THEN
      p_error_message :='Error en getLinesInfo(). Sqlcode=' || SQLCODE || ' Sqlerrm=' || SQLERRM;
      RETURN 9;
  END;


  /*
     Recibe una lista de billNumbers y un separador de los datos de
     las listas.
     Los parametros de salida p_CellsNumbersList, p_EcpList y p_StatusList tambien
     son listas de datos separadas por p_Separator.
     Retorna 0: si no hay errores
             9: si hay algun error
     Por cada linea retorna en p_CellsNumbersList el clu_cellular_number
     Por cada linea retorna en p_EcpList el ecp de la linea
     Por cada linea retorna en p_StatusList uno de los siguientes valores:
             0: si es valida
             1: si no es una linea CTI
             3: si no tiene el pack de geoloc
             4: si no encuentra el ECP
             5: si no es GSM
             6: si no esta activo
    */
  FUNCTION getlinesinfoforhub (p_billnumberslist     IN    VARCHAR2,
                 p_separator       IN    VARCHAR2,
                 p_cellsnumberslist     OUT VARCHAR2,
                 p_ecplist          OUT VARCHAR2,
                 p_statuslist        OUT VARCHAR2,
                 p_error_message      OUT VARCHAR2)
    RETURN NUMBER
  IS
    v_line       VARCHAR2 (10);
    v_tech       VARCHAR2 (10);
    v_status     VARCHAR2 (10);
    v_index      NUMBER := 1;
    v_ecp       NUMBER;
    v_exists     NUMBER;
    v_errcode     NUMBER;
    v_exception    EXCEPTION;
    v_vout_swi_id   VARCHAR2 (3);
    v_vout_msisdn   VARCHAR2 (100);
    v_result     NUMBER (2);
  BEGIN
    LOOP
      EXIT WHEN v_index >= LENGTH (p_billnumberslist);
      v_line := SUBSTR (p_billnumberslist, v_index, 10);
      v_index := v_index + 10 + LENGTH (p_separator);

      BEGIN
        --obeniendo clu_cellular_number y tecnologia de la linea
        v_errcode := 1;
        SELECT clu_cellular_number, clu_pro_mode_type, clu_status
        INTO   v_line, v_tech, v_status
        FROM   cellulars
        WHERE  clu_bill_number = v_line;

        IF v_tech IS NULL
           OR v_tech != 'GSM' THEN
          v_errcode := 5;
          RAISE v_exception;
        END IF;

        IF v_status != 'A' THEN
          v_errcode := 6;
          RAISE v_exception;
        END IF;

        --verificando packs de la linea
        v_exists := 0;
        v_errcode := 3;
        SELECT COUNT (*)
        INTO   v_exists
        FROM   cellular_packages, packages_geoloc
        WHERE  cpk_clu_cellular_number = v_line
        AND    cpk_pkt_id = pag_pkt_id
        AND    SYSDATE BETWEEN cpk_activation_date
                   AND NVL (cpk_canceled_date, SYSDATE + 1)
        AND    SYSDATE BETWEEN pag_start_date
                   AND NVL (pag_end_date, SYSDATE + 1);
        IF v_exists <= 0 THEN
          RAISE v_exception;
        END IF;

        --obteniendo ECP de la linea
        v_errcode := 4;

        -- PC88707_CD89302_Mejora_Para_Portabilidad
        v_result := stl.get_talker_info@prod (p_clu_cellular_number   => v_line,
                                              vout_swi_id        => v_vout_swi_id,
                                              vout_msisdn        => v_vout_msisdn);

        IF v_result < 0
           OR v_vout_swi_id IS NULL THEN
          RAISE v_exception;
        END IF;

        SELECT s.swi_asw_ecp_id
        INTO   v_ecp
        FROM   switches@prod s
        WHERE  s.swi_id = v_vout_swi_id;

        p_cellsnumberslist :=  p_cellsnumberslist || v_line || p_separator;
        p_ecplist := p_ecplist || v_ecp || p_separator;
        p_statuslist := p_statuslist || '0' || p_separator;
      EXCEPTION
        WHEN OTHERS THEN
          p_cellsnumberslist := p_cellsnumberslist || v_line || p_separator;
          p_ecplist := p_ecplist || '-' || p_separator;
          p_statuslist := p_statuslist || v_errcode || p_separator;
      END;
    END LOOP;
    p_error_message := 'OK';
    RETURN 0;
  EXCEPTION
    WHEN OTHERS THEN
      p_error_message :='Error en getLinesInfoForHub(). Sqlcode=' || SQLCODE || ' Sqlerrm='  || SQLERRM;
      RETURN 9;
  END;


  FUNCTION getlocations (p_cellid_list    IN   VARCHAR2,
               p_lac_list      IN   VARCHAR2,
               p_mnc_list      IN   VARCHAR2,
               p_separator      IN   VARCHAR2,
               p_lat_list       OUT VARCHAR2,
               p_lon_list       OUT VARCHAR2,
               p_zone_list       OUT VARCHAR2,
               p_error_message     OUT VARCHAR2)
    RETURN NUMBER
  IS
    v_cellid    VARCHAR2 (10);
    v_lac      VARCHAR2 (10);
    v_mnc      VARCHAR2 (10);
    v_start_lac   NUMBER := 1;
    v_end_lac    NUMBER;
    v_start_cell  NUMBER := 1;
    v_end_cell    NUMBER;
    v_start_mnc   NUMBER := 1;
    v_end_mnc    NUMBER;
    v_cia_id    VARCHAR2 (10);
    v_lat      VARCHAR2 (15);
    v_lon      VARCHAR2 (15);
    v_zone      VARCHAR2 (100);
  BEGIN
    LOOP
      BEGIN
        EXIT WHEN (v_start_cell >= LENGTH (p_cellid_list) OR LENGTH (p_cellid_list) IS NULL);

        v_end_cell := INSTR (p_cellid_list, p_separator, v_start_cell);
        v_cellid := SUBSTR (p_cellid_list,v_start_cell,(v_end_cell - v_start_cell));
        v_end_lac := INSTR (p_lac_list, p_separator, v_start_lac);
        v_lac := SUBSTR (p_lac_list,v_start_lac,(v_end_lac - v_start_lac));
        v_end_mnc := INSTR (p_mnc_list, p_separator, v_start_mnc);
        v_mnc := SUBSTR (p_mnc_list, v_start_mnc,(v_end_mnc - v_start_mnc));

        v_start_cell := v_end_cell + 1;
        v_start_lac := v_end_lac + 1;
        v_start_mnc := v_end_mnc + 1;

        BEGIN
          SELECT nrm.nrp_cia_id
          INTO   v_cia_id
          FROM   national_roaming_operators@prod nrm
          WHERE  nrm.nrp_mnc = v_mnc
          AND    ROWNUM < 2;
          
        EXCEPTION 
           WHEN NO_DATA_FOUND THEN
                v_cia_id := 'CTIS';
        END;

        SELECT TO_CHAR (clg_latitude),
             TO_CHAR (clg_longitude),
             clg_sites
        INTO   v_lat, v_lon, v_zone
        FROM   cells_locations_gsm@prod
        WHERE  clg_bts_cell_id = TO_NUMBER (v_cellid)
        AND    TO_NUMBER (v_lac) BETWEEN clg_start_lac
                       AND clg_end_lac
        AND    clg_cia_id = v_cia_id;

        p_lat_list := p_lat_list || v_lat || p_separator;
        p_lon_list := p_lon_list || v_lon || p_separator;
        p_zone_list := p_zone_list || v_zone || p_separator;

      EXCEPTION
        WHEN OTHERS THEN
          p_lat_list := p_lat_list || p_separator;
          p_lon_list := p_lon_list || p_separator;
          p_zone_list := p_zone_list || p_separator;
      END;
    END LOOP;
    p_error_message := 'Ok';
    RETURN 0;
  EXCEPTION
    WHEN OTHERS THEN
        p_error_message :='Error en getLocations(). Sqlcode='|| SQLCODE || ' Sqlerrm='|| SQLERRM;
      RETURN 1;
  END;
END pa_webservices;
/

