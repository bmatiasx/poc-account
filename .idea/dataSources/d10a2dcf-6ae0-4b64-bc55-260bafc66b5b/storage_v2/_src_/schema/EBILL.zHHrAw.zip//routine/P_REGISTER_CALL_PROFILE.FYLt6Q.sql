create PROCEDURE P_REGISTER_CALL_PROFILE (P_RESULT_OK    OUT VARCHAR2,
                                     P_ERROR_COD      OUT VARCHAR2,
                                     P_ERROR_MSG      OUT VARCHAR2)
   IS
       V_COUNT_LINES         REG_CALL_PROFILE.RCP_LINES%TYPE;
      V_ARS_RCP_ID           REG_CALL_PROFILE.RCP_ID%TYPE;
      V_RCPD_ID              VARCHAR2(200);
      V_CCR_CR_ID            CELLULAR_CALL_RESTRICTIONS.CCR_CR_ID%TYPE;
      V_EXCEPCION_PROPIA     EXCEPTION;
      V_COUNT_ERROR_LINES    NUMBER := 0;
      V_COUNT_ACTIVE_LINES   NUMBER := 0;

      CURSOR C_LINES
      IS
         SELECT (SELECT CLU.CLU_CELLULAR_NUMBER
                   FROM CELLULARS CLU
                  WHERE CLU.CLU_CELLULAR_NUMBER = RCPD.RCPD_CELLULAR_NUMBER)
                   CELLULAR_NUMBER,
                RCPD.RCPD_ID,
                RCPD.RCPD_CR_ID CR_ID
          FROM REG_CALL_PROFILE_DETAIL RCPD
          WHERE RCPD.RCPD_RCP_ID = (SELECT TO_CHAR (MAX (TO_NUMBER (RCP_ID)))
                                     FROM REG_CALL_PROFILE);

      V_CURSOR_LINES         C_LINES%ROWTYPE;

    --  PRAGMA AUTONOMOUS_TRANSACTION;
   BEGIN
         SELECT TO_CHAR (MAX (TO_NUMBER (RCP_ID)))
         INTO V_RCPD_ID
         FROM REG_CALL_PROFILE;

         BEGIN
           BEGIN
               SELECT RGP.RCP_LINES, RGP.RCP_ID
                 INTO V_COUNT_LINES, V_ARS_RCP_ID
                 FROM REG_CALL_PROFILE RGP
                WHERE RGP.RCP_ID = V_RCPD_ID;
            EXCEPTION
               WHEN NO_DATA_FOUND
               THEN
                  P_ERROR_COD := '3001';
                  P_ERROR_MSG :=
                     'No existe operacion con el RCPD_ID ingresado.';
            END;

            BEGIN
               BEGIN
                  OPEN C_LINES;

                  LOOP
                     BEGIN
                        FETCH C_LINES INTO V_CURSOR_LINES;

                        EXIT WHEN C_LINES%NOTFOUND;

                        SELECT CCR.CCR_CR_ID
                          INTO V_CCR_CR_ID
                          FROM CELLULAR_CALL_RESTRICTIONS CCR
                         WHERE     CCR.CCR_CLU_CELLULAR_NUMBER =
                                      V_CURSOR_LINES.CELLULAR_NUMBER
                               AND CCR.CCR_END_DATE IS NULL;

                        IF (V_CURSOR_LINES.CR_ID = V_CCR_CR_ID)
                        THEN
                           UPDATE REG_CALL_PROFILE_DETAIL RCPD
                              SET RCPD.RCPD_STATUS = 'E',
                                  RCPD.RCPD_GENERIC_MSG =
                                     'La linea ya posee el perfil seleccionado.',
                                  RCPD.RCPD_ORIGINAL_MSG =
                                     'La linea ya posee el perfil seleccionado.'
                            WHERE     RCPD.RCPD_CELLULAR_NUMBER =
                                         V_CURSOR_LINES.CELLULAR_NUMBER
                                  AND RCPD.RCPD_RCP_ID = V_ARS_RCP_ID;

                       --    COMMIT;

                           V_COUNT_ERROR_LINES := V_COUNT_ERROR_LINES + 1;
                        ELSE
                           UPDATE REG_CALL_PROFILE_DETAIL RCPD
                              SET RCPD.RCPD_EXECUTE_DATE = SYSDATE,
                                  RCPD.RCPD_STATUS = 'OK',
                                  RCPD.RCPD_GENERIC_MSG =
                                     'Se realizo con exito el cambio de profile para la linea.',
                                  RCPD.RCPD_ORIGINAL_MSG = 'OK'
                            WHERE     RCPD.RCPD_CELLULAR_NUMBER =
                                         V_CURSOR_LINES.CELLULAR_NUMBER
                                  AND RCPD.RCPD_RCP_ID = V_ARS_RCP_ID;

                          -- COMMIT;

                           V_COUNT_ACTIVE_LINES := V_COUNT_ACTIVE_LINES + 1;
                        END IF;
                     EXCEPTION
                        WHEN NO_DATA_FOUND
                        THEN
                          BEGIN
                           UPDATE REG_CALL_PROFILE_DETAIL RCPD
                              SET RCPD.RCPD_EXECUTE_DATE = SYSDATE,
                                  RCPD.RCPD_STATUS = 'E',
                                  RCPD.RCPD_GENERIC_MSG =
                                     'La linea no se encuentra en la tabla CELLULAR_CALL_RESTRICTIONS.',
                                  RCPD.RCPD_ORIGINAL_MSG =
                                     'La linea no se encuentra en la tabla CELLULAR_CALL_RESTRICTIONS.'
                            WHERE     RCPD.RCPD_CELLULAR_NUMBER =
                                         V_CURSOR_LINES.CELLULAR_NUMBER
                                  AND RCPD.RCPD_RCP_ID = V_ARS_RCP_ID;
                                  
                                   V_COUNT_ERROR_LINES := V_COUNT_ERROR_LINES + 1;
                                   
                          EXCEPTION
                            WHEN OTHERS THEN
                              P_ERROR_COD := '3003';
                              P_ERROR_MSG :=
                              'No se pudo realizar la actualizacion correspondiente.';
                          -- COMMIT;
                          END;
                          
                     END;
                  END LOOP;
                  COMMIT;
                  CLOSE C_LINES;
               EXCEPTION
                  WHEN OTHERS
                  THEN
                     P_ERROR_COD := '3003';
                     P_ERROR_MSG :=
                        'No se pudo realizar la actualizacion correspondiente.';
               END;

               V_COUNT_LINES := V_COUNT_ACTIVE_LINES + V_COUNT_ERROR_LINES;

               BEGIN
                  UPDATE REG_CALL_PROFILE RCP
                     SET RCP.RCP_STATUS = 'T',
                         RCP.RCP_LINES = V_COUNT_LINES,
                         RCP.RCP_ERROR_LINES = V_COUNT_ERROR_LINES,
                         RCP.RCP_ACTIVE_LINES = V_COUNT_ACTIVE_LINES
                   WHERE RCP.RCP_ID = V_RCPD_ID;

                  --COMMIT;
               EXCEPTION
                  WHEN OTHERS
                  THEN
                     P_ERROR_COD := '3004';
                     P_ERROR_MSG :=
                           'No se pudo realizar la actualizacion correspondiente.'
                        || ' ## '
                        || SQLERRM
                        || ' ## '
                        || SQLCODE;
               END;

               P_RESULT_OK := 'Se realizo con exito la tarea de F_REGISTER_CALL_PROFILE.';

            END;
         END;
   EXCEPTION
      WHEN OTHERS
      THEN
         P_ERROR_COD := '3005';
         P_ERROR_MSG := SQLERRM;
         ROLLBACK;
   END P_REGISTER_CALL_PROFILE;
/

