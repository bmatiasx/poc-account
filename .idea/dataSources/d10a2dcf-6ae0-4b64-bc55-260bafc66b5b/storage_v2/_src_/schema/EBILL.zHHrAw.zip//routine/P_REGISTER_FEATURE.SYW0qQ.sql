create PROCEDURE P_REGISTER_FEATURE(P_ERR_NUMBER OUT NUMBER, P_ERR_MESSAGE OUT VARCHAR2)
 IS
  V_STL_VALUE      NUMBER;
  V_ARF_ID         VARCHAR2(10);
  V_ARF_TRY_FAILED NUMBER;
  V_RESULT         NUMBER;
  V_TIENE          VARCHAR2(1) := 'Y';
BEGIN
  SELECT STL_VALUE
    INTO V_STL_VALUE
    FROM STL_PARAMETERS
   WHERE STL_ID = 'TRYARF'
     AND NVL(STL_END_DATE, SYSDATE + 1) > STL_END_DATE;

  BEGIN
    -- Busco el ultimo registro pendiente 
    SELECT ARF_ID, ARF_TRY_FAILED
      INTO V_ARF_ID, V_ARF_TRY_FAILED
      FROM ACCOUNT_REGISTER_FEATURES
     WHERE ARF_STATUS = 'P'
       AND ROWNUM < 2;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      P_ERR_NUMBER  := 2000;
      P_ERR_MESSAGE := 'No se encontraron transacciones pendientes';
      V_TIENE       := 'N';
    WHEN OTHERS THEN
      P_ERR_NUMBER  := SQLCODE;
      P_ERR_MESSAGE := SQLERRM;
      V_TIENE       := 'N';
  END;
  IF V_TIENE = 'Y' THEN
    -- Indico que se está ejecutando
    UPDATE ACCOUNT_REGISTER_FEATURES -- E = EJECUTANDO    P = PENDIENTE
       SET ARF_STATUS = 'E', ARF_TRY_FAILED = ARF_TRY_FAILED + 1
     WHERE ARF_ID = V_ARF_ID;
    COMMIT;
    V_RESULT := F_REGISTER_FEATURE_ACCOUNT(V_ARF_ID,
                                           P_ERR_NUMBER,
                                           P_ERR_MESSAGE);
  
    IF V_RESULT = 0 THEN
      -- Actualizo el registro correspondiente en ACCOUNT_REGISTER_FEATURES
      UPDATE ACCOUNT_REGISTER_FEATURES
         SET ARF_STATUS = 'T'
       WHERE ARF_ID = V_ARF_ID;
      COMMIT;
    ELSE
      IF V_ARF_TRY_FAILED = V_STL_VALUE THEN
        -- Si da error y era el ultimo intento seteo como fallido
        UPDATE ACCOUNT_REGISTER_FEATURES
           SET ARF_STATUS = 'F'
         WHERE ARF_ID = V_ARF_ID;
      ELSE
        -- Si da error seteo como pendiente
        UPDATE ACCOUNT_REGISTER_FEATURES
           SET ARF_STATUS = 'P'
         WHERE ARF_ID = V_ARF_ID;
      END IF;
      COMMIT;
    END IF;
  END IF;
  P_ERR_NUMBER  := 0;
  P_ERR_MESSAGE := 'El proceso corrió correctamente.';
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    P_ERR_NUMBER  := 1000;
    P_ERR_MESSAGE := 'No se encontró la cantidad de intentos fallidos.';
  WHEN OTHERS THEN
    ROLLBACK;
    P_ERR_NUMBER  := SQLCODE;
    P_ERR_MESSAGE := SQLERRM;
END P_REGISTER_FEATURE;
/

