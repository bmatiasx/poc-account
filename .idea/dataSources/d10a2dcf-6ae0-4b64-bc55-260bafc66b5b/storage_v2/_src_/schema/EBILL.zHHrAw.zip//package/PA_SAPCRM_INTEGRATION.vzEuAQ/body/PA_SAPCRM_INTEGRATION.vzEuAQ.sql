create PACKAGE BODY PA_SAPCRM_INTEGRATION IS

PROCEDURE P_INSERT_ACCOUNT_SERVICE(PI_ACC_ID        IN VARCHAR2,
                                   PI_ARS_MOVE_TYPE IN VARCHAR2,
                                   PO_RESULT        OUT NUMBER,
                                   PO_ARS_ID        OUT NUMBER,
                                   PO_ERR_NUMBER    OUT NUMBER,
                                   PO_ERR_MESSAGE   OUT VARCHAR2)
IS
v_ars_id account_register_services.ars_id%type := 0;

BEGIN
   SELECT seq_ars_id.nextval
     INTO v_ars_id
     FROM dual;

   INSERT INTO account_register_services
      (ars_id,
       ars_start_date,
       ars_move_type,
       ars_status,
       ars_acc_id,
       ars_status_delivery,
       ars_origin)
   VALUES
       (v_ars_id,
        sysdate,
        PI_ARS_MOVE_TYPE,
        PENDING_STATUS, -- Se inserta la cabecera directamente en estado Pendiente
        PI_ACC_ID,
        FINISH_STATUS,  -- El estado de delivery al iniciar es Terminado para que no se envíe el mail
        'SAP_CRM');     -- Se define como origne SAP-CRM para poder distinguir las operaciones iniciadas en este canal

po_result := 0;
po_ars_id := v_ars_id;
po_err_number := 0;
po_err_message := '';

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    po_ars_id := v_ars_id;
    po_result := SQLCODE;
    po_err_number := SQLCODE;
    po_err_message := SQLERRM;
END P_INSERT_ACCOUNT_SERVICE;

PROCEDURE P_INSERT_ACC_SERV_DETAIL(PI_ARS_ID           IN VARCHAR2,
                                   PI_LINE_BILL_NUMBER IN VARCHAR2,
                                   PI_PACKAGE_ID       IN VARCHAR2)
IS
BEGIN
   INSERT INTO acc_reg_serv_detail
      (asd_id,
       asd_ars_id,
       asd_bill_number,
       asd_package_id,
       asd_status,
       asd_move_type)
   VALUES
      (SEQ_ASD_ID.NEXTVAL,
       PI_ARS_ID,
       PI_LINE_BILL_NUMBER,
       PI_PACKAGE_ID,
       PENDING_STATUS,
       MOVE_TYPE);

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
END P_INSERT_ACC_SERV_DETAIL;
END PA_SAPCRM_INTEGRATION;
/

