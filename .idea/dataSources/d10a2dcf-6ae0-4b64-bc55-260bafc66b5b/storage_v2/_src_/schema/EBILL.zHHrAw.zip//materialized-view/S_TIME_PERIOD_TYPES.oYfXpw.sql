create materialized view S_TIME_PERIOD_TYPES
refresh complete on demand
  as
    SELECT TPT_ID,
       TPT_DESCRIPTION
FROM   test.TIME_PERIOD_TYPES@PROD.world
/

