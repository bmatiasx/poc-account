create package PA_ROV_WSMS is

  -- Author  : NBCORAR76
  -- Created : 22/07/2016 09:03:04 a.m.
  -- Purpose : proporcionar datos de las lineas a la plataforma mobileum
  
  -- Public type declarations
 
  
  -- Public constant declarations
  package_name  constant VARCHAR2(20)  := 'PA_ROV_WSMS';
  function_name constant VARCHAR2(20)  := 'GET_DATA';
  -- Public variable declarations


  -- Public function and procedure declarations
  function GET_DATA(pin_imsi VARCHAR2) return NUMBER;

end PA_ROV_WSMS;
/

