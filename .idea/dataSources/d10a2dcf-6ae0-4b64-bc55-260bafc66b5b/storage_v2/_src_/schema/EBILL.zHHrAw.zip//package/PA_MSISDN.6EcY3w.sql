create PACKAGE PA_MSISDN
IS
   /*******************************************************************************************************************************
                                HISTORIAL DE MODIFICACIONES
    ********************************************************************************************************************************
    Ev29402  creacion de la funcion   23/08/04   Claudia Requena
    v1.3   PC62427_CD67139_ODCS       02/10/2011 Pflaum, Javier --Cambios para manejo de packs de Datos ODCS



    ********************************************************************************************************************************************/

   v_prefijo_cpp   VARCHAR2 (6);
   v_prefijo_mpp   VARCHAR2 (6);

   FUNCTION GET_BILL_NUMBER (p_msisdn VARCHAR2)
      RETURN VARCHAR2;

   FUNCTION f_get_msisdn (pin_clu_type IN VARCHAR2, pin_bill_number IN VARCHAR2)
      RETURN VARCHAR2;

   --PROCEDURE DE PRUEBA
   PROCEDURE GET_SERVICE_DATA (P_USUARIO OUT VARCHAR2, P_PASSWORD OUT VARCHAR2);
END Pa_Msisdn;
/

