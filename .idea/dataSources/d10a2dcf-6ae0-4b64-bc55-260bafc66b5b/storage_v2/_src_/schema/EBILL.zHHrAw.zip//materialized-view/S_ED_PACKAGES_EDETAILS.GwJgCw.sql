create materialized view S_ED_PACKAGES_EDETAILS
refresh complete on demand
  as
    SELECT epe_pkt_id,
epe_start_date,
epe_end_date
from stl.ed_packages_edetails@PROD

/

