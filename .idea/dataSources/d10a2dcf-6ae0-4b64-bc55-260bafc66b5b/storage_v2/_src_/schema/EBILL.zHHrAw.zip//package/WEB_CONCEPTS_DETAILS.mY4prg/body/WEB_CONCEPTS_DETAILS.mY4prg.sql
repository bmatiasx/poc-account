create PACKAGE BODY WEB_CONCEPTS_DETAILS IS
type TArray is Table of Varchar2(200) index by pls_integer;
type TArrayX2 is Table of TArray index by pls_integer;
type TArrayX3 is Table of TArrayX2 index by pls_integer;

   -- evento: 49592 Factura Electrónica en Ar
  -- autor : Gallardo Fabián
  -- Proposito: Se modificó la parametrización FC en AR por una consulta
  -- Fecha modificación:  29/05/2007

  --Devuelve el path donde se descargan los archivos definido el el directory DIR_DETAIL
  --Retorna: 0: si se creo el directorio y existe el path
  --         1: si no se encuetra el directorio
  FUNCTION GET_OUTPUT_PATH(P_OUTPUT_PATH OUT VARCHAR2,
                           P_ERROR_MSG   OUT VARCHAR2) RETURN NUMBER IS
  BEGIN

    SELECT DIRECTORY_PATH
      INTO P_OUTPUT_PATH
      FROM ALL_DIRECTORIES
     WHERE DIRECTORY_NAME = 'DIR_DETAIL';

    P_ERROR_MSG := 'OK';
    RETURN 0;

  EXCEPTION
    WHEN OTHERS THEN
      P_ERROR_MSG := 'No se encuentra DIR_DETAIL en All_Directories.';
      RETURN 1;
  END;

  --Crea un archivo xml en el Directory DIR_DETAIL con toda la informacion de financiación
  --para todos los equipos
  --Retorna: 0: si genero el archivo ok.
  --         1: se produce un error abriendo el cursor Cur_Details.
  --         2: se produce un error escribiendo el archivo.
  --         3: no hay datos para la cuenta y el ciclo. No se crea el archivo.
  FUNCTION GET_HANDSET_FINANCING_DETAILS(P_SCH_ID    IN NUMBER,
                                         P_ACC_ID    IN VARCHAR2,
                                         P_FILENAME  IN VARCHAR2,
                                         P_SEPARATOR IN VARCHAR2,
                                         P_ERROR_MSG OUT VARCHAR2)
    RETURN NUMBER IS

    CURSOR CUR_DETAILS(CP_SCH_ID IN NUMBER, CP_ACC_ID IN VARCHAR2) IS
      SELECT /*+ ordered use_nl(fed_subsidio) use_nl(doc_subsidio) */
      --substr(clu_equipo.clu_bill_number,1,clu_equipo.clu_npa_digits)||'-'|| substr(clu_equipo.clu_bill_number,clu_equipo.clu_npa_digits+1,10), --Para mostrar el código de área separado
       CLU_EQUIPO.CLU_BILL_NUMBER,
       NVL(CLU_EQUIPO.CLU_CUS_USER, ' '),
       DECODE(PRO_EQUIPO.PRO_DESCRIPTION,
              NULL,
              DECODE(SIGN(PCH_EQUIPO.PCH_AMOUNT),
                     1,
                     'Cargo de equipo',
                     'Subsidio precio de equipo'),
              PRO_EQUIPO.PRO_DESCRIPTION),
       PCH_EQUIPO.PCH_AMOUNT VALOR_EQUIPO,
       SUM(NVL(PCH_SUBSIDIO.PCH_AMOUNT, 0)) VALOR_SUBSIDIO,
       PCH_EQUIPO.PCH_AMOUNT + SUM(NVL(PCH_SUBSIDIO.PCH_AMOUNT, 0)) VALOR_NETO,
       FED_EQUIPO.FED_QUOTA,
       FED_EQUIPO.FED_TOTAL_QUOTAS TOTAL_CUOTAS,
       DOC_EQUIPO.DOC_AMOUNT + SUM(NVL(DOC_SUBSIDIO.DOC_AMOUNT, 0)) VALOR_CUOTA
        FROM DOCUMENTS                    DOC_EQUIPO,
             FINANCED_EQUIPMENT_DOCUMENTS FED_EQUIPO,
             PENDING_CHARGES              PCH_EQUIPO,
             CELLULARS /*@prod*/                    CLU_EQUIPO, --para hacerla productiva agregar @prod
             PRODUCTS                     PRO_EQUIPO,
             PENDING_CHARGES              PCH_SUBSIDIO,
             FINANCED_EQUIPMENT_DOCUMENTS FED_SUBSIDIO,
             DOCUMENTS                    DOC_SUBSIDIO
       WHERE DOC_EQUIPO.DOC_DCT_ID = 'CE'
         AND DOC_EQUIPO.DOC_ACC_ID = CP_ACC_ID
         AND DOC_EQUIPO.DOC_SCH_ID = CP_SCH_ID
         AND NVL(DOC_EQUIPO.DOC_STATUS, 'x') != 'A'
         AND FED_EQUIPO.FED_DOC_CMP_ID_CUOTA_FINANC_EQ =
             DOC_EQUIPO.DOC_CMP_ID
         AND FED_EQUIPO.FED_DOC_DCT_ID_CUOTA_FINANC_EQ =
             DOC_EQUIPO.DOC_DCT_ID
         AND FED_EQUIPO.FED_DOC_ID_CUOTA_FINANC_EQ = DOC_EQUIPO.DOC_ID
         AND FED_EQUIPO.FED_DOC_LETTER_CUOTA_FINANC_EQ =
             DOC_EQUIPO.DOC_LETTER
         AND PCH_EQUIPO.PCH_ID = FED_EQUIPO.FED_PCH_ID
         AND CLU_CELLULAR_NUMBER = PCH_EQUIPO.PCH_CLU_CELLULAR_NUMBER
         AND PCH_EQUIPO.PCH_CHA_CHR_ID = PRO_CHR_ID(+)
         AND PCH_EQUIPO.PCH_PCH_ID IS NULL
         AND PCH_SUBSIDIO.PCH_PCH_ID(+) = PCH_EQUIPO.PCH_ID
         AND PCH_SUBSIDIO.PCH_ID = FED_SUBSIDIO.FED_PCH_ID(+)
         AND FED_SUBSIDIO.FED_DOC_CMP_ID_CUOTA_FINANC_EQ =
             DOC_SUBSIDIO.DOC_CMP_ID(+)
         AND FED_SUBSIDIO.FED_DOC_DCT_ID_CUOTA_FINANC_EQ =
             DOC_SUBSIDIO.DOC_DCT_ID(+)
         AND FED_SUBSIDIO.FED_DOC_ID_CUOTA_FINANC_EQ =
             DOC_SUBSIDIO.DOC_ID(+)
         AND FED_SUBSIDIO.FED_DOC_LETTER_CUOTA_FINANC_EQ =
             DOC_SUBSIDIO.DOC_LETTER(+)
         AND NVL(DOC_SUBSIDIO.DOC_DCT_ID, DOC_EQUIPO.DOC_DCT_ID) =
             DOC_EQUIPO.DOC_DCT_ID
         AND NVL(DOC_SUBSIDIO.DOC_ACC_ID, DOC_EQUIPO.DOC_ACC_ID) =
             DOC_EQUIPO.DOC_ACC_ID
         AND NVL(DOC_SUBSIDIO.DOC_SCH_ID, DOC_EQUIPO.DOC_SCH_ID) =
             DOC_EQUIPO.DOC_SCH_ID
         AND NVL(DOC_SUBSIDIO.DOC_STATUS, 'x') != 'A'
       GROUP BY --substr(clu_equipo.clu_bill_number,1,clu_equipo.clu_npa_digits)||'-'|| substr(clu_equipo.clu_bill_number,clu_equipo.clu_npa_digits+1,10),
                 CLU_EQUIPO.CLU_BILL_NUMBER,
                CLU_EQUIPO.CLU_CUS_USER,
                PRO_EQUIPO.PRO_DESCRIPTION,
                PCH_EQUIPO.PCH_AMOUNT,
                FED_EQUIPO.FED_QUOTA,
                FED_EQUIPO.FED_TOTAL_QUOTAS,
                DOC_EQUIPO.DOC_AMOUNT;

    V_FORMAT              VARCHAR2(15) := '9999999990D00';
    V_BILL_NUMBER         VARCHAR2(12);
    V_CELL_OWNER          VARCHAR2(50); --Dueño del celular
    V_DESCRIPTION         VARCHAR2(50); --Marca y tecnología
    V_CELL_VALUE          NUMBER(14, 5); --Valor del equipo
    V_SUBSIDY_VALUE       NUMBER(14, 5); --Valor del subsidio
    V_CLEAR_VALUE         NUMBER(14, 5); --Valor neto
    V_QUOTA               NUMBER(14, 5); --Cuota actual
    V_TOTAL_QUOTAS        NUMBER(14, 5); --Cantidad de cuotas
    V_QUOTA_AMOUNT        NUMBER(14, 5); --Monto de cuota
    V_TOTAL_CELL_VALUE    NUMBER(14, 5) := 0; --Suma valor del equipo
    V_TOTAL_SUBSIDY_VALUE NUMBER(14, 5) := 0; --Suma valor del subsidio
    V_TOTAL_CLEAR_VALUE   NUMBER(14, 5) := 0; --Suma valor neto
    V_TOTAL_QUOTA_AMUNT   NUMBER(14, 5) := 0; --Suma montos de cuota

    V_OUTPUT      UTL_FILE.FILE_TYPE;
    V_ITEMS       NUMBER := 0;
    V_RETURN_CODE NUMBER;

  BEGIN

    P_ERROR_MSG   := 'abriendo cursor';
    V_RETURN_CODE := 1;
    OPEN CUR_DETAILS(P_SCH_ID, P_ACC_ID);

    BEGIN

      LOOP

        FETCH CUR_DETAILS
          INTO V_BILL_NUMBER, V_CELL_OWNER, V_DESCRIPTION, V_CELL_VALUE, V_SUBSIDY_VALUE, V_CLEAR_VALUE, V_QUOTA, V_TOTAL_QUOTAS, V_QUOTA_AMOUNT;
        EXIT WHEN CUR_DETAILS%NOTFOUND;

        V_TOTAL_CELL_VALUE    := V_TOTAL_CELL_VALUE + V_CELL_VALUE;
        V_TOTAL_SUBSIDY_VALUE := V_TOTAL_SUBSIDY_VALUE + V_SUBSIDY_VALUE;
        V_TOTAL_CLEAR_VALUE   := V_TOTAL_CLEAR_VALUE + V_CLEAR_VALUE;
        V_TOTAL_QUOTA_AMUNT   := V_TOTAL_QUOTA_AMUNT + V_QUOTA_AMOUNT;

        V_RETURN_CODE := 2;
        IF V_ITEMS = 0 THEN
          P_ERROR_MSG := 'creando archivo ' || P_FILENAME;
          V_OUTPUT    := UTL_FILE.FOPEN('DIR_DETAIL', P_FILENAME, 'w');
          UTL_FILE.PUT_LINE(V_OUTPUT,
                            '<?xml version="1.0" encoding="ISO-8859-1"?>');
          UTL_FILE.PUT_LINE(V_OUTPUT, '<CONCEPTS>');
        END IF;
        P_ERROR_MSG := 'escribiendo archivo ' || P_FILENAME;
        UTL_FILE.PUT_LINE(V_OUTPUT,
                          '   <LINE><INFO>' || V_BILL_NUMBER || P_SEPARATOR ||
                          V_CELL_OWNER || P_SEPARATOR || V_DESCRIPTION ||
                          P_SEPARATOR || TO_CHAR(V_CELL_VALUE, V_FORMAT) ||
                          P_SEPARATOR || TO_CHAR(V_SUBSIDY_VALUE, V_FORMAT) ||
                          P_SEPARATOR || TO_CHAR(V_CLEAR_VALUE, V_FORMAT) ||
                          P_SEPARATOR || V_QUOTA || P_SEPARATOR ||
                          V_TOTAL_QUOTAS || P_SEPARATOR ||
                          TO_CHAR(V_QUOTA_AMOUNT, V_FORMAT) || P_SEPARATOR ||
                          '</INFO></LINE>');

        V_ITEMS := V_ITEMS + 1;
      END LOOP;

      IF V_ITEMS = 0 THEN
        P_ERROR_MSG   := 'No se encontraron datos para Sch_Id = ' ||
                         P_SCH_ID || '  y  Acc_Id = ' || P_ACC_ID;
        V_RETURN_CODE := 3; --No hay datos y no se creó el archivo
      ELSE
        P_ERROR_MSG   := 'Ok';
        V_RETURN_CODE := 0; --Se creó el archivo

        UTL_FILE.PUT_LINE(V_OUTPUT,
                          '   <LINE><INFO>Total' || P_SEPARATOR ||
                          P_SEPARATOR || P_SEPARATOR ||
                          TO_CHAR(V_TOTAL_CELL_VALUE, V_FORMAT) ||
                          P_SEPARATOR ||
                          TO_CHAR(V_TOTAL_SUBSIDY_VALUE, V_FORMAT) ||
                          P_SEPARATOR ||
                          TO_CHAR(V_TOTAL_CLEAR_VALUE, V_FORMAT) ||
                          P_SEPARATOR || P_SEPARATOR || P_SEPARATOR ||
                          TO_CHAR(V_TOTAL_QUOTA_AMUNT, V_FORMAT) ||
                          P_SEPARATOR || '</INFO>');
        UTL_FILE.PUT_LINE(V_OUTPUT, '   </LINE>');

        UTL_FILE.PUT_LINE(V_OUTPUT,
                          '   <HEADER index="0" description="Celular"> </HEADER>');
        UTL_FILE.PUT_LINE(V_OUTPUT,
                          '   <HEADER index="1" description="Usuario"> </HEADER>');
        UTL_FILE.PUT_LINE(V_OUTPUT,
                          '   <HEADER index="2" description="Equipo"> </HEADER>');
        UTL_FILE.PUT_LINE(V_OUTPUT,
                          '   <HEADER index="5" description="Costo del Equipo ($)">');
        UTL_FILE.PUT_LINE(V_OUTPUT,
                          '      <HEADER index="3" description="Valor del Equipo ($)"> </HEADER>');
        UTL_FILE.PUT_LINE(V_OUTPUT,
                          '      <HEADER index="4" description="Valor del Subsidio ($)"> </HEADER>');
        UTL_FILE.PUT_LINE(V_OUTPUT,
                          '      <HEADER index="5" description="Valor Neto ($)"> </HEADER>');
        UTL_FILE.PUT_LINE(V_OUTPUT, '   </HEADER>');
        UTL_FILE.PUT_LINE(V_OUTPUT,
                          '   <HEADER index="6" description="Número de Cuota"> </HEADER>');
        UTL_FILE.PUT_LINE(V_OUTPUT,
                          '   <HEADER index="7" description="Cantidad de Cuotas"> </HEADER>');
        UTL_FILE.PUT_LINE(V_OUTPUT,
                          '   <HEADER index="8" description="Valor de la Cuota ($)"> </HEADER>');

        UTL_FILE.PUT_LINE(V_OUTPUT, '</CONCEPTS>');
        UTL_FILE.FCLOSE(V_OUTPUT);
      END IF;

    EXCEPTION
      WHEN OTHERS THEN
        P_ERROR_MSG := 'Error ' || P_ERROR_MSG || ' ' || P_SEPARATOR ||
                       SQLCODE || ' ' || P_SEPARATOR || SQLERRM;
        CLOSE CUR_DETAILS;
        RETURN V_RETURN_CODE; --Error al escribir archivo
    END;

    CLOSE CUR_DETAILS;

    RETURN V_RETURN_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      P_ERROR_MSG := 'Error ' || P_ERROR_MSG || ' ' || P_SEPARATOR ||
                     SQLCODE || ' ' || P_SEPARATOR || SQLERRM;
      RETURN V_RETURN_CODE; --Error al abrir cursor
  END;

  --Devuelve la lista de periodos disponibles y la lista de documents id´s
  --Retorna: 0: si no hay errores
  --         1: si no encuentra datos
  --         2: por cualquier otro error
  FUNCTION GET_AVAILABLE_PERIODS(P_ACCOUNT        IN VARCHAR2,
                                 P_SEPARATOR      IN VARCHAR2,
                                 P_PERIODS_LIST   OUT VARCHAR2,
                                 P_DOCUMENTS_LIST OUT VARCHAR2,
                                 P_SHEDULERS_LIST OUT VARCHAR2,
                                 P_ERROR_TEXT     OUT VARCHAR2) RETURN NUMBER IS
    ADD_DATE    DATE;
    IDATE       DATE;
    EDATE       DATE;
    PERIODS     NUMBER := 3;
    LAST_PERIOD NUMBER := 0;
    SDATE       DATE := SYSDATE;
    CYCLE       VARCHAR2(2);
    V_CYC_ID    VARCHAR2(6);
    V_SCH_ID    NUMBER(8);
    V_DOC_ID    VARCHAR(15);
    v_ACC_LAST_BILLED_DATE date;    

  BEGIN

    P_ERROR_TEXT := 'obteniendo informacion de la Cuenta';
/*    SELECT ACC_ADD_DATE, ACC_CYC_ID
      INTO ADD_DATE, V_CYC_ID
      FROM ACCOUNTS
     WHERE ACC_ID = P_ACCOUNT;
*/

    P_Error_Text := 'obteniento informacion de la Cuenta';
    SELECT Acc_Add_Date, nvl(ACC_LAST_BILLED_DATE,sysdate)
    INTO add_date, v_ACC_LAST_BILLED_DATE
    FROM Accounts
    WHERE Acc_Id = P_Account;

   --se busca el ciclo correspondiente a la zltima fecha de facturacisn

    select cs.cst_cyc_id
    into v_cyc_id
    from cycle_status cs
    where cs.cst_acc_id=p_account
    and v_ACC_LAST_BILLED_DATE BETWEEN cs.cst_start_date AND nvl(cs.cst_end_date,sysdate+1);
     

    CYCLE := SUBSTR(V_CYC_ID, LENGTH(V_CYC_ID) - 1, 2);

    --Si se supero en el mes el cierre del ciclo, incluir este mes
    IF to_number(TO_CHAR(SDATE, 'dd')) > to_number(CYCLE) THEN
      PERIODS     := PERIODS - 1;
      LAST_PERIOD := LAST_PERIOD - 1;
    END IF;

    LOOP
      IDATE := ADD_MONTHS(SDATE, -PERIODS - 1);
      IDATE := TO_DATE(CYCLE || '-' || TO_CHAR(IDATE, 'mm-yyyy'),
                       'dd-mm-yyyy') + 1;

      EDATE := ADD_MONTHS(SDATE, -PERIODS);
      EDATE := TO_DATE(CYCLE || '-' || TO_CHAR(EDATE, 'mm-yyyy'),
                       'dd-mm-yyyy');

      IF ADD_DATE <= EDATE THEN
        P_ERROR_TEXT := 'obteniento Scheduler Id para Cycle=' || V_CYC_ID ||
                        ' y end_date=' || EDATE;
        SELECT SCH_ID
          INTO V_SCH_ID
          FROM SCHEDULERS
         WHERE SCH_CYC_ID = V_CYC_ID
           AND SCH_END_DATE = EDATE;
        
        BEGIN
        
        P_ERROR_TEXT := 'obteniento Document Id para Acc=' || P_ACCOUNT ||
                        ' y Sch=' || V_SCH_ID;
        SELECT DOC_ID
          INTO V_DOC_ID
          FROM DOCUMENTS
         WHERE DOC_ACC_ID = P_ACCOUNT
           AND DOC_DCT_ID IN
               (SELECT DCT_ID FROM DOCUMENT_TYPES WHERE DCT_DCT_ID = 'FC') --FC y FCE
           AND DOC_SCH_ID = V_SCH_ID;

        P_PERIODS_LIST   := P_PERIODS_LIST || TO_CHAR(IDATE, 'dd-mm-yyyy') ||
                            ' - ' || TO_CHAR(EDATE, 'dd-mm-yyyy') ||
                            P_SEPARATOR;
        P_DOCUMENTS_LIST := P_DOCUMENTS_LIST || V_DOC_ID || P_SEPARATOR;
        P_SHEDULERS_LIST := P_SHEDULERS_LIST || V_SCH_ID || P_SEPARATOR;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN NULL;        
        END;        
        
      END IF;

      PERIODS := PERIODS - 1;
      EXIT WHEN PERIODS = LAST_PERIOD;

    END LOOP;

    P_ERROR_TEXT := 'Ok';
    RETURN 0;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      P_ERROR_TEXT := 'Error ' || P_ERROR_TEXT;
      RETURN 1; 
    WHEN OTHERS THEN
      P_ERROR_TEXT := SQLERRM || '  sqlcode=' || SQLCODE;
      RETURN 2;
  END;

  PROCEDURE GET_COLUMN_INDEX(P_ISH_ID          IN NUMBER,
                             P_INDEX_AMOUNT    OUT PLS_INTEGER,
                             P_INDEX_QUANTITY  OUT PLS_INTEGER,
                             P_COL_DESCRIPTION OUT VARCHAR2) IS
    V_INI PLS_INTEGER := 3;
  BEGIN
    P_INDEX_AMOUNT   := -1;
    P_INDEX_QUANTITY := -1;

    CASE P_ISH_ID
      WHEN 1 THEN
        P_INDEX_AMOUNT    := V_INI + 1; --Abono
        P_COL_DESCRIPTION := 'Abono';
      WHEN 2 THEN
        P_INDEX_AMOUNT    := V_INI + 2; --Garantía
        P_COL_DESCRIPTION := 'Garantía';
      WHEN 3 THEN
        P_INDEX_AMOUNT    := V_INI + 3; --Servicios
        P_COL_DESCRIPTION := 'Servicios';
      WHEN 4 THEN
        P_INDEX_AMOUNT    := V_INI + 4; --Cargos y Reintegros
        P_COL_DESCRIPTION := 'Cargos y Reintegros';
      WHEN 5 THEN
        P_INDEX_QUANTITY  := V_INI + 5; --Minutos de Aire Incluido
        P_COL_DESCRIPTION := 'Minutos Aire';
      WHEN 6 THEN
        P_INDEX_AMOUNT    := V_INI + 6; --Aire Excedente
        P_INDEX_QUANTITY  := V_INI + 7;
        P_COL_DESCRIPTION := 'Aire Exced';
      WHEN 7 THEN
        P_INDEX_AMOUNT    := V_INI + 8; --Red fija Local, LDN...
        P_INDEX_QUANTITY  := V_INI + 9;
        P_COL_DESCRIPTION := 'Red Fija';
      WHEN 8 THEN
        P_INDEX_AMOUNT    := V_INI + 10; --DDI-Roam Internacional
        P_INDEX_QUANTITY  := V_INI + 11;
        P_COL_DESCRIPTION := 'DDI';
      WHEN 9 THEN
        P_INDEX_AMOUNT    := V_INI + 12; --Bonif. de Minutos
        P_COL_DESCRIPTION := 'Bonif. Minutos';
      WHEN 10 THEN
        P_INDEX_AMOUNT    := V_INI + 13; --Equipos
        P_COL_DESCRIPTION := 'Equipos';
      WHEN 11 THEN
        P_INDEX_AMOUNT    := V_INI + 14; --Varios
        P_COL_DESCRIPTION := 'Varios';
      WHEN 12 THEN
        P_INDEX_AMOUNT    := V_INI + 15; --Kb Inc.+Exc. en Datos
        P_INDEX_QUANTITY  := V_INI + 16;
        P_COL_DESCRIPTION := 'GPRS';
      WHEN 13 THEN
        P_INDEX_AMOUNT    := V_INI + 17; --Unidades en Datos
        P_INDEX_QUANTITY  := V_INI + 18;
        P_COL_DESCRIPTION := 'Mensajes';
      WHEN 501 THEN
        P_INDEX_AMOUNT    := V_INI + 19; --Total LD Nacional
        P_INDEX_QUANTITY  := V_INI + 20;
        P_COL_DESCRIPTION := 'LD Nac';
      WHEN 502 THEN
        P_INDEX_AMOUNT    := V_INI + 21; --Total LD Internacional
        P_INDEX_QUANTITY  := V_INI + 22;
        P_COL_DESCRIPTION := 'LD Internac';
      WHEN 503 THEN
        P_INDEX_AMOUNT    := V_INI + 23; --Otros cargos y creditos
        P_COL_DESCRIPTION := 'Otros cargos y créditos';
      WHEN -1 THEN
        P_INDEX_AMOUNT    := V_INI + 1;
        P_INDEX_QUANTITY  := V_INI + 23;
        P_COL_DESCRIPTION := '';
    END CASE;

  END;

  --Reemplaza caracteres especiales de XML para evitar errores.
  FUNCTION REPLACESPECIALCHARS(CADENA IN VARCHAR2) RETURN VARCHAR2 IS
    CADENAAUX VARCHAR2(200);
  BEGIN

    CADENAAUX := REPLACE(CADENA, '&', '&' || 'amp;');
    CADENAAUX := REPLACE(CADENAAUX, '<', '&' || 'lt;');
    CADENAAUX := REPLACE(CADENAAUX, '>', '&' || 'gt;');
    CADENAAUX := REPLACE(CADENAAUX, '"', '&' || 'quot;');
    CADENAAUX := REPLACE(CADENAAUX, '''', '&' || 'apos;');

    RETURN CADENAAUX;
  END;

  --Crea un archivo xml en el Directory DIR_DETAIL con toda la informacion de los conceptos
  --para todas las líneas de una cuenta. Por cada línea detalla también los conceptos agrupados
  --en Servicios y Varios
  --Retorna: 0: Si se crea el archivo ok
  --         1: error utilizando el cursor Cur_Lines. No se crea el archivo
  --         2: error utilizando el cursor Cur_Details. No se crea el archivo
  --         3: error buscando detalles para Servicios. No se crea el archivo
  --         4: error buscando detalles para Varios. No se crea el archivo
  --         5: error consolidando datos. No se crea el archivo
  --         6: error guardando datos. Verificar si se creo el archivo
  --         7: no hay datos para la cuenta. No se crea el archivo

  FUNCTION GET_CONCEPTS_DETAILS(P_ACC_ID    IN VARCHAR2,
                                P_DOC_ID    IN VARCHAR2,
                                P_SCH_ID    IN VARCHAR2,
                                P_FILENAME  IN VARCHAR2,
                                P_SEPARATOR IN VARCHAR2,
                                P_ERROR_MSG OUT VARCHAR2) RETURN NUMBER IS

    CURSOR CUR_CONCEPTS(CP_ACC_ID IN VARCHAR2, CP_DOC_ID IN VARCHAR2, PSCH_START_DATE IN DATE, PSCH_END_DATE IN DATE) IS
      SELECT
      /*+ ordered use_nl(clu cpk) */
       CLU_CELLULAR_NUMBER,
       CLU_BILL_NUMBER,
       CLU_CUS_USER, /*+ INDEX(cellular_plans,CPL_PK) */
       CPL_RPL_ID,
       IDS.ISH_ID,
       IC.INC_TPT_ID TPT_ID,
       SUM(DOD.DOD_AMOUNT),
       SUM(DOD.DOD_QUANTITY)
        FROM DOCUMENT_DETAILS        DOD,
             CELLULARS               CEL,
             CELLULAR_PACKAGES       CPK,
             ED_PACKAGES_EDETAILS    ED,
             CELLULAR_PLANS          CP,
             INVOICE_CONCEPT_FORMATS ICF,
             ITEM_DETAIL_SHOWS       IDS,
             INVOICE_CONCEPTS        IC
       WHERE CEL.CLU_CELLULAR_NUMBER = CPK.CPK_CLU_CELLULAR_NUMBER
         AND CPK.CPK_PKT_ID = ED.EPE_PKT_ID
         AND CP.CPL_CLU_CELLULAR_NUMBER = CEL.CLU_CELLULAR_NUMBER
         AND DOD.DOD_CLU_CELLULAR_NUMBER = CEL.CLU_CELLULAR_NUMBER
         AND DOD.DOD_INC_ID = ICF.INF_INC_ID
         AND IDS.ISH_ID = ICF.INF_ISH_ID
         AND IC.INC_ID = ICF.INF_INC_ID
         AND CLU_ACC_ID = CP_ACC_ID
         AND (CLU_STATUS = 'A' OR CEL.CLU_CANCELED_DATE BETWEEN
             PSCH_START_DATE AND PSCH_END_DATE)
         AND SYSDATE BETWEEN CPK_ACTIVATION_DATE AND
             NVL(CPK_CANCELED_DATE, SYSDATE + 1)
         AND SYSDATE BETWEEN EPE_START_DATE AND
             NVL(EPE_END_DATE, SYSDATE + 1)
         AND CPL_STG_ID = 'AH'
         AND SYSDATE BETWEEN CPL_START_DATE AND CPL_END_DATE
         AND DOD.DOD_DOC_ID = CP_DOC_ID
         AND ICF.INF_INVOICE_TYPE='C'
         AND DOD.DOD_DOC_DCT_ID IN
             (SELECT DCT_ID FROM DOCUMENT_TYPES WHERE DCT_DCT_ID = 'FC') --FC y FCE
       GROUP BY CLU_CELLULAR_NUMBER,
                CLU_BILL_NUMBER,
                CPL_RPL_ID,
                ISH_ID,
                CLU_CUS_USER,
                IC.INC_TPT_ID
       ORDER BY CLU_BILL_NUMBER, ISH_ID;

    CURSOR CUR_CONCEPT_DETAILS(CP_ACC_ID IN VARCHAR2, CP_DOC_ID IN VARCHAR2, PSCH_START_DATE IN DATE, PSCH_END_DATE IN DATE) IS
      SELECT /*+ ordered use_nl(clu cpk)*/
       CLU_CELLULAR_NUMBER,
       CLU_BILL_NUMBER,
       INF_ISH_ID,
       INF_DESCRIPTION,
       SUM(DOD_AMOUNT),
       SUM(DOD_QUANTITY)
        FROM DOCUMENT_DETAILS,
             CELLULARS,
             INVOICE_CONCEPT_FORMATS,
             CELLULAR_PACKAGES,
             ED_PACKAGES_EDETAILS
       WHERE DOD_INC_ID = INF_INC_ID
         AND CLU_CELLULAR_NUMBER = DOD_CLU_CELLULAR_NUMBER
         AND CLU_CELLULAR_NUMBER = CPK_CLU_CELLULAR_NUMBER
         AND CPK_PKT_ID = EPE_PKT_ID
         AND SYSDATE BETWEEN CPK_ACTIVATION_DATE AND
             NVL(CPK_CANCELED_DATE, SYSDATE + 1)
         AND SYSDATE BETWEEN EPE_START_DATE AND
             NVL(EPE_END_DATE, SYSDATE + 1)
         AND CLU_ACC_ID = CP_ACC_ID
         AND (CLU_STATUS = 'A' OR
             CLU_CANCELED_DATE BETWEEN PSCH_START_DATE AND PSCH_END_DATE)
         AND DOCUMENT_DETAILS.DOD_DOC_ID = CP_DOC_ID
         AND INF_INVOICE_TYPE='C'
         AND INF_ISH_ID IN (3, 11, 6, 12, 13)
       GROUP BY INF_DESCRIPTION,
                CLU_CELLULAR_NUMBER,
                CLU_BILL_NUMBER,
                INF_ISH_ID,
                INF_DESCRIPTION
       ORDER BY CLU_BILL_NUMBER, INF_ISH_ID;

    CURSOR CUR_ITEMS_SHOW IS
      SELECT ISH_ID,
             SUBSTR(ISH_DESCRIPTION,
                    INSTR(ISH_DESCRIPTION, '"', 1, 1) + 1,
                    INSTR(ISH_DESCRIPTION, '"', 1, 2) -
                    INSTR(ISH_DESCRIPTION, '"', 1, 1) - 1)
        FROM ITEM_DETAIL_SHOWS;

    V_OUTPUT      UTL_FILE.FILE_TYPE;
    V_ITEMS       NUMBER := 0;
    V_RETURN_CODE NUMBER;

    V_CELLULAR_NUMBER  VARCHAR2(10);
    V_BILL_NUMBER      VARCHAR2(10);
    V_USER_NAME        VARCHAR2(70);
    V_PLAN             VARCHAR2(6);
    V_INF_DESCRIPTION  VARCHAR2(60);
    V_BAND             VARCHAR2(4);
    V_SEC_ID           VARCHAR2(6);
    V_ISH_ID           NUMBER(3);
    V_QUANTITY         NUMBER(14, 2);
    V_CONCEPT_QUANTITY NUMBER(14, 2);
    V_AMOUNT           NUMBER(14, 2);
    V_COLUMN_TOTAL     NUMBER(14, 2);

    V_TOTAL_SERVICES   NUMBER(14, 2);
    V_TOTAL_VARIOUS    NUMBER(14, 2);
    V_TOTAL_EXCEDENTES NUMBER(14, 2);
    V_TOTAL_SMS        NUMBER(14, 2);
    V_TOTAL_QTTY       NUMBER(14, 2);
    V_TOTAL_DATOS      NUMBER(14, 2);

    V_DESCRIPTION VARCHAR2(50);
    V_TEMP        VARCHAR2(200);

    V_ARR            TARRAYX2; -- lineas x conceptos
    V_ARR_SERVICES   TARRAYX3; -- lineas x conceptos x items
    V_ARR_VARIOUS    TARRAYX3; -- lineas x conceptos x items
    V_ARR_EXCEDENTES TARRAYX3; -- lineas x conceptos x items
    V_ARR_SMS_AMOUNT TARRAYX3; -- lineas x conceptos x items
    V_ARR_SMS_QTTY   TARRAYX3; -- lineas x conceptos x items
    V_ARR_DATOS      TARRAYX3; -- lineas x conceptos x items
    V_ARR_HEADERS    TARRAYX2; -- headers x columnas
    V_ARR_TOTALS     TARRAY; -- renglon de totales

    V_MENSUALES NUMBER;
    V_CONSUMOS  NUMBER;
    V_DATOS     NUMBER;
    V_OTROS     NUMBER;
    V_DIGITS    NUMBER;

    V_LINE_INDEX     PLS_INTEGER := 0;
    V_ITEM_INDEX     PLS_INTEGER := 0;
    V_INDEX_AMOUNT   PLS_INTEGER;
    V_INDEX_QUANTITY PLS_INTEGER;
    V_INDEX_MIN      PLS_INTEGER;
    V_INDEX_MAX      PLS_INTEGER;

    V_FORMAT     VARCHAR2(15) := '9999999900D00';
    V_FORMAT_MIN VARCHAR2(15) := '9999999990';

    OLD_ISH_ID        NUMBER(3);
    N_ISH_ID          NUMBER(3);
    N_INF_DESCRIPTION VARCHAR2(60);
    N_DOD_AMOUNT      NUMBER(14, 4);
    N_DOD_QUANTITY    NUMBER(14, 4);

    V_BILL_NUMBER_OLD VARCHAR2(10);

    SCH_START_DATE DATE;
    SCH_END_DATE   DATE;

  BEGIN

    P_ERROR_MSG       := 'abriendo cursor Cur_Lines';
    V_RETURN_CODE     := 1;
    V_BILL_NUMBER_OLD := '-1';

    V_TOTAL_SERVICES   := 0;
    V_TOTAL_VARIOUS    := 0;
    V_TOTAL_EXCEDENTES := 0;
    V_TOTAL_SMS        := 0;
    V_TOTAL_QTTY       := 0;
    V_TOTAL_DATOS      := 0;

/*    SELECT SCH.SCH_START_DATE, SCH.SCH_END_DATE
      INTO SCH_START_DATE, SCH_END_DATE
      FROM DOCUMENTS DOCS, SCHEDULERS SCH
     WHERE DOCS.DOC_ID = P_DOC_ID
       AND SCH.SCH_ID = P_SCH_ID
       AND DOCS.DOC_SCH_ID = SCH.SCH_ID;
*/

    SELECT SCH.SCH_START_DATE, SCH.SCH_END_DATE
      INTO SCH_START_DATE, SCH_END_DATE
      FROM SCHEDULERS SCH
     WHERE SCH.SCH_ID = P_SCH_ID;


    OPEN CUR_CONCEPTS(P_ACC_ID, P_DOC_ID, SCH_START_DATE, SCH_END_DATE);
    LOOP

      FETCH CUR_CONCEPTS
        INTO V_CELLULAR_NUMBER, V_BILL_NUMBER, V_USER_NAME, V_PLAN, V_ISH_ID, V_BAND, V_AMOUNT, V_QUANTITY;
      EXIT WHEN CUR_CONCEPTS%NOTFOUND;

      IF V_BILL_NUMBER_OLD <> V_BILL_NUMBER THEN
        V_LINE_INDEX := V_LINE_INDEX + 1;
        V_ARR(V_LINE_INDEX)(1) := V_BILL_NUMBER;
        V_ARR(V_LINE_INDEX)(2) := V_USER_NAME;
        V_ARR(V_LINE_INDEX)(3) := V_PLAN;
        GET_COLUMN_INDEX(-1, V_INDEX_MIN, V_INDEX_MAX, V_DESCRIPTION);
        FOR I IN V_INDEX_MIN .. V_INDEX_MAX + 9 LOOP
          V_ARR(V_LINE_INDEX)(I) := '0';
        END LOOP;
      END IF;
      V_BILL_NUMBER_OLD := V_BILL_NUMBER;

      GET_COLUMN_INDEX(V_ISH_ID,
                       V_INDEX_AMOUNT,
                       V_INDEX_QUANTITY,
                       V_DESCRIPTION);

      IF V_INDEX_AMOUNT <> -1 THEN
        IF V_ISH_ID = 12 /*and ( v_sec_id = 'S6.4' or v_sec_id = 'S6.24')*/
         THEN
          --12 es DATOS a fraccionar

          CASE V_BAND
            WHEN 'X' THEN
              V_BAND := '128';
            WHEN 'Y' THEN
              V_BAND := '256';
            WHEN 'Z' THEN
              V_BAND := '512';
            WHEN 'U' THEN
              V_BAND := '1024';
            ELSE
              V_BAND := '';
          END CASE;
          V_ARR(V_LINE_INDEX)(V_INDEX_MAX + 8) := V_BAND;
        END IF;

        v_arr(v_line_index)(v_index_amount) := v_arr(v_line_index)(v_index_amount) + v_amount;

      END IF;
      IF V_INDEX_QUANTITY <> -1 THEN
        IF V_ISH_ID = 12 /*and ( v_sec_id = 'S6.4' or v_sec_id = 'S6.24')*/
         THEN
          --12 es DATOS a fraccionar
          V_ARR(V_LINE_INDEX)(V_INDEX_MAX + 8) := V_BAND;
        END IF;

        v_arr(v_line_index)(v_index_quantity) := v_arr(v_line_index)(v_index_quantity) + v_quantity;

      END IF;
    END LOOP;
    CLOSE CUR_CONCEPTS;

    V_ITEM_INDEX      := 0;
    OLD_ISH_ID        := 3;
    V_BILL_NUMBER_OLD := '-1';
    V_LINE_INDEX      := 0;

    OPEN CUR_CONCEPT_DETAILS(P_ACC_ID,
                             P_DOC_ID,
                             SCH_START_DATE,
                             SCH_END_DATE);
    LOOP
      FETCH CUR_CONCEPT_DETAILS
        INTO V_CELLULAR_NUMBER, V_BILL_NUMBER, N_ISH_ID, N_INF_DESCRIPTION, N_DOD_AMOUNT, N_DOD_QUANTITY;
      EXIT WHEN CUR_CONCEPT_DETAILS%NOTFOUND;

      IF V_BILL_NUMBER_OLD <> V_BILL_NUMBER THEN
        V_LINE_INDEX := V_LINE_INDEX + 1;
        V_ARR_SERVICES(V_LINE_INDEX)(1)(1) := NULL;
        V_ARR_VARIOUS(V_LINE_INDEX)(1)(1) := NULL;
        V_ARR_EXCEDENTES(V_LINE_INDEX)(1)(1) := NULL;
        V_ARR_DATOS(V_LINE_INDEX)(1)(1) := NULL;
        V_ARR_SMS_AMOUNT(V_LINE_INDEX)(1)(1) := NULL;
        V_ARR_SMS_QTTY(V_LINE_INDEX)(1)(1) := NULL;
        OLD_ISH_ID := -1;
      END IF;
      IF N_ISH_ID <> OLD_ISH_ID THEN
        V_ITEM_INDEX := 0;
      END IF;

      V_BILL_NUMBER_OLD := V_BILL_NUMBER;
      V_ITEM_INDEX      := V_ITEM_INDEX + 1;
      N_INF_DESCRIPTION := REPLACESPECIALCHARS(N_INF_DESCRIPTION);
      CASE N_ISH_ID
        WHEN 3 THEN
          --services
          V_ARR_SERVICES(V_LINE_INDEX)(V_ITEM_INDEX)(1) := N_INF_DESCRIPTION;
          V_ARR_SERVICES(V_LINE_INDEX)(V_ITEM_INDEX)(2) := N_DOD_AMOUNT;
          V_TOTAL_SERVICES := V_TOTAL_SERVICES + N_DOD_AMOUNT;
        WHEN 6 THEN
          --excedentes
          V_ARR_EXCEDENTES(V_LINE_INDEX)(V_ITEM_INDEX)(1) := N_INF_DESCRIPTION;
          V_ARR_EXCEDENTES(V_LINE_INDEX)(V_ITEM_INDEX)(2) := N_DOD_AMOUNT;
          V_TOTAL_EXCEDENTES := V_TOTAL_EXCEDENTES + N_DOD_AMOUNT;
        WHEN 11 THEN
          --various
          V_ARR_VARIOUS(V_LINE_INDEX)(V_ITEM_INDEX)(1) := N_INF_DESCRIPTION;
          V_ARR_VARIOUS(V_LINE_INDEX)(V_ITEM_INDEX)(2) := N_DOD_AMOUNT;
          V_TOTAL_VARIOUS := V_TOTAL_VARIOUS + N_DOD_AMOUNT;
        WHEN 12 THEN
          --datos
          V_ARR_DATOS(V_LINE_INDEX)(V_ITEM_INDEX)(1) := N_INF_DESCRIPTION;
          V_ARR_DATOS(V_LINE_INDEX)(V_ITEM_INDEX)(2) := N_DOD_QUANTITY;
          V_TOTAL_DATOS := V_TOTAL_DATOS + N_DOD_QUANTITY;
        WHEN 13 THEN
          --mensajes
          V_ARR_SMS_AMOUNT(V_LINE_INDEX)(V_ITEM_INDEX)(1) := N_INF_DESCRIPTION;
          V_ARR_SMS_AMOUNT(V_LINE_INDEX)(V_ITEM_INDEX)(2) := N_DOD_AMOUNT;
          V_TOTAL_SMS := V_TOTAL_SMS + N_DOD_AMOUNT;
          V_ARR_SMS_QTTY(V_LINE_INDEX)(V_ITEM_INDEX)(1) := N_INF_DESCRIPTION;
          V_ARR_SMS_QTTY(V_LINE_INDEX)(V_ITEM_INDEX)(2) := N_DOD_QUANTITY;
          V_TOTAL_QTTY := V_TOTAL_QTTY + N_DOD_QUANTITY;
      END CASE;
      OLD_ISH_ID := N_ISH_ID;
    END LOOP;
    CLOSE CUR_CONCEPT_DETAILS;

    IF V_LINE_INDEX = 0 THEN
      P_ERROR_MSG   := 'No hay datos para la cuenta ' || P_ACC_ID ||
                       '. No se creo el archivo';
      V_RETURN_CODE := 7;
    END IF;

    P_ERROR_MSG   := 'consolidando datos';
    V_RETURN_CODE := 5;

    --Abonos y servicios mensuales = 4 + 5 + 6(Servicios) + 7
    --Cargos por consumos = 9 + 11 + 13 + 22 + 24
    --Otros = 15 + 16 + 17(Varios) + 26
    --Datos = 18 + 20

    -- Con -1 obtiene el rango de conceptos a sumar
    GET_COLUMN_INDEX(-1, V_INDEX_MIN, V_INDEX_MAX, V_DESCRIPTION);

    --Suma de subtotales por renglones
    FOR I IN 1 .. V_ARR.COUNT LOOP

      V_MENSUALES := 0;
      V_CONSUMOS  := 0;
      V_DATOS     := 0;
      V_OTROS     := 0;
      FOR J IN V_INDEX_MIN .. V_INDEX_MAX --Columnas de los conceptos
       LOOP

        IF J IN (4, 5, 6, 7) THEN
          V_MENSUALES := V_MENSUALES + TO_NUMBER(V_ARR(I) (J));
          V_ARR(I)(J) := TO_CHAR(TO_NUMBER(V_ARR(I) (J)), V_FORMAT);
        END IF;
        IF J IN (9, 11, 13, 22, 24, 18, 20) THEN
          V_CONSUMOS := V_CONSUMOS + TO_NUMBER(V_ARR(I) (J));
          V_ARR(I)(J) := TO_CHAR(TO_NUMBER(V_ARR(I) (J)), V_FORMAT);
        END IF;
        IF J IN (15, 16, 17, 26) THEN
          V_OTROS := V_OTROS + TO_NUMBER(V_ARR(I) (J));
          V_ARR(I)(J) := TO_CHAR(TO_NUMBER(V_ARR(I) (J)), V_FORMAT);
        END IF;
        IF J IN (18, 20) THEN
          V_DATOS := V_DATOS + TO_NUMBER(V_ARR(I) (J));
          V_ARR(I)(J) := TO_CHAR(TO_NUMBER(V_ARR(I) (J)), V_FORMAT);
        END IF;

        IF J IN (8, 10, 14, 19, 21, 23, 25) THEN
          --            v_datos := v_datos + to_number( v_arr(i)(j) );
          IF FLOOR(TO_NUMBER(V_ARR(I) (J))) - TO_NUMBER(V_ARR(I) (J)) <= 0.5 THEN
            V_ARR(I)(J) := FLOOR(TO_NUMBER(V_ARR(I) (J)));
          ELSE
            V_ARR(I)(J) := CEIL(TO_NUMBER(V_ARR(I) (J)));
          END IF;
          V_ARR(I)(J) := TO_CHAR(TO_NUMBER(V_ARR(I) (J)), V_FORMAT_MIN);
        END IF;
      END LOOP;
      V_ARR(I)(V_INDEX_MAX + 1) := TO_CHAR(V_MENSUALES, V_FORMAT);
      V_ARR(I)(V_INDEX_MAX + 2) := TO_CHAR(V_CONSUMOS, V_FORMAT);
      V_ARR(I)(V_INDEX_MAX + 3) := TO_CHAR(V_DATOS, V_FORMAT);
      V_ARR(I)(V_INDEX_MAX + 4) := TO_CHAR(V_OTROS, V_FORMAT);
      V_ARR(I)(V_INDEX_MAX + 5) := TO_CHAR(V_MENSUALES + V_CONSUMOS + /*v_datos +*/
                                           V_OTROS,
                                           V_FORMAT);
      V_ARR(I)(V_INDEX_MAX + 6) := 'services';
      V_ARR(I)(V_INDEX_MAX + 7) := 'various';
      IF V_ARR(I) (V_INDEX_MAX + 8) = '0' THEN
        --34
        V_ARR(I)(V_INDEX_MAX + 8) := '-'; --v_index_max + 8 es la columna q tiene las bandas
      END IF;
      V_ARR(I)(V_INDEX_MAX + 9) := 'excedentes';
      V_ARR(I)(V_INDEX_MAX + 10) := 'smsAmount';
      V_ARR(I)(V_INDEX_MAX + 11) := 'datos';
      V_ARR(I)(V_INDEX_MAX + 12) := 'smsQtty';
    END LOOP;

    --Suma de totales por columnas
    V_ARR_TOTALS(1) := 'Total';
    V_ARR_TOTALS(2) := ' - ';
    V_ARR_TOTALS(3) := ' - ';
    V_ARR_TOTALS(V_ARR(1).COUNT - 6) := 'services';
    V_ARR_TOTALS(V_ARR(1).COUNT - 5) := 'various';
    V_ARR_TOTALS(V_ARR(1).COUNT - 3) := 'excedentes';
    V_ARR_TOTALS(V_ARR(1).COUNT - 4) := '-';
    V_ARR_TOTALS(V_ARR(1).COUNT - 1) := 'datos';
    V_ARR_TOTALS(V_ARR(1).COUNT - 2) := 'smsAmount';
    V_ARR_TOTALS(V_ARR(1).COUNT) := 'smsQtty';

    FOR I IN V_INDEX_MIN .. V_ARR(1).COUNT - 7 LOOP
      V_ARR_TOTALS(I) := '0';
      V_COLUMN_TOTAL := 0;

      FOR J IN 1 .. V_ARR.COUNT LOOP
        V_COLUMN_TOTAL := V_COLUMN_TOTAL + TO_NUMBER(V_ARR(J) (I));
      END LOOP;
      V_ARR_TOTALS(I) := TO_CHAR(V_COLUMN_TOTAL, V_FORMAT);
    END LOOP;

    --Al guardar los datos los indices deben comenzar desde cero y no desde 1 como en pl\slq
    P_ERROR_MSG   := 'guardando datos';
    V_RETURN_CODE := 6;
    V_OUTPUT      := UTL_FILE.FOPEN('DIR_DETAIL', P_FILENAME, 'w');

    UTL_FILE.PUT_LINE(V_OUTPUT,
                      '<?xml version="1.0" encoding="ISO-8859-1"?>');
    UTL_FILE.PUT_LINE(V_OUTPUT, '<CONCEPTS>');

    FOR I IN 1 .. V_ARR.COUNT LOOP

      UTL_FILE.PUT_LINE(V_OUTPUT, '   <LINE>');
      UTL_FILE.PUT(V_OUTPUT, '      <INFO>');

      FOR J IN 1 .. V_ARR(I).COUNT LOOP
        UTL_FILE.PUT(V_OUTPUT, V_ARR(I) (J) || P_SEPARATOR);
      END LOOP;

      UTL_FILE.PUT_LINE(V_OUTPUT, '</INFO>');
      UTL_FILE.PUT(V_OUTPUT, '      <SERVICES>');

      IF V_ARR_SERVICES(I) (1) (1) IS NOT NULL THEN
        FOR J IN 1 .. V_ARR_SERVICES(I).COUNT LOOP
          UTL_FILE.PUT(V_OUTPUT,
                       V_ARR_SERVICES(I) (J)
                       (1) || P_SEPARATOR || V_ARR_SERVICES(I) (J)
                       (2) || P_SEPARATOR);
        END LOOP;
      ELSE
        --si no hay detalles de varios escribir el mismo valor de Document_Details
        GET_COLUMN_INDEX(3,
                         V_INDEX_AMOUNT,
                         V_INDEX_QUANTITY,
                         V_DESCRIPTION);
        UTL_FILE.PUT(V_OUTPUT,
                     '-' || P_SEPARATOR || V_ARR(I)
                     (V_INDEX_AMOUNT) || P_SEPARATOR);
      END IF;

      UTL_FILE.PUT_LINE(V_OUTPUT, '</SERVICES>');
      UTL_FILE.PUT(V_OUTPUT, '      <VARIOUS>');

      IF V_ARR_VARIOUS(I) (1) (1) IS NOT NULL THEN
        FOR J IN 1 .. V_ARR_VARIOUS(I).COUNT LOOP
          UTL_FILE.PUT(V_OUTPUT,
                       V_ARR_VARIOUS(I) (J)
                       (1) || P_SEPARATOR || V_ARR_VARIOUS(I) (J)
                       (2) || P_SEPARATOR);
        END LOOP;
      ELSE
        --si no hay detalles de varios escribir el mismo valor de Document_Details
        GET_COLUMN_INDEX(11,
                         V_INDEX_AMOUNT,
                         V_INDEX_QUANTITY,
                         V_DESCRIPTION);
        UTL_FILE.PUT(V_OUTPUT,
                     '-' || P_SEPARATOR || V_ARR(I)
                     (V_INDEX_AMOUNT) || P_SEPARATOR);
      END IF;

      UTL_FILE.PUT_LINE(V_OUTPUT, '</VARIOUS>');
      UTL_FILE.PUT(V_OUTPUT, '      <EXCEDENTES>');

      IF V_ARR_EXCEDENTES(I) (1) (1) IS NOT NULL THEN
        FOR J IN 1 .. V_ARR_EXCEDENTES(I).COUNT LOOP
          UTL_FILE.PUT(V_OUTPUT,
                       V_ARR_EXCEDENTES(I) (J)
                       (1) || P_SEPARATOR || V_ARR_EXCEDENTES(I) (J)
                       (2) || P_SEPARATOR);
        END LOOP;
      ELSE
        --si no hay detalles de varios escribir el mismo valor de Document_Details
        GET_COLUMN_INDEX(6,
                         V_INDEX_AMOUNT,
                         V_INDEX_QUANTITY,
                         V_DESCRIPTION);
        UTL_FILE.PUT(V_OUTPUT,
                     '-' || P_SEPARATOR || V_ARR(I)
                     (V_INDEX_AMOUNT) || P_SEPARATOR);
      END IF;
      UTL_FILE.PUT_LINE(V_OUTPUT, '</EXCEDENTES>');

      UTL_FILE.PUT(V_OUTPUT, '      <SMSAMOUNT>');

      IF V_ARR_SMS_AMOUNT(I) (1) (1) IS NOT NULL THEN
        FOR J IN 1 .. V_ARR_SMS_AMOUNT(I).COUNT LOOP
          UTL_FILE.PUT(V_OUTPUT,
                       V_ARR_SMS_AMOUNT(I) (J)
                       (1) || P_SEPARATOR || V_ARR_SMS_AMOUNT(I) (J)
                       (2) || P_SEPARATOR);
        END LOOP;
      ELSE
        --si no hay detalles de varios escribir el mismo valor de Document_Details
        GET_COLUMN_INDEX(13,
                         V_INDEX_AMOUNT,
                         V_INDEX_QUANTITY,
                         V_DESCRIPTION);
        UTL_FILE.PUT(V_OUTPUT,
                     '-' || P_SEPARATOR || V_ARR(I)
                     (V_INDEX_AMOUNT) || P_SEPARATOR);
      END IF;
      UTL_FILE.PUT_LINE(V_OUTPUT, '</SMSAMOUNT>');
      UTL_FILE.PUT(V_OUTPUT, '      <DATOS>');

      IF V_ARR_DATOS(I) (1) (1) IS NOT NULL THEN
        FOR J IN 1 .. V_ARR_DATOS(I).COUNT LOOP
          UTL_FILE.PUT(V_OUTPUT,
                       V_ARR_DATOS(I) (J)
                       (1) || P_SEPARATOR || V_ARR_DATOS(I) (J)
                       (2) || P_SEPARATOR);
        END LOOP;
      ELSE
        --si no hay detalles de varios escribir el mismo valor de Document_Details
        GET_COLUMN_INDEX(12,
                         V_INDEX_AMOUNT,
                         V_INDEX_QUANTITY,
                         V_DESCRIPTION);
        UTL_FILE.PUT(V_OUTPUT,
                     '-' || P_SEPARATOR || V_ARR(I)
                     (V_INDEX_QUANTITY) || P_SEPARATOR);
      END IF;
      UTL_FILE.PUT_LINE(V_OUTPUT, '</DATOS>');

      UTL_FILE.PUT(V_OUTPUT, '      <SMSQTTY>');

      IF V_ARR_SMS_QTTY(I) (1) (1) IS NOT NULL THEN
        FOR J IN 1 .. V_ARR_SMS_QTTY(I).COUNT LOOP
          UTL_FILE.PUT(V_OUTPUT,
                       V_ARR_SMS_QTTY(I) (J)
                       (1) || P_SEPARATOR || V_ARR_SMS_QTTY(I) (J)
                       (2) || P_SEPARATOR);
        END LOOP;
      ELSE
        --si no hay detalles de varios escribir el mismo valor de Document_Details
        GET_COLUMN_INDEX(13,
                         V_INDEX_AMOUNT,
                         V_INDEX_QUANTITY,
                         V_DESCRIPTION);
        UTL_FILE.PUT(V_OUTPUT,
                     '-' || P_SEPARATOR || V_ARR(I)
                     (V_INDEX_QUANTITY) || P_SEPARATOR);
      END IF;
      UTL_FILE.PUT_LINE(V_OUTPUT, '</SMSQTTY>');

      UTL_FILE.PUT_LINE(V_OUTPUT, '   </LINE>');
    END LOOP;

    --Escribe la última línea de totales
    UTL_FILE.PUT_LINE(V_OUTPUT, '   <LINE>');
    UTL_FILE.PUT(V_OUTPUT, '      <INFO>');
    FOR I IN 1 .. V_ARR_TOTALS.COUNT LOOP
      UTL_FILE.PUT(V_OUTPUT, V_ARR_TOTALS(I) || P_SEPARATOR);
    END LOOP;

    UTL_FILE.PUT_LINE(V_OUTPUT, '      </INFO>');

    UTL_FILE.PUT_LINE(V_OUTPUT,
                      '      <SERVICES>' ||
                      TO_CHAR(V_TOTAL_SERVICES, V_FORMAT) || '#</SERVICES>');
    UTL_FILE.PUT_LINE(V_OUTPUT,
                      '      <VARIOUS>' ||
                      TO_CHAR(V_TOTAL_VARIOUS, V_FORMAT) || '#</VARIOUS>');
    UTL_FILE.PUT_LINE(V_OUTPUT,
                      '      <EXCEDENTES>' ||
                      TO_CHAR(V_TOTAL_EXCEDENTES, V_FORMAT) ||
                      '#</EXCEDENTES>');
    UTL_FILE.PUT_LINE(V_OUTPUT,
                      '      <SMSAMOUNT>' || V_TOTAL_SMS || '#</SMSAMOUNT>');
    UTL_FILE.PUT_LINE(V_OUTPUT,
                      '      <DATOS>' || TO_CHAR(V_TOTAL_DATOS, V_FORMAT) ||
                      '#</DATOS>');
    UTL_FILE.PUT_LINE(V_OUTPUT,
                      '      <SMSQTTY>' ||
                      TO_CHAR(V_TOTAL_QTTY, V_FORMAT_MIN) || '#</SMSQTTY>');

    UTL_FILE.PUT_LINE(V_OUTPUT, '   </LINE>');

    --A partir de acá se escribe la informacion relacionada a las jerarquías
    --de las columnas a los efectos de agruparla en un solo lugar
    OPEN CUR_ITEMS_SHOW;
    V_ARR_HEADERS(1)(1) := '';
    V_ARR_HEADERS(2)(1) := '';
    V_ARR_HEADERS(3)(1) := '';
    V_ARR_HEADERS(4)(1) := '';
    LOOP
      FETCH CUR_ITEMS_SHOW
        INTO V_ISH_ID, V_DESCRIPTION;
      EXIT WHEN CUR_ITEMS_SHOW%NOTFOUND;
      GET_COLUMN_INDEX(V_ISH_ID,
                       V_INDEX_AMOUNT,
                       V_INDEX_QUANTITY,
                       V_DESCRIPTION);

      IF V_INDEX_AMOUNT IN (4, 5, 6, 7) OR V_INDEX_QUANTITY IN (4, 5, 6, 7) THEN
        V_ITEM_INDEX := 1;
      END IF;
      IF V_INDEX_AMOUNT IN (9, 11, 13, 22, 24) OR
         V_INDEX_QUANTITY IN (9, 11, 13, 22, 24) THEN
        V_ITEM_INDEX := 2;
      END IF;
      IF V_INDEX_AMOUNT IN (18, 20) OR V_INDEX_QUANTITY IN (18, 20) THEN
        V_ITEM_INDEX := 3;
      END IF;
      IF V_INDEX_AMOUNT IN (15, 16, 17, 26) OR
         V_INDEX_QUANTITY IN (15, 16, 17, 26) THEN
        V_ITEM_INDEX := 4;
      END IF;

      IF V_INDEX_AMOUNT <> -1 THEN
        V_TEMP := '      <HEADER unit="($)" index="' ||
                  (V_INDEX_AMOUNT - 1) || '" description="' ||
                  V_DESCRIPTION || '">';

        IF V_ISH_ID = 3 THEN
          V_TEMP := V_TEMP || '         <HEADER index="' ||
                    (V_INDEX_MAX + 5) ||
                    '" description="Detalles"> </HEADER>' || '      ';
        END IF;

        IF V_ISH_ID = 6 THEN
          V_TEMP := V_TEMP || '         <HEADER index="' ||
                    (V_INDEX_MAX + 8) ||
                    '" description="Detalles"> </HEADER>' || '      ';
        END IF;

        IF V_ISH_ID = 11 THEN
          V_TEMP := V_TEMP || '         <HEADER index="' ||
                    (V_INDEX_MAX + 6) ||
                    '" description="Detalles"> </HEADER>' || '      ';
        END IF;

        IF V_ISH_ID = 13 THEN
          V_TEMP := V_TEMP || '         <HEADER index="' ||
                    (V_INDEX_MAX + 9) ||
                    '" description="Detalles"> </HEADER>' || '      ';
        END IF;

        V_ARR_HEADERS(V_ITEM_INDEX)(V_ARR_HEADERS(V_ITEM_INDEX).COUNT + 1) := V_TEMP ||
                                                                              '</HEADER>';
      END IF;

      IF V_INDEX_QUANTITY <> -1 THEN
        V_TEMP := '      <HEADER unit="(Min)" index="' ||
                  (V_INDEX_QUANTITY - 1) || '" description="' ||
                  V_DESCRIPTION || '">';
        IF V_ISH_ID = 3 THEN
          V_TEMP := V_TEMP || '         <HEADER index="' ||
                    (V_INDEX_MAX + 6) ||
                    '" description="Detalles"> </HEADER>' || '      ';
        END IF;
        IF V_ISH_ID = 11 THEN
          V_TEMP := V_TEMP || '         <HEADER index="' ||
                    (V_INDEX_MAX + 8) ||
                    '" description="Detalles"> </HEADER>' || '      ';
        END IF;
        IF V_ISH_ID = 13 THEN
          V_TEMP := '      <HEADER unit="(Unid.)" index="' ||
                    (V_INDEX_QUANTITY - 1) || '" description="' ||
                    V_DESCRIPTION || '">';
          V_TEMP := V_TEMP || '         <HEADER index="' ||
                    (V_INDEX_MAX + 11) ||
                    '" description="Detalles"> </HEADER>' || '      ';
        END IF;
        IF V_ISH_ID <> 12 THEN
          V_ARR_HEADERS(V_ITEM_INDEX)(V_ARR_HEADERS(V_ITEM_INDEX).COUNT + 1) := V_TEMP ||
                                                                                '</HEADER>';
        END IF;

        IF V_ISH_ID = 12 THEN
          V_TEMP := '      <HEADER unit="(Kb)" index="' ||
                    (V_INDEX_QUANTITY - 1) || '" description="' ||
                    V_DESCRIPTION || '">';
          V_TEMP := V_TEMP || '         <HEADER index="' ||
                    (V_INDEX_MAX + 10) ||
                    '" description="Detalles"> </HEADER>' || '      ';
          V_ARR_HEADERS(V_ITEM_INDEX)(V_ARR_HEADERS(V_ITEM_INDEX).COUNT + 1) := V_TEMP ||
                                                                                '</HEADER>';
          V_TEMP := '      <HEADER index="' || (V_INDEX_MAX + 7) ||
                    '" description="Frac. (b)"> </HEADER>';
          V_ARR_HEADERS(V_ITEM_INDEX)(V_ARR_HEADERS(V_ITEM_INDEX).COUNT + 1) := V_TEMP;
        END IF;

      END IF;

    END LOOP;
    CLOSE CUR_ITEMS_SHOW;

    UTL_FILE.PUT_LINE(V_OUTPUT,
                      '   <HEADER index="0" description="Celular"> </HEADER>');
    UTL_FILE.PUT_LINE(V_OUTPUT,
                      '   <HEADER index="1" description="Usuario"> </HEADER>');
    UTL_FILE.PUT_LINE(V_OUTPUT,
                      '   <HEADER index="2" description="Plan"> </HEADER>');
    UTL_FILE.PUT_LINE(V_OUTPUT,
                      '   <HEADER unit="($)" index="' || (V_INDEX_MAX + 0) ||
                      '" description="Abonos y servicios mensuales">');

    FOR I IN 2 .. V_ARR_HEADERS(1).COUNT LOOP
      UTL_FILE.PUT_LINE(V_OUTPUT, V_ARR_HEADERS(1) (I));
    END LOOP;

    UTL_FILE.PUT_LINE(V_OUTPUT, '   </HEADER>');
    UTL_FILE.PUT_LINE(V_OUTPUT,
                      '   <HEADER unit="($)" index="' || (V_INDEX_MAX + 1) ||
                      '" description="Cargos por consumos">');

    FOR I IN 2 .. V_ARR_HEADERS(2).COUNT LOOP
      UTL_FILE.PUT_LINE(V_OUTPUT, V_ARR_HEADERS(2) (I));
    END LOOP;

    UTL_FILE.PUT_LINE(V_OUTPUT,
                      '      <HEADER unit="($)" index="' ||
                      (V_INDEX_MAX + 2) || '" description="Datos">');

    FOR I IN 2 .. V_ARR_HEADERS(3).COUNT LOOP
      UTL_FILE.PUT_LINE(V_OUTPUT, '   ' || V_ARR_HEADERS(3) (I));
    END LOOP;

    UTL_FILE.PUT_LINE(V_OUTPUT, '      </HEADER>');
    UTL_FILE.PUT_LINE(V_OUTPUT, '   </HEADER>');
    UTL_FILE.PUT_LINE(V_OUTPUT,
                      '   <HEADER unit="($)" index="' || (V_INDEX_MAX + 3) ||
                      '" description="Otros">');

    FOR I IN 2 .. V_ARR_HEADERS(4).COUNT LOOP
      UTL_FILE.PUT_LINE(V_OUTPUT, V_ARR_HEADERS(4) (I));
    END LOOP;

    UTL_FILE.PUT_LINE(V_OUTPUT, '   </HEADER>');
    UTL_FILE.PUT_LINE(V_OUTPUT,
                      '   <HEADER unit="($)" index="' || (V_INDEX_MAX + 4) ||
                      '" description="Total"> </HEADER>');
    UTL_FILE.PUT_LINE(V_OUTPUT, '</CONCEPTS>');
    UTL_FILE.FCLOSE(V_OUTPUT);

    P_ERROR_MSG   := 'OK';
    V_RETURN_CODE := 0;
    RETURN V_RETURN_CODE;

  EXCEPTION
    WHEN OTHERS THEN
      P_ERROR_MSG := 'Error ' || P_ERROR_MSG || ' ' || P_SEPARATOR ||
                     SQLCODE || ' ' || P_SEPARATOR || SQLERRM;
      RETURN V_RETURN_CODE;

  END;

  --Valida el celular que se esta logueando.
  --Chequea que tenga los packs de factura electrónica y que el password sea correcto
  --Retorna: 0: cuando se loguea ok
  --         1: no existe el celular
  --         2: no tiene el pack
  --         3: el password es incorrecto
  --         4: la linea no esta activa
  FUNCTION VALIDATE_CELLULAR(P_BILL_NUMBER  IN VARCHAR2,
                             P_CLT_PASSWORD IN VARCHAR2,
                             P_CLT_ID       OUT VARCHAR2,
                             P_CLT_NAME     OUT VARCHAR2,
                             P_ERROR_TEXT   OUT VARCHAR2) RETURN NUMBER IS

    RESULT                NUMBER;
    V_ERROR               NUMBER := 0;
    V_CLU_CELLULAR_NUMBER VARCHAR2(10);
    V_LISTA_CUENTAS       VARCHAR2(250);
    V_STATUS              VARCHAR2(2);
    V_CLT_PASSWORD        VARCHAR2(100);
    V_PASS VARCHAR2(100);
    V_STL_VALUE VARCHAR2(10);
    
  BEGIN
    BEGIN
      SELECT CLU_CELLULAR_NUMBER, CLU_STATUS
        INTO V_CLU_CELLULAR_NUMBER, V_STATUS
        FROM CELLULARS
       WHERE CLU_BILL_NUMBER = P_BILL_NUMBER;
    EXCEPTION
      WHEN OTHERS THEN
        P_ERROR_TEXT := 'La línea no existe';
        RETURN 1;
    END;

    IF V_STATUS != 'A' THEN
      P_ERROR_TEXT := 'La línea no esta activa';
      RETURN 4;
    END IF;

    /*************************************/

    IF LTRIM(RTRIM(P_CLT_PASSWORD)) = '' OR P_CLT_PASSWORD IS NULL THEN
      P_CLT_ID     := NULL;
      P_ERROR_TEXT := 'Password nulo';
      RETURN - 1;
    END IF;

     SELECT STL_CHAR_VALUE
     INTO V_STL_VALUE
    FROM STL_PARAMETERS
    WHERE STL_ID ='LCPENC';


      V_PASS := stl.PA_CRYPTO.encriptar3des@PROD (P_CLT_PASSWORD, V_STL_VALUE);

     SELECT CLT_PASSWORD,
           CLT_ID,
           LTRIM(RTRIM(CLT_NAME)) || ' ' || LTRIM(RTRIM(CLT_SURNAME))
      INTO V_CLT_PASSWORD, P_CLT_ID, P_CLT_NAME
      FROM CLIENT, ACCOUNTS, CELLULARS
     WHERE ACC_CLT_ID = CLT_ID
       AND ACC_ID = CLU_ACC_ID
       AND CLU_CELLULAR_NUMBER = V_CLU_CELLULAR_NUMBER;
    IF LTRIM(RTRIM(V_CLT_PASSWORD)) <> LTRIM(RTRIM(V_PASS )) OR
       V_CLT_PASSWORD IS NULL THEN
      P_CLT_ID     := NULL;
      P_ERROR_TEXT := 'Password incorrecto';
      RETURN 3;
    END IF;
    P_CLT_NAME := LTRIM(RTRIM(P_CLT_NAME));

    /*************************************/

    /*devuelve 0 o -1*/
    -- result := Web_Consumo.ValidaPassClient( v_Clu_Cellular_Number, p_Clt_Password, p_Clt_Id, p_Clt_Name );

    SELECT COUNT(*)
      INTO RESULT
      FROM CELLULARS, CELLULAR_PACKAGES, ED_PACKAGES_EDETAILS
     WHERE CLU_BILL_NUMBER = P_BILL_NUMBER
       AND CLU_CELLULAR_NUMBER = CPK_CLU_CELLULAR_NUMBER
       AND CPK_PKT_ID = EPE_PKT_ID
       AND SYSDATE BETWEEN CPK_ACTIVATION_DATE AND
           NVL(CPK_CANCELED_DATE, SYSDATE + 1)
       AND SYSDATE BETWEEN EPE_START_DATE AND
           NVL(EPE_END_DATE, SYSDATE + 1);

    IF RESULT = 0 THEN
      P_ERROR_TEXT := 'No tiene pack';
      RETURN 2;
    END IF;

    P_ERROR_TEXT := 'OK';
    RETURN 0;

  EXCEPTION
    WHEN OTHERS THEN
      RETURN(SQLCODE);
  END;

  --Devuelve la lista de cuentas de un cliente
  --Retorna: 0: Si encuentra la(s) cuanta(s)
  --         1: Sin ocurre algun error
  --         2: No se encontraron datos

  -- CD: 4782 - Detalle Llamadas para AR
  -- autor : Franco, Pablo A.
  -- Proposito: Se modificó para optimizar respuesta.
  -- Fecha modificación:  31/10/2007

  FUNCTION GET_CLIENT_ACCOUNTS(P_CLT_ID        IN VARCHAR2,
                               P_SEPARATOR     IN VARCHAR2,
                               P_LIST_ACCOUNTS OUT VARCHAR2,
                               P_ERROR_TEXT    OUT VARCHAR2) RETURN NUMBER IS

    CURSOR CUR_ACCOUTS(CP_CLT_ID IN VARCHAR2) IS

    SELECT /*+ ordered use_nl(clu cpk) */
    distinct(clu_acc_id)
    FROM accounts acc,
         cellulars clu,
         cellular_packages cpk,
         ed_packages_edetails
    WHERE acc_clt_id = CP_Clt_Id
     AND clu_acc_id = acc_id
     AND cpk_clu_cellular_number = clu_cellular_number
     AND epe_pkt_id = cpk_pkt_id
     AND sysdate BETWEEN cpk_activation_date
     AND NVL(cpk_canceled_date,sysdate+1)
     AND sysdate BETWEEN epe_start_date
     AND NVL(epe_end_date,sysdate+1)
   ORDER BY 1;

    V_LIST_ACCOUNTS VARCHAR2(5000) := NULL;
    V_ACC_ID        VARCHAR2(10);

  BEGIN

    OPEN CUR_ACCOUTS(P_CLT_ID);
    LOOP
      FETCH CUR_ACCOUTS
        INTO V_ACC_ID;
      EXIT WHEN CUR_ACCOUTS%NOTFOUND;

      V_LIST_ACCOUNTS := V_LIST_ACCOUNTS || P_SEPARATOR || TRIM(V_ACC_ID) ||
                         P_SEPARATOR;
    END LOOP;
    CLOSE CUR_ACCOUTS;

    IF V_LIST_ACCOUNTS IS NULL THEN
      P_ERROR_TEXT := 'No se encontraron datos';
      RETURN 2;
    END IF;

    P_LIST_ACCOUNTS := V_LIST_ACCOUNTS;
    P_ERROR_TEXT    := 'OK';
    RETURN 0;

  EXCEPTION
    WHEN OTHERS THEN
      P_ERROR_TEXT := 'Error buscando cuentas: ' || SQLERRM || ' - ' ||
                      SQLCODE;
      RETURN 1;
  END;

  --Devuelve la lista de cuentas de un cliente
  --Retorna: 0: Si encuentra la(s) línea(s)
  --         1: Sin ocurre algun error
  --         2: No se encontraron datos
  FUNCTION GET_CLIENT_LINES(P_ACC_ID        IN VARCHAR2,
                            P_SEPARATOR     IN VARCHAR2,
                            P_BILL_LIST     OUT VARCHAR2,
                            P_CELLULAR_LIST OUT VARCHAR2,
                            P_NAMES_LIST    OUT VARCHAR2,
                            P_ERROR_TEXT    OUT VARCHAR2) RETURN NUMBER IS

    CURSOR CUR_LINES(CP_ACC_ID IN VARCHAR2) IS
      SELECT /*+ ordered use_nl(clu cpk) */
       CLU_CELLULAR_NUMBER, CLU_BILL_NUMBER, CLU_CUS_USER
        FROM CELLULARS /*@prod*/, CELLULAR_PACKAGES, ED_PACKAGES_EDETAILS --para subirla a producción agregar @prod
       WHERE CLU_ACC_ID = CP_ACC_ID
         AND CLU_STATUS = 'A'
         AND CLU_CELLULAR_NUMBER = CPK_CLU_CELLULAR_NUMBER
         AND CPK_PKT_ID = EPE_PKT_ID
         AND SYSDATE BETWEEN CPK_ACTIVATION_DATE AND
             NVL(CPK_CANCELED_DATE, SYSDATE + 1)
         AND SYSDATE BETWEEN EPE_START_DATE AND
             NVL(EPE_END_DATE, SYSDATE + 1)
       ORDER BY CLU_BILL_NUMBER;

    V_BILL_LIST       VARCHAR2(5000) := NULL;
    V_CELLULAR_LIST   VARCHAR2(5000) := NULL;
    V_NAMES_LIST      VARCHAR2(8000) := NULL;
    V_BILL_NUMBER     VARCHAR2(10);
    V_CELLULAR_NUMBER VARCHAR2(10);
    V_CUS_USER        VARCHAR2(70);

  BEGIN

    OPEN CUR_LINES(P_ACC_ID);
    LOOP
      FETCH CUR_LINES
        INTO V_CELLULAR_NUMBER, V_BILL_NUMBER, V_CUS_USER;
      EXIT WHEN CUR_LINES%NOTFOUND;
      V_BILL_LIST     := V_BILL_LIST || TRIM(V_BILL_NUMBER) || P_SEPARATOR;
      V_CELLULAR_LIST := V_CELLULAR_LIST || TRIM(V_CELLULAR_NUMBER) ||
                         P_SEPARATOR;
      V_NAMES_LIST    := V_NAMES_LIST || TRIM(V_CUS_USER) || P_SEPARATOR;
    END LOOP;
    CLOSE CUR_LINES;

    IF V_BILL_LIST IS NULL THEN
      P_ERROR_TEXT := 'No se encontraron datos';
      RETURN 2;
    END IF;

    P_BILL_LIST     := V_BILL_LIST;
    P_NAMES_LIST    := V_NAMES_LIST;
    P_CELLULAR_LIST := V_CELLULAR_LIST;
    P_ERROR_TEXT    := 'OK';
    RETURN 0;

  EXCEPTION
    WHEN OTHERS THEN
      P_ERROR_TEXT := 'Error buscando cuentas: ' || SQLERRM || ' - ' ||
                      SQLCODE;
      RETURN 1;
  END;
END WEB_CONCEPTS_DETAILS;
/

