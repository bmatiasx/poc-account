create materialized view S_COMPANIES
refresh force on demand
  as
    SELECT cmp_id, cmp_vat_id, cmp_name, cmp_street, cmp_number, cmp_floor,  cmp_city, cmp_zip_code, cmp_state, cmp_country, cmp_telephone, cmp_cuit, cmp_ingresos_brutos, cmp_start_date, cmp_tape, cmp_cai_number,     cmp_cai_due_date, cmp_tti, cmp_end_date, cmp_sap_company, cmp_sap_movement, cmp_letterhead, cmp_billing_name, cmp_cpa, cmp_benefit_center, cmp_sap_sale_company, cmp_rate_company
from companies@PROD


/

