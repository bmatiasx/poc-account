create FUNCTION F_VALIDATE_STATUS_ACCOUNT

 (P_ACCOUNT IN VARCHAR2
 ,P_ERR_NUMBER OUT NUMBER
 ,P_ERR_MESSAGE OUT VARCHAR2
 )
 RETURN NUMBER
 IS
v_active VARCHAR2(1);
BEGIN

    BEGIN

      SELECT 'Y'
      INTO v_active
      FROM s_cellulars
      WHERE clu_acc_id = p_account
      AND clu_status IN ('A')
      AND ROWNUM < 2;

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
          v_active := 'N';
        WHEN OTHERS THEN
          p_err_number := SQLCODE;
          p_err_message := SQLERRM;
          RETURN -1;
    END;

    IF v_active = 'N' THEN
        p_err_message := 'La cuenta no esta activa.';
        RETURN 1;
    END IF;

    RETURN 0;


EXCEPTION
  WHEN OTHERS THEN
    p_err_number := SQLCODE;
    p_err_message := SQLERRM;
    RETURN -1;
END;
/

