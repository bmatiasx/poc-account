create FUNCTION f_get_claro_circle_points(p_cellular    VARCHAR2,
                                                     p_quantity    OUT NUMBER,
                                                     p_err_number  OUT NUMBER,
                                                     p_err_message OUT VARCHAR2)
  RETURN NUMBER IS
  v_result NUMBER;

BEGIN

  v_result := pa_mileage.f_quantity_available_points@prod(p_cellular,
                                                     p_quantity,
                                                     p_err_number,
                                                     p_err_message);
  RETURN v_result;

END;
/

