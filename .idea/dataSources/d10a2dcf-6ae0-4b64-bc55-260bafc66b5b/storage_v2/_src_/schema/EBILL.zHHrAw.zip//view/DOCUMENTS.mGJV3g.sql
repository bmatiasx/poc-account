create view DOCUMENTS as
  select
 DOC_CMP_ID                      ,
 DOC_DCT_ID                      ,
 DOC_ID                          ,
 DOC_LETTER                      ,
 DOC_ACC_ID                      ,
 DOC_SYSTEM_DATE                 ,
 DOC_DOCUMENT_DATE               ,
 DOC_AMOUNT                      ,
 DOC_BALANCE                     ,
 DOC_DUE_DATE                    ,
 DOC_RFB_DATE                    ,
 DOC_SECOND_AMOUNT               ,
 DOC_PRINTED                     ,
 DOC_TCK_ID                      ,
 DOC_SCH_ID                      ,
 DOC_LAST_UPDATED_DATE           ,
 DOC_USR_ID                      ,
 DOC_STATUS                      ,
 DOC_SECOND_DUE_DATE
from DOCUMENTS@prod
/

