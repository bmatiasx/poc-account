create PACKAGE IVR_TRACE IS

---------------------------------------------------------------
TYPE tabla IS TABLE OF CLOB;
--FUNCTION parser (p_in_flujo CLOB) RETURN APEX_APPLICATION_GLOBAL.VC_ARR2;

FUNCTION parser (p_in_flujo CLOB) RETURN tabla;

-- funcion que hace el insert en la tabla principal. 
--Se le saco el "id" que tenia anteriormente, por lo que no se utiliza la secuencia.
FUNCTION insertInfoTraza(
    in_aplicacion_id IN NUMBER,
    in_fecha_inicio    IN VARCHAR2,
    in_fecha_fin       IN VARCHAR2,
    in_hora_inicio     IN VARCHAR2,
    in_hora_fin        IN VARCHAR2,
    in_abandono        IN VARCHAR2,
    in_ani             IN VARCHAR2,
    in_dnis            IN VARCHAR2,
    in_ucid            IN VARCHAR2,
    in_uui             IN VARCHAR2,
    in_flujo           IN CLOB,
    out_error_text     OUT NOCOPY VARCHAR2
    ) RETURN NUMBER;
    
FUNCTION procesarInfoTraza(out_error_text OUT NOCOPY VARCHAR2) RETURN NUMBER;

 FUNCTION f_save_call_data(in_aplicacion_id IN NUMBER,
                          in_fecha_inicio IN VARCHAR2, 
                          in_fecha_fin IN VARCHAR2, 
                          in_hora_inicio IN VARCHAR2, 
                          in_hora_fin IN VARCHAR2, 
                          in_abandono IN VARCHAR2, 
                          in_ani IN VARCHAR2, 
                          in_dnis IN VARCHAR2, 
                          in_ucid IN VARCHAR2, 
                          in_uui IN VARCHAR2, 
                          in_flujo IN CLOB,
                          out_error_text OUT NOCOPY VARCHAR2)  
RETURN NUMBER;
          
END IVR_TRACE;
/

