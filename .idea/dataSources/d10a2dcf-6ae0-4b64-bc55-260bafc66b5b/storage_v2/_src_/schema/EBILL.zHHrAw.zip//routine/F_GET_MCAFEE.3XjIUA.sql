create FUNCTION F_GET_MCAFEE

 (P_PKT_ID IN VARCHAR2
 ,P_CELLULAR IN VARCHAR2
 )
 RETURN VARCHAR2
 IS
  v_key           VARCHAR2(200);
  v_error_message VARCHAR2(200);
  v_code_number   NUMBER;
  feature         VARCHAR2(6);
  features        VARCHAR2(200);

  -- Cursor para features del package
  CURSOR cursorFeatures(p_pkt_id s_packages.pkt_id%TYPE) IS
    SELECT ftr.ftr_id
      FROM s_feature_packages pks, s_features ftr
     WHERE pks.pks_ftr_id = ftr.ftr_id
       AND pks.pks_pkt_id = p_pkt_id;
BEGIN
  BEGIN
    SELECT stl_char_value
      INTO features
      FROM stl_parameters
     WHERE stl_id = 'MCAFEE';
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN '';
  END;

  BEGIN
    OPEN cursorFeatures(p_pkt_id);
    LOOP
      FETCH cursorFeatures
        INTO feature;
      EXIT WHEN cursorFeatures%NOTFOUND;

      IF INSTR(features, '#' || feature || '#') <> 0 THEN
        P_OBTENER_URL_ANTIVIRUS_MCAFEE(p_cellular,
                                       v_key,
                                       v_code_number,
                                       v_error_message);
        IF v_code_number <> 0 THEN
          RETURN '';
        END IF;

        RETURN v_key;

      END IF;
    END LOOP;
    CLOSE cursorFeatures;
  END;

  RETURN '';

EXCEPTION
  WHEN OTHERS THEN
    RETURN '';

END;
/

