create FUNCTION F_SEND_EMAIL

 (P_FROM IN VARCHAR2
 ,P_TO IN VARCHAR2
 ,P_SUBJECT IN VARCHAR2
 ,P_BODY IN VARCHAR2
 ,P_ABSOLUT_PATH IN VARCHAR2
 ,P_ERR_NUMBER OUT NUMBER
 ,P_ERR_MESSAGE OUT VARCHAR2
 )
 RETURN NUMERIC
 IS
v_result  NUMBER;
v_err_message VARCHAR2(255);
BEGIN

  v_err_message := 'Llamando a pa_mail_interface.preparemail: ';
  v_result := pa_mail_interface.preparemail(p_from,
                                            p_to,
                                            NULL,
                                            p_subject,
                                            v_err_message);
  if v_result <> 0 THEN
    p_err_number := v_result;
    p_err_message := 'Error al preparar el email '||v_err_message;
    RETURN -1;
  END IF;

  v_err_message := 'Llamando a pa_mail_interface.setbody ';
  v_result := pa_mail_interface.setbody(p_body, v_err_message);
  if v_result <> 0 THEN
    p_err_number := v_result;
    p_err_message := 'Error al setear cuerpo del email '||v_err_message;
    RETURN -1;
  END IF;

  v_err_message := 'Llamando a pa_mail_interface.setosattach ';
  v_result := pa_mail_interface.setosattach(pattfilename => p_absolut_path,
                                            ptype        => NULL,
                                            perror       => v_err_message);
  if v_result <> 0 THEN
    p_err_number := v_result;
    p_err_message := 'Error al adjuntar file '||v_err_message;
    RETURN -1;
  END IF;

  v_err_message := 'Llamando a pa_mail_interface.send ';
  v_result := pa_mail_interface.send(v_result, v_err_message);
  if v_result <> 0 THEN
    p_err_number := v_result;
    p_err_message := 'Error al enviar email '||v_err_message;
    RETURN -1;
  END IF;

  p_err_number := 0;
  p_err_message := 'OK';
  RETURN 0;

EXCEPTION
  WHEN OTHERS THEN
    p_err_number := -1;
    p_err_message := v_err_message||SQLERRM;
END;
/

