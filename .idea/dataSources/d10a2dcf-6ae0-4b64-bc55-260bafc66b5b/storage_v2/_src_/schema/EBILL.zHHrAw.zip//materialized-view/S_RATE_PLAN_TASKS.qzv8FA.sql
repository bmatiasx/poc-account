create materialized view S_RATE_PLAN_TASKS
refresh complete on demand
  as
    SELECT RPK_TAS_ID,
  RPK_RPL_ID,
  RPK_START_DATE,
  RPK_END_DATE
from STL.rate_plan_tasks@prod

/

