create PACKAGE BODY PA_USSD_CONSUME IS
/***************************************************************************************************************
  Package PA_USSD_CONSUME que permite validar el acceso a saldos y consumos ussd 
  y mostrar al cliente informacion relacionada.
*************************************************************************************************************** 
    FECHA             EVENTO           DESARROLLADOR      DESCRIPCION                                          
    19/06/2014        CTIU100104165    Jose M. Lascano     1.0 - Se agrego la funcion FOARMAT_NUMBER            
                                                                 y esta fue puesta en uso en las funciones  
                                                                 DAILY_CONSUMPTIONS y DETAIL_CONSUMPTIONS,    
                                                                 se cambio el tam?o para la variable del       
                                                                 simbolo de moneda pais.
                                                             
    23/10/2014        CTIU100109381   Mariano L. Giuga     1.1 - Se cambia la forma en que se obtiene 
                                                                 el precio del pack internet por dia a partir 
                                                                 del plan de la linea.  
                                                                 
    14/04/2016        USSD-271        Bertorello Pablo G.  1.2  - Se agrega la funcion USSD_SYC_GET_VOICE_CO 
                                                                  para el manejo de packs de voz
    
    27/04/2016        USSD-291        Bertorello Pablo G.  1.3  - Se agrega el filtro rownum en VALIDATE_ENTRY para
                                                                  solucionar problemas en la funcion 
   
   17/05/2016        USSD-291        Bertorello Pablo G.  1.34  - Se modifica la funcion VALIDATE_ENTRY para
                                                                  solucionar problemas en la misma, ademas se actualiza el historial de versiones que era incorrecto                                                                                                                                           
****************************************************************************************************************/

 /* Esta funcion valida que el cliente que ingresa est? activo y obtiene los datos necesarios para realizar la
  consulta de saldos y consumos.
   *    @param MSISDN : El MSISDN provisto por ATS
   *    @param PP_CELLULAR_NUMBER : El n?mero de l?nea sin c?digo de pa?s
   *    @param PP_LINETYPE : El tipo de l?nea
   *    @param PP_CATEGORY : Categor?a de la l?nea.
   *    @param PP_ACCOUNT_ID : Identificaci?n de la cuenta.
   *    @param PP_GEU_ID : Provincia a la cual pertenece la l?nea.
   *    @param PP_PLAN_ID : Identificaci?n del plan con el que cuenta la l?nea.
   *    @param PP_CICLO : Ciclo de la l?nea.
   *    @param PP_RTY_ID : Categor?a de la l?nea.
   *    @param PP_ERR_TEXT : Mensaje de error desplegado al cliente, en caso de haberlo.*/

  FUNCTION VALIDATE_ENTRY(MSISDN             IN S_CELLULARS.CLU_BILL_NUMBER%TYPE,
                          PP_CELLULAR_NUMBER OUT s_cellulars.clu_cellular_number%TYPE,
                          PP_LINETYPE        OUT s_cellulars.clu_cbt_id%TYPE,
                          PP_CATEGORY        OUT s_client.clt_category%TYPE,
                          PP_ACCOUNT_ID      OUT s_cellulars.clu_acc_id%TYPE,
                          PP_GEU_ID          OUT s_accounts.acc_geu_id%TYPE,
                          PP_PLAN_ID         OUT s_cellular_plans.cpl_rpl_id%TYPE,
                          PP_CICLO           OUT s_cycles.cyc_cyc_id%TYPE,
                          PP_RTY_ID          OUT s_rate_plans.rpl_rty_id%TYPE,
                          PP_STL_VALUE       OUT s_stl_parameters.stl_char_value%TYPE,
                          PP_PP_ERR_TEXT     OUT VARCHAR2,
                          PP_SQL_CODE        OUT VARCHAR2,
                          PP_ERR_CODE        OUT NUMBER) RETURN NUMBER IS

    V_CELLULAR_NUMBER s_cellulars.clu_cellular_number%TYPE;
    V_LINETYPE        s_cellulars.clu_cbt_id%TYPE;
    V_CATEGORY        s_client.clt_category%TYPE;
    V_ACCOUNT_ID      s_cellulars.clu_acc_id%TYPE;
    V_GEU_ID          s_accounts.acc_geu_id%TYPE;
    V_PLAN_ID         s_cellular_plans.cpl_rpl_id%TYPE;
    V_CICLO           s_cycles.cyc_cyc_id%TYPE;
    V_RTY_ID          s_rate_plans.rpl_rty_id%TYPE;
    V_STL_VALUE       S_STL_PARAMETERS.STL_CHAR_VALUE%TYPE := 0;
    v_param           VARCHAR2(10);

  BEGIN

    SELECT clu.clu_cellular_number,
           clu.clu_cbt_id,
           clt.clt_category,
           clu.clu_acc_id,
           acc_geu_id,
           cpl.cpl_rpl_id,
           cyc.cyc_cyc_id,
           rpl.rpl_rty_id
      INTO V_CELLULAR_NUMBER,
           V_LINETYPE,
           V_CATEGORY,
           V_ACCOUNT_ID,
           V_GEU_ID,
           V_PLAN_ID,
           V_CICLO,
           V_RTY_ID
      FROM s_cellulars      clu,
           s_accounts       acc,
           s_client         clt,
           s_cellular_plans cpl,
           s_cycles         cyc,
           s_rate_plans     rpl
     WHERE clu.Clu_Bill_Number = MSISDN
       AND clu.clu_status = 'A'
       and cpl.cpl_rpl_id = rpl.rpl_id
       and clu.clu_stg_id = cpl.cpl_stg_id
       AND clu.clu_acc_id = acc.acc_id
       AND acc.acc_clt_id = clt.clt_id
       AND cpl.cpl_clu_cellular_number = clu.clu_cellular_number
       AND cpl.cpl_stg_id = clu.clu_stg_id
       AND SYSDATE BETWEEN cpl.cpl_start_date AND
           NVL(cpl.cpl_end_date, SYSDATE + 1)
       AND cyc.cyc_id = acc.acc_cyc_id;

    PP_CELLULAR_NUMBER := V_CELLULAR_NUMBER;
    PP_LINETYPE        := V_LINETYPE;
    PP_CATEGORY        := V_CATEGORY;
    PP_ACCOUNT_ID      := V_ACCOUNT_ID;
    PP_GEU_ID          := V_GEU_ID;
    PP_PLAN_ID         := V_PLAN_ID;
    PP_CICLO           := V_CICLO;
    PP_RTY_ID          := V_RTY_ID;
	  
    BEGIN
    /* Obtengo precio del pack Internet por dia */
    SELECT stl_char_value
    INTO v_param
    FROM  S_STL_PARAMETERS
    WHERE stl_id ='USDINP';  
    
    
    
    SELECT IPL_DATA_PRICE
    INTO V_STL_VALUE
    FROM S_INFO_PLANS
    WHERE IPL_RPL_ID = V_PLAN_ID
    AND SYSDATE BETWEEN IPL_START_DATE AND NVL(IPL_END_DATE, SYSDATE +1)
    AND INSTR(v_param, IPL_TYPE)>0;
    
    EXCEPTION
     WHEN NO_DATA_FOUND THEN
      PP_STL_VALUE:= 0;
      PP_PP_ERR_TEXT := 'No se encuentra el id del plan.';
      PP_ERR_CODE    := -2;
      PP_SQL_CODE    := SQLCODE || ' ' || SQLERRM;
      RETURN 0;
    END;
    
    PP_STL_VALUE       := V_STL_VALUE;

    RETURN 0;

  EXCEPTION
     WHEN OTHERS THEN
      PP_PP_ERR_TEXT := 'Ha ocurrido un error y la transaccion no pudo completarse. Por favor intente nuevamente mas tarde';
      PP_ERR_CODE    := -3;
      PP_SQL_CODE    := SQLCODE || ' ' || SQLERRM;
      RETURN - 1;

  END;

  --
  FUNCTION USSD_SYC_GET_USED_AMOUNT_CO(p_celular  s_cellulars.CLU_CELLULAR_NUMBER%TYPE,
                                       P_GEU_ID   STL_PARAMETERS.STL_CHAR_VALUE%TYPE,
                                       P_RESPONSE OUT VARCHAR2,
                                       P_ERR_TEXT OUT VARCHAR2,
                                       P_ERR_CODE OUT NUMBER,
                                       P_SQL_CODE OUT VARCHAR2) RETURN NUMBER IS
    V_RETURN NUMBER;
  BEGIN
    V_RETURN := PA_USSD_SALDOSYCONSUMOS_CO.USSD_SYC_GET_USED_AMOUNT_CO(p_celular,
                                                                       P_RESPONSE,
                                                                       P_ERR_TEXT,
                                                                       P_ERR_CODE,
                                                                       P_SQL_CODE);
    RETURN V_RETURN;
  END USSD_SYC_GET_USED_AMOUNT_CO;

  --
  FUNCTION USSD_SYC_GPRS_CO(P_CELLULAR IN s_cellulars.CLU_CELLULAR_NUMBER%TYPE,
                            p_acc_id   IN s_accounts.acc_id%TYPE,
                            P_CYCLE    IN s_cycles.cyc_cyc_id%TYPE,
                            P_RESPONSE OUT VARCHAR2,
                            P_ERR_TEXT OUT VARCHAR2,
                            P_ERR_CODE OUT NUMBER,
                            P_SQL_CODE OUT VARCHAR2) RETURN NUMBER IS
    V_RETURN NUMBER;
  BEGIN
    V_RETURN := PA_USSD_SALDOSYCONSUMOS_CO.USSD_SYC_GPRS_CO(P_CELLULAR,
                                                            p_acc_id,
                                                            P_CYCLE,
                                                            P_RESPONSE,
                                                            P_ERR_TEXT,
                                                            P_ERR_CODE,
                                                            P_SQL_CODE);
    RETURN V_RETURN;
  END USSD_SYC_GPRS_CO;

  FUNCTION USSD_SYC_GET_SMS_CO(P_CELLULAR IN s_cellulars.CLU_CELLULAR_NUMBER%TYPE,
                               P_CYCLE    IN s_cycles.cyc_cyc_id%TYPE,
                               P_RESPONSE OUT VARCHAR2,
                               P_ERR_TEXT OUT VARCHAR2,
                               P_ERR_CODE OUT NUMBER,
                               P_SQL_CODE OUT VARCHAR2) RETURN NUMBER IS
    V_RETURN NUMBER;
  BEGIN
    V_RETURN := PA_USSD_SALDOSYCONSUMOS_CO.USSD_SYC_GET_SMS_CO(P_CELLULAR,
                                                               P_CYCLE,
                                                               P_RESPONSE,
                                                               P_ERR_TEXT,
                                                               P_ERR_CODE,
                                                               P_SQL_CODE);
    RETURN V_RETURN;
  END USSD_SYC_GET_SMS_CO;

  FUNCTION USSD_SYC_GET_SURPLUS_CO(p_acc_id   IN s_accounts.acc_id%TYPE,
                                   p_cellular IN s_cellulars.clu_bill_number%TYPE,
                                   P_GEU_ID   s_STL_PARAMETERS.STL_CHAR_VALUE%TYPE,
                                   P_RESPONSE OUT VARCHAR2,
                                   P_ERR_TEXT OUT VARCHAR2,
                                   P_ERR_CODE OUT NUMBER,
                                   P_SQL_CODE OUT VARCHAR2) RETURN NUMBER IS
    --
    v_resultado      VARCHAR2(4000);
    v_description    VARCHAR2(4000);
    v_cantidad       VARCHAR2(4000);
    v_unidad         VARCHAR2(4000);
    v_precio_sin_IVA VARCHAR2(4000);
    v_precio_con_IVA VARCHAR2(4000);
    --

    V_RETURN NUMBER;
  BEGIN

    v_resultado := f_get_surplus(p_acc_id         => p_acc_id,
                                 p_cellular       => p_cellular,
                                 p_description    => v_description,
                                 p_cantidad       => v_cantidad,
                                 p_unidad         => v_unidad,
                                 p_precio_sin_iva => v_precio_sin_iva,
                                 p_precio_con_iva => v_precio_con_iva,
                                 p_err_number     => P_ERR_CODE,
                                 p_err_txt        => P_ERR_TEXT);

    IF v_resultado <> 0 and p_err_code <> -1003 THEN
      RETURN v_resultado;
    END IF;

    V_RETURN := PA_USSD_SALDOSYCONSUMOS_CO.USSD_SYC_GET_SURPLUS_CO(p_acc_id,
                                                                   p_cellular,
                                                                   P_GEU_ID,
                                                                   v_description,
                                                                   v_cantidad,
                                                                   v_unidad,
                                                                   v_precio_sin_iva,
                                                                   v_precio_con_iva,
                                                                   P_RESPONSE,
                                                                   P_ERR_TEXT,
                                                                   P_ERR_CODE,
                                                                   P_SQL_CODE);
    RETURN V_RETURN;
  END USSD_SYC_GET_SURPLUS_CO;

  --
  FUNCTION DAILY_CONSUMPTIONS(PP_CELLULAR VARCHAR2,
                              PP_DIA      IN NUMBER,
                              PP_RESPONSE OUT VARCHAR2,
                              PP_ERR_TEXT OUT VARCHAR2,
                              PP_ERR_CODE OUT NUMBER,
                              PP_SQL_CODE OUT VARCHAR2) RETURN NUMBER AS

    V_DIA       VARCHAR2(10);
    m_simbolo   STL_PARAMETERS.STL_CHAR_VALUE%TYPE;
	v_return    varchar2(30);
    v_monto     varchar2(20);

    CURSOR C_DET_CONSU(P_CELULLAR_NUMBER IN VARCHAR2, P_DIA IN VARCHAR2) IS
      SELECT /*+ leading(pc) index(ceo(ceo_pce_handle))*/
       CEO.ceo_cellular_number cellularNumber,
       ORCT.orct_tipo_operacion operacion,
       sum(CEO.ceo_amount) monto
        FROM cellular_operations         CEO,
             operation_reasons           ORE,
             prepay_cellulars_ccard      PCE,
             operation_reason_cust_types@CCARD.WORLD ORCT
       WHERE ceo.ceo_ore_id = ore.ore_id
         AND PCE.pce_handle = ceo.ceo_pce_handle
--         AND CEO.ceo_cellular_number = P_CELULLAR_NUMBER
         AND pce.pce_clu_cellular_number = P_CELULLAR_NUMBER
         AND ore.ore_orct_id = orct.orct_id
         AND ceo.ceo_add_date BETWEEN to_date(P_DIA, 'DD/MM/YYYY') AND
             to_date(P_DIA, 'DD/MM/YYYY') + 1
         AND orct.ORCT_VISIBLE = 'Y'
       GROUP BY ceo.ceo_cellular_number, orct.orct_tipo_operacion
       ORDER BY orct.orct_tipo_operacion;

  BEGIN

    CASE
      WHEN PP_DIA = 0 THEN
        V_DIA := TO_CHAR(SYSDATE, 'DD/MM/YYYY');
      WHEN PP_DIA = 1 THEN
        V_DIA := TO_CHAR(SYSDATE - 1, 'DD/MM/YYYY');
      WHEN PP_DIA = 2 THEN
        V_DIA := TO_CHAR(SYSDATE - 2, 'DD/MM/YYYY');
      WHEN PP_DIA = 3 THEN
        V_DIA := TO_CHAR(SYSDATE - 3, 'DD/MM/YYYY');
      WHEN PP_DIA = 4 THEN
        V_DIA := TO_CHAR(SYSDATE - 4, 'DD/MM/YYYY');
      WHEN PP_DIA = 5 THEN
        V_DIA := TO_CHAR(SYSDATE - 5, 'DD/MM/YYYY');
      WHEN PP_DIA = 6 THEN
        V_DIA := TO_CHAR(SYSDATE - 6, 'DD/MM/YYYY');
      ELSE
        V_DIA := NULL;
    END CASE;

    select stl_char_value
      into m_simbolo
      from stl_parameters
     where stl_id = 'USSDMD';
     
    
      FOR C IN C_DET_CONSU(PP_CELLULAR, V_DIA) LOOP
      IF  C.monto <> 0 THEN
       v_return := PA_USSD_COMMON.FORMAT_NUMBER (TO_CHAR(ABS(C.monto)), v_monto);
         PP_RESPONSE := PP_RESPONSE || '<CONSUMO><TIPO>' || C.operacion || '</TIPO><MONTO>' ||
                    m_simbolo ||   v_monto || '</MONTO></CONSUMO>';
       END IF;
      END LOOP;
     
    RETURN 0;

  EXCEPTION
    WHEN OTHERS THEN
      PP_ERR_TEXT := 'ERROR DE SISTEMAS';
      PP_ERR_CODE := -1;
      PP_SQL_CODE := SQLCODE || ' ' || SQLERRM;
      RETURN - 1;
      --
  END DAILY_CONSUMPTIONS;

  FUNCTION DETAIL_CONSUMPTIONS(PP_CELLULAR IN OUT VARCHAR2,
                               PP_DIA      IN VARCHAR2,
                               PP_SERV     IN VARCHAR2,
                               PP_RESPONSE OUT VARCHAR2,
                               PP_ERR_TEXT OUT VARCHAR2,
                               PP_ERR_CODE OUT NUMBER,
                               PP_SQL_CODE OUT VARCHAR2) RETURN NUMBER IS

    V_DIA       VARCHAR2(10);
    V_DESTINO   VARCHAR2(17);
    V_COSTO     NUMBER(14, 4);
    m_simbolo   STL_PARAMETERS.STL_CHAR_VALUE%TYPE;
    P_GEU_ID s_accounts.acc_geu_id%TYPE;
    V_IMP NUMBER(14,4);
    V_GEO_ERR EXCEPTION;
    V_GEO VARCHAR2(100);
    v_return    varchar2(30);
    v_monto     varchar2(20);

    CURSOR C_DET_CONS(V_DIA IN VARCHAR) IS
      select cal_clu_cellular_number cellularNumber,
             cal_date fechaOut,
             cal_dialed_number numDestino,
             cal_extended_duration duracion,
             (cal_air_charge + cal_land_charge + cal_cpp_charge) costo,
             decode(cal_direction,
                    'O',
                    'Salida',
                    'I',
                    'Entrada',
                    cal_direction) direccion,
             decode(cal_cell_type,
                    'B',
                    'Llamada',
                    'R',
                    'Roaming',
                    'V',
                    'SMS',
                    'Q',
                    'Internet',
                    cal_cell_type) tipo,
             cal_location lugar,
             cal_cat_id categoria,
             cal_cell_type
        from calls
       where cal_clu_cellular_number = PP_CELLULAR
         AND cal_date BETWEEN TO_DATE(V_DIA, 'DD/MM/YYYY') AND
             TO_DATE(V_DIA, 'DD/MM/YYYY') + 1
         and cal_cell_type = PP_SERV
       order by 1;

  BEGIN
    --saco el geu_id de la linea con su cellular_number y lo meto en P_GEU_ID
    select acc_geu_id
    into P_GEU_ID
    from s_accounts ac, s_cellulars c
    where AC.ACC_ID = C.CLU_ACC_ID
    and C.CLU_CELLULAR_NUMBER = PP_CELLULAR;

     SELECT STL_CHAR_VALUE INTO V_GEO
     FROM   S_STL_PARAMETERS
     WHERE  STL_ID = 'USSDGE';

    --ingreso en V_IMP los valores de imp sumados
    SELECT SUM(STL_VALUE) INTO V_IMP
    FROM   S_STL_PARAMETERS
    WHERE  STL_ID IN ('USSDIM', 'USSDII');

    --si no tengo P_GEU_ID disparo un error para que lo agarre la exception final
      IF P_GEU_ID IS NULL THEN
         RAISE V_GEO_ERR;
      END IF;

     IF INSTR('##'||P_GEU_ID||'##', V_GEO) >= 1 THEN
        -- CALCULO SIN IMPUESTO.
        V_IMP:= 1;
     ELSE  -- CALCULO CON IMPUESTOS.
        V_IMP:= 1 + V_IMP;
     END IF;

    CASE
      WHEN PP_DIA = '0' THEN
        V_DIA := TO_CHAR(SYSDATE, 'DD/MM/YYYY');
      WHEN PP_DIA = '1' THEN
        V_DIA := TO_CHAR(SYSDATE - 1, 'DD/MM/YYYY');
      WHEN PP_DIA = '2' THEN
        V_DIA := TO_CHAR(SYSDATE - 2, 'DD/MM/YYYY');
      WHEN PP_DIA = '3' THEN
        V_DIA := TO_CHAR(SYSDATE - 3, 'DD/MM/YYYY');
      WHEN PP_DIA = '4' THEN
        V_DIA := TO_CHAR(SYSDATE - 4, 'DD/MM/YYYY');
      WHEN PP_DIA = '5' THEN
        V_DIA := TO_CHAR(SYSDATE - 5, 'DD/MM/YYYY');
      WHEN PP_DIA = '6' THEN
        V_DIA := TO_CHAR(SYSDATE - 6, 'DD/MM/YYYY');
      ELSE
        V_DIA := NULL;
    END CASE;

    PP_RESPONSE := NULL;

    select stl_char_value
      into m_simbolo
      from stl_parameters
     where stl_id = 'USSDMD';

       -- si el servicio es SMS
    IF PP_SERV = 'V' THEN
      FOR C1 IN C_DET_CONS(V_DIA) LOOP
        --     v_indice:= v_indice +1;
        DBMS_OUTPUT.put_line(C1.numDestino);
        V_DESTINO:= PA_USSD_COMMON.GET_BILL_NUMBER(TO_CHAR(TO_NUMBER(C1.NUMDESTINO)));
        IF C1.COSTO <> 0 THEN
          V_COSTO     := ROUND(C1.COSTO, 2);
          v_return := PA_USSD_COMMON.FORMAT_NUMBER (TO_CHAR(ABS(V_COSTO*V_IMP)), v_monto);
          PP_RESPONSE := PP_RESPONSE || '<CONSUMO>';
          PP_RESPONSE := PP_RESPONSE || '<HORA>' || TO_CHAR(C1.FECHAOUT, 'HH24:MI:SS') || '</HORA>';
          PP_RESPONSE := PP_RESPONSE || '<DESTINO>' || V_DESTINO ||  '</DESTINO>';
          PP_RESPONSE := PP_RESPONSE || '<COSTO>' || m_simbolo || v_monto || '</COSTO>';
          PP_RESPONSE := PP_RESPONSE || '</CONSUMO>';
        END IF;
      END LOOP;
    END IF;

    -- si el servicio es LLAMADA

    IF PP_SERV = 'B' THEN
      FOR C1 IN C_DET_CONS(V_DIA) LOOP
        V_DESTINO := PA_USSD_COMMON.GET_BILL_NUMBER(TO_CHAR(TO_NUMBER(C1.NUMDESTINO)));
        IF C1.COSTO <> 0 THEN
          V_COSTO     := ROUND(C1.COSTO, 2);
          v_return := PA_USSD_COMMON.FORMAT_NUMBER (TO_CHAR(ABS(V_COSTO*V_IMP)), v_monto);
          PP_RESPONSE := PP_RESPONSE || '<CONSUMO>';
          PP_RESPONSE := PP_RESPONSE || '<HORA>' || TO_CHAR(C1.FECHAOUT, 'HH24:MI:SS') || '</HORA>';
          PP_RESPONSE := PP_RESPONSE || '<DESTINO>' || V_DESTINO || '</DESTINO>';
          PP_RESPONSE := PP_RESPONSE || '<COSTO>' || m_simbolo || v_monto || '</COSTO>';
          PP_RESPONSE := PP_RESPONSE || '<DURACION>' || C1.DURACION || '</DURACION>';
          PP_RESPONSE := PP_RESPONSE || '</CONSUMO>';
        END IF;
      END LOOP;
    END IF;

    IF PP_RESPONSE IS NULL THEN

      PP_ERR_TEXT := 'No se han registrado consumos para este dia';
      PP_ERR_CODE := 1;
      RETURN 1;
    ELSE
      PP_RESPONSE := '<DETALLE_CONSUMOS>' || PP_RESPONSE ||
                     '</DETALLE_CONSUMOS>';
      RETURN 0;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      PP_ERR_TEXT := 'ERROR DE SISTEMAS';
      PP_ERR_CODE := -1;
      PP_SQL_CODE := SQLCODE || ' ' || SQLERRM;
      RETURN - 1;

  END DETAIL_CONSUMPTIONS;
  
  --------
  
  
  FUNCTION USSD_SYC_GET_VOICE_CO(P_MSISDN IN VARCHAR2,
                            P_RESPONSE OUT VARCHAR2,
                            P_ERR_TEXT OUT VARCHAR2,
                            P_ERR_CODE OUT NUMBER,
                            P_SQL_CODE OUT VARCHAR2) RETURN NUMBER IS
    V_RETURN NUMBER;
  BEGIN
    V_RETURN := PA_USSD_SALDOSYCONSUMOS_CO.USSD_SYC_GET_VOICE_CO(P_MSISDN,
                               P_RESPONSE ,
                               P_ERR_TEXT ,
                               P_ERR_CODE ,
                               P_SQL_CODE );
    RETURN V_RETURN;
  END USSD_SYC_GET_VOICE_CO;
  
  
  
  
  
END PA_USSD_CONSUME;
/

