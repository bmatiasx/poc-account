create PACKAGE PA_SAPCRM_INTEGRATION IS

PENDING_STATUS CONSTANT varchar2(1) := 'P';
FINISH_STATUS CONSTANT varchar2(1) := 'T';
MOVE_TYPE CONSTANT varchar2(1) := 'A';

  /* Inserta en la tabla ACCOUNT_REGISTER_SERVICES una cabecera que indica la cuenta
  para la cual se darán alta de paquetes.*/
  PROCEDURE P_INSERT_ACCOUNT_SERVICE(PI_ACC_ID        IN VARCHAR2,
                                     PI_ARS_MOVE_TYPE IN VARCHAR2,
                                     PO_RESULT        OUT NUMBER,
                                     PO_ARS_ID        OUT NUMBER,
                                     PO_ERR_NUMBER    OUT NUMBER,
                                     PO_ERR_MESSAGE   OUT VARCHAR2);

  /* Inserta en la tabla ACC_REG_SERV_DETAIL cada línea y paquete detallados en los parametros
  PI_LINE_BILL_NUMBER y PI_PACKAGE_ID.
  Cada fila insertada se asocia a su cabecera de la tabla ACCOUNT_REGISTER_SERVICES a partir
  de la clave PI_ARS_ID.*/
  PROCEDURE P_INSERT_ACC_SERV_DETAIL(PI_ARS_ID           IN VARCHAR2,
                                     PI_LINE_BILL_NUMBER IN VARCHAR2,
                                     PI_PACKAGE_ID       IN VARCHAR2);
END PA_SAPCRM_INTEGRATION;

/

