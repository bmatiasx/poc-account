create PACKAGE BODY PA_USSD_CLAROCLUB IS

FUNCTION POINTS_EXCHANGE (P_NIM IN VARCHAR2
                         ,P_CONCEPT IN VARCHAR2
                         ,P_MIP_ID IN VARCHAR2
                         ,P_MEC_MAP_ID IN VARCHAR2
                         ,P_MIA_ID IN VARCHAR2
                         ,P_QUANTITY IN VARCHAR2
                         ,P_COMMENTS IN VARCHAR2
                         ,P_ERR_CODE OUT NUMBER
                         ,P_ERR_TEXT OUT VARCHAR2
                         ,P_SQL_CODE OUT VARCHAR2
                         ,P_RESPONSE OUT VARCHAR2) RETURN NUMBER
IS
  
  v_return  number;

BEGIN

  v_return := f_canjear_puntos(p_nim => p_nim,
                               p_concept => p_concept,
                               p_mip_id => p_mip_id,
                               p_mec_map_id => p_mec_map_id,
                               p_mia_id => p_mia_id,
                               p_quantity => p_quantity,
                               p_comments => p_comments,
                               p_err_no => P_ERR_CODE,
                               p_err_txt => P_ERR_TEXT);

  IF v_return <> 0 THEN
     P_ERR_CODE := P_ERR_CODE;
     P_SQL_CODE := P_ERR_TEXT;     
     P_ERR_TEXT:= PA_USSD_COMMON.GET_MESSAGE_USSD('MSGERRGEN');
     RETURN V_RETURN;
  END IF;

P_RESPONSE:= PA_USSD_COMMON.GET_MESSAGE_USSD('USSDCCCDC');
RETURN 0;  
  
EXCEPTION 
  WHEN OTHERS THEN
    P_ERR_CODE := P_ERR_CODE;
    P_SQL_CODE := P_ERR_TEXT;
    P_ERR_TEXT:= PA_USSD_COMMON.GET_MESSAGE_USSD('MSGERRGEN');
    RETURN - 1;
END POINTS_EXCHANGE;                                                

--
FUNCTION VALIDATE_ENTRY ( MSISDN IN OUT VARCHAR2,
                          P_CELLULAR_NUMBER OUT s_cellulars.clu_cellular_number%TYPE,
                          P_BALANCE OUT NUMBER,
                          P_ACC_ID OUT VARCHAR2,
                          P_CLT_ID OUT NUMBER,
                          P_CLT_SURNAME OUT VARCHAR2,
                          P_CLT_NAME OUT VARCHAR2,
                          P_OBTENIDOS OUT NUMBER,  
                          P_CANJEADOS OUT NUMBER, 
                          P_AVENCER OUT NUMBER, 
                          P_CADENA OUT VARCHAR2, 
                          P_FECHA_PROX_VTO OUT DATE, 
                          P_RESPONSE OUT VARCHAR2, 
                          P_MIP_ID OUT VARCHAR2,
                          P_MEC_MAP_ID OUT VARCHAR2,
                          P_ERR_TEXT OUT VARCHAR2,
                          P_ERR_CODE OUT NUMBER,
                          P_SQL_CODE OUT VARCHAR2) RETURN NUMBER
IS

  V_RETURN NUMBER;
  V_CELLULAR_NUMBER cellulars.clu_cellular_number%TYPE;
  V_BILL_NUMBER cellulars.clu_bill_number%TYPE;
  v_status cellulars.clu_mileage_status%TYPE;
  V_CATEGORIA VARCHAR2(100);
  V_PUNTOS_ACTULES VARCHAR2(8);
  v_fecha_prox_vto varchar2(10);

BEGIN

   v_cellular_number := PA_USSD_COMMON.GET_CELLULAR_NUMBER(PA_USSD_COMMON.GET_BILL_NUMBER(MSISDN));
   P_CELLULAR_NUMBER:= v_cellular_number;

  -- Validar si la linea esta activa
  BEGIN 
    SELECT clu.clu_mileage_status 
      INTO v_status 
      FROM cellulars clu
     WHERE clu.clu_cellular_number = v_cellular_number
       AND clu.clu_status = 'A';
  
       IF v_status is null then
        P_CELLULAR_NUMBER:= v_cellular_number; 
        P_ERR_TEXT:= PA_USSD_COMMON.GET_MESSAGE_USSD('USSDCCNA');
        P_ERR_CODE := 1; 
        RETURN 1;
       END IF;
   
   EXCEPTION 
     WHEN NO_DATA_FOUND THEN   
     P_ERR_TEXT:= 'NO_DATA_FOUND'; 
     P_ERR_CODE := -1;
     P_SQL_CODE := SQLCODE || ' ' || SQLERRM; 
     RETURN -1;
   END;
   
-- LLamado a funcion f_valida_nim_canjepremios para obtener mip_id y mec_map_id
/*

* 0 = Adherido y sin deuda

* -1 = -1 Otros errores 

* -1 = -10 El celular no existe o se encuentra cancelado/suspendido.

* -1 = -12 Este NIM esta cancelado en el programa de Cmrculo Claro.

* -2 = -17 Este NIM no esta activo en el programa de Cmrculo Claro.

* -3 = -24 Este NIM no ha registrado cargas en el ultimo mes. / Error obteniendo el ciclo de la cuenta. 

* -3 = -25 La cuenta de este NIM tiene una deuda de $

*/

  V_RETURN:= f_valida_nim_canjepremios(p_nim => V_CELLULAR_NUMBER,
                                       p_transfer => null, 
                                       p_acc_id => p_acc_id,
                                       p_bill_number => V_BILL_NUMBER,
                                       p_clt_id => p_clt_id,
                                       p_clt_surname => p_clt_surname,
                                       p_clt_name => p_clt_name,
                                       p_balance => p_balance,
                                       p_mip_id => p_mip_id,
                                       p_mec_map_id => p_mec_map_id,
                                       p_err_nro => P_ERR_CODE,
                                       p_err_txt => P_ERR_TEXT);   


  IF V_RETURN <> 0 THEN
     IF V_RETURN = -1 OR V_RETURN = -12 OR V_RETURN = -10 THEN
        P_ERR_CODE := V_RETURN; 
        P_ERR_TEXT := PA_USSD_COMMON.GET_MESSAGE_USSD('MSGERRGEN');   
        RETURN -1;
     ELSIF V_RETURN = -24 THEN        
        P_ERR_CODE := V_RETURN; 
        P_ERR_TEXT := PA_USSD_COMMON.GET_MESSAGE_USSD('USSDCCNC');   
        RETURN 3;
     ELSIF V_RETURN = -25 THEN        
        P_ERR_CODE := V_RETURN; 
        P_ERR_TEXT := PA_USSD_COMMON.GET_MESSAGE_USSD('USSDCCFI');   
        RETURN 3;
     END IF;
  END IF;     


/*LLamar a f_get_claro_circle_points para obtener puntos y p_err_message devuelve categoria 
cliente (PREPAGO, RED, BLACK)*/   

  V_RETURN:= f_get_claro_circle_points (p_cellular => v_cellular_number,
                                        p_quantity => P_BALANCE,
                                        p_err_number => P_ERR_CODE,
                                        p_err_message => P_ERR_TEXT);


  IF V_RETURN <> 0 then
     P_ERR_CODE := P_ERR_CODE;
     P_SQL_CODE := P_ERR_TEXT; 
     P_ERR_TEXT:= PA_USSD_COMMON.GET_MESSAGE_USSD('MSGERRGEN');   
     RETURN V_RETURN;
  END IF;

  V_CATEGORIA:= P_ERR_TEXT;

  V_RETURN:= QUERY_GRAL_POINTS (P_NIM => V_CELLULAR_NUMBER,
                                P_BILL_NUMBER => V_BILL_NUMBER,
                                P_ACC_ID => P_ACC_ID,
                                P_CLT_ID => P_CLT_ID,
                                P_CLT_SURNAME => P_CLT_SURNAME,
                                P_CLT_NAME => P_CLT_NAME,
                                P_BALANCE => P_BALANCE,
                                P_OBTENIDOS => P_OBTENIDOS,
                                P_CANJEADOS => P_CANJEADOS,
                                P_AVENCER => P_AVENCER,
                                P_RESPONSE => P_CADENA,
                                P_FECHA_PROX_VTO => P_FECHA_PROX_VTO,
                                P_ERR_TEXT => P_ERR_TEXT,
                                P_ERR_CODE => P_ERR_CODE,
                                P_SQL_CODE => P_SQL_CODE);

    IF V_RETURN <> 0 then
       P_ERR_CODE := P_ERR_CODE;
       P_SQL_CODE := P_ERR_TEXT; 
       P_ERR_TEXT:= PA_USSD_COMMON.GET_MESSAGE_USSD('MSGERRGEN');   
       RETURN V_RETURN;
    END IF;

   V_PUNTOS_ACTULES:= P_BALANCE;
   v_fecha_prox_vto:= TO_CHAR(P_FECHA_PROX_VTO, 'DD/MM/YYYY');

   IF V_PUNTOS_ACTULES = 0 THEN 
      P_RESPONSE:= '<POINTS>'||PA_USSD_COMMON.GET_MESSAGE_USSD('USSDCCT0P')||'</POINTS>';  
   ELSE 
      P_RESPONSE:= REPLACE(PA_USSD_COMMON.GET_MESSAGE_USSD('USSDCCPYC'), '$v(PTOS_ACT)', REPLACE(TO_CHAR(V_PUNTOS_ACTULES, 'FM9G999G999'), ',', '.')); 
      P_RESPONSE:= REPLACE(P_RESPONSE, '$v(CAT)', V_CATEGORIA); 
   END IF;

   IF P_AVENCER <> 0 THEN 
      P_RESPONSE:= P_RESPONSE||REPLACE(PA_USSD_COMMON.GET_MESSAGE_USSD('USSDCCFYA'), '$v(fecha_prox_vto)', v_fecha_prox_vto); 
      P_RESPONSE:= REPLACE(P_RESPONSE, '$v(avencer)', REPLACE(TO_CHAR(p_avencer, 'FM9G999G999'), ',', '.')); 
   END IF; 

   IF p_cadena IS NULL OR P_CADENA = ' ' THEN
      P_ERR_TEXT := NULL; 
      P_ERR_CODE:= 0;
      RETURN 0;
   ELSE 
      P_RESPONSE:= P_RESPONSE||'<LAST-EXCHANGES>'||p_cadena||'</LAST-EXCHANGES>'; 
      P_ERR_TEXT := NULL; 
      P_ERR_CODE:= 0;
      RETURN 0;
   END IF;

EXCEPTION
  WHEN OTHERS THEN
    P_SQL_CODE := SQLCODE || ' ' ||SQLERRM; 
    P_ERR_TEXT:= PA_USSD_COMMON.GET_MESSAGE_USSD('MSGERRGEN');  
    RETURN - 1;
END VALIDATE_ENTRY;

--

FUNCTION AVAILABLE_AWARDS  (P_NIM IN OUT VARCHAR2,
                            P_BALANCE IN VARCHAR2,
                            P_FILTER IN OUT VARCHAR2,
                            P_RESPONSE OUT VARCHAR2,
                            P_ERR_TEXT OUT VARCHAR2,
                            P_ERR_CODE OUT NUMBER,
                            P_SQL_CODE OUT VARCHAR2) RETURN NUMBER

IS

 P_RECORD_PRM_DSP PKG_MILLAJE.REC_PRM_DSP;
 P_RECORD_PRM_DSP_FILTER PKG_MILLAJE.REC_PRM_DSP;
 COD_FUNCTION NUMBER;
 V_IDX NUMBER;
 V_IDX_FILTER NUMBER:=0;
 V_MIA_TYPE VARCHAR2(50);
 V_CAT_FILTER VARCHAR2(300);

BEGIN
  
  COD_FUNCTION := PKG_MILLAJE.CONS_PRM_DISPONIBLES(P_NIM => P_NIM,
                                                   P_BALANCE =>  P_BALANCE,
                                                   RECORD_PRM_DSP => P_RECORD_PRM_DSP,
                                                   P_ERR_NO => P_ERR_CODE,
                                                   P_ERRTXT => P_ERR_TEXT);


  IF COD_FUNCTION <> 0 THEN 
     P_ERR_CODE := P_ERR_CODE;
     P_SQL_CODE := P_ERR_TEXT; 
     P_ERR_TEXT:= PA_USSD_COMMON.GET_MESSAGE_USSD('MSGERRGEN');   
     RETURN COD_FUNCTION;
  END IF;   

  BEGIN 

  SELECT NVL(STL_CHAR_VALUE, ' ') 
  INTO   V_CAT_FILTER
  FROM   STL_PARAMETERS
  where  STL_ID = 'USSDTC';
  
  EXCEPTION WHEN NO_DATA_FOUND THEN
            V_CAT_FILTER:= NULL;
  END;

  V_MIA_TYPE:= NULL;
  V_IDX := P_RECORD_PRM_DSP.FIRST;
  P_FILTER:= UPPER(P_FILTER);
   
    IF V_IDX >= 0 THEN

       FOR C IN P_RECORD_PRM_DSP.FIRST..P_RECORD_PRM_DSP.LAST LOOP 
           IF P_RECORD_PRM_DSP(V_IDX).P_VALIDATE <> 0 THEN 
              IF V_CAT_FILTER IS NULL OR INSTR(V_CAT_FILTER, '##'||P_RECORD_PRM_DSP(V_IDX).P_MIA_TYPE||'##') = 0 THEN 
                 IF P_FILTER IS NULL OR INSTR(P_RECORD_PRM_DSP(V_IDX).P_MIA_DESCRIPTION, P_FILTER) >= 1 THEN
                    P_RECORD_PRM_DSP_FILTER(V_IDX_FILTER):= P_RECORD_PRM_DSP(V_IDX);
                    V_IDX_FILTER:= V_IDX_FILTER + 1;                  
                 END IF;
              END IF;
           END IF;
       V_IDX:= V_IDX + 1;       
       END LOOP;

     V_IDX := P_RECORD_PRM_DSP_FILTER.FIRST;

     IF V_IDX IS NULL THEN
        P_ERR_TEXT:= PA_USSD_COMMON.GET_MESSAGE_USSD('USSDCCBNP');
        P_ERR_CODE:= 2;
        RETURN 1;
     END IF;
     
     P_RESPONSE:= '<PM>';
     FOR C IN P_RECORD_PRM_DSP_FILTER.FIRST..P_RECORD_PRM_DSP_FILTER.LAST LOOP 
         IF V_MIA_TYPE IS NULL THEN
            V_MIA_TYPE:= P_RECORD_PRM_DSP_FILTER(V_IDX).P_MIA_TYPE;
            P_RESPONSE:= P_RESPONSE||'<'||REPLACE(V_MIA_TYPE, ' ', '_' )||'>'; 
         END IF;

         IF V_MIA_TYPE <> P_RECORD_PRM_DSP_FILTER(V_IDX).P_MIA_TYPE THEN
            P_RESPONSE:= P_RESPONSE||'</'||REPLACE(V_MIA_TYPE, ' ', '_' )||'>';
            V_MIA_TYPE:= P_RECORD_PRM_DSP_FILTER(V_IDX).P_MIA_TYPE;
            P_RESPONSE:= P_RESPONSE||'<'||REPLACE(V_MIA_TYPE, ' ', '_' )||'>';
         END IF;
         P_RESPONSE:= P_RESPONSE||'<IT>'
                                ||'<ID>'||P_RECORD_PRM_DSP_FILTER(V_IDX).P_MIA_ID||'</ID>' 
                                ||'<DT>'||LOWER(P_RECORD_PRM_DSP_FILTER(V_IDX).P_MIA_DESCRIPTION)||'</DT>'
                                -- Validar py, separador de miles es ,
                                ||'<PT>'||REPLACE(TO_CHAR(P_RECORD_PRM_DSP_FILTER(V_IDX).P_MEC_POINTS, 'FM9G999G999'), ',', '.')||'</PT>'
                                ||'</IT>';
         V_IDX := V_IDX + 1;
     END LOOP;
     P_RESPONSE:= P_RESPONSE||'</'||REPLACE(V_MIA_TYPE, ' ', '_' )||'>';
     P_RESPONSE:=P_RESPONSE|| '</PM>';
  ELSE 
     P_ERR_TEXT:= PA_USSD_COMMON.GET_MESSAGE_USSD('USSDCCNP');
     P_ERR_CODE:= 1;
     RETURN 1;
  END IF;

  P_ERR_CODE:= 0;
  RETURN 0;
  --
EXCEPTION
   WHEN OTHERS THEN
        P_ERR_TEXT:= PA_USSD_COMMON.GET_MESSAGE_USSD('MSGERRGEN');  
        P_SQL_CODE := SQLCODE || ' ' ||SQLERRM; 
        RETURN (SQLCODE);
END AVAILABLE_AWARDS;

--

FUNCTION SUBSCRIBE_WELCOME_BONUS (nim cellular_mileages.cem_clu_cellular_number%type,
                                  err_code OUT NUMBER,
                                  err_txt OUT VARCHAR2,
                                  P_RESPONSE OUT VARCHAR2) RETURN NUMBER
IS

v_mip_id mileage_points.mip_id%type;
fallar EXCEPTION;
v_result number;

 BEGIN
/* Esta funcion se centraliza con la inserta_cellmileage que incluye todos los controles FL 05/06/2007
*/
 err_txt := 'Buscando la definicion del bono de bienvenida';
 select mip_id
 into   v_mip_id
 from   mileage_points
 where  mip_mpp_id = 'BBIENV'
 and    nvl(mip_end_date,sysdate + 1) > sysdate;
 
 v_result := PA_MILEAGE.Inserta_Cellmileage(P_NIM => nim,
                                            P_CEM_ID => v_mip_id,
                                            P_ERRTXT => err_txt);
 
 if v_result <> 0 then
    err_code := v_result;
    raise fallar;
 end if;
 
 err_txt:='OK';
 err_code:=0;
 P_RESPONSE:= PA_USSD_COMMON.GET_MESSAGE_USSD('USSDCCACC');
 RETURN 0;
 EXCEPTION
 WHEN fallar THEN
 err_code:= err_code;
 err_txt:= PA_USSD_COMMON.GET_MESSAGE_USSD('MSGERRGEN');
 RETURN -1;

 WHEN OTHERS THEN
 err_code:=-1;
 err_txt:= PA_USSD_COMMON.GET_MESSAGE_USSD('MSGERRGEN');
 RETURN -1;
END SUBSCRIBE_WELCOME_BONUS;

FUNCTION QUERY_GRAL_POINTS (P_NIM IN OUT VARCHAR2,
                            P_BILL_NUMBER IN OUT VARCHAR2,
                            P_ACC_ID OUT VARCHAR2,
                            P_CLT_ID OUT NUMBER,
                            P_CLT_SURNAME OUT VARCHAR2,
                            P_CLT_NAME OUT VARCHAR2,
                            P_BALANCE OUT VARCHAR2,
                            P_OBTENIDOS OUT NUMBER,
                            P_CANJEADOS OUT NUMBER,
                            P_AVENCER OUT NUMBER,
                            P_RESPONSE OUT VARCHAR2,
                            P_FECHA_PROX_VTO OUT DATE,
                            P_ERR_TEXT OUT VARCHAR2,
                            P_ERR_CODE OUT NUMBER,
                            P_SQL_CODE OUT VARCHAR2) RETURN NUMBER
IS

P_CEM_RECORD PKG_MILLAJE.REC_CELL_MIL;
V_IDX NUMBER;

BEGIN
     PKG_MILLAJE.CONSULTA_GRAL_PUNTOS( p_nim => P_NIM,
                                       p_clu_bill_number => P_BILL_NUMBER,
                                       p_clu_acc_id => P_ACC_ID,
                                       p_clt_id => P_CLT_ID,
                                       p_clt_surname => P_CLT_SURNAME,
                                       p_clt_name => P_CLT_NAME,
                                       p_balance => P_BALANCE,
                                       p_obtenidos => P_OBTENIDOS,
                                       p_canjeados => P_CANJEADOS,
                                       p_avencer => P_AVENCER,
                                       p_cem_record => P_CEM_RECORD,
                                       p_fecha_prox_vto => P_FECHA_PROX_VTO,
                                       p_errtxt => P_ERR_TEXT);

  V_IDX := P_CEM_RECORD.FIRST;

    IF NVL(V_IDX,-1) <> -1 THEN
       P_RESPONSE := '<premios>';
       FOR C IN P_CEM_RECORD.FIRST..P_CEM_RECORD.LAST LOOP
           IF P_CEM_RECORD(C).CEM_MOVEMENT_TYPE = 'D' AND 
              TO_CHAR(P_CEM_RECORD(V_IDX).CEM_MOVEMENT_DATE,'DD/MM/YYYY') >= TO_CHAR(SYSDATE-20, 'DD/MM/YYYY') THEN  
                IF P_CEM_RECORD(C).CEM_PIN IS NOT NULL THEN 
                   P_RESPONSE := P_RESPONSE  ||'<ITEM>'
                                             ||'<DATE>'||TO_CHAR(P_CEM_RECORD(C).CEM_MOVEMENT_DATE, 'DD/MM/YYYY')||'</DATE>'
                                             ||'<DESC>'||lower(P_CEM_RECORD(C).CEM_MIP_DESC)||' - PIN: '||P_CEM_RECORD(C).CEM_PIN||'</DESC>'
                                             ||'<PTS>'||REPLACE(TO_CHAR(P_CEM_RECORD(C).CEM_QUANTITY, 'FM9G999G999'), ',', '.')||'</PTS>'
                                             ||'</ITEM>';
                ELSE 
                   P_RESPONSE := P_RESPONSE  ||'<ITEM>'
                                             ||'<DATE>'||TO_CHAR(P_CEM_RECORD(C).CEM_MOVEMENT_DATE, 'DD/MM/YYYY')||'</DATE>'
                                             ||'<DESC>'||lower(P_CEM_RECORD(C).CEM_MIP_DESC)||'</DESC>'
                                             ||'<PTS>'||REPLACE(TO_CHAR(P_CEM_RECORD(C).CEM_QUANTITY, 'FM9G999G999'), ',', '.')||'</PTS>'
                                             ||'</ITEM>';
                END IF;
           END IF;
           V_IDX := V_IDX + 1;
       END LOOP;
       P_RESPONSE := P_RESPONSE||'</premios>';
          IF INSTR(P_RESPONSE, '<premios></premios>') = 1 THEN
             P_RESPONSE:= '';
             P_ERR_CODE := 0;
             RETURN 0;
          END IF;
    P_ERR_CODE := 0;
    RETURN 0;
    ELSE        
       P_ERR_TEXT := PA_USSD_COMMON.GET_MESSAGE_USSD('MSGERRGEN');
       P_ERR_CODE := 1;
       RETURN 1;
    END IF;

EXCEPTION
     WHEN OTHERS THEN
          P_ERR_CODE := P_ERR_CODE;
          P_SQL_CODE := P_ERR_TEXT; 
          P_ERR_TEXT:= PA_USSD_COMMON.GET_MESSAGE_USSD('MSGERRGEN');   
     RETURN -1;
END QUERY_GRAL_POINTS;

END PA_USSD_CLAROCLUB;
/

