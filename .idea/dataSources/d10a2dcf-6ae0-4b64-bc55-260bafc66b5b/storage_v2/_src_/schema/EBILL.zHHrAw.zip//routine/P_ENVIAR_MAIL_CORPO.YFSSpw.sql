create PROCEDURE P_ENVIAR_MAIL_CORPO

 (P_FROM IN VARCHAR2
 ,P_TO IN VARCHAR2
 ,P_CO IN VARCHAR2 := '''N'''
 ,P_SUBJECT IN VARCHAR2
 ,P_CONTENT IN VARCHAR2
 ,P_FILE IN VARCHAR2 := 'null'
 )
 IS
v_conn              utl_smtp.connection;
BOUNDARY            CONSTANT VARCHAR2(256) := '-----7D81B75CCC90D2974F7A1CBD';
MULTIPART_MIME_TYPE CONSTANT VARCHAR2(256) := 'multipart/mixed; boundary="'||BOUNDARY || '"';
FIRST_BOUNDARY      CONSTANT VARCHAR2(256) := '--' || BOUNDARY || utl_tcp.CRLF;
LAST_BOUNDARY       CONSTANT VARCHAR2(256) := '--' || BOUNDARY || '--' ||utl_tcp.CRLF;
----- 15/05/2006 -- Cambió el servidor de SMTP -----
--- Ya no se diferencia entre interno y externo ---
Host                VARCHAR2(255);   ---:='mailer.cti';
                         -- External 'smtp_inter'
                         -- Internal 'smtp_intra.cti'
------------------------------------------------------
Port                NUMBER(10):=25;
  procedure set_rcpts(p_char VARCHAR2) is
  v_recipients       VARCHAR2(5000);  --PC61044 cambio tamaño variable
  v_rcpt             VARCHAR2(100);
  begin
  v_recipients:=p_char;
  LOOP
    EXIT WHEN (v_recipients IS NULL);
    IF instr(v_recipients,';') > 0 THEN
       v_rcpt := substr(v_recipients,1,instr(v_recipients,';')-1);
       v_recipients := substr(v_recipients,instr(v_recipients,';')+1);
    ELSE
       v_rcpt := v_recipients;
       v_recipients := NULL;
    END IF;
    utl_smtp.rcpt(v_conn, v_rcpt);
  END LOOP;
  end;
begin
 ----- Ev. 46702 ---------------------------

  Select  stl_char_value
  into host
  from s_stl_parameters
  where stl_id = 'SEMAIL'
  and nvl(stl_end_date,sysdate+1) > sysdate;

 ----- Fin Ev. 46702 -----------------------

  v_conn:= utl_smtp.open_connection(Host, Port);

  utl_smtp.helo(v_conn, Host);
  utl_smtp.mail(v_conn,p_from);
  set_rcpts(p_to);
/*   write_mime_header(conn, 'From', sender);
     write_mime_header(conn, 'X-Mailer', MAILER_ID);  */

  utl_smtp.open_data(v_conn);
  if nvl(p_co,'N')='N'  then
     utl_smtp.write_data(v_conn, 'To: ' || p_to||utl_tcp.CRLF);
  end if;
  utl_smtp.write_data(v_conn, 'Subject: ' || p_subject||utl_tcp.CRLF);
--    utl_smtp.write_data(v_conn, 'Content-Type' || ': ' || MULTIPART_MIME_TYPE || utl_tcp.CRLF);

--LINEA PARA QUE MANDE MAILS CON FORMATO HTML PARA AUTOGESTION CORPO
    utl_smtp.write_data(v_conn, 'Content-Type' || ': ' || 'text/html' || utl_tcp.CRLF);


  utl_smtp.write_data(v_conn, utl_tcp.CRLF);
/*if p_file is not null then
   utl_smtp.write_data(v_conn, FIRST_BOUNDARY);
   utl_smtp.write_data(v_conn, 'Content-Type' || ': ' || 'text/plain'|| utl_tcp.CRLF);
   utl_smtp.write_data(v_conn, 'Content-Disposition: attachment; filename="'||p_file||'"');
   utl_smtp.write_data(v_conn, utl_tcp.CRLF);
   utl_smtp.write_data(v_conn, LAST_BOUNDARY);
end if;*/
  utl_smtp.write_data(v_conn, p_content);
  utl_smtp.close_data(v_conn);
  utl_smtp.quit(v_conn);
end;
/

