create materialized view S_PACKAGE_RESTRICTION_OP
refresh force on demand
  as
    SELECT prp_id,
prp_pkt_id,
prp_clt_category,
prp_cbt_id,
prp_available_up,
prp_available_change,
prp_available_down,
prp_available_view,
prp_start_date,
prp_end_date,
prp_clt_type,
prp_visible,
prp_order_view,
prp_channel_up
FROM stl.package_restriction_operations@PROD
/

