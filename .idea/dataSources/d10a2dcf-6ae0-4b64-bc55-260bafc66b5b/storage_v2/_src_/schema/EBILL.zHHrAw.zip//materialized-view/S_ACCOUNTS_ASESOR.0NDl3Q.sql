create materialized view S_ACCOUNTS_ASESOR
refresh complete on demand
  as
    select *
    from ACCOUNTS_ASESOR@PROD
   where nvl(AAR_FECHA_HASTA, SYSDATE+1) > SYSDATE
         AND AAR_FECHA_DESDE < SYSDATE
/

