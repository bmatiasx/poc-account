create FUNCTION NC_F_CHECK_DNI
 (P_DNI IN VARCHAR2
 ,P_ERROR_CODE OUT NUMBER
 ,P_ERROR_TEXT OUT VARCHAR2
 )
 RETURN NUMBER
 IS
/*
 *sistema........: webmaveric
 *implementación.: Control de datos para tipo de documento DNI.
 *actualizaciones:
 *29/11/2005     Silvina F. creado Ev_42199_Control_DNI_Argentina
 *10/04/2014     Diego S.   PC82893_CD101516_Tipo_Documento_EXT_A_Confirmar
*/
v_num    NUMBER;
v_value s_stl_parameters.stl_value%type;--Diego S.   PC82893_CD101516_Tipo_Documento_EXT_A_Confirmar
BEGIN

   IF instr(p_dni,'.') > 0 THEN
         p_error_text:='El número de DNI no es válido.';
         RETURN -1;
   END IF;

   IF length(p_dni)< 7 THEN
      p_error_text:='El número de DNI no es válido.';
      RETURN -1;
   END IF;

   ----Diego S. - PC82893_CD101516_Tipo_Documento_EXT_A_Confirmar
   SELECT stl_value --Se recupera la longitud maxima permitida para el tipo de documento DNI
   INTO v_value
   FROM s_stl_parameters
   WHERE stl_id = 'LONDNI';

   IF length(p_dni) > v_value THEN
      p_error_text := 'La longitud del DNI no puede superar los '||v_value||' caracteres';
      RETURN -1;
   END IF;
   ----

   BEGIN
      v_num := TO_NUMBER(p_dni);
   EXCEPTION
     WHEN OTHERS THEN
       p_error_text:='El Nro. DNI debe ser numérico';
       RETURN -1;
   END;

   RETURN 0;

 EXCEPTION
   WHEN OTHERS THEN
    p_error_text := 'NC_F_CHECK_DNI...Error: '||sqlerrm;
    RETURN(SQLCODE);
end NC_F_CHECK_DNI;
/

