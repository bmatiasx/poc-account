create FUNCTION F_CHANGE_NIM

 (P_BILL_NUMBER IN OUT VARCHAR2
 ,P_NEW_BILL_NUMBER IN OUT VARCHAR2
 ,P_BLOCK_CODE IN OUT VARCHAR2
 ,P_ACCOUNT_ID IN OUT VARCHAR2
 ,P_ERROR_CODE OUT INTEGER
 ,P_ERROR_MESSAGE OUT VARCHAR2
 )
 RETURN NUMBER
 IS
V_ACT_ID VARCHAR(100) := 'CMB#';
    V_STATUS VARCHAR(100) :=NULL;
     V_DESCRIPTION VARCHAR(300) := 'Cambio de número del NIM '  || P_BILL_NUMBER ||  ' por el NIM ' ||  P_NEW_BILL_NUMBER;
              RESULT_INSERT_TICKLER NUMBER;
              RESULT_CHANGE_NIM NUMBER;
BEGIN
                 RESULT_INSERT_TICKLER  := INSERT_TICKLER(act_id => V_ACT_ID,
                                            cellular_number => P_BILL_NUMBER,
                                            account_id => P_ACCOUNT_ID,
                                            rsn_id => NULL,
                                            descripcion => V_DESCRIPTION,
                                            status => V_STATUS);



             IF RESULT_INSERT_TICKLER = -1 THEN

                   P_ERROR_MESSAGE := 'Error al intentar insertar el ticlker. ' || V_STATUS;
                   P_ERROR_CODE := '100';
                   ROLLBACK;
                   RETURN 1;

             ELSE
               BEGIN

                                    RESULT_CHANGE_NIM := CAMBIO_NIM@PROD(P_NIM_OLD => P_BILL_NUMBER,
                                                                P_NIM_NEW => P_NEW_BILL_NUMBER,
                                                                P_BLK_ID => P_BLOCK_CODE,
                                                                P_TCK_ID => RESULT_INSERT_TICKLER,
                                                                P_ACC_NEW => P_ACCOUNT_ID,
                                                                POUT_MSG_ERR => P_ERROR_MESSAGE,
                                                                P_CMB_MODE => 'N',
                                                                P_INSERT_SWITCH => 'Y',
                                                                P_RAZON => NULL,
                                                                P_RSN_PN => NULL);
               IF RESULT_CHANGE_NIM !=0 THEN
                   P_ERROR_MESSAGE := P_ERROR_MESSAGE;
                   P_ERROR_CODE := '200';
                   ROLLBACK;
                   RETURN 1;
               END IF;
               END;
             END IF;
     COMMIT;
     RETURN 0;
END;
/

