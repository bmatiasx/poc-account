create PACKAGE PA_PHONE_COM_PROD IS

  Function phone_number(p_subno            VARCHAR2,
                        p_phone_number OUT VARCHAR2,
                        p_error        OUT VARCHAR2) RETURN NUMBER;

  Function phone_number(p_subno            VARCHAR2,
                        p_phone_number OUT VARCHAR2,
                        p_omp_id       OUT NUMBER,
                        p_error        OUT VARCHAR2) RETURN NUMBER;

--Funcion utilizada para obtencion de puntos para promo Blockbuster
-- Dario 05/04/2001
  Function phone_number_points(p_subno            VARCHAR2,
                        p_phone_number OUT VARCHAR2,
                        p_points       OUT NUMBER,
                        p_error        OUT VARCHAR2) RETURN NUMBER;

  Function phone_number_points_proces(p_celular            VARCHAR2,
                        p_passblock                 VARCHAR2,
                        p_tipopel                   VARCHAR2,
                        p_codigo_oper       OUT VARCHAR2,
                        p_error        OUT VARCHAR2) RETURN NUMBER;
END PA_PHONE_COM_PROD;
/

