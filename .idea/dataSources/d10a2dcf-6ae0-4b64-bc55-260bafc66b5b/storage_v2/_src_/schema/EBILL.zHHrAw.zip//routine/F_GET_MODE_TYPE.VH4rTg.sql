create FUNCTION F_get_mode_type

 (P_NIM     IN VARCHAR2,
  P_MODE_TYPE    OUT VARCHAR2,
  P_MSGERR  OUT VARCHAR2
 )
 RETURN NUMBER
 IS
  V_RESULT    NUMBER;

BEGIN

    V_RESULT := get_mode_type@PROD(P_NIM => P_NIM,
                                     P_MODE_TYPE => P_MODE_TYPE,
                                     P_MSGERR => P_MSGERR);
    IF V_RESULT <> 0 THEN
      RETURN V_RESULT;
    END IF;


  RETURN 0;


EXCEPTION
  WHEN OTHERS THEN
   
    P_MSGERR := 'ERROR AL CONSULTAR EL TIPO DE TECNOLOGIA';
    RETURN - 1;
END;
/

