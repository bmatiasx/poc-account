create package body Pa_prov_blackBerry_stl is
--Bb_Activation
  function Bb_Activation(p_imsi BLACKBERRY_INTERFACES.BBI_PARAM1%TYPE,
                         p_msisdn BLACKBERRY_INTERFACES.BBI_PARAM2%TYPE,
                         p_service BLACKBERRY_INTERFACES.BBI_PARAM3%TYPE,
                         p_pin varchar2 default null,
                         p_fecha date default null,
                         p_message out varchar2) return number is
  v_return                    number := 0;
  v_fecha                     date;
  BEGIN
    p_message := 'Bb_Activation';
    IF p_fecha IS NULL THEN
       v_fecha := SYSDATE;
    ELSE
       v_fecha := p_fecha;
    END IF;
    BEGIN
      INSERT INTO BLACKBERRY_INTERFACES(BBI_ID,
                                        BBI_ACTION,
                                        BBI_PARAM1,
                                        BBI_PARAM2,
                                        BBI_PARAM3,
                                        BBI_STATUS,
                                        BBI_SYSTEM_DATE,
                                        BBI_ACTION_DATE)
      VALUES (BLACKBERRY_INTERFACES_ID.NEXTVAL,
              cBB_ACTIVATE_SERVICE,
              p_imsi,
              p_msisdn,
              p_service,
              cPENDING_STATUS,
              SYSDATE,
              v_fecha);
    EXCEPTION
       WHEN OTHERS THEN
          p_message := cERR_001 ||' '|| TO_CHAR(SQLCODE) ||' '|| sqlerrm;
          raise e_error;
    END;
  p_message := '';
  return v_return;
  EXCEPTION
     WHEN e_error THEN
        v_return := -1;
        return v_return;
     WHEN others THEN
        v_return := -1;
        p_message := p_message||' '||TO_CHAR(SQLCODE)||' '||sqlerrm;
        return v_return;
  END;
--Bb_ChangeService
  function Bb_ChangeService(p_imsi BLACKBERRY_INTERFACES.BBI_PARAM1%TYPE,
                            p_service BLACKBERRY_INTERFACES.BBI_PARAM2%TYPE,
                            p_pin BLACKBERRY_INTERFACES.BBI_PARAM3%TYPE default null,
                            p_fecha date default null,
                            p_message out varchar2) return number is
  v_return                    number := 0;
  v_fecha                     date;
  BEGIN
    p_message := 'Bb_ChangeService';
    IF p_fecha IS NULL THEN
       v_fecha := SYSDATE;
    ELSE
       v_fecha := p_fecha;
    END IF;
    BEGIN
      INSERT INTO BLACKBERRY_INTERFACES(BBI_ID,
                                        BBI_ACTION,
                                        BBI_PARAM1,
                                        BBI_PARAM2,
                                        BBI_STATUS,
                                        BBI_SYSTEM_DATE,
                                        BBI_ACTION_DATE)
      VALUES (BLACKBERRY_INTERFACES_ID.NEXTVAL,
              cBB_CHANGE_SERVICE,
              p_imsi,
              p_service,
              cPENDING_STATUS,
              SYSDATE,
              v_fecha);
    EXCEPTION
       WHEN OTHERS THEN
          p_message := cERR_001 ||' '|| TO_CHAR(SQLCODE) ||' '|| sqlerrm;
          raise e_error;
    END;
  p_message := '';
  return v_return;
  EXCEPTION
     WHEN e_error THEN
        v_return := -1;
        return v_return;
     WHEN others THEN
        v_return := -1;
        p_message := p_message||' '||TO_CHAR(SQLCODE)||' '||sqlerrm;
        return v_return;
  END;
--Bb_Cancelation
  function Bb_Cancelation(p_imsi BLACKBERRY_INTERFACES.BBI_PARAM1%TYPE,
                          p_pin BLACKBERRY_INTERFACES.BBI_PARAM2%TYPE default null,
                          p_fecha date default null,
                          p_message out varchar2) return number  is
  v_return                    number := 0;
  v_fecha                     date;
  BEGIN
    p_message := 'Bb_Cancelation';
    IF p_fecha IS NULL THEN
       v_fecha := SYSDATE;
    ELSE
       v_fecha := p_fecha;
    END IF;
    BEGIN
      INSERT INTO BLACKBERRY_INTERFACES(BBI_ID,
                                        BBI_ACTION,
                                        BBI_PARAM1,
                                        BBI_STATUS,
                                        BBI_SYSTEM_DATE,
                                        BBI_ACTION_DATE)
      VALUES (BLACKBERRY_INTERFACES_ID.NEXTVAL,
              cBB_CANCEL_SERVICE,
              p_imsi,
              cPENDING_STATUS,
              SYSDATE,
              v_fecha);
    EXCEPTION
       WHEN OTHERS THEN
          p_message := cERR_001 ||' '|| TO_CHAR(SQLCODE) ||' '|| sqlerrm;
          raise e_error;
    END;
  p_message := '';
  return v_return;
  EXCEPTION
     WHEN e_error THEN
        v_return := -1;
        return v_return;
     WHEN others THEN
        v_return := -1;
        p_message := p_message||' '||TO_CHAR(SQLCODE)||' '||sqlerrm;
        return v_return;
  END;
--Bb_Suspend
  function Bb_Suspend(p_imsi BLACKBERRY_INTERFACES.BBI_PARAM1%TYPE,
                      p_pin BLACKBERRY_INTERFACES.BBI_PARAM2%TYPE default null,
                      p_fecha date default null,
                      p_message out varchar2) return number  is
  v_return                    number := 0;
  v_fecha                     date;
  BEGIN
    p_message := 'Bb_Suspend';
    IF p_fecha IS NULL THEN
       v_fecha := SYSDATE;
    ELSE
       v_fecha := p_fecha;
    END IF;
    BEGIN
      INSERT INTO BLACKBERRY_INTERFACES(BBI_ID,
                                        BBI_ACTION,
                                        BBI_PARAM1,
                                        BBI_STATUS,
                                        BBI_SYSTEM_DATE,
                                        BBI_ACTION_DATE)
      VALUES (BLACKBERRY_INTERFACES_ID.NEXTVAL,
              cBB_SUSPEND_SERVICE,
              p_imsi,
              cPENDING_STATUS,
              SYSDATE,
              v_fecha);
    EXCEPTION
       WHEN OTHERS THEN
          p_message := cERR_001 ||' '|| TO_CHAR(SQLCODE) ||' '|| sqlerrm;
          raise e_error;
    END;
  p_message := '';
  return v_return;
  EXCEPTION
     WHEN e_error THEN
        v_return := -1;
        return v_return;
     WHEN others THEN
        v_return := -1;
        p_message := p_message||' '||TO_CHAR(SQLCODE)||' '||sqlerrm;
        return v_return;
  END;
--Bb_Resume
  function Bb_Resume(p_imsi BLACKBERRY_INTERFACES.BBI_PARAM1%TYPE,
                     p_pin BLACKBERRY_INTERFACES.BBI_PARAM2%TYPE default null,
                     p_fecha date default null,
                     p_message OUT varchar2) return number  is
  v_return                    number := 0;
  v_fecha                     date;
  BEGIN
    p_message := 'Bb_Resume';
    IF p_fecha IS NULL THEN
       v_fecha := SYSDATE;
    ELSE
       v_fecha := p_fecha;
    END IF;
    BEGIN
      INSERT INTO BLACKBERRY_INTERFACES(BBI_ID,
                                        BBI_ACTION,
                                        BBI_PARAM1,
                                        BBI_STATUS,
                                        BBI_SYSTEM_DATE,
                                        BBI_ACTION_DATE)
      VALUES (BLACKBERRY_INTERFACES_ID.NEXTVAL,
              cBB_RESUME_SERVICE,
              p_imsi,
              cPENDING_STATUS,
              SYSDATE,
              v_fecha);
    EXCEPTION
       WHEN OTHERS THEN
          p_message := cERR_001 ||' '|| TO_CHAR(SQLCODE) ||' '|| sqlerrm;
          raise e_error;
    END;
  p_message := '';
  return v_return;
  EXCEPTION
     WHEN e_error THEN
        v_return := -1;
        return v_return;
     WHEN others THEN
        v_return := -1;
        p_message := p_message||' '||TO_CHAR(SQLCODE)||' '||sqlerrm;
        return v_return;
  END;
--Bb_ChangeBI
  function Bb_ChangeBI  (p_imsi  BLACKBERRY_INTERFACES.BBI_PARAM1%TYPE,
                         p_newImsi  BLACKBERRY_INTERFACES.BBI_PARAM2%TYPE,
                         p_fecha date default null,
                         p_message out varchar2) return number  is
  v_return                    number := 0;
  v_fecha                     date;
  v_message                   varchar2(1000);
  BEGIN
    p_message := 'Bb_ChangeBI';
    IF p_fecha IS NULL THEN
       v_fecha := SYSDATE;
    ELSE
       v_fecha := p_fecha;
    END IF;
    BEGIN
      INSERT INTO BLACKBERRY_INTERFACES(BBI_ID,
                                        BBI_ACTION,
                                        BBI_PARAM1,
                                        BBI_PARAM2,
                                        BBI_STATUS,
                                        BBI_SYSTEM_DATE,
                                        BBI_ACTION_DATE)
      VALUES (BLACKBERRY_INTERFACES_ID.NEXTVAL,
              cBB_CHANGE_BI,
              p_imsi,
              p_newImsi,
              cPENDING_STATUS,
              SYSDATE,
              v_fecha);
    EXCEPTION
       WHEN OTHERS THEN
          p_message := cERR_001 ||' '|| TO_CHAR(SQLCODE) ||' '|| sqlerrm;
          raise e_error;
    END;
  p_message := '';
  return v_return;
  EXCEPTION
     WHEN e_error THEN
        v_return := -1;
        return v_return;
     WHEN others THEN
        v_return := -1;
        p_message := p_message||' '||TO_CHAR(SQLCODE)||' '||sqlerrm;
        return v_return;
  END;
--Bb_ChangeNBI
  function Bb_ChangeNBI (p_imsi BLACKBERRY_INTERFACES.BBI_PARAM1%TYPE,
                         p_identifier BLACKBERRY_INTERFACES.BBI_PARAM2%TYPE,
                         p_newValue BLACKBERRY_INTERFACES.BBI_PARAM3%TYPE,
                         p_fecha date default null,
                         p_message OUT varchar2) return number  is
  v_return                    number := 0;
  v_fecha                     date;
  BEGIN
    p_message := 'Bb_ChangeNBI';
    IF p_fecha IS NULL THEN
       v_fecha := SYSDATE;
    ELSE
       v_fecha := p_fecha;
    END IF;
    BEGIN
      INSERT INTO BLACKBERRY_INTERFACES(BBI_ID,
                                        BBI_ACTION,
                                        BBI_PARAM1,
                                        BBI_PARAM2,
                                        BBI_PARAM3,
                                        BBI_STATUS,
                                        BBI_SYSTEM_DATE,
                                        BBI_ACTION_DATE)
      VALUES (BLACKBERRY_INTERFACES_ID.NEXTVAL,
              cBB_CHANGE_NON_BI,
              p_imsi,
              p_identifier,
              p_newValue,
              cPENDING_STATUS,
              SYSDATE,
              v_fecha);
    EXCEPTION
       WHEN OTHERS THEN
          p_message := cERR_001 ||' '|| TO_CHAR(SQLCODE) ||' '|| sqlerrm;
          raise e_error;
    END;
  p_message := '';
  return v_return;
  EXCEPTION
     WHEN e_error THEN
        v_return := -1;
        return v_return;
     WHEN others THEN
        v_return := -1;
        p_message := p_message||' '||TO_CHAR(SQLCODE)||' '||sqlerrm;
        return v_return;
  END;
--Bb_AssignService
  function Bb_AssignService(p_pin BLACKBERRY_INTERFACES.BBI_PARAM1%TYPE,
                            p_services BLACKBERRY_INTERFACES.BBI_PARAM2%TYPE default NULL,
                            p_fecha date default null,
                            p_message OUT varchar2) return number  is
  v_bbi_id                    BLACKBERRY_INTERFACES.BBI_ID%TYPE;
  v_return                    number := 0;
  v_fecha                     date;
  end_line                    number; -- indica el fin de linea
  res                         number; -- guarda el resultado de la funcion instr
  pos                         number:=1; -- guarda la posicion desde donde buscar
                                         --  cuando encuentra un delimitador.
  largo                       number; -- indica cuanto es el largo del campo a leer
  v_service                   BLACKBERRY_ASSIGN_PARAMS.BAP_SERVICE%TYPE;
  v_bnd_out                   number := 0;
  BEGIN
    p_message := 'Bb_AssignService';
    IF p_fecha IS NULL THEN
       v_fecha := SYSDATE;
    ELSE
       v_fecha := p_fecha;
    END IF;
    BEGIN
      SELECT BLACKBERRY_INTERFACES_ID.NEXTVAL
      INTO v_bbi_id
      FROM DUAL;
      INSERT INTO BLACKBERRY_INTERFACES(BBI_ID,
                                        BBI_ACTION,
                                        BBI_PARAM1,
                                        BBI_STATUS,
                                        BBI_SYSTEM_DATE,
                                        BBI_ACTION_DATE)
      VALUES (v_bbi_id,
              cBB_ASSIGN_SERVICES,
              p_pin,
              cPENDING_STATUS,
              SYSDATE,
              v_fecha);
    EXCEPTION
       WHEN OTHERS THEN
          p_message := cERR_001 ||' '|| TO_CHAR(SQLCODE) ||' '|| sqlerrm;
          raise e_error;
    END;
    end_line := length(p_services)+1;
    IF p_services is not null THEN
      loop
          v_service := '';
          -- busco la posicion del proximo delimitador
          res:=instr(p_services,chr(44),pos);
          -- calculo cuanto tengo que leer
           largo:= res - pos;
           if (res!= 0) then
              -- Busco el servicio
              v_service:=substr(p_services,pos,largo);
              pos:=res+1;
           ELSE
              -- Busco el ultimo servicio
              largo:= end_line - pos;
              v_service:=substr(p_services,pos,largo);
              v_bnd_out := 1; -- No busco mas
           END IF;
           BEGIN
             INSERT INTO BLACKBERRY_ASSIGN_PARAMS(BAP_ID,
                                                  BAP_BBI_ID,
                                                  BAP_SERVICE)
                         VALUES(BLACKBERRY_ASSIGN_PARAMS_ID.NEXTVAL,
                                v_bbi_id,
                                v_service);
           EXCEPTION
              WHEN OTHERS THEN
                 p_message := cERR_002 ||' '|| TO_CHAR(SQLCODE) ||' '|| sqlerrm;
                 raise e_error;
           END;
           IF v_bnd_out = 1 THEN
              exit; --Salgo del loop
           END IF;
      end loop;
  END IF;
  p_message := '';
  return v_return;
  EXCEPTION
     WHEN e_error THEN
        v_return := -1;
        return v_return;
     WHEN others THEN
        v_return := -1;
        p_message := p_message||' '||TO_CHAR(SQLCODE)||' '||sqlerrm;
        return v_return;
  END;
--Bb_SendDisplay
  function Bb_SendDisplay (p_imsi BLACKBERRY_INTERFACES.BBI_PARAM1%TYPE,
                           p_bbi_id out BLACKBERRY_INTERFACES.BBI_ID%TYPE,
                           p_message out varchar2) return number is
  v_return                    number := 0;
  BEGIN
    p_message := 'Bb_SendDisplay';
    BEGIN
      SELECT BLACKBERRY_INTERFACES_ID.NEXTVAL
      INTO p_bbi_id
      FROM DUAL;
      INSERT INTO BLACKBERRY_INTERFACES(BBI_ID,
                                        BBI_ACTION,
                                        BBI_PARAM1,
                                        BBI_STATUS,
                                        BBI_SYSTEM_DATE,
                                        BBI_ACTION_DATE)
      VALUES (p_bbi_id,
              cBB_DISPLAY_SERVICES,
              p_imsi,
              cPENDING_STATUS,
              SYSDATE,
              SYSDATE);
    EXCEPTION
       WHEN OTHERS THEN
          p_message := cERR_001 ||' '|| TO_CHAR(SQLCODE) ||' '|| sqlerrm;
          raise e_error;
    END;
  p_message := '';
  return v_return;
  EXCEPTION
     WHEN e_error THEN
        v_return := -1;
        return v_return;
     WHEN others THEN
        v_return := -1;
        p_message := p_message||' '||TO_CHAR(SQLCODE)||' '||sqlerrm;
        return v_return;
  END;
--Bb_GetStatus
function Bb_GetStatus (p_bbi_id BLACKBERRY_INTERFACES.BBI_ID%TYPE,
                       p_bbi_status out BLACKBERRY_INTERFACES.BBI_STATUS%TYPE,
                       p_bie_code out BLACKBERRY_INTERFACES_ERRORS.BIE_CODE%TYPE,
                       p_bie_description out BLACKBERRY_INTERFACES_ERRORS.BIE_DESCRIPTION%TYPE,
                       p_message out varchar2) return number is
  v_return                    number := 0;
  BEGIN
    p_message := 'Bb_GetStatus';
    BEGIN
      SELECT BBI_STATUS
      INTO p_bbi_status
      FROM BLACKBERRY_INTERFACES
      WHERE BBI_ID=p_bbi_id;
      IF p_bbi_status = 'E' THEN
         SELECT BIE_CODE,
                BIE_DESCRIPTION
         INTO   p_bie_code,
                p_bie_description
         FROM BLACKBERRY_INTERFACES_ERRORS
         WHERE BIE_BBI_ID=p_bbi_id;
      END IF;
    EXCEPTION
       WHEN OTHERS THEN
          p_message := cERR_200 ||' '|| TO_CHAR(SQLCODE) ||' '|| sqlerrm;
          raise e_error;
    END;
  p_message := '';
  return v_return;
  EXCEPTION
     WHEN e_error THEN
        v_return := -1;
        return v_return;
     WHEN others THEN
        v_return := -1;
        p_message := p_message||' '||TO_CHAR(SQLCODE)||' '||sqlerrm;
        return v_return;
  END;
--Bb_NotifyUpdate
  function Bb_NotifyUpdate (p_message OUT varchar2) return number is
  v_return                    number := 0;
  BEGIN
    v_return := PA_PROV_BLACKBERRY_TALKER.F_NOTIFY_UPDATE_BBI();
    p_message := '';
    return v_return;
  EXCEPTION
     WHEN others THEN
        v_return := -1;
        p_message := cERR_101;
        return v_return;
  END;
--Bb_NotifyReview
  function Bb_NotifyReview (p_message OUT varchar2) return number is
  v_return                    number := 0;
  BEGIN
    v_return := PA_PROV_BLACKBERRY_TALKER.F_NOTIFY_REVIEW_BBI();
    p_message := '';
    return v_return;
  EXCEPTION
     WHEN others THEN
        v_return := -1;
        p_message := cERR_102;
        return v_return;
  END;
end Pa_prov_blackBerry_stl;
/

