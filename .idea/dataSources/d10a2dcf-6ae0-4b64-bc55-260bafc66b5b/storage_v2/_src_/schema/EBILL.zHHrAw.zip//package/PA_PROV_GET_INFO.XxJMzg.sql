create package PA_PROV_GET_INFO is

  -- Author  : NBCORAR76
  -- Created : 25/07/2016 04:34:57 p.m.
  -- Purpose : -- obtener informacion varia
  TYPE T_CURSOR IS REF CURSOR;
  
  c_package_name  constant VARCHAR2(20)  := 'PA_PROV_GET_INFO.';
 
   
  PROCEDURE P_GET_MSISDN_CELLULAR_IMSI(p_Imsi            IN OUT S_SIMS.SIM_IMSI%TYPE,
                                       p_Msisdn          IN OUT S_SIMS.SIM_msisdn%TYPE,
                                       p_Cellular_Number IN OUT S_CELLULARS.CLU_CELLULAR_NUMBER%TYPE,
                                       p_Imei            IN CELLULAR_IMEI_TRACKINGS.CIM_IMEI%TYPE,
                                       p_Action_Date     IN DATE DEFAULT SYSDATE,
                                       p_Acc_Id          IN VARCHAR2 DEFAULT NULL);

  PROCEDURE P_GET_MSISDN_CELLULAR_IMSI(p_Imsi            IN OUT S_SIMS.SIM_IMSI%TYPE,
                                       p_Msisdn          IN OUT S_SIMS.SIM_msisdn%TYPE,
                                       p_Cellular_Number IN OUT S_CELLULARS.CLU_CELLULAR_NUMBER%TYPE,
                                       p_iccid           IN OUT sims.sim_iccid%TYPE,
                                       p_Imei            IN CELLULAR_IMEI_TRACKINGS.CIM_IMEI%TYPE,
                                       p_Action_Date     IN DATE DEFAULT SYSDATE,
                                       p_Acc_Id          IN VARCHAR2 DEFAULT NULL);


  FUNCTION P_GET_CELLULAR_INFO (pin_cellular_number IN OUT S_CELLULARS.CLU_CELLULAR_NUMBER%TYPE,
                                pout_cursor_cellular_info OUT T_CURSOR,
                                p_Action_Date     IN DATE DEFAULT SYSDATE,
                                pout_message              OUT VARCHAR2)
                                RETURN NUMBER; 
                                
  FUNCTION P_GET_TECHNOLOGY    (pin_cellular_number   IN  CELLULARS.CLU_CELLULAR_NUMBER%TYPE,
                                pin_Action_Date       IN  DATE DEFAULT SYSDATE,
                                pout_technology       OUT PRODUCTS.PRO_TECHNOLOGY%TYPE,
                                pout_message          OUT VARCHAR2)
                                RETURN NUMBER;   
                                
 PROCEDURE GET_ACTIVATE_SERVICE(pin_cellular_number          IN CELLULARS.CLU_CELLULAR_NUMBER%TYPE,
           	                    pin_feature                  IN VARCHAR2,
                                pin_package                  IN VARCHAR2,
                                pin_action_date              IN DATE,
                                pout_flag_active_service     OUT VARCHAR2,
                                pout_message                 OUT VARCHAR2);
                                                                                  



end PA_PROV_GET_INFO;
/

