create FUNCTION f_get_rpl_id2 (p_cellular_number     IN  cellulars.clu_cellular_number%TYPE,
                                         p_stg_id              IN  cellulars.clu_stg_id%TYPE, --> No es obligatorio ingresarlo.
                                         p_future_rpl_id       OUT future_rate_plans.frpl_rpl_id_future%TYPE,
                                         p_future_date         OUT future_rate_plans.frpl_end_date%TYPE,
                                         p_current_rpl_id      OUT cellular_plans.cpl_rpl_id%TYPE,
                                         p_current_date        OUT cellular_plans.cpl_start_date%TYPE,
                                         p_rpl_rty_id          OUT rate_plans.rpl_rty_id%TYPE,
                                         p_online              OUT VARCHAR2,
                                         p_msg_err             OUT VARCHAR2)
                  RETURN NUMBER IS

  /*************************************************************************************************
   * Nombre:        F_GET_RPL_ID                                                                   *
   * Proposito:     Busca el plan vigente de la línea.                                             *
   *                                                                                               *
   * Pais:          AUP                                                                            *
   *                                                                                               *
   * Módulo:       Customer                                                                        *
   * Autor:        Martín, Vallejo - Fernado, Petrei                                               *
   * Fecha:        10/10/2017                                                                      *
   *                                                                                               *
   * HISTORIAL DE MODIFICACIONES                                                                   *
   * Desarrollador                          Jira            Fecha          Observaciones           *
   * --------------------------------------------------------------------------------------------- *
   * Martín, Vallejo - Fernado, Petrei      CUST-460        10/10/2017     Creacion de la funcion  *
   *                                                                                               *
   *************************************************************************************************/

    v_clu_cellular_number  cellulars.clu_cellular_number%TYPE;
    v_stg_id               cellulars.clu_stg_id%TYPE;
    v_error                VARCHAR2(144);
    v_record               NUMBER := 0;

    CURSOR c_plan IS
       SELECT *
         FROM (SELECT cp.cpl_clu_cellular_number,
                      cp.cpl_stg_id,
                      cp.cpl_rpl_id,
                      cp.cpl_start_date,
                      cp.cpl_end_date,
                      cp.cpl_add_date,
                      rp.rpl_rty_id,
                      DECODE(cp.cpl_rpl_online,NULL,'N',cp.cpl_rpl_online) cpl_rpl_online,
                      LAG(cp.cpl_rpl_id,1,NULL) over(ORDER BY cp.cpl_start_date ASC) cpl_rpl_id_prev,
                      LAG(cpl_start_date,1,NULL) over(ORDER BY cp.cpl_start_date ASC) cpl_start_date_prev,
                      LAG(cpl_end_date,1,NULL) over(ORDER BY cp.cpl_start_date ASC) cpl_end_date_prev,
                      LAG(cpl_add_date,1,NULL) over(ORDER BY cp.cpl_start_date ASC) cpl_add_date_prev,
                      LAG(rpl_rty_id,1,NULL) over(ORDER BY cp.cpl_start_date ASC) rpl_rty_id_prev,
                      LAG(DECODE(cp.cpl_rpl_online,NULL,'N',cp.cpl_rpl_online),1,NULL) over(ORDER BY cp.cpl_start_date ASC) cpl_rpl_online_prev
                 FROM s_cellular_plans cp,
                      s_rate_plans rp
                WHERE rp.rpl_id = cp.cpl_rpl_id
                  AND cp.cpl_clu_cellular_number = v_clu_cellular_number
                  AND cp.cpl_stg_id = DECODE(p_stg_id,NULL,v_stg_id,p_stg_id)
                ORDER
                   BY cp.cpl_start_date DESC)
        WHERE ROWNUM < 2;

  BEGIN
     BEGIN
        SELECT clu_cellular_number,
               clu_stg_id
          INTO v_clu_cellular_number,
               v_stg_id
          FROM s_cellulars
         WHERE clu_cellular_number = p_cellular_number;
     EXCEPTION
          WHEN NO_DATA_FOUND THEN
               BEGIN
                  p_msg_err := 'Error f_get_rpl_id: Busqueda de línea - ' || SQLERRM;
                  SELECT clu_cellular_number,
                         clu_stg_id
                    INTO v_clu_cellular_number,
                         v_stg_id
                    FROM s_cellulars
                   WHERE clu_bill_number = p_cellular_number;
               EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                         p_msg_err := 'Error Busqueda de Bill Number: No se encuentra la línea que ingreso como párametro.';
                         RETURN 1;
                    WHEN OTHERS THEN
                         p_msg_err := 'Error Busqueda de Bill Number: Error al buscar la Línea - '|| SQLERRM;
                         RETURN 1;
               END;
          WHEN OTHERS THEN
               p_msg_err := 'Error Busqueda del NIM: Error al buscar la Línea - '|| SQLERRM;
               RETURN 1;
     END;

     FOR r_plan IN c_plan LOOP
         IF r_plan.cpl_rpl_online = 'Y' THEN
            IF SYSDATE < r_plan.cpl_start_date THEN
               p_current_rpl_id := r_plan.cpl_rpl_id;
               p_current_date   := r_plan.cpl_add_date;
               p_future_rpl_id  := r_plan.cpl_rpl_id;
               p_future_date    := r_plan.cpl_start_date;
               p_rpl_rty_id     := r_plan.rpl_rty_id;
               p_online         := r_plan.cpl_rpl_online;
               RETURN 0;
            ELSE
               p_current_rpl_id := r_plan.cpl_rpl_id;
               p_current_date   := r_plan.cpl_start_date;
               p_future_rpl_id  := r_plan.cpl_rpl_id;
               p_future_date    := r_plan.cpl_start_date;
               p_rpl_rty_id     := r_plan.rpl_rty_id;
               p_online         := r_plan.cpl_rpl_online;
               RETURN 0;
            END IF;
         ELSE
            IF SYSDATE < r_plan.cpl_start_date THEN
               p_current_rpl_id := r_plan.cpl_rpl_id;
               p_current_date   := r_plan.cpl_start_date;
               p_future_rpl_id  := r_plan.cpl_rpl_id;
               p_future_date    := r_plan.cpl_start_date;
               p_rpl_rty_id     := r_plan.rpl_rty_id;
               p_online         := r_plan.cpl_rpl_online;
               RETURN 0;
            ELSE
               p_current_rpl_id := r_plan.cpl_rpl_id;
               p_current_date   := r_plan.cpl_start_date;
               p_future_rpl_id  := r_plan.cpl_rpl_id;
               p_future_date    := r_plan.cpl_start_date;
               p_rpl_rty_id     := r_plan.rpl_rty_id;
               p_online         := r_plan.cpl_rpl_online;
               RETURN 0;
            END IF;
         END IF;

     END LOOP;

     RETURN 0;

  EXCEPTION
       WHEN OTHERS THEN
            p_msg_err := 'Error f_get_rpl_id: ' || SQLERRM;
            RETURN 1;
  END;
/

