create FUNCTION F_VALIDA_NUMERO_TEL_TOP

 (P_CELLULAR IN VARCHAR2
 ,P_ACC_ID IN VARCHAR2
 ,P_ERR_NUMBER OUT NUMBER
 ,P_ERR_MESSAGE OUT VARCHAR2
 )
 RETURN NUMBER
 IS
var_acc_id VARCHAR2(100);
var_cellular_status VARCHAR2(1);
fallar    EXCEPTION;
BEGIN

    SELECT c.clu_acc_id, c.clu_status
    INTO var_acc_id, var_cellular_status
    FROM s_cellulars c
    WHERE c.clu_bill_number = p_cellular;

    IF(var_cellular_status <> 'A') THEN
       P_ERR_NUMBER := -2;
       p_err_message := 'La línea no está activa';
       RETURN 1;
    END IF;
    IF(var_acc_id = p_acc_id) THEN
       P_ERR_NUMBER := -3;
       p_err_message := 'La línea pertenece a la misma cuenta';
       RETURN 1;
    END IF;
    RETURN 0;

EXCEPTION

  WHEN NO_DATA_FOUND THEN
      P_ERR_NUMBER := -1;
      p_err_message := 'La línea no pertenece a Claro';
      RETURN 1;
  WHEN TOO_MANY_ROWS THEN
     p_err_message := 'La consulta retorno mas de un elemento';
     P_ERR_NUMBER := -4;
     RETURN  1;
END F_VALIDA_NUMERO_TEL_TOP;
/

