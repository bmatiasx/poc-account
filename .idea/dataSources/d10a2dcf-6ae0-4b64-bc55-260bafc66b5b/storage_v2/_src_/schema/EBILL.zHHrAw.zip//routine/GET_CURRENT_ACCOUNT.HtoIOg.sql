create FUNCTION Get_Current_Account(p_clu_id VARCHAR2) RETURN VARCHAR2 AS

v_acc_id S_ACCOUNTS.acc_id%TYPE;
BEGIN
  SELECT cac_acc_id INTO v_acc_id
  FROM S_CELLULAR_ACCOUNTS
  WHERE TRUNC(cac_start_date) <= TRUNC(SYSDATE)
  AND  (cac_end_date >= TRUNC(SYSDATE) OR cac_end_date IS NULL)
  AND  cac_clu_cellular_number = p_clu_id;

  RETURN v_acc_id;
EXCEPTION
WHEN OTHERS THEN
  RETURN NULL;
END;
/

