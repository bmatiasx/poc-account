create PACKAGE BODY PA_WEB_GEOLOC IS


FUNCTION ValidaGroup (p_nameGroup IN VARCHAR2,
                     p_passGroup IN VARCHAR2,
                     p_clt_id OUT NUMBER,
                     p_client_name OUT VARCHAR2,
		     p_GCG_CLU_BILL_NUMBER_MASTER OUT VARCHAR2) RETURN NUMBER is
BEGIN
    RETURN stl.geoloc_gr.ValidaGroup@PROD
		(p_nameGroup 			=> p_nameGroup ,
                 p_passGroup 			=> p_passGroup,
                 p_clt_id 			=> p_clt_id,
                 p_client_name 			=> p_client_name,
		 p_GCG_CLU_BILL_NUMBER_MASTER 	=> p_GCG_CLU_BILL_NUMBER_MASTER);
EXCEPTION
    WHEN OTHERS THEN
        RETURN SQLCODE;
END;


FUNCTION ObtenerCellularNumber(p_bill_number in  varchar2,
                               p_cellular    out varchar2)
                               return number is
BEGIN
    RETURN web_consumo.ObtenerCellularNumber@PROD
            (bill_number  => p_bill_number,
            celular      => p_cellular);
EXCEPTION
    WHEN OTHERS THEN
        RETURN SQLCODE;
END;


FUNCTION ValidaPassClient(p_cellular_number in varchar2,
                          p_password        in varchar2,
                          p_clt_id          out number,
                          p_client_name     out varchar2)
                return number is
BEGIN
    return f_ValidaPassClient@PROD
            (P_CELLULAR_NUMBER  => p_cellular_number,
            P_PASSWORD          => p_password,
            P_CLT_ID            => p_clt_id,
            P_CLIENT_NAME       => p_client_name);
EXCEPTION
     WHEN OTHERS THEN
         P_CLT_ID := NULL;
         RETURN SQLCODE;
END;


FUNCTION loadDatosGrupo
            (p_GCG_name			IN  varchar2,
            p_GCG_clt_id		IN  number,
            p_GCG_ID 			out number,
            p_GCG_DESCRIPTION 	out varchar2,
            p_GCG_PASSWORD 		out varchar2,
            p_GCG_STATUS 		out varchar2,
            p_GCG_CLU_BILL_NUMBER_MASTER out varchar2)
     RETURN NUMBER is
BEGIN
    return stl.geoloc_gr.loadDatosGrupo@PROD
            (p_GCG_name			=> p_GCG_name,
            p_GCG_clt_id			=> p_GCG_clt_id,
            p_GCG_ID 			=> p_GCG_ID,
            p_GCG_DESCRIPTION 		=> p_GCG_DESCRIPTION ,
            p_GCG_PASSWORD 			=> p_GCG_PASSWORD ,
            p_GCG_STATUS 			=> p_GCG_STATUS ,
            p_GCG_CLU_BILL_NUMBER_MASTER 	=> p_GCG_CLU_BILL_NUMBER_MASTER);
EXCEPTION
     WHEN OTHERS THEN
         RETURN SQLCODE;
END;


FUNCTION getECP(p_cellular_number VARCHAR2,
            vout_ecp_id OUT VARCHAR2,
            vout_error OUT VARCHAR2)
        return number is
BEGIN
    return Pa_Geoloca.getECP@PROD(P_CELLULAR_NUMBER     => p_cellular_number,
                                VOUT_ECP_ID             => vout_ecp_id,
                                VOUT_ERROR              => vout_error);
EXCEPTION
    WHEN OTHERS THEN
      vout_error := SQLERRM;
      RETURN SQLCODE;
END;


FUNCTION where_am_i(p_cell_id VARCHAR2,
                    p_antena VARCHAR2,
                    p_ecp_id VARCHAR2,
                    vout_sites OUT VARCHAR2,
                    vout_neighborhood OUT VARCHAR2,
                    vout_cities OUT VARCHAR2,
                    vout_latitud OUT VARCHAR2,
                    vout_longitud OUT VARCHAR2,
                    vout_error OUT VARCHAR2)
     return number is
BEGIN
    return Pa_Geoloca.where_am_i@PROD(P_CELL_ID         => p_cell_id,
                                    P_ANTENA            => p_antena,
                                    P_ECP_ID            => p_ecp_id,
                                    VOUT_SITES          => vout_sites,
                                    VOUT_NEIGHBORHOOD   => vout_neighborhood,
                                    VOUT_CITIES         => vout_cities,
                                    VOUT_LATITUD        => vout_latitud,
                                    VOUT_LONGITUD       => vout_longitud,
                                    VOUT_ERROR          => vout_error);
EXCEPTION
    WHEN OTHERS THEN
      vout_error := SQLERRM;
      RETURN SQLCODE;
END;


Function where_am_i_gsm( bts_cell_id VARCHAR2,
                         lac         VARCHAR2,
                         mnc         VARCHAR2,
                         cell_id     OUT VARCHAR2,
                         site        OUT VARCHAR2,
                         latitude    OUT VARCHAR2,
                         longitude   OUT VARCHAR2,
                         error       OUT VARCHAR2 ) return number is
BEGIN
    return Pa_Geoloca.where_am_i_gsm(p_bts_cell_id  => bts_cell_id,
                                          p_lac          => lac,
                                          p_mnc          => mnc,
                                          p_cell_id      => cell_id,
                                          p_site         => site,
                                          p_latitude     => latitude,
                                          p_longitude    => longitude,
                                          p_error        => error);
EXCEPTION
    WHEN OTHERS THEN
      error := SQLERRM;
      RETURN SQLCODE;
END;


FUNCTION valida_celular( p_celular in VARCHAR2)
    return number is
BEGIN
    return WEB_GEOLOC.valida_celular@PROD(P_CELULAR => p_celular);
EXCEPTION
    WHEN OTHERS THEN
        RETURN SQLCODE;
END;


FUNCTION area_numero(p_clu_cellular_number IN VARCHAR2,
                     p_cod_area            OUT varchar2,
                     p_numero              OUT varchar2,
                     p_mensaje             OUT varchar2)
    RETURN number is
BEGIN
    return WEB_GEOLOC.area_numero@PROD(P_CLU_CELLULAR_NUMBER => p_clu_cellular_number,
                                    P_COD_AREA              => p_cod_area,
                                    P_NUMERO                => p_numero,
                                    P_MENSAJE               => p_mensaje);
EXCEPTION
    WHEN OTHERS THEN
        RETURN SQLCODE;
END;


FUNCTION encrypt(p_value IN VARCHAR2,
                p_result OUT VARCHAR2)
            RETURN NUMBER is
BEGIN
    return stl.Encrip_geoloc_id.encrypt@PROD(p_value => p_value,
                                        p_result => p_result);
EXCEPTION
    WHEN OTHERS THEN
        RETURN SQLCODE;
END;


FUNCTION decrypt(p_value IN VARCHAR2,
                p_result OUT VARCHAR2)
            RETURN NUMBER is
BEGIN
    return stl.Encrip_geoloc_id.decrypt@PROD(p_value => p_value,
                                        p_result => p_result);
EXCEPTION
    WHEN OTHERS THEN
        RETURN SQLCODE;
END;


FUNCTION get_id_geoloc(p_cellular_number   IN  VARCHAR2,
                       id_client_encripted OUT VARCHAR2,
                       p_bill_number       OUT VARCHAR2)
    RETURN NUMBER is
BEGIN
    return PA_GEOLOCA.get_id_geoloc@PROD(p_cellular_number  => p_cellular_number,
                                id_client_encripted         => id_client_encripted,
                                p_bill_number               => p_bill_number);
END;


FUNCTION insert_log(p_APPLICATION_NAME VARCHAR2,
                    p_NIM_LOGGED VARCHAR2,
		    p_NIM_LOCATED VARCHAR2,
		    p_status VARCHAR2, -- S (Solicitado) E (Enviado) C (Confirmado)
		    p_ERR_ID NUMBER,
 		    vout_rowid OUT VARCHAR2,
            p_GTL_CALL_TYPE VARCHAR2 DEFAULT NULL) RETURN NUMBER AS
BEGIN
    RETURN PA_GEOLOCA.insert_log@PROD(p_APPLICATION_NAME    => p_APPLICATION_NAME,
                                    p_NIM_LOGGED            => p_NIM_LOGGED,
                                    p_NIM_LOCATED           => p_NIM_LOCATED,
                                    p_status                => p_status,
                                    p_ERR_ID                => p_ERR_ID,
                                    vout_rowid              => vout_rowid,
                                    p_GTL_CALL_TYPE         => p_GTL_CALL_TYPE);
END;


FUNCTION update_log(p_rowid VARCHAR2,
		   p_latitude NUMBER,
		   p_longitude NUMBER,
		   p_status VARCHAR2,
		   p_err_id NUMBER ) RETURN NUMBER AS

BEGIN
    RETURN PA_GEOLOCA.update_log@PROD(p_rowid   => p_rowid,
                                    p_latitude  => p_latitude,
                                    p_longitude => p_longitude,
                                    p_status    => p_status,
                                    p_err_id    => p_err_id);
END;


FUNCTION ValidaPass_Client(p_client_id number,
                        p_password VARCHAR2,
                        p_client_name out VARCHAR2)RETURN NUMBER is
BEGIN
    RETURN stl.GEOLOC_GR.ValidaPassClient@PROD(p_client_id => p_client_id ,
			                   p_password => p_password ,
                        		   p_client_name => p_client_name);
EXCEPTION
    WHEN OTHERS THEN
        RETURN SQLCODE;
END;


FUNCTION valida_con_clt_id(p_clt_id IN number,
			   p_service IN VARCHAR2)RETURN NUMBER AS

BEGIN
    RETURN GLOBAL_PACKAGE_SERVICE.valida_con_clt_id@PROD(p_clt_id => p_clt_id ,
			                   		p_service => p_service);
EXCEPTION
    WHEN OTHERS THEN
        RETURN SQLCODE;
END;


-- insert en cabecera de geoloc_cellular_groups
FUNCTION create_group
            (p_GCG_name                     IN VARCHAR2,
            p_GCG_description               IN VARCHAR2,
            p_GCG_clt_id                    IN NUMBER,
            p_GCG_password                  IN VARCHAR2,
            p_GCG_CLU_BILL_NUMBER_MASTER    IN VARCHAR2,
            p_message                       OUT varchar2)
        RETURN  number as
BEGIN
    RETURN stl.GEOLOC_GR.create_group@PROD (p_GCG_name                     => p_GCG_name,
                                        p_GCG_description               => p_GCG_description,
                                        p_GCG_clt_id                    => p_GCG_clt_id,
                                        p_GCG_password                  => p_GCG_password,
                                        p_GCG_CLU_BILL_NUMBER_MASTER    => p_GCG_CLU_BILL_NUMBER_MASTER ,
                                        p_message 			=> p_message ) ;
EXCEPTION
    WHEN OTHERS THEN
        RETURN SQLCODE;
END;


-- delete cabecera y detalle de geoloc_cellular_groups y geoloc_cellular_groups_details
FUNCTION delete_group
            (p_GCG_name       IN VARCHAR2,
            p_GCG_clt_id      IN NUMBER,
            p_message         OUT varchar2)
        RETURN  number as
begin
    RETURN stl.GEOLOC_GR.delete_group@PROD (p_GCG_name         => p_GCG_name,
                                        p_GCG_clt_id       => p_GCG_clt_id,
                                        p_message          => p_message ) ;
EXCEPTION
    WHEN OTHERS THEN
        RETURN SQLCODE;
END;


-- insert cabecera y detalle en geoloc_cellular_groups y geoloc_cellular_groups_details
FUNCTION insert_ingroup_detail
        (p_GCG_name             IN VARCHAR2,
        p_GCG_clt_id            IN NUMBER,
        p_GGD_CLU_BILL_NUMBER_S IN varchar2,
        p_message               OUT varchar2)
    RETURN  number as
BEGIN
    RETURN stl.GEOLOC_GR.insert_ingroup_detail@PROD (p_GCG_name                => p_GCG_name,
                                                 p_GCG_clt_id              => p_GCG_clt_id,
                                                 p_GGD_CLU_BILL_NUMBER_S   => p_GGD_CLU_BILL_NUMBER_S,
                                                 p_message                 => p_message ) ;
EXCEPTION
    WHEN OTHERS THEN
        RETURN SQLCODE;
END;


--update descripcin de grupo
FUNCTION update_description
        (p_GCG_name         IN VARCHAR2,
        p_GCG_clt_id        IN NUMBER,
        p_GCG_description   IN VARCHAR2,
        p_message           OUT varchar2)
    RETURN  number as
BEGIN
    RETURN stl.GEOLOC_GR.update_description@PROD (p_GCG_name                => p_GCG_name,
                                              p_GCG_clt_id              => p_GCG_clt_id,
                                              p_GCG_description         => p_GCG_description,
                                              p_message                 => p_message ) ;
EXCEPTION
        WHEN OTHERS THEN
            RETURN SQLCODE;
END;


--update pass de grupo
FUNCTION update_pass
        (p_GCG_name                     IN VARCHAR2,
        p_GCG_clt_id                    IN NUMBER,
        p_GCG_password                  IN VARCHAR2,
        p_message OUT varchar2)
    RETURN  number as
BEGIN
    RETURN stl.GEOLOC_GR.update_pass@PROD (p_GCG_name                => p_GCG_name,
                                           p_GCG_clt_id              => p_GCG_clt_id,
                                           p_GCG_password            => p_GCG_password,
                                           p_message                 => p_message ) ;
EXCEPTION
       WHEN OTHERS THEN
           RETURN SQLCODE;
END;


--update bill_numbver a facturar del grupo
FUNCTION update_bill
        (p_GCG_name                     IN VARCHAR2,
        p_GCG_clt_id                    IN NUMBER,
        p_GCG_CLU_BILL_NUMBER_MASTER    IN VARCHAR2,
        p_message                       OUT varchar2)
    RETURN  number as
BEGIN
	RETURN stl.GEOLOC_GR.update_bill@PROD (p_GCG_name                  => p_GCG_name,
                                          p_GCG_clt_id                 => p_GCG_clt_id,
                                          p_GCG_CLU_BILL_NUMBER_MASTER => p_GCG_CLU_BILL_NUMBER_MASTER,
                                          p_message                    => p_message ) ;
EXCEPTION
    WHEN OTHERS THEN
       RETURN SQLCODE;
END;


-- Inicio SP para RR5
FUNCTION Validapass (celular IN VARCHAR2,
                        password1 IN VARCHAR2,
                        password2 IN VARCHAR2,
                        tipo_negocio_c OUT VARCHAR2,
                        tipo_cliente OUT VARCHAR2)
                RETURN NUMBER is
BEGIN
	RETURN web_consumo.Validapass@PROD (celular => celular,
                                          password1 => password1,
                                          password2 => password2,
                                          tipo_negocio_c => tipo_negocio_c,
                                          tipo_cliente   => tipo_cliente ) ;
EXCEPTION
    WHEN OTHERS THEN
       RETURN SQLCODE;
END;


FUNCTION Validanegocio (celular IN VARCHAR2,
                        tipo_negocio_c OUT VARCHAR2,
                        tipo_cliente OUT VARCHAR2)
                RETURN NUMBER is
begin
	RETURN web_consumo.Validanegocio@PROD (celular => celular,
                                          tipo_negocio_c => tipo_negocio_c,
                                          tipo_cliente   => tipo_cliente ) ;
EXCEPTION
    WHEN OTHERS THEN
       RETURN SQLCODE;
END;


FUNCTION get_option_rr5
        (p_clu_cellular_number IN VARCHAR2,
         p_funcionalidad OUT varchar2,
         p_frase OUT varchar2,
         p_inc_cpp OUT varchar2,
         p_inc_pico OUT varchar2,
         p_inc_nopico OUT varchar2,
         p_noinc_pico OUT varchar2,
         p_noinc_nopico OUT varchar2,
         p_mensaje OUT varchar2)
                RETURN NUMBER is
begin
	RETURN ivr_information.get_option_rr5@PROD (p_clu_cellular_number => p_clu_cellular_number,
                                          p_funcionalidad => p_funcionalidad,
                                          p_frase => p_frase,
                                          p_inc_cpp => p_inc_cpp,
                                          p_inc_pico => p_inc_pico,
                                          p_inc_nopico => p_inc_nopico,
                                          p_noinc_pico => p_noinc_pico,
                                          p_noinc_nopico => p_noinc_nopico,
                                          p_mensaje => p_mensaje) ;
EXCEPTION
    WHEN OTHERS THEN
       RETURN SQLCODE;
END;
-- Fin SP para RR5
END PA_WEB_GEOLOC;
/

