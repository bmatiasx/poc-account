create materialized view S_ACC_TYPE_CLU_BUSINESS_TYPES
refresh complete on demand
  as
    SELECT aby_cbt_id, aby_aty_id, aby_rty_id, aby_start_date, aby_end_date
FROM STL.acc_type_clu_business_types@PROD
  WHERE aby_start_date <  GET_DATE
AND NVL(aby_end_date, GET_DATE+1) > GET_DATE

/

