create PACKAGE PA_WEB_STATISTICS IS
  -- Author  : DBRITOS
  -- Created : 08/11/2005 12:11:23
  -- Purpose :
  function set_stat(pSessionID in varchar2,pStat in number,pUC in number,pApp in number,pCluCellularNumber in varchar2,pAccId in varchar2) return number;
END PA_WEB_STATISTICS;
/

