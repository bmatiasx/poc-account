create materialized view S_PACKAGE_RATE_PLANS
refresh complete on demand
  as
    SELECT pkr_pkt_id,
pkr_rpl_id,
pkr_price,
pkr_frt_id,
pkr_effective_date,
pkr_default,
pkr_end_date
FROM STL.package_rate_plans@PROD
/

