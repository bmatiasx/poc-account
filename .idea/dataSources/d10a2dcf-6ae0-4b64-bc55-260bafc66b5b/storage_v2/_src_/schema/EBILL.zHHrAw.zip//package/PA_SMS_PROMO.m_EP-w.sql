create PACKAGE PA_SMS_PROMO
IS
FUNCTION PROCESS_MESSAGES ( P_CELLULAR_NUMBER  IN VARCHAR2,
                            P_MESSAGE          IN VARCHAR2,
                            P_SHORT_NUMBER     IN VARCHAR2,
                            P_RESPONSE         OUT VARCHAR2,
                            P_MESSAGE_LOG      OUT VARCHAR2
                       ) RETURN NUMBER;

END;
/

