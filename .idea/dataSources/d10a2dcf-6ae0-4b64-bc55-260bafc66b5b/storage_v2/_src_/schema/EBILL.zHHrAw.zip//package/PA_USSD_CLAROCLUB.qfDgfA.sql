create PACKAGE PA_USSD_CLAROCLUB IS

FUNCTION POINTS_EXCHANGE (P_NIM IN VARCHAR2
                         ,P_CONCEPT IN VARCHAR2
                         ,P_MIP_ID IN VARCHAR2
                         ,P_MEC_MAP_ID IN VARCHAR2
                         ,P_MIA_ID IN VARCHAR2
                         ,P_QUANTITY IN VARCHAR2
                         ,P_COMMENTS IN VARCHAR2
                         ,P_ERR_CODE OUT NUMBER
                         ,P_ERR_TEXT OUT VARCHAR2
                         ,P_SQL_CODE OUT VARCHAR2
                         ,P_RESPONSE OUT VARCHAR2) RETURN NUMBER;
--
FUNCTION VALIDATE_ENTRY ( MSISDN IN OUT VARCHAR2,
                          P_CELLULAR_NUMBER OUT s_cellulars.clu_cellular_number%TYPE,
                          P_BALANCE OUT NUMBER,
                          P_ACC_ID OUT VARCHAR2,
                          P_CLT_ID OUT NUMBER,
                          P_CLT_SURNAME OUT VARCHAR2,
                          P_CLT_NAME OUT VARCHAR2,
                          P_OBTENIDOS OUT NUMBER,  
                          P_CANJEADOS OUT NUMBER, 
                          P_AVENCER OUT NUMBER, 
                          P_CADENA OUT VARCHAR2, 
                          P_FECHA_PROX_VTO OUT DATE, 
                          P_RESPONSE OUT VARCHAR2, 
                          P_MIP_ID OUT VARCHAR2,
                          P_MEC_MAP_ID OUT VARCHAR2,
                          P_ERR_TEXT OUT VARCHAR2,
                          P_ERR_CODE OUT NUMBER,
                          P_SQL_CODE OUT VARCHAR2) RETURN NUMBER;
                                
FUNCTION AVAILABLE_AWARDS  (P_NIM IN OUT VARCHAR2,
                            P_BALANCE IN VARCHAR2,
                            P_FILTER IN OUT VARCHAR2,
                            P_RESPONSE OUT VARCHAR2,
                            P_ERR_TEXT OUT VARCHAR2,
                            P_ERR_CODE OUT NUMBER,
                            P_SQL_CODE OUT VARCHAR2) RETURN NUMBER;  
                              
FUNCTION SUBSCRIBE_WELCOME_BONUS (nim cellular_mileages.cem_clu_cellular_number%type,
                             err_code OUT NUMBER,
                             err_txt OUT VARCHAR2,
                             P_RESPONSE OUT VARCHAR2) RETURN NUMBER;                                                            

FUNCTION QUERY_GRAL_POINTS (P_NIM IN OUT VARCHAR2,
                            P_BILL_NUMBER IN OUT VARCHAR2,
                            P_ACC_ID OUT VARCHAR2,
                            P_CLT_ID OUT NUMBER,
                            P_CLT_SURNAME OUT VARCHAR2,
                            P_CLT_NAME OUT VARCHAR2,
                            P_BALANCE OUT VARCHAR2,
                            P_OBTENIDOS OUT NUMBER,
                            P_CANJEADOS OUT NUMBER,
                            P_AVENCER OUT NUMBER,
                            P_RESPONSE OUT VARCHAR2,
                            P_FECHA_PROX_VTO OUT DATE,
                            P_ERR_TEXT OUT VARCHAR2,
                            P_ERR_CODE OUT NUMBER,
                            P_SQL_CODE OUT VARCHAR2) RETURN NUMBER;

END PA_USSD_CLAROCLUB;
/

