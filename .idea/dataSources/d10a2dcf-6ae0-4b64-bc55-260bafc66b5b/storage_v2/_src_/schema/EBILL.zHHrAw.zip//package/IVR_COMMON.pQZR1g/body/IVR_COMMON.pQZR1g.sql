create PACKAGE BODY IVR_COMMON
AS

/*
  11/10/2007: PC2336 - Msj Promo Dia. Agregado de funcion Validate_Promotion_Dia
              Autor: M.Bulgheroni.
              Se agrega funcionalidad para Video Llamada 
              Fecha: 24/10/2007     
              Desarrollador: Gallardo Fabián
  14/12/2007: PC7184 CD7834: Se agrega funciones validate_all_data y validate_date
     para ivr Infopago de Cobranzas
        Autor: M.Bulgheroni.
        
  30/01/2015: PC108576 *PAGO UY - Se modifico funcion F_GET_CLU_INFO para que retorne el tipo de linea (fijo o movil) 
              Autor: Gette Alan (EXA68274)
  03/03/2015 PC108092: Se grega la funcion F_OBTENER_PRIORIDAD_CR_CO, nos permite ver si una linea es priorizada o no. (parametros acotados en comparacion con la f_get_clu_info)
  12/03/2015 PC108092: Se corrige la funcion F_GET_CLU_INFO y F_OBTENER_PRIORIDAD_CR_CO para que en caso de que la MILEAGE_CATEGORY no tenga datos
  21/04/2015 PC116181: Se actualiza la funcion VALIDAR_INTENTO_SUSPENSION agregandose la restriccion de que no se permita realizar una 
                       suspension si ya se han realizado una nn cantidad de veces en los ultimos n dias determinados, donde n es definido por parametro. 
                       Autor: M.L.Giuga.
  21/04/2015 PC116181: Se actualiza la funcion SUSPENDER_VERIFICAR_IVR modificandose la informacion de contacto a enviar para la insercion del tickler. 
                       Autor: M.L.Giuga.
*/

---PC67150 migracion IVR







  FUNCTION F_CHECK_DNI(P_DNI        IN VARCHAR2,
                       P_ERROR_CODE OUT NUMBER,
                       P_ERROR_TEXT OUT VARCHAR2) RETURN NUMBER IS
  
  v_num    NUMBER;
  v_value s_stl_parameters.stl_value%type;

  BEGIN
   IF instr(p_dni,'.') > 0 OR length(p_dni) < 7 THEN
      P_ERROR_TEXT:='El número de DNI no es válido.';
      RETURN -1;
   END IF;

   --Se recupera la longitud maxima permitida para el tipo de documento DNI
   SELECT stl_value 
   INTO v_value
   FROM s_stl_parameters
   WHERE stl_id = 'LONDNI';

   IF length(p_dni) > v_value THEN
      P_ERROR_TEXT := 'La longitud del DNI no puede superar los '||v_value||' caracteres';
      RETURN -1;
   END IF;
   ----

   BEGIN
      v_num := TO_NUMBER(p_dni);
   EXCEPTION
     WHEN OTHERS THEN
       P_ERROR_TEXT:='El numero de DNI debe ser numerico';
       RETURN -1;
   END;
   RETURN 0;
  EXCEPTION
    WHEN OTHERS THEN
      P_ERROR_TEXT := P_ERROR_TEXT || sqlerrm;
      P_ERROR_CODE := SQLCODE;
      RETURN - 1;
  End F_CHECK_DNI;
  
  
  
  
  
  
  
Function VALIDATE_CUSTOMER_DATA(P_NUMBER     IN VARCHAR2,
                                  P_ERROR_CODE OUT NUMBER,
                                  P_ERROR_TEXT OUT VARCHAR2) RETURN NUMBER IS
  
    V_DOC         VARCHAR2(20);
    V_TEL_CONTACT VARCHAR2(30);
  
  BEGIN
  
    P_ERROR_CODE := 0;
    SELECT clt.clt_identification_number, clt.clt_bill_contact
      INTO V_DOC, V_TEL_CONTACT
      FROM CLIENT clt, CELLULARS cel, ACCOUNTS a
     WHERE a.acc_id = cel.clu_acc_id
       AND a.acc_clt_id = clt.clt_id
       AND CLU_CELLULAR_NUMBER = P_NUMBER;
  
    if V_DOC is null and V_TEL_CONTACT is null then
      P_ERROR_CODE := 3; --no Doc, no TEL
      P_ERROR_TEXT := 'Completar tipo y nro de doc y teléfono de contacto';
    elsif V_DOC is null then
      P_ERROR_CODE := 1; --no Doc 
      P_ERROR_TEXT := 'Completar tipo y nro de doc';
    elsif V_TEL_CONTACT is null then
      P_ERROR_CODE := 2; --no tel 
      P_ERROR_TEXT := 'Completar Teléfono de contacto ';
    end if;
  
    RETURN 0;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      P_ERROR_CODE := 3; --no Doc, no TEL
      P_ERROR_TEXT := 'Completar tipo y nro de doc y teléfono de contacto';
    
      RETURN 0;
    
    WHEN OTHERS THEN
      RETURN(SQLCODE);
    
  END VALIDATE_CUSTOMER_DATA;
 end;
/

