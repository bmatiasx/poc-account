create materialized view S_TELE_STATUS_ORDERS
refresh force on demand
  as
    SELECT SAO_ORH_ID, SAO_CHS_ID, SAO_DATE
  from TELE_STATUS_ORDERS@PROD
  WHERE 1 = 1 and sao_date >=  to_date('01/01/2013','dd/mm/yyyy')
/

