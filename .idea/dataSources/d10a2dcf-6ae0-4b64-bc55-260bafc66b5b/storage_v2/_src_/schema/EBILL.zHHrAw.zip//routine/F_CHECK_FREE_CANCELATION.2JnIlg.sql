create FUNCTION F_CHECK_FREE_CANCELATION
 (P_ACCOUNT IN VARCHAR2
 ,P_TOTAL_LINEAS_ACTIVAS_SUSP OUT NUMBER
 ,P_CANCELADAS_GRATIS OUT NUMBER
 ,P_DISPONIBLES_CANCELAR OUT NUMBER
 ,P_ERR_NUMBER OUT NUMBER
 ,P_ERR_MESSAGE OUT VARCHAR2
 )
 RETURN NUMBER
 IS
v_desc_error                   VARCHAR2(250);
v_aty_id                          s_accounts.acc_aty_id%TYPE;
v_clt_id                           s_client.clt_id%TYPE ;
v_clt_type                        s_client.clt_type%TYPE ;
v_cit_percent_free_cancelation  NUMBER;
v_total_gral                    NUMBER:=0;
BEGIN

    v_desc_error := 'Obteniendo Id cliente y tipo de Cuenta';
     SELECT acc_aty_id,
                 acc.acc_clt_id,
                 cli.clt_type
      INTO v_aty_id,
              v_clt_id,
              v_clt_type
      FROM s_accounts  acc 
              ,s_client    cli
      WHERE acc.acc_clt_id = cli.clt_id
      AND acc.acc_id = p_account;

    v_desc_error := 'Obteniendo porcentaje cancelaciones exentas del cobro por Tipo Cuenta' ;
    BEGIN
       SELECT nvl(cit_percent_free_cancelation , 0)
       
         INTO v_cit_percent_free_cancelation
         FROM s_client_types
        WHERE cit_id = v_aty_id ;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
          v_desc_error := 'Obteniendo porcentaje cancelaciones exentas del cobro por Tipo Cliente' ;
          SELECT nvl(cit_percent_free_cancelation , 0)
            INTO v_cit_percent_free_cancelation
            FROM s_client_types
           WHERE cit_id = v_clt_type ; 
           
    END;

    ------------------------------------------------------------------
    --- Si el porcentaje de exentos es Mayor a cero
    --- se debe verificar si esta linea se puede cancelar gratis.
    ------------------------------------------------------------------

    IF  v_cit_percent_free_cancelation > 0 THEN
  
          v_desc_error := 'Obteniendo total de líneas activas y suspendidas' ;
            SELECT count(1)
            INTO p_total_lineas_activas_susp
            FROM s_accounts ,
                     s_cellulars
           WHERE clu_acc_id = acc_id   
            AND clu_status in ( 'A' , 'S' ) 
            AND acc_clt_id = v_clt_id; 
            
          v_desc_error := 'Obteniendo cantidad de líneas que ya fueron canceladas gratis los últimos 365 días';
           SELECT COUNT(1)
             INTO p_canceladas_gratis
             FROM s_free_counter_cancelations
            WHERE fcc_clt_id = v_clt_id 
            AND fcc_creation_date  > SYSDATE - 365;

           v_total_gral := p_total_lineas_activas_susp + p_canceladas_gratis;
           p_disponibles_cancelar := TRUNC(  (v_total_gral * v_cit_percent_free_cancelation) / 100 ) - p_canceladas_gratis;
    END IF;

    p_total_lineas_activas_susp := nvl(p_total_lineas_activas_susp, 0);
    p_canceladas_gratis := nvl(p_canceladas_gratis, 0);
    
    p_disponibles_cancelar :=nvl(p_disponibles_cancelar, 0);

    RETURN 0;
    
EXCEPTION
WHEN OTHERS THEN
    p_err_number := SQLCODE;
    p_err_message := 'Error. ' || v_desc_error || ' - ' || SQLERRM;
    RETURN -1;
END F_CHECK_FREE_CANCELATION;
/

