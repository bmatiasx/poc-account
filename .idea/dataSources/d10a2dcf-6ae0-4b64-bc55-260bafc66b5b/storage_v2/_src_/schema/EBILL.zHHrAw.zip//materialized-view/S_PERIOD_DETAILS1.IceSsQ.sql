create materialized view S_PERIOD_DETAILS1
refresh complete on demand
  as
    SELECT PED_PER_ID,
       PED_START_RANGE,
       PED_END_RANGE,
       PED_EFFECTIVE_DATE,
       PED_TPT_ID,
       PED_DURATION,
       PED_PERCENTAGE_UNIT,
       PED_END_DATE
  FROM test.PERIOD_DETAILS@PROD
/

