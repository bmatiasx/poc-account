create package body operaciones is

  function operar(parametro1     in varchar2,
                  parametro2     in varchar2,
                  suma           out varchar2,
                  multiplicacion out varchar2) return number is
  
  begin
    suma := to_number(parametro1) + to_number(parametro2);
    dbms_output.put_line('SUMA: ' || suma);
    multiplicacion := parametro1 * parametro2;
    dbms_output.put_line('MULTIPLICACI¿N: ' || multiplicacion);
    return 0;
  
  exception
    when others then
      dbms_output.put_line(SQLERRM);
      return - 1;
  end;

end operaciones;
/

