create materialized view S_FREE_PERIOD_CELLULAR_USAGES
on prebuilt table
refresh force on demand
  as
    SELECT /*+ FULL(A) PARALLEL(A,6)*/
 fcu_frm_rpl_id,
 fcu_frm_stc_id,
 fcu_frm_tpc_id,
 fcu_frm_call_direction,
 fcu_frm_start_date,
 fcu_free,
 fcu_free_usages,
 fcu_inc_id,
 fcu_start_date,
 fcu_end_date,
 fcu_clu_cellular_number,
 fcu_frm_dtc_id,
 fcu_frm_cyclic_flag
 FROM   test.FREE_PERIOD_CELLULAR_USAGES@SPB1.WORLD A
 WHERE  NVL (fcu_end_date, TO_DATE ('01022014', 'ddmmyyyy')) > TO_DATE ('31012014', 'ddmmyyyy')

/

