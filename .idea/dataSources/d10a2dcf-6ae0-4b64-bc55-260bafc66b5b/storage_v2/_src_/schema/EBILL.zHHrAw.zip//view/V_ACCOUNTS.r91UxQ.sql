create view V_ACCOUNTS as
  select ACC_ID, ACC_CLT_ID, acc_e_mail, ACC_CYC_ID from accounts
/

