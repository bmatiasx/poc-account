create materialized view S_CELLULAR_CALL_RESTRICTIONS
refresh complete on demand
  as
    SELECT CCR_ID,
       CCR_CR_ID,
       CCR_START_DATE,
       CCR_TCK_ID,
       CCR_RMR_ID,
       CCR_USR_ID,
       CCR_CLU_CELLULAR_NUMBER,
       CCR_END_DATE,
       CCR_LAST_UPDATED_DATE,
       CCR_RSN_ID
  FROM STL.CELLULAR_CALL_RESTRICTIONS@prod
/

