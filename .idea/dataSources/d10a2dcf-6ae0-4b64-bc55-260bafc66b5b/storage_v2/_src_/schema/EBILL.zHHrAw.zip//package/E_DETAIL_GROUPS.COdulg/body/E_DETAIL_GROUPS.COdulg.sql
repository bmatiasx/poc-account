create PACKAGE BODY E_DETAIL_GROUPS IS
FUNCTION insert_account_group
        (p_ega_name       IN ed_group_accounts.ega_name%type,
        p_ega_description IN ed_group_accounts.ega_description%type,
        p_ega_clt_id      IN ed_group_accounts.ega_clt_id%type,
        p_message OUT varchar2)
        RETURN  number is

    v_count_name               number;

begin
    SELECT count(*)
      INTO v_count_name
      FROM ed_group_accounts
     WHERE ega_name   = upper(p_ega_name)
       AND ega_clt_id = p_ega_clt_id;

    if (v_count_name > 0) then
        p_message := 'ya existe el grupo: ' || upper(p_ega_name);
        return 2;   -- el nombre ya esta usado, el usuario debe elegir otro nombre.
    else
        -- el nombre es correcto, se procede a insertar el grupo.
        INSERT INTO ed_group_accounts(ega_id, ega_clt_id, ega_name, ega_description)
        VALUES (ed_group_seq.nextval, p_ega_clt_id, upper(p_ega_name), p_ega_description);

        commit; -- deberma estar en la aplicacisn, pero por ahora esta aca.

        p_message := 'OK';
        return 0;
    end if;

EXCEPTION
      WHEN OTHERS THEN
          rollback; -- deberma estar en la aplicacisn, pero por ahora esta aca.
          p_message := 'Error:' || SQLCODE || p_message;
          return -1;
end;


FUNCTION delete_account_group
        (p_ega_name       IN ed_group_accounts.ega_name%type,
        p_ega_clt_id      IN ed_group_accounts.ega_clt_id%type,
        p_message OUT varchar2)
        RETURN  number is

    v_ega_id               ed_group_accounts.ega_id%type;

begin
    SELECT ega_id
      INTO v_ega_id
      FROM ed_group_accounts
     WHERE ega_name   = upper(p_ega_name)
       AND ega_clt_id = p_ega_clt_id;


    DELETE
      FROM ed_group_account_include
     WHERE eai_ega_id = v_ega_id;

    DELETE
      FROM ed_group_accounts
     WHERE ega_id = v_ega_id;

    commit; -- deberma estar en la aplicacisn, pero por ahora esta aca.
    p_message := 'OK';
    return 0;

EXCEPTION
      WHEN OTHERS THEN
          rollback; -- deberma estar en la aplicacisn, pero por ahora esta aca.
          p_message := 'Error:' || SQLCODE || p_message;
          return -1;
end;



FUNCTION insert_account_ingroup( p_ega_name        IN  ed_group_accounts.ega_name%type,
                                 p_ega_clt_id      IN  ed_group_accounts.ega_clt_id%type,
                                 p_account_string  IN  varchar2,
                                 p_message         OUT varchar2 ) RETURN number is

v_ega_id        ed_group_accounts.ega_id%type;
v_acc_id        varchar2(10);
posicion        number;
p_string_tmp    varchar2(2000);

BEGIN
    ---------------------------------
    -- Borra todas las cuentas que pertenecen al grupo pasado por parametro --
    ---------------------------------
    select ega_id
      into v_ega_id
      from ed_group_accounts
     where ega_name   = p_ega_name
       and ega_clt_id = p_ega_clt_id;

    DELETE
      FROM ed_group_account_include
     WHERE eai_ega_id = v_ega_id;


    -------------------
    -- Check cuentas --
    -------------------
    if p_account_string = '#' or p_account_string is null or p_account_string = '' then
        p_message := 'sali por falta de parametro in';
        return 0;
    end if;

    ------------------------
    -- Recorrer el string -- <acc_id>#<acc_id>#...
    ------------------------
    p_string_tmp := p_account_string;
    loop
        posicion :=  instr(p_string_tmp,'#') - 1;
        dbms_output.put_line('posicion: ' || posicion);

        v_acc_id := substr(p_string_tmp,1,posicion);
        p_string_tmp := substr(p_string_tmp,posicion+2,length(p_string_tmp));
        dbms_output.put_line('cuenta: ' || v_acc_id);
        dbms_output.put_line('string restante: ' || p_string_tmp);

        INSERT INTO ed_group_account_include(eai_ega_id, eai_acc_id, eai_clu_bill_number)
        VALUES (v_ega_id, v_acc_id, null);

        exit when   posicion = 0 or p_string_tmp = '#' or p_string_tmp is null;
    end loop;

    commit; -- deberma estar en la aplicacisn, pero por ahora esta aca.
    p_message := 'Insert Ok';
    return 0;

EXCEPTION
      WHEN OTHERS THEN
          rollback; -- deberma estar en la aplicacisn, pero por ahora esta aca.
          p_message := 'Error:' || SQLCODE || p_message;
          return -1;

end;



FUNCTION insert_lines_ingroup( p_ega_name        IN  ed_group_accounts.ega_name%type,
                                 p_ega_clt_id    IN  ed_group_accounts.ega_clt_id%type,
                                 p_lines_string  IN  varchar2,
                                 p_message       OUT varchar2 ) RETURN number is

v_ega_id        ed_group_accounts.ega_id%type;
v_cell_number   varchar2(10);
v_account_id    varchar2(10);
posicion        number;
p_string_tmp    varchar2(2000);

BEGIN
    ---------------------------------
    -- Borra todas las lineas que pertenecen al grupo pasado por parametro --
    ---------------------------------
    select ega_id
      into v_ega_id
      from ed_group_accounts
     where ega_name   = p_ega_name
       and ega_clt_id = p_ega_clt_id;

    DELETE
      FROM ed_group_account_include
     WHERE eai_ega_id = v_ega_id;


    -------------------
    -- Check cuentas --
    -------------------
    if p_lines_string = '#' or p_lines_string is null or p_lines_string = '' then
        p_message := 'Error en los parametros: P_LINES_STRING';
        return 0;
    end if;

    ------------------------
    -- Recorrer el string -- <cellular_number> # <cellular_number> #...
    ------------------------
    p_string_tmp := p_lines_string;
    loop
        posicion :=  instr(p_string_tmp,'#') - 1;
        v_cell_number := substr(p_string_tmp, 1, posicion );
        p_string_tmp := substr(p_string_tmp, posicion+2, length(p_string_tmp) );

        posicion :=  instr(p_string_tmp,'#') - 1;
        v_account_id := substr( p_string_tmp, 1, posicion );
        p_string_tmp := substr(p_string_tmp, posicion+2, length(p_string_tmp) );

        dbms_output.put_line('celular: ' || v_cell_number);
        dbms_output.put_line('cuenta:  ' || v_account_id);
        dbms_output.put_line('string restante: ' || p_string_tmp);

        INSERT INTO ed_group_account_include(eai_ega_id, eai_acc_id, eai_clu_bill_number)
        VALUES (v_ega_id, v_account_id, v_cell_number);

        exit when   posicion = 0 or p_string_tmp = '#' or p_string_tmp is null;
    end loop;

    commit; -- deberma estar en la aplicacisn, pero por ahora esta aca.
    p_message := 'Insert Ok';
    return 0;

EXCEPTION
      WHEN OTHERS THEN
          rollback; -- deberma estar en la aplicacisn, pero por ahora esta aca.
          p_message := 'Error:' || SQLCODE || p_message;
          return -1;

end;
END E_DETAIL_GROUPS;
/

