create FUNCTION F_CONSULTAR_ESTADO_ORDEN
 (P_NRO_ORDEN IN VARCHAR2
 ,P_FEC_ING_ORDEN OUT VARCHAR2
 ,P_IMP_ORDEN OUT VARCHAR2
 ,P_ESTADO_ORDEN OUT VARCHAR2
 ,P_DESC_EQUIPO OUT VARCHAR2
 ,P_ERROR OUT VARCHAR2
 )
 RETURN NUMBER
 IS
V_RESULT    NUMBER;
BEGIN

 V_RESULT := PKG_SERVICIO_TECNICO.CONSULTAR_ESTADO_ORDEN(P_NRO_ORDEN,
                                                            P_FEC_ING_ORDEN,
                                                            P_IMP_ORDEN,
                                                            P_ESTADO_ORDEN,
                                                            P_DESC_EQUIPO,
                                                            P_ERROR);
    IF V_RESULT <> 0 THEN
      RETURN V_RESULT;
    END IF;

   
  RETURN 0;


EXCEPTION
  WHEN OTHERS THEN
    
    P_ERROR := 'Error '; 
    RETURN - 1;
END;
/

