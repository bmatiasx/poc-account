create package body PA_WS_ECOM_INTERFACE is

FUNCTION F_INTERFACE_CLIENTS(p_inc_ino_orh_id NUMBER,
                               p_inc_type_doc   VARCHAR2,
                               p_inc_nro_doc    NUMBER,
                               p_inc_last_name  VARCHAR2,
                               p_inc_first_name VARCHAR2,
                               p_inc_birth_date DATE,
                               p_inc_telephone  VARCHAR2,
                               p_inc_type       VARCHAR2) RETURN NUMBER IS
  
  BEGIN
  
    INSERT INTO INTERFACE_CLIENTS
      (INC_INO_ORH_ID,
       INC_TYPE_DOC,
       INC_NRO_DOC,
       INC_LAST_NAME,
       INC_FIRST_NAME,
       INC_BIRTH_DATE,
       INC_TELEPHONE,
       INC_TYPE)
    VALUES
      (p_inc_ino_orh_id,
       p_inc_type_doc,
       p_inc_nro_doc,
       p_inc_last_name,
       p_inc_first_name,
       p_inc_birth_date,
       p_inc_telephone,
       p_inc_type);
  
    RETURN 0;
  EXCEPTION
    WHEN OTHERS THEN
      pa_ws_interface_new.p_grabo_error(p_error_code => SQLCODE,
                                        p_error_text => 'Error al grabar en INTERFACE_CLIENTS ' ||
                                                        SQLERRM,
                                        p_sentence   => 'insert into INTERFACE_CLIENTS...',
                                        p_comment    => 'Error al registrar los datos del cliente.');
      RETURN SQLCODE;
  END;
  
  FUNCTION F_INTERFACE_ADDRESS(p_ina_ino_orh_id  NUMBER,
                               p_ina_street      VARCHAR2,
                               p_ina_number      VARCHAR2,
                               p_ina_floor       VARCHAR2,
                               p_ina_flat        VARCHAR2,
                               p_ina_apartment   VARCHAR2,
                               p_ina_district    VARCHAR2,
                               p_ina_city        VARCHAR2,
                               p_ina_observation VARCHAR2,
                               p_ina_cpa         VARCHAR2,
                               p_ina_zip_code    VARCHAR2,
                               p_ina_province    VARCHAR2,
                               p_ina_type        VARCHAR2) RETURN NUMBER IS
  
  BEGIN
    INSERT INTO INTERFACE_ADDRESS
      (INA_INO_ORH_ID,
       INA_STREET,
       INA_NUMBER,
       INA_FLOOR,
       INA_FLAT,
       INA_APARTMENT,
       INA_DISTRICT,
       INA_CITY,
       INA_OBSERVATION,
       INA_CPA,
       INA_ZIP_CODE,
       INA_PROVINCE,
       INA_TYPE)
    VALUES
      (p_ina_ino_orh_id,
       p_ina_street,
       p_ina_number,
       p_ina_floor,
       p_ina_flat,
       p_ina_apartment,
       p_ina_district,
       p_ina_city,
       p_ina_observation,
       p_ina_cpa,
       p_ina_zip_code,
       p_ina_province,
       p_ina_type);
    RETURN 0;
  EXCEPTION
    WHEN OTHERS THEN
      pa_ws_interface_new.p_grabo_error(p_error_code => SQLCODE,
                                        p_error_text => 'Error al grabar en INTERFACE_ADDRESS ' ||
                                                        SQLERRM,
                                        p_sentence   => 'insert into INTERFACE_ADDRESS...',
                                        p_comment    => 'Error al registrar los datos del domicilio.');
      RETURN SQLCODE;
  END;
  
  
   FUNCTION F_INTERFACE_EQUIPEMENTS(p_ine_id          NUMBER,
                                   p_ine_ino_orh_id  NUMBER,
                                   p_ine_product_id  VARCHAR2,
                                   p_ine_rpl_id      VARCHAR2,
                                   p_ine_price_level VARCHAR2,
                                   p_ine_est_id      VARCHAR2,
                                   p_ine_zip_code    VARCHAR2,
                                   p_ine_type        VARCHAR2) RETURN NUMBER IS
  
  BEGIN
    INSERT INTO INTERFACE_EQUIPEMENTS
      (INE_ID,
       INE_INO_ORH_ID,
       INE_PRODUCT_ID,
       INE_RPL_ID,
       INE_PRICE_LEVEL,
       INE_EST_ID,
       INE_ZIP_CODE,
       INE_TYPE)
    VALUES
      (p_ine_id,
       p_ine_ino_orh_id,
       p_ine_product_id,
       p_ine_rpl_id,
       p_ine_price_level,
       p_ine_est_id,
       p_ine_zip_code,
       p_ine_type);
    RETURN 0;
  EXCEPTION
    WHEN OTHERS THEN
      pa_ws_interface_new.p_grabo_error(p_error_code => SQLCODE,
                                        p_error_text => 'Error al grabar en INTERFACE_EQUIPEMENTS ' ||
                                                        SQLERRM,
                                        p_sentence   => 'insert into INTERFACE_EQUIPEMENTS...',
                                        p_comment    => 'Error al registrar los datos del equipo.');
      RETURN SQLCODE;
  END;
  
  FUNCTION F_INTERFACE_METHOD_OF_DAY(p_inm_ino_orh_id       NUMBER,
                                     p_inm_pay_id           NUMBER,
                                     p_inm_transaction_date DATE,
                                     p_inm_origin           NUMBER,
                                     p_inm_eco_id           NUMBER)
    RETURN NUMBER IS
  
  BEGIN
    INSERT INTO INTERFACE_METHOD_OF_DAY
      (INM_INO_ORH_ID,
       INM_PAY_ID,
       INM_TRANSACTION_DATE,
       INM_ORIGIN,
       INM_ECO_ID)
    VALUES
      (p_inm_ino_orh_id,
       p_inm_pay_id,
       p_inm_transaction_date,
       p_inm_origin,
       p_inm_eco_id);
    RETURN 0;
  EXCEPTION
    WHEN OTHERS THEN
      pa_ws_interface_new.p_grabo_error(p_error_code => SQLCODE,
                                        p_error_text => 'Error al grabar en INTERFACE_METHOD_OF_DAY ' ||
                                                        SQLERRM,
                                        p_sentence   => 'insert into INTERFACE_METHOD_OF_DAY...',
                                        p_comment    => 'Error al registrar los datos del metodo de pago.');
      RETURN SQLCODE;
    
  END;
  
  FUNCTION F_INTERFACE_CREDIT_CARD(p_incc_ino_orh_id         NUMBER,
                                   p_incc_credit_card_number VARCHAR2,
                                   p_incc_eco_id             NUMBER)
    RETURN NUMBER IS
  
  BEGIN
    INSERT INTO INTERFACE_CREDIT_CARD
      (INCC_INO_ORH_ID, INCC_CREDIT_CARD_NUMBER, INCC_ECO_ID)
    VALUES
      (p_incc_ino_orh_id, p_incc_credit_card_number, p_incc_eco_id);
    RETURN 0;
  EXCEPTION
    WHEN OTHERS THEN
      pa_ws_interface_new.p_grabo_error(p_error_code => SQLCODE,
                                        p_error_text => 'Error al grabar en INTERFACE_CREDIT_CARD ' ||
                                                        SQLERRM,
                                        p_sentence   => 'insert into INTERFACE_CREDIT_CARD...',
                                        p_comment    => 'Error al registrar los datos de la tarjeta.');
      RETURN SQLCODE;
    
  END;
  
  FUNCTION F_INTERFACE_ORDERS(p_ino_orh_id          NUMBER,
                              p_ino_clt_id          NUMBER,
                              p_ino_acc_id          VARCHAR2,
                              p_ino_time_admission  DATE,
                              p_ino_hour_window     NUMBER,
                              p_ino_usr_id          VARCHAR2,
                              p_ino_cellular_number VARCHAR2,
                              p_ino_business_type   VARCHAR2,
                              p_ino_spc_id          VARCHAR2,
                              p_ino_entity          NUMBER,
                              p_ino_id_ecom         NUMBER,
                              p_ino_creation_date   DATE,
                              p_ino_type            VARCHAR2) RETURN NUMBER IS
  
  BEGIN
    INSERT INTO INTERFACE_ORDERS
      (INO_ORH_ID,
       INO_CLT_ID,
       INO_ACC_ID,
       INO_TIME_ADMISSION,
       INO_HOUR_WINDOW,
       INO_USR_ID,
       INO_CELLULAR_NUMBER,
       INO_BUSINESS_TYPE,
       INO_SPC_ID,
       INO_ENTITY,
       INO_ID_ECOM,
       INO_CREATION_DATE,
       INO_TYPE)
    VALUES
      (p_ino_orh_id,
       p_ino_clt_id,
       p_ino_acc_id,
       p_ino_time_admission,
       p_ino_hour_window,
       p_ino_usr_id,
       p_ino_cellular_number,
       p_ino_business_type,
       p_ino_spc_id,
       p_ino_entity,
       p_ino_id_ecom,
       p_ino_creation_date,
       p_ino_type);
    RETURN 0;
  EXCEPTION
    WHEN OTHERS THEN
      pa_ws_interface_new.p_grabo_error(p_error_code => SQLCODE,
                                        p_error_text => 'Error al grabar en INTERFACE_ORDERS ' ||
                                                        SQLERRM,
                                        p_sentence   => 'insert into INTERFACE_ORDERS...',
                                        p_comment    => 'Error al registrar los datos del pedido.');
      RETURN SQLCODE;
    
  END;
  
  FUNCTION F_INTERFACE_CHARGE(p_inca_ino_orh_id    NUMBER,
                              p_inca_price_sale    NUMBER,
                              p_inca_price_without NUMBER,
                              p_inca_discount      NUMBER,
                              p_inca_ine_id        NUMBER) RETURN NUMBER IS
  
  BEGIN
    INSERT INTO INTERFACE_CHARGE
      (INCA_INO_ORH_ID,
       INCA_PRICE_SALE,
       INCA_PRICE_WITHOUT,
       INCA_DISCOUNT,
       INCA_INE_ID)
    VALUES
      (P_inca_ino_orh_id,
       P_inca_price_sale,
       P_inca_price_without,
       P_inca_discount,
       P_inca_ine_id);
    RETURN 0;
  EXCEPTION
    WHEN OTHERS THEN
      pa_ws_interface_new.p_grabo_error(p_error_code => SQLCODE,
                                        p_error_text => 'Error al grabar en INTERFACE_CHARGE ' ||
                                                        SQLERRM,
                                        p_sentence   => 'insert into INTERFACE_CHARGE...',
                                        p_comment    => 'Error al registrar los cargos.');
      RETURN SQLCODE;
    
  END;
  
  FUNCTION F_INTERFACE_CHARGE_PLANS(p_incp_ino_orh_id          NUMBER,
                                    p_incp_plan                VARCHAR2,
                                    p_incp_plan_new            VARCHAR2,
                                    p_incp_start_date_cyc      DATE,
                                    p_incp_end_date_cyc        DATE,
                                    p_incp_flag_change         VARCHAR2,
                                    p_incp_change_bonification VARCHAR2,
                                    p_incp_amount_charge       NUMBER,
                                    p_incp_stg_id              VARCHAR2,
                                    p_incp_module              VARCHAR2,
                                    p_incp_flag_ff             VARCHAR2)
    RETURN NUMBER IS
  
  BEGIN
    INSERT INTO INTERFACE_CHARGE_PLANS
      (incp_ino_orh_id,
       incp_plan,
       incp_plan_new,
       incp_start_date_cyc,
       incp_end_date_cyc,
       incp_flag_change,
       incp_change_bonification,
       incp_amount_charge,
       incp_stg_id,
       incp_module,
       incp_flag_ff)
    VALUES
      (P_incp_ino_orh_id,
       p_incp_plan,
       p_incp_plan_new,
       p_incp_start_date_cyc,
       p_incp_end_date_cyc,
       p_incp_flag_change,
       p_incp_change_bonification,
       p_incp_amount_charge,
       p_incp_stg_id,
       p_incp_module,
       p_incp_flag_ff);
    RETURN 0;
  EXCEPTION
    WHEN OTHERS THEN
      pa_ws_interface_new.p_grabo_error(p_error_code => SQLCODE,
                                        p_error_text => 'Error al grabar en INTERFACE_CHARGE_PLANS ' ||
                                                        SQLERRM,
                                        p_sentence   => 'insert into INTERFACE_CHARGE_PLANS...',
                                        p_comment    => 'Error al registrar los datos para el cambio de plan.');
      RETURN SQLCODE;
    
  END;
  
  FUNCTION F_INTERFACE_STATUS(p_ins_ino_orh_id NUMBER,
                              p_ins_status     VARCHAR2) RETURN NUMBER IS
  
  BEGIN
    INSERT INTO INTERFACE_STATUS
      (INS_INO_ORH_ID, INS_STATUS, INS_START_DATE)
    VALUES
      (p_ins_ino_orh_id, p_ins_status, SYSDATE);
    RETURN 0;
  EXCEPTION
    WHEN OTHERS THEN
      pa_ws_interface_new.p_grabo_error(p_error_code => SQLCODE,
                                        p_error_text => 'Error al grabar en INTERFACE_STATUS ' ||
                                                        SQLERRM,
                                        p_sentence   => 'insert into INTERFACE_STATUS...',
                                        p_comment    => 'Error al registrar el estado del pedido.');
      RETURN SQLCODE;
    
  END;
  
  FUNCTION F_UPDATE_INTERFACE_STATUS(p_ins_ino_orh_id NUMBER,
                                     p_ins_status     VARCHAR2) RETURN NUMBER IS
    v_sentence VARCHAR2(100);
  BEGIN
  
    v_sentence := 'Error en el update en INTERFACE_STATUS...';
    UPDATE INTERFACE_STATUS
       SET INS_END_DATE = SYSDATE
     WHERE INS_INO_ORH_ID = p_ins_ino_orh_id
       AND INS_END_DATE IS NULL;
  
    v_sentence := 'Despues del update, error en insert into INTERFACE_STATUS...';
    INSERT INTO INTERFACE_STATUS
      (INS_INO_ORH_ID, INS_STATUS, INS_START_DATE)
    VALUES
      (p_ins_ino_orh_id, p_ins_status, SYSDATE);
  
    RETURN 0;
  EXCEPTION
    WHEN OTHERS THEN
      pa_ws_interface_new.p_grabo_error(p_error_code => SQLCODE,
                                        p_error_text => 'Error al grabar en INTERFACE_STATUS ' ||
                                                        SQLERRM,
                                        p_sentence   => v_sentence,
                                        p_comment    => 'Error al registrar el cambio de estado del pedido.');
      RETURN SQLCODE;
    
  END;
end PA_WS_ECOM_INTERFACE;
/

