create PACKAGE PA_USSD_FRIENDS_AND_FAMILY IS
/* El metodo muestra la informacion de las promos que puede seleccionar la linea. */
 FUNCTION getPromos(P_NIM        IN VARCHAR2,
                    P_cellularNumber OUT cellulars.clu_cellular_number%TYPE,
                     P_ERR_CODE   OUT NUMBER, 
                     P_ERR_TEXT   OUT VARCHAR2,
                     P_SQL_CODE   OUT VARCHAR2,
                     P_RESPONSE   OUT VARCHAR2,
                     P_COD_PAIS   OUT VARCHAR2) RETURN NUMBER;

/* El metodo trae la informacion relacionada con la promo de la linea, dicha informacion es la descripcion 
 cantidad de numero claro, cantidad de n?meros externos, cantidad de movimientos disponibles, cantidad de movimientos. */
 FUNCTION getPromoData(P_cellularNumber IN VARCHAR2,--IN cellulars.clu_cellular_number%TYPE, 
                       P_PROMID     IN VARCHAR2,
                       P_QuantityInserts IN NUMBER, --cantidad total de movimientos disponibles
                       P_QuantityNumbers IN NUMBER, ---cantidad total de numeros disponibles para configurar
                       P_QuantityBF IN NUMBER, --cantidad total de disp. numeros mej. amigos
                       P_QuantityOnNet IN NUMBER, --cantidad total de disp. numeros claros
                       P_QuantityFixed IN NUMBER, --cantidad total de disp. numeros externos
                       P_ERR_CODE   OUT NUMBER, 
                       P_ERR_TEXT   OUT VARCHAR2, 
                       P_SQL_CODE   OUT VARCHAR2, 
                       P_RESPONSE   OUT VARCHAR2,                       
                       P_QuantityMovDisp OUT NUMBER,
                       P_QuantityNumbersConfig OUT NUMBER) RETURN NUMBER;                     

/* Validaciones antes de realizar el cambio de numero */
 FUNCTION validateNewFriend(P_cellularNumber IN cellulars.clu_cellular_number%TYPE, 
                       P_PROMID     IN VARCHAR2, --id de la promo
                       P_DESCRIPTION   IN VARCHAR2, -- descripcion de la promo
                       P_friendNumber cellulars.clu_cellular_number%TYPE, -- numero a agregar
                       P_account IN VARCHAR2, -- account id
                       P_plan   IN VARCHAR2, -- plan id
                       P_canBeBF OUT VARCHAR2, -- dice si puede ser best friend
                       P_prefix IN VARCHAR2, -- codigo del pais
                       P_Response OUT VARCHAR2, -- Mensaje de salida
                       P_offnet out varchar2,
                       P_QuantityMovDisp IN number,--Cantidad de modificaciones de nros cargados disponibles
                       P_ERR_CODE   OUT NUMBER, 
                       P_ERR_TEXT   OUT VARCHAR2, 
                       P_SQL_CODE   OUT VARCHAR2) RETURN NUMBER; 
                       
 /* Validaciones antes de realizar el cambio del numero mejor amigo */
 FUNCTION validateAvailableChangeBF(P_cellularNumber IN cellulars.clu_cellular_number%TYPE, 
                       P_PROMID     IN VARCHAR2, --id de la promo
                       P_Response OUT VARCHAR2, -- Mensaje de salida
                       P_ERR_CODE   OUT NUMBER, 
                       P_ERR_TEXT   OUT VARCHAR2, 
                       P_SQL_CODE   OUT VARCHAR2,
                       P_BF_CARGADO OUT VARCHAR2,
                       P_CANTIDAD_NROS OUT NUMBER) RETURN NUMBER; 
                       
/* Inserta un nuevo numero a la promocion de la linea. */
 FUNCTION insertNewFriend(P_cellularNumber IN cellulars.clu_cellular_number%TYPE,
                       P_PROMID     IN VARCHAR2, --id de la promo
                       P_friendNumber IN cellulars.clu_cellular_number%TYPE, -- numero a agregar
                       P_account IN VARCHAR2, -- account id
                       P_isBF IN VARCHAR2, -- dice si es best friend
                       P_prefix IN VARCHAR2, -- codigo del pais
                       P_Response OUT VARCHAR2,
                       P_ERR_CODE   OUT NUMBER, 
                       P_ERR_TEXT   OUT VARCHAR2, 
                       P_SQL_CODE   OUT VARCHAR2) RETURN NUMBER;

/* Permite cambiar un numero marcado como mejor amigo por otro, el nuevo numero ingresado debera ser del
 ONNET para poder ser marcado como mejor amigo, en el caso de que se desee cambiar el numero por un numero
 del tipo OFFNET este se cargara pero como un numero externo unicamente debido a que "NO" es posible marcar
 un numero OFFNET como mejor amigo.*/               
FUNCTION changeFriendBF(P_cellularNumber IN cellulars.clu_cellular_number%TYPE, 
                       P_PROMID     IN VARCHAR2, --id de la promo
                       P_friendNumberOld IN cellulars.clu_cellular_number%TYPE, -- numero a cambiar
                       P_friendNumber IN cellulars.clu_cellular_number%TYPE, -- numero a agregar
                       P_response OUT VARCHAR2,
                       P_ERR_CODE   OUT NUMBER, 
                       P_ERR_TEXT   OUT VARCHAR2, 
                       P_SQL_CODE   OUT VARCHAR2,
                       P_prefix IN VARCHAR2) RETURN NUMBER;
                                   
/* Permite realizar cambios en los numeros que se cargan en la promocion, estos cambios pueden ser ONNET por ONNET, ONNET 
   por OFFNET, OFFNET por ONNET, OFFNET por OFFNET. Estos cambion depende de el tipo de promocion que posea cargada la linea. */               
FUNCTION changeFF(P_cellularNumber IN cellulars.clu_cellular_number%TYPE,
                       P_PROMID     IN VARCHAR2, --id de la promo
                       P_friendNumberOld IN cellulars.clu_cellular_number%TYPE, -- numero a cambiar
                       P_friendNumber IN cellulars.clu_cellular_number%TYPE, -- numero a agregar  
                       P_account IN VARCHAR2, -- account id
                       P_prefix IN VARCHAR2, -- codigo del pais
                       P_response OUT VARCHAR2,
                       P_ERR_CODE   OUT NUMBER,
                       P_ERR_TEXT   OUT VARCHAR2,
                       P_SQL_CODE   OUT VARCHAR2) RETURN NUMBER;
                       
FUNCTION listarNrosConfig( P_cellularNumber IN cellulars.clu_cellular_number%TYPE, 
                                    P_PROMID     IN VARCHAR2, --id de la promo
                                    P_RESPONSE OUT VARCHAR2, -- Mensaje de salida
                                    P_ERR_CODE   OUT NUMBER, 
                                    P_ERR_TEXT   OUT VARCHAR2, 
                                    P_SQL_CODE   OUT VARCHAR2,
                                    P_tieneBF out varchar2) RETURN NUMBER; 
                                    
                                    
/* Permite setear un numero CARGADO, como mejor amigo cuando NO TIENE ningun numero configurado como BF.*/               
FUNCTION setFriendBF(P_cellularNumber IN cellulars.clu_cellular_number%TYPE, 
                       P_PROMID     IN VARCHAR2, --id de la promo
                       P_friendNumber IN cellulars.clu_cellular_number%TYPE, -- numero a agregar  
                       P_response OUT VARCHAR2,
                       P_ERR_CODE   OUT NUMBER, 
                       P_ERR_TEXT   OUT VARCHAR2, 
                       P_SQL_CODE   OUT VARCHAR2,
                       P_prefix IN VARCHAR2) RETURN NUMBER;
                       
FUNCTION listarNrosClaro(P_cellularNumber IN cellulars.clu_cellular_number%TYPE, 
                          P_PROMID     IN VARCHAR2, --id de la promo
                          P_RESPONSE OUT VARCHAR2, -- Mensaje de salida
                          P_ERR_CODE   OUT NUMBER, 
                          P_ERR_TEXT   OUT VARCHAR2, 
                          P_SQL_CODE   OUT VARCHAR2) RETURN NUMBER;
                          
FUNCTION listarNrosClaroBF(P_cellularNumber IN cellulars.clu_cellular_number%TYPE, 
                          P_PROMID     IN VARCHAR2, --id de la promo
                          P_RESPONSE OUT VARCHAR2, -- Mensaje de salida
                          P_ERR_CODE   OUT NUMBER, 
                          P_ERR_TEXT   OUT VARCHAR2, 
                          P_SQL_CODE   OUT VARCHAR2) RETURN NUMBER;
END PA_USSD_FRIENDS_AND_FAMILY;
/

