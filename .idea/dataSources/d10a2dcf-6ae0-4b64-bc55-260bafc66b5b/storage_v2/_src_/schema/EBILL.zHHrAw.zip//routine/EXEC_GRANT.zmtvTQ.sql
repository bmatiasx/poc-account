create Procedure       exec_grant 
    (stat IN VARCHAR2)  
--
-- Permite dar grants desde lo usaurios que poseen execute
-- de esta procedure
-- Seguridad de Datos.
--

 IS 
   cid NUMBER;
   ex  NUMBER;

   BEGIN
     cid := DBMS_SQL.OPEN_CURSOR;
     DBMS_SQL.PARSE(cid, stat, dbms_sql.v7);
     ex := DBMS_SQL.EXECUTE(cid);
     DBMS_SQL.CLOSE_CURSOR(cid);

   EXCEPTION
     WHEN OTHERS THEN
       DBMS_SQL.CLOSE_CURSOR(cid);
       RAISE;  
   END exec_grant;
/

