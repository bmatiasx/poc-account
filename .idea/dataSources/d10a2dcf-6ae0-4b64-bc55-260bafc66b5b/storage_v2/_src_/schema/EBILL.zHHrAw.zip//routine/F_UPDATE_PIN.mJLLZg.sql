create FUNCTION F_UPDATE_PIN(P_CELULAR      IN VARCHAR2,
                                        P_CLU_PASSWORD IN VARCHAR2,
                                        P_ERR_NUMBER   OUT NUMBER,
                                        P_ERR_MESSAGE  OUT VARCHAR2)
  RETURN NUMBER IS

  v_result NUMBER;

BEGIN

  BEGIN
    v_result := F_UPDATE_PIN@PROD(P_CELULAR,
                                  P_CLU_PASSWORD,
                                  P_ERR_NUMBER,
                                  P_ERR_MESSAGE);

    IF v_result = 0 THEN
      update cellular_profiles
         set cpr_blocked = 'N', cpr_try_failed = 0, cpr_prf_id = null
       where cpr_clu_cellular_number = p_celular;

      P_ERR_NUMBER  := 0;
      P_ERR_MESSAGE := 'OK';
      return 0;
    ELSE
      P_ERR_MESSAGE := 'error en F_UPDATE_PIN: ' || P_ERR_MESSAGE;
      return - 1;

    END IF;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      P_ERR_NUMBER  := -1001;
      P_ERR_MESSAGE := 'El numero de linea ingresado no existe.';
      RETURN 1;

    WHEN OTHERS THEN
      P_ERR_NUMBER  := SQLCODE;
      P_ERR_MESSAGE := SQLERRM;
      RETURN - 1;

  END;

END;
/

