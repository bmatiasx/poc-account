create materialized view S_BUSINESS_RESTRICTION_CHANGES
refresh complete on demand
  as
    SELECT brc_id,
brc_cbt_id,
brc_cbt_id_new,
brc_start_date,
brc_end_date
FROM STL.business_restriction_changes@PROD
  WHERE brc_start_date <  GET_DATE
AND NVL(brc_end_date,GET_DATE+1) > GET_DATE

/

