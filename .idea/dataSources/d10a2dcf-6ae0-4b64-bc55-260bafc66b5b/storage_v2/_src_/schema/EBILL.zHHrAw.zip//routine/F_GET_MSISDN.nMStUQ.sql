create FUNCTION F_GET_MSISDN

 (P_CELLULAR IN VARCHAR2
 ,P_SUBID OUT VARCHAR2
 ,P_ERR_NUMBER OUT INTEGER
 ,P_ERR_MESSAGE OUT VARCHAR2
 )
 RETURN NUMBER
 IS
     v_clu_type cellulars.clu_type% TYPE;
     v_clu_bill_number cellulars.clu_bill_number% TYPE;
BEGIN

   BEGIN
       SELECT  clu.clu_type, clu.clu_bill_number
         INTO    v_clu_type, v_clu_bill_number
       FROM    cellulars clu
      WHERE   clu.clu_cellular_number = p_cellular;

    EXCEPTION
     WHEN NO_DATA_FOUND THEN
       p_err_message := SQLERRM;
       p_err_number := SQLCODE;
       RETURN  1;
     WHEN OTHERS THEN
       p_err_message := SQLERRM;
       p_err_number := SQLCODE;
       RETURN - 1;

     END;

    p_subid:= Pa_Msisdn.f_Get_Msisdn(v_clu_type, v_clu_bill_number);

    RETURN 0;

END F_GET_MSISDN;
/

