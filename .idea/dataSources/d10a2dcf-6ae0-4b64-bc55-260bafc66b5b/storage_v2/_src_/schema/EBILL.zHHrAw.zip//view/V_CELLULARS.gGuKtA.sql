create view V_CELLULARS as
  select clu_cellular_number, clu_bill_number, clu_acc_id, clu_pro_mode_type
  FROM cellulars where clu_status = 'A'
/

