create view V_ACC_SERV_DETAIL_SAP_CRM as
  SELECT ars_id,
ars_start_date,
ars_status,
ars_lines,
ars_error_lines,
ars_active_lines,
ars_acc_id,
asd_id,
asd_bill_number,
asd_package_id,
asd_status,
asd_execute_date,
asd_generic_msg,
asd_original_msg
FROM account_register_services
JOIN acc_reg_serv_detail a ON asd_ars_id = ars_id
WHERE ars_origin = 'SAP_CRM'
 
/

