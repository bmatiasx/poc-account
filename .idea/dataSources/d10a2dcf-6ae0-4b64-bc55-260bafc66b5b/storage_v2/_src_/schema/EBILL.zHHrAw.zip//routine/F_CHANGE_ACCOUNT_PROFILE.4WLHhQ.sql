create FUNCTION F_CHANGE_ACCOUNT_PROFILE

 (P_ACP_ACC_ID IN VARCHAR2
 ,P_ACP_PRF_ID IN NUMBER
 ,P_ERR_NUMBER OUT NUMBER
 ,P_ERR_MESSAGE OUT VARCHAR2
 )
 RETURN NUMBER
 IS
begin


  case p_acp_prf_id


          when 2 then


          update account_profiles set ACP_PRF_ID = p_ACP_PRF_ID, ACP_PRF_HST= 'Y'
          where account_profiles.ACP_ACC_ID =p_ACP_ACC_ID;

          when 1 then

      update account_profiles set ACP_PRF_ID = p_ACP_PRF_ID, ACP_PRF_HST= 'N'
          where account_profiles.ACP_ACC_ID =p_ACP_ACC_ID;

     else

        update account_profiles set ACP_PRF_ID = p_ACP_PRF_ID
        where account_profiles.ACP_ACC_ID =p_ACP_ACC_ID;

   end case;

  return 0;
exception
  when others then
    --errors
    P_ERR_NUMBER :='Error:'||SQLERRM;
    P_ERR_MESSAGE :='OCURRIO UN ERROR AL ACTUALIZAR EL PERFIL.';
    return -1;
 end;
/

