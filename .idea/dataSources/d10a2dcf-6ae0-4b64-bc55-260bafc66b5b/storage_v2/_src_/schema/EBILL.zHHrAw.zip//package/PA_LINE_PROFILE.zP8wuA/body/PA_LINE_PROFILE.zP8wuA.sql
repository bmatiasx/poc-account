create package body PA_LINE_PROFILE is

  /*
  Author Lucas Bonansea
  Version 1.1.1
  Last Modification: 18/3/2015
  Gets a basic line profile from cellular, accounts and client tables.
  */
  FUNCTION Get_Basic_Profile(pio_bill_number    in out varchar2,
                             pio_cellularNumber in out varchar2,
                             po_accountId       out varchar2,
                             po_companyId       out varchar2,
                             po_businessType    out varchar2,
                             po_clientId        out varchar2,
                             po_clientType      out varchar2,
                             po_clientCategory  out varchar2,
                             po_lineStatus      out varchar2,
                             po_codigo_error    out varchar2,
                             po_mensaje_error   out varchar2,
                             po_mensaje_salida  out varchar2) return NUMBER is
  BEGIN
    po_codigo_error   := 0;
    po_mensaje_error  := 'OK';
    po_mensaje_salida := 'OK';
    -- At least one Cellular or Bill Number must be given
    IF pio_bill_number IS NULL AND pio_cellularNumber IS NULL THEN
      po_codigo_error   := 1;
      po_mensaje_error  := 'Faltan Datos Obligatorios';
      po_mensaje_salida := 'Debe Proporcionar al menos 1 numero de referencia';
      RETURN 1;
    END IF;
    -- Cellular Number has preference over Bill Number. So if cellular number
    -- is given, then bill number is ignored.
    IF pio_cellularNumber IS NOT NULL THEN
      pio_bill_number := null;
    END IF;
    SELECT CLU_BILL_NUMBER,
           CLU_CELLULAR_NUMBER,
           CLU_ACC_ID,
           ACC_CMP_ID,
           CLU_CBT_ID,
           CLT_ID,
           CLT_TYPE,
           CLT_CATEGORY,
           CLU_STATUS
      INTO pio_bill_number,
           pio_cellularNumber,
           po_accountId,
           po_companyId,
           po_businessType,
           po_clientId,
           po_clientType,
           po_clientCategory,
           po_lineStatus
      FROM S_CELLULARS
      JOIN S_ACCOUNTS ON ACC_ID = CLU_ACC_ID
      JOIN S_CLIENT ON CLT_ID = ACC_CLT_ID
     WHERE (pio_bill_number IS NOT null AND CLU_BILL_NUMBER = pio_bill_number)
       OR (pio_cellularNumber IS NOT null AND CLU_CELLULAR_NUMBER = pio_cellularNumber);
    RETURN 0;
  EXCEPTION
    WHEN no_data_found THEN
      po_codigo_error   := SQLCODE;
      po_mensaje_error  := SUBSTR(SQLERRM, 1, 100);
      po_mensaje_salida := 'NOTFOUND';
      RETURN 1;
  END Get_Basic_Profile;
  /*
  Author Lucas Bonansea
  Version 1.1.2
  Last Modification: 18/09/2015
  Gets a complete line profile from cellular, accounts and client tables.
  Adds the following information to the basic line profile:
  Cellular Data:
           cellularReasonId,
           reasonDescription,
           cellularType,
           claroClubStatus,
           password,
           serviceType,
           technology,
           mileageCategory,
           serviceStatus
  Account Data:
          accountGeoUnit,
          accountBillContact,
          cycleDay,
          email,
          emailValidated,
          accFlag,
          accountType,
          accountClass,
          accountEntityId
  Client Data:
         clientBirthDate,
         clientCategory,
         clientFirstName,
         clientIdentificationNumber,
         clientLastName,
         clientClass
  */
  FUNCTION Get_Complete_Profile(pio_bill_number    in out varchar2,
                                pio_cellularNumber in out varchar2,
                                pi_get_email_validated in varchar2,
                                po_accountId       out varchar2,
                                po_companyId       out varchar2,
                                po_businessType    out varchar2,
                                po_clientId        out varchar2,
                                po_clientType      out varchar2,
                                po_clientCategory  out varchar2,
                                po_lineStatus      out varchar2,
                                po_cellular_data   out varchar2, --cellularReasonId, reasonDescription, cellularType, claroClubStatus, password, serviceType, technology, mileageCategory
                                po_client_data     out varchar2, --clientBirthDate, clientCategory, clientFirstName, clientIdentificationNumber, clientLastName, clientClass
                                po_account_data    out varchar2, --accountGeoUnit, accountBillContact, cycleDay, email, emailValidated, accFlag, accountType, accountClass, accountEntityId
                                po_codigo_error    out varchar2,
                                po_mensaje_error   out varchar2,
                                po_mensaje_salida  out varchar2)
    RETURN NUMBER IS
    v_cellularReasonId  s_cellulars.clu_rsn_id%type;
    v_reasonDescription s_reasons.rsn_description%type;
    v_cellularType      s_cellulars.clu_type%type;
    v_claroClubStatus   s_cellulars.clu_mileage_status%type;
    v_password          s_cellulars.clu_password%type;
    v_serviceType       s_cellulars.clu_stg_id%type;
    v_technology        varchar2(10); -- s_cellulars.clu_pro_mode_type%type; (No se puede usar porque no da la cantidad de digitos)
    v_mileageCategory   s_mileage_category.mic_category%type;
    v_serviceStatus     s_service_status.sst_service_status%type;
    v_clientBirthDate            varchar2(12);
    v_clientCategory             s_client.clt_category%type;
    v_clientFirstName            s_client.clt_name%type;
    v_clientIdentificationNumber s_client.clt_identification_number%type;
    v_clientLastName             s_client.clt_surname%type;
    v_clientClass                s_client.clt_class%type;
    v_accountGeoUnit     s_accounts.acc_geu_id%type;
    v_accountBillContact s_accounts.acc_bill_contact%type;
    v_cycleDay           varchar2(2);
    v_email              s_accounts.acc_e_mail%type;
    v_emailValidated     varchar2(5);
    v_accflag            s_accounts.acc_flags%type;
    v_accountType        s_accounts.acc_aty_id%type;--It is added to be used in IngresoLineaCORE
    v_accountClass        VARCHAR2(10);--It is added to be used in IngresoLineaCORE
    v_accountEntityId    s_accounts.acc_ent_id%type;--It is added to be used in IngresoLineaCORE
  BEGIN
    po_codigo_error   := 0;
    po_mensaje_error  := 'OK';
    po_mensaje_salida := 'OK';
    -- At least one Cellular or Bill Number must be given
    IF pio_bill_number IS NULL AND pio_cellularNumber IS NULL THEN
      po_codigo_error   := 1;
      po_mensaje_error  := 'Faltan Datos Obligatorios';
      po_mensaje_salida := 'Debe Proporcionar al menos 1 numero de referencia';
      RETURN 1;
    END IF;
    -- Cellular Number has preference over Bill Number. So if cellular number
    -- is given, then bill number is ignored.
    IF pio_cellularNumber IS NOT NULL THEN
      pio_bill_number := null;
    END IF;
    SELECT /*+ INDEX_DESC(S_CELLULARS) */ CLU_BILL_NUMBER,
           CLU_CELLULAR_NUMBER,
           CLU_ACC_ID,
           ACC_CMP_ID,
           CLU_CBT_ID,
           CLT_ID,
           CLT_TYPE,
           CLT_CATEGORY,
           CLU_STATUS,
           CLU_RSN_ID,
           RSN_DESCRIPTION,
           CLU_TYPE,
           CLU_MILEAGE_STATUS,
           CLU_PASSWORD,
           CLU_STG_ID,
           NVL(CLU_PRO_MODE_TYPE, 'NOGSM'),
           MIC_CATEGORY,
           TO_CHAR(CLT_BIRTH_DATE, 'DD/MM/YYYY'),
           CLT_NAME,
           CLT_IDENTIFICATION_NUMBER,
           CLT_SURNAME,
           CLT_CLASS,
           ACC_GEU_ID,
           ACC_BILL_CONTACT,
           SUBSTR(ACC_CYC_ID, -2),
           ACC_E_MAIL,
           ACC_FLAGS,
           ACC_ATY_ID,
           NVL(ACC_ENT_ID, 0),
           s_service_status.sst_service_status
      INTO pio_bill_number,
           pio_cellularNumber,
           po_accountId,
           po_companyId,
           po_businessType,
           po_clientId,
           po_clientType,
           po_clientCategory,
           po_lineStatus,
           v_cellularReasonId,
           v_reasonDescription,
           v_cellularType,
           v_claroClubStatus,
           v_password,
           v_serviceType,
           v_technology,
           v_mileageCategory,
           v_clientBirthDate,
           v_clientFirstName,
           v_clientIdentificationNumber,
           v_clientLastName,
           v_clientClass,
           v_accountGeoUnit,
           v_accountBillContact,
           v_cycleDay,
           v_email,
           v_accflag,
           v_accountType,
           v_accountEntityId,
           v_serviceStatus
      FROM S_CELLULARS
      JOIN S_ACCOUNTS ON ACC_ID = CLU_ACC_ID
      JOIN S_CLIENT ON CLT_ID = ACC_CLT_ID
      JOIN S_SERVICE_STATUS ON SST_CLU_CELLULAR_NUMBER = CLU_CELLULAR_NUMBER 
      LEFT JOIN S_MILEAGE_CATEGORY ON MIC_CELLULAR_NUMBER = CLU_CELLULAR_NUMBER
      LEFT JOIN S_REASONS ON CLU_RSN_ID = RSN_ID
      WHERE ((pio_bill_number IS NOT null AND CLU_BILL_NUMBER = pio_bill_number)
      OR (pio_cellularNumber IS NOT null AND CLU_CELLULAR_NUMBER = pio_cellularNumber))
      AND SST_START_DATE <= SYSDATE
      AND NVL(SST_END_DATE, SYSDATE + 1) > SYSDATE;
    po_cellular_data := '#cellularReasonId=' || v_cellularReasonId ||
                        '#reasonDescription=' || v_reasonDescription ||
                        '#cellularType=' || v_cellularType ||
                        '#claroClubStatus=' || v_claroClubStatus ||
                        '#password=' || v_password ||
                        '#serviceType=' || v_serviceType ||
                        '#technology=' || v_technology ||
                        '#mileageCategory=' || v_mileageCategory || 
                        '#serviceStatus=' || v_serviceStatus || '#';
    po_client_data := '#clientBirthDate=' || v_clientBirthDate ||
                      '#clientCategory=' || v_clientCategory ||
                      '#clientFirstName=' || v_clientFirstName ||
                      '#clientIdentificationNumber=' || v_clientIdentificationNumber ||
                      '#clientLastName=' || v_clientLastName ||
                      '#clientClass=' || v_clientClass || '#';
        --Get the classification of the accountType. Eg: accountType='N' --> accountTypeClass='CORPO'
        --Primero buscamos tipo de cuenta en IVRAT1
         v_accountClass:=decode_x_parametros(ClaveParametros => 'IVRAT1',
                             ClaveADecodificar => trim(v_accountType));-- Tipo de cuenta en IVRAT1
         
         IF v_accountClass IS NULL THEN --Si no esta en IVRAT1, buscamos en IVRAT2
            v_accountClass:=decode_x_parametros(ClaveParametros => 'IVRAT2',
                             ClaveADecodificar => trim(v_accountType));-- Tipo de cuenta eb IVRAT2
         END IF;
         
    po_account_data := '#accountGeoUnit=' || v_accountGeoUnit ||
                       '#accountBillContact=' || v_accountBillContact ||
                       '#cycleDay=' || v_cycleDay ||
                       '#email=' || v_email ||
                       '#accflag=' || v_accflag || 
                       '#accountType=' || v_accountType || 
                       '#accountClass=' || v_accountClass || 
                       '#accountEntityId=' || v_accountEntityId || '#';
                       
    IF UPPER(pi_get_email_validated) = 'TRUE' OR
       UPPER(pi_get_email_validated) = 'YES' THEN
        SELECT DECODE(COUNT(1), 0, 'FALSE', 'TRUE')
          INTO v_emailValidated
          FROM S_ACCOUNTS
          JOIN S_ACCOUNT_EMAILS ON ACC_ID = AEM_ACC_ID
                               AND TRIM(ACC_E_MAIL) = TRIM(AEM_E_MAIL)
         WHERE ACC_ID = po_accountId
           AND AEM_START_DATE <= SYSDATE
           AND NVL(AEM_END_DATE, SYSDATE + 1) > SYSDATE
           AND AEM_VERIF_DATE IS NOT NULL;
        po_account_data := po_account_data || 'emailValidated=' || v_emailValidated || '#';
    END IF;
    RETURN 0;
  EXCEPTION
    WHEN no_data_found THEN
      po_codigo_error   := SQLCODE;
      po_mensaje_error  := SUBSTR(SQLERRM, 1, 100);
      po_mensaje_salida := 'NOTFOUND';
      RETURN 1;
      
    WHEN too_many_rows THEN
      po_codigo_error   := SQLCODE;
      po_mensaje_error  := SUBSTR(SQLERRM, 1, 100);
      po_mensaje_salida := 'TOO_MANY_ROWS_ERROR';
      RETURN 1;
  END Get_Complete_Profile;
  /*
  Author Lucas Bonansea
  Version 1.1.1
  Last Modification: 18/3/2015
  Extends the complete line profile adding information from other tables according
  to flags that indicate whether or not to obtain the info.
  Extended Data:
  Call Restriction Data:
          callRestrictionId,
          callRestrictionDesc
  Plan Data:
          planId,
          planType,
          lineBAM,
          planAdmiteFF
  Authorization Data:
         authorizationBillNumber,
         authorizationCellularNumber
  IVR Parametrized Data:
         sendSurvey,
         lineFixedMovile
  Other Data:
         Empty, available for future use
  */
  FUNCTION Get_Extended_Profile(pio_bill_number            in out Varchar2,
                                pio_cellularNumber         in out varchar2,
                                pi_get_email_validated     in varchar2,
                                po_accountId               out varchar2,
                                po_companyId               out varchar2,
                                po_businessType            out varchar2,
                                po_clientId                out varchar2,
                                po_clientType              out varchar2,
                                po_clientCategory          out varchar2,
                                po_lineStatus              out varchar2,
                                po_cellular_data           out varchar2, --cellularReasonId, reasonDescription, cellularType, claroClubStatus, password, serviceType, technology, mileageCategory
                                po_client_data             out varchar2, --clientId, clientBirthDate, clientCategory, clientFirstName, clientIdentificationNumber, clientLastName, clientClass
                                po_account_data            out varchar2, --accountGeoUnit, cycleDay, email, emailValidated, accflag, accountType, accountEntityId
                                pio_call_restrictions_data in out varchar2, --callRestrictionId, callRestrictionDesc
                                pio_plan_data              in out varchar2, --planId, planType, lineBAM, planAdmiteFF
                                pio_authorization_data     in out varchar2, --authorizationBillNumber, authorizationCellularNumber
                                pio_ivr_parameters         in out varchar2, --sendSurvey, lineFixedMovile
                                pio_other_data             in out varchar2, --
                                po_codigo_error            out varchar2,
                                po_mensaje_error           out varchar2,
                                po_mensaje_salida          out varchar2)
    return NUMBER is
    v_resultQueryCompleta number;
      
  BEGIN
  
    po_codigo_error   := 0;
    po_mensaje_error  := 'OK';
    po_mensaje_salida := 'OK';
    v_resultQueryCompleta := pa_line_profile.get_complete_profile(pio_bill_number    => pio_bill_number,
                                                                  pio_cellularnumber => pio_cellularnumber,
                                                                  pi_get_email_validated => pi_get_email_validated,
                                                                  po_accountid       => po_accountid,
                                                                  po_companyid       => po_companyid,
                                                                  po_businesstype    => po_businesstype,
                                                                  po_clientId        => po_clientId,
                                                                  po_clienttype      => po_clienttype,
                                                                  po_clientCategory  => po_clientCategory,
                                                                  po_linestatus      => po_linestatus,
                                                                  po_cellular_data   => po_cellular_data,
                                                                  po_client_data     => po_client_data,
                                                                  po_account_data    => po_account_data,
                                                                  po_codigo_error    => po_codigo_error,
                                                                  po_mensaje_error   => po_mensaje_error,
                                                                  po_mensaje_salida  => po_mensaje_salida);
    IF v_resultQueryCompleta <> 0 THEN
      RETURN v_resultQueryCompleta;
    END IF;
    -------------------------------------------
    -- Gets Call Restriction Data
    -------------------------------------------
    IF UPPER(pio_call_restrictions_data) = 'TRUE' OR
       UPPER(pio_call_restrictions_data) = 'YES' THEN
      DECLARE
        v_callRestrictionId   s_cellular_call_restrictions.ccr_id%type;
        v_callRestrictionDesc s_cellular_call_restrictions.ccr_rsn_id%type;
        v_callRestrictionClass VARCHAR2(10);
        v_ccr_cr_id s_cellular_call_restrictions.ccr_cr_id%type;
      BEGIN
        SELECT ccr_id, ccr_rsn_id, ccr_cr_id
          INTO v_callRestrictionId, v_callRestrictionDesc, v_ccr_cr_id
          FROM s_cellular_call_restrictions
         WHERE ccr_clu_cellular_number = pio_cellularnumber
           AND NVL(ccr_end_date, SYSDATE + 1) > SYSDATE
           AND ccr_start_date <= SYSDATE;
         --Get the classification of the presuspension
         v_callRestrictionClass:=decode_x_parametros(ClaveParametros => 'IVRPR',
                             ClaveADecodificar => trim(v_ccr_cr_id)||trim(v_callRestrictionDesc));             
                             
        pio_call_restrictions_data := '#callRestrictionId=' || v_callRestrictionId ||
                                      '#callRestrictionDesc=' || v_callRestrictionDesc || 
                                      '#callRestrictionClass=' || v_callRestrictionClass || '#';
      EXCEPTION
        WHEN no_data_found THEN
          pio_call_restrictions_data := '#callRestrictionId=' || '0' ||
                                        '#callRestrictionDesc=' || 'NOT FOUND' || 
                                        '#callRestrictionClass=' || 'NOT FOUND' || '#';
       
      
       --This when others is necesary as a fault in this section should not prevent the
        --function to return a valid result.
        WHEN others THEN
          pio_call_restrictions_data := '#ERROR Obtaining call restriction data:' ||
                                        SQLCODE || '. ' ||
                                        SUBSTR(SQLERRM, 1, 100) || '#';
      END;
    ELSE
      pio_call_restrictions_data := NULL;
    END IF;
    -------------------------------------------
    -- Gets Plan Data
    -------------------------------------------
    IF UPPER(pio_plan_data) = 'TRUE' OR UPPER(pio_plan_data) = 'YES' THEN
      DECLARE
        v_planId                      s_rate_plans.rpl_id%type;
        v_planType                    s_rate_plans.rpl_rty_id%type;
        v_planType_in_lineBAM_param   number;
        v_planTypeId_in_lineBAM_param number;
        v_lineBAM                     varchar2(5);
        v_planAdmiteFF                varchar2(5);
      BEGIN
        SELECT rpl_id, rpl_rty_id
          INTO v_planId, v_planType
          FROM s_cellular_plans
          JOIN s_rate_plans ON rpl_id = cpl_rpl_id
         WHERE cpl_clu_cellular_number = pio_cellularnumber
           AND cpl_stg_id = 'AH'
           AND cpl_start_date <= SYSDATE
           AND NVL(cpl_end_date, SYSDATE + 1) > SYSDATE;
        SELECT INSTR(stl_char_value, v_planType)
          INTO v_planType_in_lineBAM_param
          FROM s_stl_parameters
         WHERE stl_id = 'RTYBAM';
        v_lineBAM := 'FALSE';
        IF v_planType_in_lineBAM_param > 0 THEN
          v_lineBAM := 'TRUE';
        ELSE
          SELECT INSTR(stl_char_value, '#' || v_planType || ':' || v_planId || '#') +
                 INSTR(stl_char_value, '#*:' || v_planId || '#')
            INTO v_planTypeId_in_lineBAM_param
            FROM s_stl_parameters
           WHERE stl_id = 'RPLBAM';
          IF v_planTypeId_in_lineBAM_param > 0 THEN
            v_lineBAM := 'TRUE';
          END IF;
        END IF;
        SELECT DECODE(COUNT(1), 0, 'FALSE', 'TRUE')
          INTO v_planAdmiteFF
          FROM s_special_number_promotions
         WHERE snp_rpl_id = v_planId;
        pio_plan_data := '#planId=' || v_planId ||
                         '#planType=' || v_planType ||
                         '#lineBAM=' || v_lineBAM ||
                         '#planAdmiteFF=' || v_planAdmiteFF || '#';
      EXCEPTION
        WHEN no_data_found THEN
          pio_plan_data := '#planId=' || 0 || '#planType=' || 'NOT FOUND' ||
                           '#lineBAM=' || '' || '#planAdmiteFF=' || '' || '#';
        --This when others is necesary as a fault in this section should not prevent the
        --function to return a valid result.
        WHEN others THEN
          pio_plan_data := '#ERROR Obtaining plan data:' || SQLCODE || '. ' ||
                           SUBSTR(SQLERRM, 1, 100) || '#';
      END;
    ELSE
      pio_plan_data := NULL;
    END IF;
    -------------------------------------------
    -- Gets Authorization Data
    -------------------------------------------
    IF UPPER(pio_authorization_data) = 'TRUE' OR
       UPPER(pio_authorization_data) = 'YES' THEN
      DECLARE
        v_authorizationBillNumber     s_cellular_approval_accounts.caa_clu_cellular_number%type;
        v_authorizationCellularNumber cellulars.clu_bill_number%type;
      BEGIN
        SELECT caa_clu_cellular_number, clu_bill_number
          INTO v_authorizationCellularNumber, v_authorizationBillNumber
          FROM s_cellular_approval_accounts
          join s_cellulars ON caa_clu_cellular_number = clu_cellular_number
         WHERE caa_acc_id = po_accountId
           AND caa_start_date <= SYSDATE AND NVL(caa_end_date, SYSDATE+1) > SYSDATE;
        pio_authorization_data := '#authorizationBillNumber=' || v_authorizationBillNumber ||
                                  '#authorizationCellularNumber=' || v_authorizationCellularNumber || '#';
      EXCEPTION
        WHEN no_data_found THEN
          pio_authorization_data := '#authorizationBillNumber=' || 'NOT FOUND' ||
                                    '#authorizationCellularNumber=' || 'NOT FOUND' || '#';
        --This when others is necesary as a fault in this section should not prevent the
        --function to return a valid result.
        WHEN others THEN
          pio_authorization_data := '#ERROR Obtaining authorization data:' ||
                                    SQLCODE || '. ' ||
                                    SUBSTR(SQLERRM, 1, 100) || '#';
      END;
    ELSE
      pio_authorization_data := NULL;
    END IF;
    -------------------------------------------
    -- Get IVR Parametrized Data
    -------------------------------------------
    IF UPPER(pio_ivr_parameters) = 'TRUE' OR
       UPPER(pio_ivr_parameters) = 'YES' THEN
      DECLARE
        v_sendSurvey               varchar2(5);
        v_lineFixedMovile          varchar2(5);
        v_businessType_paramtrized number;
      BEGIN
        SELECT DECODE(INSTR(stl_char_value, '#' || po_businessType || '#'),
                      '0',
                      'FALSE',
                      'TRUE')
          INTO v_sendSurvey
          FROM s_stl_parameters
         WHERE stl_id = 'WWIENC';
        v_businessType_paramtrized := 0;
        -- Check if the business type is Movil
        SELECT (Instr(STL_CHAR_VALUE, '#' || po_businessType || '#'))
          INTO v_businessType_paramtrized
          FROM S_STL_PARAMETERS
         WHERE stl_id = 'WWITNM'
           AND SYSDATE BETWEEN stl_start_date AND
               NVL(stl_end_date, SYSDATE);
        IF v_businessType_paramtrized > 0 THEN
          v_lineFixedMovile := 'Movil';
        ELSE
          -- Check if the business type is  Fijo
          SELECT (Instr(STL_CHAR_VALUE, '#' || po_businessType || '#'))
            INTO v_businessType_paramtrized
            FROM S_STL_PARAMETERS
           WHERE stl_id = 'WWITNF'
             AND SYSDATE BETWEEN stl_start_date AND
                 NVL(stl_end_date, SYSDATE);
          IF v_businessType_paramtrized > 0 THEN
            v_lineFixedMovile := 'Fijo';
          END IF;
        END IF;
        pio_ivr_parameters := '#sendSurvey=' || v_sendSurvey ||
                              '#lineFixedMovile=' || v_lineFixedMovile ||  '#';
      EXCEPTION
        WHEN no_data_found THEN
          pio_ivr_parameters := '#sendSurvey=' || 'NOT FOUND' ||
                                '#lineFixedMovile=' || 'NOT FOUND' || '#';
      END;
    ELSE
      pio_ivr_parameters := NULL;
    END IF;
    -------------------------------------------
    -- Get Other Data
    -------------------------------------------
    IF UPPER(pio_other_data) = 'TRUE' OR UPPER(pio_other_data) = 'YES' THEN
       -- Available for future use. currently not used.
      pio_other_data := NULL;
    END IF;
    -------------------------------------------
    RETURN v_resultQueryCompleta;
  EXCEPTION
    WHEN no_data_found THEN
      po_codigo_error   := SQLCODE;
      po_mensaje_error  := SUBSTR(SQLERRM, 1, 100);
      po_mensaje_salida := 'NOTFOUND';
      RETURN 1;
  END Get_Extended_Profile;
  /*
  Author Gette Alan
  Version 1.0
  Last Modification: 03/12/2015
  Gets a line profile to be used on IVR's apps.
  Note: the value MileageCategory will be used in the future 
  */
  FUNCTION Get_Profile_Ivr(pio_billNumber          in out varchar2,
                           pio_cellularNumber      in out varchar2,
                           po_accountId            out varchar2,
                           po_accountType          out varchar2, 
                           po_accountClass         out varchar2, 
                           po_accountEntityId      out varchar2,
                           po_companyId            out varchar2,
                           po_businessType         out varchar2,
                           po_clientId             out varchar2,
                           po_clientType           out varchar2,
                           po_clientCategory       out varchar2,
                           po_clientClass	         out varchar2,
                           po_lineStatus           out varchar2,
                           po_cellularReasonId     out varchar2, 
                           po_reasonDescription    out varchar2, 
                           po_claroClubStatus      out varchar2, 
                           po_password             out varchar2, 
                           po_technology           out varchar2, 
                           po_mileageCategory      out varchar2,
                           po_serviceStatus        out varchar2,
                           po_lineFixedMovile      out varchar2,
                           po_callRestrictionId    out varchar2,
                           po_callRestrictionDesc  out varchar2,
                           po_callRestrictionClass out varchar2,
                           po_codigoError          out varchar2,
                           po_mensajeError         out varchar2,
                           po_mensajeSalida        out varchar2)
    RETURN NUMBER IS
  BEGIN
    po_codigoError   := 0;
    po_mensajeError  := 'OK';
    po_mensajeSalida := 'OK';
    -- At least one Cellular or Bill Number must be given
    IF pio_billNumber IS NULL AND pio_cellularNumber IS NULL THEN
      po_codigoError   := 1;
      po_mensajeError  := 'Faltan Datos Obligatorios';
      po_mensajeSalida := 'Debe Proporcionar al menos 1 numero de referencia';
      RETURN 1;
    END IF;
    -- Cellular Number has preference over Bill Number. So if cellular number
    -- is given, then bill number is ignored.
    IF pio_cellularNumber IS NOT NULL THEN
      pio_billNumber := null;
    END IF;
    
    SELECT /*+ INDEX_DESC(S_CELLULARS) */ CLU_BILL_NUMBER,
           CLU_CELLULAR_NUMBER,
           CLU_ACC_ID,
           ACC_ATY_ID,
           NVL(ACC_ENT_ID, 0),
           ACC_CMP_ID,
           CLU_CBT_ID,
           CLT_ID,
           CLT_TYPE,
           CLT_CATEGORY,
           CLT_CLASS,
           CLU_STATUS,
           CLU_RSN_ID,
           RSN_DESCRIPTION,
           CLU_MILEAGE_STATUS,
           CLU_PASSWORD,
           NVL(CLU_PRO_MODE_TYPE, 'NOGSM'),
           MIC_CATEGORY,
           s_service_status.sst_service_status
      INTO pio_billNumber,
           pio_cellularNumber,
           po_accountId,
           po_accountType,
           po_accountEntityId,
           po_companyId,
           po_businessType,
           po_clientId,
           po_clientType,
           po_clientCategory,
           po_clientClass,
           po_lineStatus,
           po_cellularReasonId,
           po_reasonDescription,
           po_claroClubStatus,
           po_password,
           po_technology,
           po_mileageCategory,
           po_serviceStatus
      FROM S_CELLULARS
      JOIN S_ACCOUNTS ON ACC_ID = CLU_ACC_ID
      JOIN S_CLIENT ON CLT_ID = ACC_CLT_ID
      JOIN S_SERVICE_STATUS ON SST_CLU_CELLULAR_NUMBER = CLU_CELLULAR_NUMBER 
      LEFT JOIN S_MILEAGE_CATEGORY ON MIC_CELLULAR_NUMBER = CLU_CELLULAR_NUMBER
      LEFT JOIN S_REASONS ON CLU_RSN_ID = RSN_ID
      WHERE ((pio_billNumber IS NOT null AND CLU_BILL_NUMBER = pio_billNumber)
      OR (pio_cellularNumber IS NOT null AND CLU_CELLULAR_NUMBER = pio_cellularNumber))
      AND SST_START_DATE <= SYSDATE
      AND NVL(SST_END_DATE, SYSDATE + 1) > SYSDATE;
      --Get the classification of the accountType. Eg: accountType='N' --> accountTypeClass='CORPO'
      --Primero buscamos tipo de cuenta en IVRAT1
      po_accountClass:=decode_x_parametros(ClaveParametros => 'IVRAT1',
                             ClaveADecodificar => trim(po_accountType));-- Tipo de cuenta en IVRAT1
         
      IF po_accountClass IS NULL THEN --Si no esta en IVRAT1, buscamos en IVRAT2
         po_accountClass:=decode_x_parametros(ClaveParametros => 'IVRAT2',
                             ClaveADecodificar => trim(po_accountType));-- Tipo de cuenta eb IVRAT2
      END IF;
         
    -------------------------------------------
    -- Gets Call Restriction Data
    -------------------------------------------
      DECLARE
        v_ccr_cr_id s_cellular_call_restrictions.ccr_cr_id%type;
      BEGIN
        SELECT ccr_id, ccr_rsn_id, ccr_cr_id
          INTO po_callRestrictionId, po_callRestrictionDesc, v_ccr_cr_id
          FROM s_cellular_call_restrictions
         WHERE ccr_clu_cellular_number = pio_cellularnumber
           AND NVL(ccr_end_date, SYSDATE + 1) > SYSDATE
           AND ccr_start_date <= SYSDATE;
           dbms_output.put_line('v_ccr_cr_id: '||v_ccr_cr_id);
           dbms_output.put_line('`po_callRestrictionDesc: '||po_callRestrictionDesc);

         --Get the classification of the presuspension
         po_callRestrictionClass:=decode_x_parametros(ClaveParametros => 'IVRPR',
                             ClaveADecodificar => trim(v_ccr_cr_id)||trim(po_callRestrictionDesc));             
                             
      EXCEPTION
        WHEN no_data_found THEN
          po_callRestrictionId := '0';
          po_callRestrictionDesc := 'NOT FOUND';
          po_callRestrictionClass := 'NOT FOUND';
                           
       --This when others is necesary as a fault in this section should not prevent the
        --function to return a valid result.
        WHEN others THEN
          po_callRestrictionId := '0';
          po_callRestrictionDesc := 'NOT FOUND';
          po_callRestrictionClass := 'NOT FOUND';
      END;
    
    -------------------------------------------
    -- Get IVR Parametrized Data
    -------------------------------------------
      DECLARE
        v_businessType_paramtrized number;
      BEGIN
        v_businessType_paramtrized := 0;
        -- Check if the business type is Movil
        SELECT (Instr(STL_CHAR_VALUE, '#' || po_businessType || '#'))
          INTO v_businessType_paramtrized
          FROM S_STL_PARAMETERS
         WHERE stl_id = 'WWITNM'
           AND SYSDATE BETWEEN stl_start_date 
           AND NVL(stl_end_date, SYSDATE);
        IF v_businessType_paramtrized > 0 THEN
          po_lineFixedMovile := 'Movil';
        ELSE
          -- Check if the business type is  Fijo
          SELECT (Instr(STL_CHAR_VALUE, '#' || po_businessType || '#'))
            INTO v_businessType_paramtrized
            FROM S_STL_PARAMETERS
           WHERE stl_id = 'WWITNF'
             AND SYSDATE BETWEEN stl_start_date 
             AND NVL(stl_end_date, SYSDATE);
          IF v_businessType_paramtrized > 0 THEN
            po_lineFixedMovile := 'Fijo';
          END IF;
        END IF;
      EXCEPTION
        WHEN no_data_found THEN
          po_lineFixedMovile := 'NOT FOUND';
      END;
    -------------------------------------------
    RETURN 0;
  EXCEPTION
    WHEN no_data_found THEN
      po_codigoError   := SQLCODE;
      po_mensajeError  := SUBSTR(SQLERRM, 1, 100);
      po_mensajeSalida := 'NOTFOUND';
      RETURN 1;
      
    WHEN too_many_rows THEN
      po_codigoError   := SQLCODE;
      po_mensajeError  := SUBSTR(SQLERRM, 1, 100);
      po_mensajeSalida := 'TOO_MANY_ROWS_ERROR';
      RETURN 1;
  END Get_Profile_Ivr;

END PA_LINE_PROFILE;
/

