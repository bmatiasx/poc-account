create FUNCTION get_datelu RETURN date DETERMINISTIC is
begin
return sysdate;
end get_datelu;
/

