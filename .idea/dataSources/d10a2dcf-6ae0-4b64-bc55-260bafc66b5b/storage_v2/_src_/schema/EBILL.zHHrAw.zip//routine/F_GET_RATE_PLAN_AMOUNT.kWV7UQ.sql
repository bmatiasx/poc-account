create FUNCTION F_GET_RATE_PLAN_AMOUNT
 (P_RPL_ID IN VARCHAR2
 ,P_RPL_DESCRIPTION OUT VARCHAR2
 ,P_INVOICE_CONCEPT OUT VARCHAR2
 ,P_RATE_PLAN_AMOUNT OUT NUMBER
 ,P_ERR_MESSAGE OUT VARCHAR2
 ,P_ERR_NUMBER OUT NUMBER
 )
 RETURN NUMBER
 IS
BEGIN
  p_err_message := 'Buscando el monto del abono ' || p_rpl_id || '.';
  SELECT rp.rpl_description, ic.inc_description, ROUND(vcp.chp_amount, 2)
    INTO p_rpl_description, p_invoice_concept, p_rate_plan_amount
    FROM s_charge_plans vcp, s_charges chr, s_invoice_concepts ic, s_rate_plans rp
   WHERE vcp.chp_start_date <= SYSDATE
     AND NVL(vcp.chp_end_date, SYSDATE + 1) > SYSDATE
     AND vcp.chp_chr_id = 'CU'
     AND rp.rpl_id = vcp.chp_rpl_id
     AND ic.inc_id = chr.chr_inc_id
     AND chr.chr_id = vcp.chp_chr_id
     AND vcp.chp_rpl_id = p_rpl_id;
  p_err_message := 'OK';
  p_err_number  := NULL;
  RETURN 0;
EXCEPTION
  WHEN no_data_found THEN
    p_err_message := 'No se econtraron datos del plan ' || p_rpl_id || '. ';
    p_err_number  := NULL;
    RETURN 1;
  WHEN OTHERS THEN
    p_err_message := substr('Error: ' || p_err_message || SQLERRM, 255);
    p_err_number  := SQLCODE;
    RETURN - 1;
END;
/

