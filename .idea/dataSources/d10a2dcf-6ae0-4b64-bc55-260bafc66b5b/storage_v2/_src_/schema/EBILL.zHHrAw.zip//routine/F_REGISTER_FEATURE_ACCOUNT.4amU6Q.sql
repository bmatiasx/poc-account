create FUNCTION F_REGISTER_FEATURE_ACCOUNT

(P_ARF_ID IN VARCHAR2, P_ERR_NUMBER OUT NUMBER, P_ERR_MESSAGE OUT VARCHAR2)
  RETURN NUMBER IS
  V_CCR_CR_ID        VARCHAR2(10);
  V_REASON_CR        VARCHAR2(20);
  V_REASON_SI        VARCHAR2(20);
  V_FEATURES_SEP     VARCHAR2(10);
  V_ARF_ACC_ID       VARCHAR2(10);
  V_RESULT           NUMBER;
  V_CALL_RESTRICTION VARCHAR2(100);
  V_ID               VARCHAR2(10);
  V_DESCRIPTION      VARCHAR2(200);
  V_VALUE            VARCHAR2(100);
  CURSOR C_LINES(P_ARF_ID IN VARCHAR2) IS
    SELECT (SELECT CLU_CELLULAR_NUMBER
              FROM S_CELLULARS
             WHERE CLU_CELLULAR_NUMBER = AFD_CELLULAR_NUMBER) AS AFD_CELLULAR_NUMBER,
           AFD_ID,
           AFD_STATUS,
           AFD_FEATURE_ID,
           AFD_FEATURE_STATUS,
           AFD_TRANSACTION_TYPE
      FROM ACC_REG_FEATURE_DETAIL
     WHERE AFD_ARF_ID = P_ARF_ID;
BEGIN
  -- Busco si existe la transaccion
  BEGIN
    SELECT ARF_ACC_ID
      INTO V_ARF_ACC_ID
      FROM ACCOUNT_REGISTER_FEATURES
     WHERE ARF_ID = P_ARF_ID;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      P_ERR_NUMBER  := -3001;
      P_ERR_MESSAGE := 'NO EXISTE LA OPERACION';
      RETURN 1;
  END;
  -- Busco en stl_parameters
  BEGIN
    SELECT STL_CHAR_VALUE
      INTO V_REASON_CR
      FROM STL_PARAMETERS
     WHERE STL_ID = 'REASCR';
    SELECT STL_CHAR_VALUE
      INTO V_REASON_SI
      FROM STL_PARAMETERS
     WHERE STL_ID = 'REASSI';
    SELECT STL_CHAR_VALUE
      INTO V_REASON_SI
      FROM STL_PARAMETERS
     WHERE STL_ID = 'AFDSEP';
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      P_ERR_NUMBER  := -3002;
      P_ERR_MESSAGE := 'NO SE ENCUENTRA PARAMETRO';
      RETURN 1;
  END;
  -- Busco el detalle de la transaccion y recorro el cursor
  FOR CELLULAR IN C_LINES(P_ARF_ID) LOOP
    IF CELLULAR.AFD_TRANSACTION_TYPE = 'CR' THEN
      -- Cambio CR
      BEGIN
        -- Busco CR vigente
        BEGIN
          SELECT CCR_CR_ID
            INTO V_CCR_CR_ID
            FROM S_CELLULAR_CALL_RESTRICTIONS
           WHERE CCR_CLU_CELLULAR_NUMBER = CELLULAR.AFD_CELLULAR_NUMBER
             AND NVL(CCR_START_DATE, SYSDATE + 1) > SYSDATE;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            P_ERR_NUMBER  := -3003;
            P_ERR_MESSAGE := 'ERROR AL TRAER CR ACTUAL';
            RETURN 1;
        END;
        -- Aplico el cambio
        V_RESULT := F_CHANGE_CR(CELLULAR.AFD_CELLULAR_NUMBER,
                                V_CCR_CR_ID,
                                CELLULAR.AFD_FEATURE_STATUS,
                                V_REASON_CR,
                                V_REASON_SI,
                                NULL,
                                V_CALL_RESTRICTION,
                                V_ID,
                                V_DESCRIPTION,
                                V_VALUE,
                                P_ERR_NUMBER,
                                P_ERR_MESSAGE);
        -- Actualizo el registro correspondiente en ACC_REG_FEATURE_DETAIL
        IF V_RESULT = 0 THEN
          UPDATE ACC_REG_FEATURE_DETAIL
             SET AFD_EXECUTE_DATE = SYSDATE,
                 AFD_STATUS       = 'OK',
                 AFD_ORIGINAL_MSG = P_ERR_MESSAGE
           WHERE AFD_ID = CELLULAR.AFD_ID;
        
        ELSE
          UPDATE ACC_REG_FEATURE_DETAIL
             SET AFD_EXECUTE_DATE = SYSDATE,
                 AFD_STATUS       = 'E',
                 AFD_ORIGINAL_MSG = P_ERR_MESSAGE
           WHERE AFD_ID = CELLULAR.AFD_ID;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          P_ERR_NUMBER  := -3004;
          P_ERR_MESSAGE := 'ERROR AL EJECUTAR F_CHANGE_CR';
          RETURN - 1;
      END;
    ELSE
      -- Cambio de Features
      BEGIN
        V_RESULT := F_CHANGE_FEATURE(CELLULAR.AFD_CELLULAR_NUMBER,
                                     CELLULAR.AFD_FEATURE_STATUS,
                                     V_FEATURES_SEP,
                                     P_ERR_MESSAGE);
        -- Actualizo el registro correspondiente en ACC_REG_FEATURE_DETAIL
        IF V_RESULT = 0 THEN
          UPDATE ACC_REG_FEATURE_DETAIL
             SET AFD_EXECUTE_DATE = SYSDATE,
                 AFD_STATUS       = 'OK',
                 AFD_ORIGINAL_MSG = P_ERR_MESSAGE
           WHERE AFD_ID = CELLULAR.AFD_ID;
        
        ELSE
          UPDATE ACC_REG_FEATURE_DETAIL
             SET AFD_EXECUTE_DATE = SYSDATE,
                 AFD_STATUS       = 'E',
                 AFD_ORIGINAL_MSG = P_ERR_MESSAGE
           WHERE AFD_ID = CELLULAR.AFD_ID;
        END IF;
        P_ERR_NUMBER := 0; -- Lo agrego aca ya que la funcion no lo hace
      EXCEPTION
        WHEN OTHERS THEN
          P_ERR_NUMBER  := -3005;
          P_ERR_MESSAGE := 'ERROR AL EJECUTAR F_CHANGE_FEATURE';
          RETURN - 1;
      END;
    END IF;
  END LOOP;

  RETURN 0;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    P_ERR_NUMBER  := SQLCODE;
    P_ERR_MESSAGE := SQLERRM;
    RETURN - 1;
END F_REGISTER_FEATURE_ACCOUNT;
/

