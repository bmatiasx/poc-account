create FUNCTION F_UPDATE_USERNAME
 (P_CLU_CELLULAR_NUMBER IN VARCHAR2
 ,P_CUS_NAME IN VARCHAR2
 ,P_CUS_SURNAME IN VARCHAR2
 ,P_ERR_NUMBER OUT NUMBER
 ,P_ERR_MESSAGE OUT VARCHAR2
 )
 RETURN NUMBER
 IS
BEGIN
    
    RETURN f_update_username@prod (p_clu_cellular_number => p_clu_cellular_number
                                                        ,p_cus_name => p_cus_name
                                                        ,p_cus_surname => p_cus_surname
                                                        ,p_err_number => p_err_number
                                                        ,p_err_message => p_err_message
    );
    
EXCEPTION
WHEN OTHERS THEN
    p_err_number := SQLCODE;
    p_err_message := SQLERRM;
    RETURN -1;
END f_update_username;
/

