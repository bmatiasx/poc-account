create PACKAGE PKG_SERVICES_TECNOTREE IS
  FUNCTION F_GET_FROZEN_BALANCE_DAYS(P_FECHA_EXPIRACION_MAIN IN VARCHAR2,
                                     P_FECHA_EXPIRACION_CONG OUT DATE,
                                     P_ERROR_MSG             OUT VARCHAR2)
    RETURN NUMBER;
  FUNCTION F_GET_PKG_INFO(P_CADENA       IN VARCHAR2,
                          P_CELLULAR     IN VARCHAR2,
                          P_SEPARADOR    IN VARCHAR2,
                          P_SALIDA       OUT VARCHAR2,
                          P_ERROR        OUT VARCHAR2,
                          P_ERROR_NUMBER OUT NUMBER) RETURN VARCHAR2;
END PKG_SERVICES_TECNOTREE;
/

