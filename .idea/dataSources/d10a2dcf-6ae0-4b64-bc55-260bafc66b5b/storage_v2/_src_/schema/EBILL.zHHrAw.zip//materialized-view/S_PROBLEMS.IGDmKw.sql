create materialized view S_PROBLEMS
refresh complete on demand
  as
    SELECT PBL_ID,
                      PBL_DESCRIPTION,
	   PBL_START_DATE,
	   PBL_END_DATE,
	   PBL_FLAG_CORPO,
	   PBL_FLAG_EECC,
	   PBL_FLAG_CRITIC
FROM STL.PROBLEMS@PROD

/

