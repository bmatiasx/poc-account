create PACKAGE WEB_PA_IVR_COB IS

  function test return number;
  
  Function web_registra_pago_tc (p_acc_id IN ACCOUNTS.ACC_ID%TYPE,
                    p_celular_NUMBER IN CELLULARS.clu_cellular_number%TYPE,
                    p_credit_card_nro IN VARCHAR2,
                    p_credit_card_pin IN VARCHAR2,
                    p_credit_card_vto IN VARCHAR2,
                    p_crd_id IN t_cards.crd_id%TYPE,
                    p_entidad IN COLLECTION_ENTITIES.coe_id%TYPE,
                    p_tipo_entidad IN COLLECTION_ENTITIES.coe_cet_id%TYPE,
                    p_cuotas IN NUMBER,
                    p_compania IN VARCHAR2,
                    p_importe_transaccion IN NUMBER,
                    p_tipo_operacion IN VARCHAR2,
                    p_origen IN VARCHAR2,
                    p_nro_documento IN NUMBER,
                    pVERSION_SOFT IN VARCHAR2,
                    pID_SISTEMA IN VARCHAR2,
                    p_aCTION in VARCHAR2,
                    p_REASON  in   VARCHAR2,
                    p_gRC_id OUT NUMBER,
                    p_mensaje OUT VARCHAR2,
                    p_mensaje_codigo OUT VARCHAR2)
  RETURN NUMBER ;
END WEB_PA_IVR_COB;

/

