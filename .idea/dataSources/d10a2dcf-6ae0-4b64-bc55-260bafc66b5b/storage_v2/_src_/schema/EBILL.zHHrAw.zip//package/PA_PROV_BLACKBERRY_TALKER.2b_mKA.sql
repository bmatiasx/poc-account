create package PA_PROV_BLACKBERRY_TALKER is

  -- Author  : Mariano Arselan
  -- Created : 06/03/2006 03:23:22 p.m.
  -- Purpose : Funciones de escritura de respuestas del talker en las tablas de blackberry y funciones
  --           de manejo de notificaciones entre el modulo de charly y el talker


  -- Public constant declarations
     -- Transaction States
   c_PENDING constant varchar2(1) := 'P';
   c_IN_PROGRESS constant varchar2(1) := 'I';
   c_OK constant varchar2(1) := 'O';
   c_ERROR constant varchar2(1) := 'E';
      -- Service codes
   c_REV constant varchar(4) := 'REV';
      -- constants for REV replies
   c_STATUS_REPLY constant varchar(1) := 'S';
   c_ERROR_REPLY constant varchar(1) := 'E';
   c_SINGLE_REPLY constant varchar(4) := 'SR';
      -- constants for pipes
   c_PIPE_MESSAGE_RECEIVED constant number := 0;
   c_PIPE_TIMEOUT constant number := 1;
   c_PIPE_INTERRUPTED constant number := 3;
   c_PIPE_INSUFFICIENT_PRIVILEGES constant number := 23322;

      -- nombre de los pipes
   c_PIPE_UPDATE constant varchar2(20) := 'bb_pipe_update_bbi';
   c_PIPE_REVIEW constant varchar2(20) := 'bb_pipe_review_bbi';
      -- id de los registros en la tabla bb_locks
   c_LOCK_UPDATE constant number := 1;
   c_LOCK_REVIEW constant number := 2;

  -- Public variable declarations
  -- Public types declarations
  type ref_pending_services_cursor is ref cursor;
  type ref_assign_services_cursor is ref cursor;

  -- Public function and procedure declarations
  function f_get_next_transaction_id return number;
  procedure p_set_transaction_started(p_bbi_id number, p_transaction_id number);
  procedure p_set_transaction_responsed(p_bbi_id number, p_status varchar2);

  procedure p_save_ids_reply(p_bbi_id number, p_imei varchar2, p_msisdn varchar2);
  procedure p_save_reply(p_bbi_id number, p_service varchar2, p_code number, p_description varchar2);
  procedure p_save_error_code(p_bbi_id number, p_code number, p_description varchar2);



  function f_fetch_update_requests (p_max_fetch_size number) return ref_pending_services_cursor;
  function f_fetch_review_requests (p_max_fetch_size number) return ref_pending_services_cursor;

  function f_fetch_assign_services (p_bbi_id number) return ref_assign_services_cursor;
  procedure p_save_assign_reply(p_bap_id number, p_code number, p_description varchar2);

  -- funciones bloqueantes que escuchan avisos de inserts de datos en
  -- la tabla blackberry_interfaces
  function f_listen_update_bbi return number;
  function f_listen_review_bbi return number;
  function f_listen_bbi(p_pipe_name varchar2, p_lock_id number) return number;

  -- funciones que dan avisos de insert de datos en
  -- la tabla blackberry_interfaces
  function f_notify_update_bbi return number;
  function f_notify_review_bbi return number;
  function f_notify_bbi(p_pipe_name varchar2, p_lock_id number) return number;


end PA_PROV_BLACKBERRY_TALKER;
/

