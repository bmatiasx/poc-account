create PACKAGE BODY     PA_WEB_CLARO_PLAY IS
  PROCEDURE P_GET_MAIN_LINE(P_CELLULAR_NUMBER IN VARCHAR2,
                                            VOUT_MAIN_LINE OUT NOCOPY VARCHAR2,
                                            VOUT_ADDITIONAL_LINES OUT NOCOPY VARCHAR2,
                                            VOUT_ERROR OUT NOCOPY NUMBER,
                                            VOUT_ERROR_MSG OUT NOCOPY VARCHAR2
  ) IS

  CURSOR cur_adicional IS
    SELECT mml.adicional
    FROM mock_main_lines mml
    WHERE mml.principal = principal
          AND mml.adicional <> mml.principal;

  v_adicional   VARCHAR2(100) := NULL;

  BEGIN
    VOUT_ERROR := NULL;
    VOUT_ERROR_MSG := NULL;

    SELECT principal
    INTO VOUT_MAIN_LINE
    FROM mock_main_lines
    WHERE adicional = P_CELLULAR_NUMBER
          AND ROWNUM <= 1;

    FOR cur IN cur_adicional LOOP
      IF cur_adicional%ROWCOUNT = 1 THEN
        v_adicional := '#' || cur.adicional || '#';
      ELSE
        v_adicional := v_adicional || cur.adicional || '#';
      END IF;
    END LOOP;

    VOUT_ADDITIONAL_LINES := v_adicional;

    EXCEPTION
    WHEN OTHERS THEN
    VOUT_ERROR := 100;
    VOUT_ERROR_MSG := SQLERRM;
    RETURN;
  END P_GET_MAIN_LINE;
END PA_WEB_CLARO_PLAY;
/

