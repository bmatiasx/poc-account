create TYPE TYPE_TAB_MATRIZ AS TABLE OF TYPE_REC_MATRIZ
select * from dba_objects a
where a.owner  = 'EBILL'
/

