create materialized view S_FEATURES
refresh fast on demand
  as
    SELECT FTR_ID,
	   FTR_DESCRIPTION,
	   FTR_SWITCH_FLAG,
	   FTR_TECHNOLOGY,
	   FTR_AVAILABILITY,
	   FTR_VOICE_FLAG,
	   FTR_LIMIT_LICENSES,
	   FTR_USED_LICENSES,
	   FTR_NEEDS_SPECIAL_PRODUCT,
                      FTR_INDEX_PROFILE,
                      FTR_SPEED_QOSP,
                      FTR_FEP_ID,
                      FTR_SCP_PACKAGE_ID,
                      FTR_SPEED,
                      FTR_TYPE,
                      FTR_WEB_DESCRIPTION,
                      FTR_VISIBILITY,
                      FTR_HELP,
                      FTR_BOUQUET
FROM TEST.FEATURES@PROD.WORLD


/

