create FUNCTION f_get_valor

(p_nim       IN VARCHAR2,
 p_mode_type OUT VARCHAR2,
 p_msgerr    OUT VARCHAR2) RETURN BOOLEAN IS
 v_result NUMBER;
 v_valor  NUMBER;

BEGIN
 BEGIN
 

  SELECT 1
  INTO   v_valor
  FROM   s_cellulars
  WHERE  clu_cellular_number = p_nim;
 EXCEPTION
  WHEN no_data_found THEN
   v_valor := -1;
 END;
 dbms_output.put_line('antes del query: '||  v_valor);
 IF v_valor = -1 THEN
 dbms_output.put_line(' valor = 1 = false');
  RETURN FALSE;
 END IF;

 RETURN TRUE;

EXCEPTION
 WHEN OTHERS THEN
  p_msgerr := 'ERROR AL CONSULTAR si existe la linea';
  RETURN FALSE;
END;
/

