create FUNCTION F_PRESUSPE
 (P_CELULAR IN VARCHAR2
 ,P_TCK IN NUMBER
 ,P_RAZON IN VARCHAR2
 ,P_USER_CONECT IN VARCHAR2
 )
 RETURN NUMBER
 IS
result NUMBER;
BEGIN
 
    result := presuspe@PROD (celular => p_celular 
                                         ,tck => p_tck
                                         ,razon => p_razon
                                         ,p_user_conect => p_user_conect
                                         );
    RETURN result;
    
END f_presuspe;
/

