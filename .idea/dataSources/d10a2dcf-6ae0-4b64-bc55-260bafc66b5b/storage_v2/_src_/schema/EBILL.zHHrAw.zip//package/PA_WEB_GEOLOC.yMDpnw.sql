create PACKAGE PA_WEB_GEOLOC IS

FUNCTION ValidaGroup (p_nameGroup IN VARCHAR2,
                     p_passGroup IN VARCHAR2,
                     p_clt_id OUT NUMBER,
                     p_client_name OUT VARCHAR2,
		             p_GCG_CLU_BILL_NUMBER_MASTER OUT VARCHAR2)
                RETURN NUMBER;


Function ObtenerCellularNumber(p_bill_number in  varchar2,
                               p_cellular    out varchar2)
                               return number;


Function ValidaPassClient(p_cellular_number in varchar2,
                          p_password        in varchar2,
                          p_clt_id          out number,
                          p_client_name     out varchar2)
                return number;


FUNCTION loadDatosGrupo
            (p_GCG_name			IN  varchar2,
            p_GCG_clt_id		IN  number,
            p_GCG_ID 			out number,
            p_GCG_DESCRIPTION 	out varchar2,
            p_GCG_PASSWORD 		out varchar2,
            p_GCG_STATUS 		out varchar2,
            p_GCG_CLU_BILL_NUMBER_MASTER out varchar2)
     RETURN NUMBER;


Function getECP(p_cellular_number in VARCHAR2,
                vout_ecp_id       OUT VARCHAR2,
                vout_error        OUT VARCHAR2)
    return number;


Function where_am_i(p_cell_id VARCHAR2,
                    p_antena VARCHAR2,
                    p_ecp_id VARCHAR2,
                    vout_sites OUT VARCHAR2,
                    vout_neighborhood OUT VARCHAR2,
                    vout_cities OUT VARCHAR2,
                    vout_latitud OUT VARCHAR2,
                    vout_longitud OUT VARCHAR2,
                    vout_error OUT VARCHAR2)
     return number;


Function where_am_i_gsm( bts_cell_id VARCHAR2,
                         lac         VARCHAR2,
                         mnc         VARCHAR2,
                         cell_id     OUT VARCHAR2,
                         site        OUT VARCHAR2,
                         latitude    OUT VARCHAR2,
                         longitude   OUT VARCHAR2,
                         error       OUT VARCHAR2 ) return number;


Function valida_celular( p_celular in VARCHAR2)
    return number;


Function area_numero(p_clu_cellular_number IN VARCHAR2,
                     p_cod_area            OUT varchar2,
                     p_numero              OUT varchar2,
                     p_mensaje             OUT varchar2)
    RETURN number;


FUNCTION encrypt(p_value IN VARCHAR2,
                p_result OUT VARCHAR2)
            RETURN NUMBER;


FUNCTION decrypt(p_value IN VARCHAR2,
                p_result OUT VARCHAR2)
            RETURN NUMBER;


FUNCTION get_id_geoloc(p_cellular_number   IN  VARCHAR2,
                       id_client_encripted OUT VARCHAR2,
                       p_bill_number       OUT VARCHAR2)
    RETURN NUMBER;


FUNCTION insert_log(p_APPLICATION_NAME VARCHAR2,
                  p_NIM_LOGGED VARCHAR2,
        		  p_NIM_LOCATED VARCHAR2,
		          p_status VARCHAR2, -- S (Solicitado) E (Enviado) C (Confirmado)
		          p_ERR_ID NUMBER,
 		          vout_rowid OUT VARCHAR2,
                  p_GTL_CALL_TYPE VARCHAR2 DEFAULT NULL) RETURN NUMBER;


FUNCTION update_log(p_rowid VARCHAR2,
		   p_latitude NUMBER,
		   p_longitude NUMBER,
		   p_status VARCHAR2,
		   p_err_id NUMBER ) RETURN NUMBER;


FUNCTION ValidaPass_Client(p_client_id IN number,
                        p_password IN VARCHAR2,
                        p_client_name OUT VARCHAR2)RETURN NUMBER;


FUNCTION valida_con_clt_id(p_clt_id IN number,
			   p_service IN VARCHAR2)RETURN NUMBER;


--insert cabecera en tabla geoloc_cellular_groups
FUNCTION create_group
            (p_GCG_name                     IN VARCHAR2,
            p_GCG_description               IN VARCHAR2,
            p_GCG_clt_id                    IN NUMBER,
            p_GCG_password                  IN VARCHAR2,
            p_GCG_CLU_BILL_NUMBER_MASTER    IN VARCHAR2,
            p_message                       OUT varchar2)
    RETURN number;


--borra cabecera y detalle en tabla geoloc_cellular_groups y geoloc_cellular_groups_details
FUNCTION delete_group
            (p_GCG_name       IN VARCHAR2,
            p_GCG_clt_id      IN NUMBER,
            p_message         OUT varchar2)
    RETURN number;


--insert detalle en tabla geoloc_cellular_groups_details
FUNCTION insert_ingroup_detail
        (p_GCG_name             IN VARCHAR2,
        p_GCG_clt_id            IN NUMBER,
        p_GGD_CLU_BILL_NUMBER_S IN varchar2,
        p_message               OUT varchar2)
    RETURN number;


--update descripcin de grupo
FUNCTION update_description
        (p_GCG_name         IN VARCHAR2,
        p_GCG_clt_id        IN NUMBER,
        p_GCG_description   IN VARCHAR2,
        p_message           OUT varchar2)
    RETURN number;

--update pass de grupo
FUNCTION update_pass
        (p_GCG_name                     IN VARCHAR2,
        p_GCG_clt_id                    IN NUMBER,
        p_GCG_password                  IN VARCHAR2,
        p_message OUT varchar2)
    RETURN number;


--update bill_numbver a facturar del grupo
FUNCTION update_bill
        (p_GCG_name                     IN VARCHAR2,
        p_GCG_clt_id                    IN NUMBER,
        p_GCG_CLU_BILL_NUMBER_MASTER    IN VARCHAR2,
        p_message                       OUT varchar2)
    RETURN number;

-- Inicio SP para RR5
FUNCTION Validapass (celular IN VARCHAR2,
                        password1 IN VARCHAR2,
                        password2 IN VARCHAR2,
                        tipo_negocio_c OUT VARCHAR2,
                        tipo_cliente OUT VARCHAR2)
                RETURN NUMBER;

FUNCTION Validanegocio (celular IN VARCHAR2,
                        tipo_negocio_c OUT VARCHAR2,
                        tipo_cliente OUT VARCHAR2)
                    RETURN NUMBER;

FUNCTION get_option_rr5
        (p_clu_cellular_number IN VARCHAR2,
         p_funcionalidad OUT varchar2,
         p_frase OUT varchar2,
         p_inc_cpp OUT varchar2,
         p_inc_pico OUT varchar2,
         p_inc_nopico OUT varchar2,
         p_noinc_pico OUT varchar2,
         p_noinc_nopico OUT varchar2,
         p_mensaje OUT varchar2)
    RETURN number;
-- Fin SP para RR5
END PA_WEB_GEOLOC; -- Package spec
/

