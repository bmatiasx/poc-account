create FUNCTION F_INS_UPD_CELL_PROFILE (P_CELLULAR      IN     VARCHAR2,
                                    P_DD_TYPE_NEW   IN     VARCHAR2,
                                    P_RESULT_OK        OUT VARCHAR2,
                                    P_ERROR_COD        OUT VARCHAR2,
                                    P_ERROR_MSG        OUT VARCHAR2)
      RETURN NUMBER
   IS
      V_CCR_ID    VARCHAR2 (15);
      V_CED_ID    VARCHAR2 (15);
      V_DD_TYPE   VARCHAR2 (20);

      PRAGMA AUTONOMOUS_TRANSACTION;

   BEGIN
      BEGIN
         SELECT CED_DDI_TYPE
           INTO V_DD_TYPE
           FROM CELLULAR_DDI_TYPES
          WHERE CED_CLU_CELLULAR_NUMBER = P_CELLULAR
          AND CED_END_DATE IS NULL;

      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
              INSERT INTO CELLULAR_DDI_TYPES (CED_ID,
                                              CED_CLU_CELLULAR_NUMBER,
                                              CED_DDI_TYPE,
                                              CED_USER,
                                              CED_APPROVAL_REQUIRED,
                                              CED_START_DATE)
                     VALUES (CED_SEQ.NEXTVAL,
                             P_CELLULAR,
                             P_DD_TYPE_NEW,
                             USER,
                             'N',
                             SYSDATE);

               P_RESULT_OK := 'Su transaccion fue realizada correctamente.';
               COMMIT;
               RETURN 0;


         WHEN OTHERS
         THEN
            P_ERROR_COD := '4001';
            P_ERROR_MSG :=
                  'Error al intentar consultar CELLULAR_DDI_TYPES: '
               || SQLCODE
               || ' ## '
               || SQLERRM;
            RETURN 1;
      END;

      BEGIN
         --Si es DDN, DDI Común, DDI Full
      IF V_DD_TYPE IN ('N', 'C', 'F') AND P_DD_TYPE_NEW IN ('N', 'C', 'F')
         THEN
            --## Ingresa con el parametro V_DD_TYPE como DDN (Discado Directo Nacional)
            IF V_DD_TYPE = 'N' THEN
                         IF P_DD_TYPE_NEW IS NULL
                            THEN
                                BEGIN
                                          RAISE TYPE_NEW_EXCEPTION;
                                EXCEPTION
                                WHEN TYPE_NEW_EXCEPTION
                                THEN
                                     P_ERROR_COD := '4002';
                                     P_ERROR_MSG :=
                                     'El parametro P_DD_TYPE_NEW no debe ser nulo.';
                                     RETURN 1;
                                     ROLLBACK;

                                END;
                          ELSIF P_DD_TYPE_NEW = 'N'
                             THEN
                                BEGIN
                                   RAISE TYPE_NEW_EXCEPTION;
                                EXCEPTION
                                WHEN TYPE_NEW_EXCEPTION
                                THEN
                                  P_ERROR_COD := '4003';
                                  P_ERROR_MSG :=
                                     'La linea ya posee el profile que intenta agregar.';
                                RETURN 1;
                                ROLLBACK;

                                END;
               --Actualiza en C o F el tipo de DDI (Discado Directo Internacional)
            ELSIF P_DD_TYPE_NEW IN ('C', 'F')
               THEN
                  BEGIN
                     SELECT CED_ID
                       INTO V_CED_ID
                       FROM CELLULAR_DDI_TYPES
                      WHERE     CED_CLU_CELLULAR_NUMBER = P_CELLULAR
                            AND CED_END_DATE IS NULL;

                     UPDATE CELLULAR_DDI_TYPES
                        SET CED_END_DATE = SYSDATE
                      WHERE CED_ID = V_CED_ID;

                     INSERT INTO CELLULAR_DDI_TYPES (CED_ID,
                                                     CED_CLU_CELLULAR_NUMBER,
                                                     CED_DDI_TYPE,
                                                     CED_USER,
                                                     CED_APPROVAL_REQUIRED,
                                                     CED_START_DATE)
                          VALUES (CED_SEQ.NEXTVAL,
                                  P_CELLULAR,
                                  P_DD_TYPE_NEW,
                                  USER,
                                  'N',
                                  SYSDATE);
                                  COMMIT;

                  EXCEPTION
                     WHEN NO_DATA_FOUND
                     THEN
                        --Lo carga en CELLULAR_DDI_TYPES
                        --en caso de ser la primera vez que tiene algun cambio a DDI
                        INSERT
                          INTO CELLULAR_DDI_TYPES (CED_ID,
                                                   CED_CLU_CELLULAR_NUMBER,
                                                   CED_DDI_TYPE,
                                                   CED_USER,
                                                   CED_APPROVAL_REQUIRED,
                                                   CED_START_DATE)
                        VALUES (CED_SEQ.NEXTVAL,
                                P_CELLULAR,
                                P_DD_TYPE_NEW,
                                USER,
                                'N',
                                SYSDATE);
                  END;

                  BEGIN
                     DBMS_APPLICATION_INFO.SET_CLIENT_INFO('CAMBIO_DDI_DDN_VIA_WEB');
                  END;

                  BEGIN
                    NUMBER V_RESULT := PA_SWITCH_INTERFACES.INSERT_SWITCH_INTERFACE(P_CELULAR     => P_CELLULAR,
                                                    P_ACTION        => 'U',
                                                    P_ACTION_DATE   => SYSDATE,
                                                    P_PRIORIDAD     => '4',
                                                    P_ESTADO        => NULL,
                                                    P_RSN           => P_REASON_SI,
                                                    P_ESN           => NULL,
                                                    P_CALL_DELIVERY => P_CALL_DELIVERY,
                                                    P_DCL           => NULL,
                                                    P_PRA           => NULL,
                                                    P_PACK          => NULL,
                                                    P_CALLR         => '1', --P_DD_TYPE_NEW,
                                                    P_CHANGE_NIM    => NULL,
                                                    MSG_ERR         => P_ERROR_MSG,
                                                    P_LIMITE_CONS   => NULL);

                    IF V_RESULT <> 0 THEN
                      P_ERROR_COD := '4004';
                      P_ERROR_MSG := 'Error al intentar actualizar SWITCH_INTERFACE: ' || P_ERROR_MSG;
                      RETURN - 1;
                    END IF;
                  EXCEPTION
                        WHEN OTHERS THEN
                             P_ERROR_COD := '4005';
                             P_ERROR_MSG := 'Error al intentar actualizar SWITCH_INTERFACE: ' ||
                             SQLCODE || ' ## ' || SQLERRM;
                             RETURN - 1;
                  END;

                    P_RESULT_OK := 'Su transaccion fue realizada correctamente.';
                    COMMIT;
                    RETURN 0;

                     WHEN OTHERS
                     THEN
                        P_ERROR_COD := '4006';
                        P_ERROR_MSG :=
                              'No se pudo realizar la actualizacion de la tabla CELLULAR_DDI_TYPES: '
                           || SQLCODE
                           || ' ## '
                           || SQLERRM;

                           RETURN 1;
                        ROLLBACK;
                  END;
     --- END IF;

































































    ELSIF V_DD_TYPE = 'C'
            THEN
               IF P_DD_TYPE_NEW IS NULL
               THEN
                  BEGIN
                     RAISE TYPE_NEW_EXCEPTION;
                  EXCEPTION
                     WHEN TYPE_NEW_EXCEPTION
                     THEN
                        P_ERROR_COD := '4007';
                        P_ERROR_MSG :=
                           'El parametro P_DD_TYPE_NEW no debe ser nulo.';
                           RETURN 1;
                        ROLLBACK;

                  END;
       ELSIF P_DD_TYPE_NEW = 'C'
               THEN
                  BEGIN
                     RAISE TYPE_NEW_EXCEPTION;
                  EXCEPTION
                     WHEN TYPE_NEW_EXCEPTION
                     THEN
                        P_ERROR_COD := '4008';
                        P_ERROR_MSG :=
                           'La linea ya posee el profile que intenta agregar.';
                           RETURN 1;
                        ROLLBACK;

                  END;
        ELSIF P_DD_TYPE_NEW = 'N'
               THEN
                  --## Ingresa con el parametro V_DD_TYPE como DDN (Discado Directo Nacional)
                  BEGIN
                     SELECT CCR_ID
                       INTO V_CCR_ID
                       FROM CELLULAR_CALL_RESTRICTIONS
                      WHERE     CCR_CLU_CELLULAR_NUMBER = P_CELLULAR
                            AND CCR_END_DATE IS NULL;

                     UPDATE CELLULAR_CALL_RESTRICTIONS
                        SET CCR_LAST_UPDATED_DATE = SYSDATE,
                            CCR_END_DATE = SYSDATE
                      WHERE CCR_ID = V_CCR_ID;

                     INSERT
                       INTO CELLULAR_CALL_RESTRICTIONS (
                               CCR_ID,
                               CCR_CR_ID,
                               CCR_START_DATE,
                               CCR_CLU_CELLULAR_NUMBER,
                               CCR_LAST_UPDATED_DATE,
                               CCR_RSN_ID)
                     VALUES (CCR_SEQ.NEXTVAL,
                             '2',
                             SYSDATE,
                             P_CELLULAR,
                             SYSDATE,
                             NULL);
                             COMMIT;
                  EXCEPTION
                     WHEN OTHERS
                     THEN
                        P_ERROR_COD := '4009';
                        P_ERROR_MSG :=
                              'No se pudo actualizar la tabla CELLULAR_CALL_RESTRICTIONS: '
                           || SQLCODE
                           || ' ## '
                           || SQLERRM;
                           RETURN 1;
                        ROLLBACK;

                  END;

                  BEGIN
                        DBMS_APPLICATION_INFO.SET_CLIENT_INFO('CAMBIO_DDI_DDN_VIA_WEB');
                  END;

                  BEGIN
                        V_RESULT := PA_SWITCH_INTERFACES.INSERT_SWITCH_INTERFACE(P_CELULAR       => P_CELLULAR,
                                                                   P_ACTION        => 'U',
                                                                   P_ACTION_DATE   => SYSDATE,
                                                                   P_PRIORIDAD     => '4',
                                                                   P_ESTADO        => NULL,
                                                                   P_RSN           => P_REASON_SI,
                                                                   P_ESN           => NULL,
                                                                   P_CALL_DELIVERY => P_CALL_DELIVERY,
                                                                   P_DCL           => NULL,
                                                                   P_PRA           => NULL,
                                                                   P_PACK          => NULL,
                                                                   P_CALLR         => '2', --P_DD_TYPE_NEW,
                                                                   P_CHANGE_NIM    => NULL,
                                                                   MSG_ERR         => V_ERR_MSG,
                                                                   P_LIMITE_CONS   => NULL);

                      IF V_RESULT <> 0 THEN
                        P_ERR_NUM := '4008';
                        P_ERR_MSG := 'Error al intentar actualizar SWITCH_INTERFACE: ' ||
                                     V_ERR_MSG;
                        RETURN - 1;
                      END IF;
                  EXCEPTION
                    WHEN OTHERS THEN
                      P_ERR_NUM := '4009';
                      P_ERR_MSG := 'Error al intentar actualizar SWITCH_INTERFACE: ' ||
                                   SQLCODE || ' ## ' || SQLERRM;
                      RETURN - 1;
                  END;

                  P_RESULT_OK :=
                     'Su transaccion fue realizada correctamente.';
                     RETURN 0;
                     COMMIT;


                    WHEN OTHERS
                     THEN
                        P_ERROR_COD := '4010';
                        P_ERROR_MSG :=
                              'No se pudo realizar la actualizacion de la tabla CELLULAR_DDI_TYPES: '
                           || SQLCODE
                           || ' ## '
                           || SQLERRM;

                           RETURN 1;
                        ROLLBACK;
                  END;



















              ELSIF P_DD_TYPE_NEW = 'F'
               THEN
                  -- Ingresa con el parametro V_DD_TYPE como DDI Full
                  -- (Discado Directo Internacional Full)
                  BEGIN
                     SELECT CED_ID
                       INTO V_CED_ID
                       FROM CELLULAR_DDI_TYPES
                      WHERE     CED_CLU_CELLULAR_NUMBER = P_CELLULAR
                            AND CED_END_DATE IS NULL;

                     UPDATE CELLULAR_DDI_TYPES
                        SET CED_END_DATE = SYSDATE
                      WHERE CED_ID = V_CED_ID;

                     INSERT INTO CELLULAR_DDI_TYPES (CED_ID,
                                                     CED_CLU_CELLULAR_NUMBER,
                                                     CED_DDI_TYPE,
                                                     CED_USER,
                                                     CED_APPROVAL_REQUIRED,
                                                     CED_START_DATE)
                          VALUES (CED_SEQ.NEXTVAL,
                                  P_CELLULAR,
                                  P_DD_TYPE_NEW,
                                  USER,
                                  'N',
                                  SYSDATE);
                                  COMMIT;

                  EXCEPTION
                     --Se inserta el registro para el caso de que
                     --no se encuentre en la tabla CELLULAR_DDI_TYPES.
                     WHEN NO_DATA_FOUND
                     THEN
                        INSERT
                          INTO CELLULAR_DDI_TYPES (CED_ID,
                                                   CED_CLU_CELLULAR_NUMBER,
                                                   CED_DDI_TYPE,
                                                   CED_USER,
                                                   CED_APPROVAL_REQUIRED,
                                                   CED_START_DATE)
                        VALUES (CED_SEQ.NEXTVAL,
                                P_CELLULAR,
                                P_DD_TYPE_NEW,
                                USER,
                                'N',
                                SYSDATE);

                     WHEN OTHERS
                     THEN
                        P_ERROR_COD := '4008';
                        P_ERROR_MSG :=
                              'Error al intentar actualizar la tabla CELLULAR_DDI_TYPES: '
                           || SQLCODE
                           || ' ## '
                           || SQLERRM;

                           RETURN 1;
                        ROLLBACK;

                  END;


                  BEGIN
                        DBMS_APPLICATION_INFO.SET_CLIENT_INFO('CAMBIO_DDI_DDN_VIA_WEB');
                  END;

                  BEGIN
                        V_RESULT := PA_SWITCH_INTERFACES.INSERT_SWITCH_INTERFACE(P_CELULAR       => P_CELLULAR,
                                                                   P_ACTION        => 'U',
                                                                   P_ACTION_DATE   => SYSDATE,
                                                                   P_PRIORIDAD     => '4',
                                                                   P_ESTADO        => NULL,
                                                                   P_RSN           => P_REASON_SI,
                                                                   P_ESN           => NULL,
                                                                   P_CALL_DELIVERY => P_CALL_DELIVERY,
                                                                   P_DCL           => NULL,
                                                                   P_PRA           => NULL,
                                                                   P_PACK          => NULL,
                                                                   P_CALLR         => '1', --P_DD_TYPE_NEW,
                                                                   P_CHANGE_NIM    => NULL,
                                                                   MSG_ERR         => V_ERR_MSG,
                                                                   P_LIMITE_CONS   => NULL);

                IF V_RESULT <> 0 THEN
                  P_ERR_NUM := '1023';
                  P_ERR_MSG := 'Error al intentar actualizar SWITCH_INTERFACE: ' ||
                               V_ERR_MSG;
                  RETURN - 1;
                END IF;
                EXCEPTION
                  WHEN OTHERS THEN
                    P_ERR_NUM := '4009';
                    P_ERR_MSG := 'Error al intentar actualizar SWITCH_INTERFACE: ' ||
                                 SQLCODE || ' ## ' || SQLERRM;
                    RETURN - 1;
                END;

                  P_RESULT_OK :=
                     'Su transaccion fue realizada correctamente.';
                     RETURN 0;
                     COMMIT;
    END IF;






   ELSIF V_DD_TYPE = 'F'
            THEN
               IF P_DD_TYPE_NEW IS NULL
                  THEN
                    BEGIN
                       RAISE TYPE_NEW_EXCEPTION;
                    EXCEPTION
                       WHEN TYPE_NEW_EXCEPTION
                       THEN
                          P_ERROR_COD := '4009';
                          P_ERROR_MSG :=
                             'El parametro P_DD_TYPE_NEW no debe ser nulo.';
                             RETURN 1;
                          ROLLBACK;

                    END;
               ELSIF P_DD_TYPE_NEW = 'F'
                     THEN
                        BEGIN
                           RAISE TYPE_NEW_EXCEPTION;
                        EXCEPTION
                           WHEN TYPE_NEW_EXCEPTION
                           THEN
                              P_ERROR_COD := '4010';
                              P_ERROR_MSG :=
                                 'La linea ya posee el profile que intenta agregar.';
                                 RETURN 1;
                              ROLLBACK;

                        END;
                         ELSIF P_DD_TYPE_NEW = 'N'
                               THEN
                            -- (Discado Directo Internacional Full), se pasa a DDN (Discado Directo Nacional)
                            -- Viene con DDI Full, se pasa a DDN
                            BEGIN
                               SELECT CCR_ID
                                 INTO V_CCR_ID
                                 FROM CELLULAR_CALL_RESTRICTIONS
                                WHERE     CCR_CLU_CELLULAR_NUMBER = P_CELLULAR
                                      AND CCR_END_DATE IS NULL;

                               UPDATE CELLULAR_CALL_RESTRICTIONS
                                  SET CCR_LAST_UPDATED_DATE = SYSDATE,
                                      CCR_END_DATE = SYSDATE
                                WHERE CCR_ID = V_CCR_ID;

                               INSERT
                                 INTO CELLULAR_CALL_RESTRICTIONS (
                                         CCR_ID,
                                         CCR_CR_ID,
                                         CCR_START_DATE,
                                         CCR_CLU_CELLULAR_NUMBER,
                                         CCR_LAST_UPDATED_DATE,
                                         CCR_RSN_ID)
                               VALUES (CCR_SEQ.NEXTVAL,
                                       '2',
                                       SYSDATE,
                                       P_CELLULAR,
                                       SYSDATE,
                                       NULL);

                               BEGIN
                                       DBMS_APPLICATION_INFO.SET_CLIENT_INFO('CAMBIO_DDI_DDN_VIA_WEB');
                               END;

                               BEGIN
                                       V_RESULT := PA_SWITCH_INTERFACES.INSERT_SWITCH_INTERFACE(P_CELULAR       => P_CELLULAR,
                                                                   P_ACTION        => 'U',
                                                                   P_ACTION_DATE   => SYSDATE,
                                                                   P_PRIORIDAD     => '4',
                                                                   P_ESTADO        => NULL,
                                                                   P_RSN           => P_REASON_SI,
                                                                   P_ESN           => NULL,
                                                                   P_CALL_DELIVERY => P_CALL_DELIVERY,
                                                                   P_DCL           => NULL,
                                                                   P_PRA           => NULL,
                                                                   P_PACK          => NULL,
                                                                   P_CALLR         => '2', --P_DD_TYPE_NEW,
                                                                   P_CHANGE_NIM    => NULL,
                                                                   MSG_ERR         => P_ERROR_MSG,
                                                                   P_LIMITE_CONS   => NULL);

                                     IF V_RESULT <> 0 THEN
                                        P_ERROR_COD := '4011';
                                        P_ERROR_MSG := 'Error al intentar actualizar SWITCH_INTERFACE: ' ||
                                        P_ERROR_MSG;
                                        RETURN - 1;
                                     END IF;
                               EXCEPTION
                               WHEN OTHERS THEN
                                    P_ERROR_COD := '4012';
                                    P_ERROR_MSG := 'Error al intentar actualizar SWITCH_INTERFACE: ' ||
                                    SQLCODE || ' ## ' || SQLERRM;
                                    RETURN - 1;
                                END;
                                      P_RESULT_OK :=
                                        'Su transaccion fue realizada correctamente.';
                                        COMMIT;
                                        RETURN 0;

                            EXCEPTION
                               WHEN OTHERS
                               THEN
                                  P_ERROR_COD := '4013';
                                  P_ERROR_MSG :=
                                        'No se pudo actualizar la tabla CELLULAR_CALL_RESTRICTIONS: '
                                     || SQLCODE
                                     || ' ## '
                                     || SQLERRM;
                                  ROLLBACK;
                                  RETURN 1;
                            END;



               ELSIF P_DD_TYPE_NEW = 'C'
               THEN
                  -- (Discado Directo Internacional Full), se pasa a DDI (Discado Directo Internacional)
                  BEGIN
                     SELECT CED_ID
                       INTO V_CED_ID
                       FROM CELLULAR_DDI_TYPES
                      WHERE     CED_CLU_CELLULAR_NUMBER = P_CELLULAR
                            AND CED_END_DATE IS NULL;

                     UPDATE CELLULAR_DDI_TYPES
                        SET CED_END_DATE = SYSDATE
                      WHERE CED_ID = V_CED_ID;

                          INSERT INTO CELLULAR_DDI_TYPES (CED_ID,
                                                     CED_CLU_CELLULAR_NUMBER,
                                                     CED_DDI_TYPE,
                                                     CED_USER,
                                                     CED_APPROVAL_REQUIRED,
                                                     CED_START_DATE)
                          VALUES (CED_SEQ.NEXTVAL,
                                  P_CELLULAR,
                                  P_DD_TYPE_NEW,
                                  USER,
                                  'N',
                                  SYSDATE);
                          EXCEPTION
                          WHEN OTHERS
                          THEN
                               P_ERROR_COD := '4014';
                               P_ERROR_MSG :=
                                           'No se pudo actualizar la tabla CELLULAR_DDI_TYPES: '
                                           || SQLCODE
                                           || ' ## '
                                           || SQLERRM;

                                           RETURN 1;
                                           ROLLBACK;
                           END;


                  BEGIN
                           DBMS_APPLICATION_INFO.SET_CLIENT_INFO('CAMBIO_DDI_DDN_VIA_WEB');
                  END;

                  BEGIN
                           V_RESULT := PA_SWITCH_INTERFACES.INSERT_SWITCH_INTERFACE(P_CELULAR       => P_CELLULAR,
                                                                   P_ACTION        => 'U',
                                                                   P_ACTION_DATE   => SYSDATE,
                                                                   P_PRIORIDAD     => '4',
                                                                   P_ESTADO        => NULL,
                                                                   P_RSN           => P_REASON_SI,
                                                                   P_ESN           => NULL,
                                                                   P_CALL_DELIVERY => P_CALL_DELIVERY,
                                                                   P_DCL           => NULL,
                                                                   P_PRA           => NULL,
                                                                   P_PACK          => NULL,
                                                                   P_CALLR         => '1', --P_DD_TYPE_NEW,
                                                                   P_CHANGE_NIM    => NULL,
                                                                   MSG_ERR         => P_ERROR_MSG,
                                                                   P_LIMITE_CONS   => NULL);

                           IF V_RESULT <> 0 THEN
                               P_ERROR_COD := '4015';
                               P_ERROR_MSG := 'Error al intentar actualizar SWITCH_INTERFACE: ' ||
                               P_ERROR_MSG;
                                   RETURN - 1;
                           END IF;

                P_RESULT_OK :=
                     'Su transaccion fue realizada correctamente.';
                      RETURN 0;
                     COMMIT;

         END IF;
            END IF;
         ELSE
            P_ERROR_COD := '4016';
            P_ERROR_MSG :=
               'El o los parametros ingresados P_DD_TYPE_NEW no son validos.';
            RETURN 1;
         END IF;
      EXCEPTION
         WHEN OTHERS
         THEN
            P_ERROR_COD := '4017';
            P_ERROR_MSG :=
                  'Error en F_INS_UPD_CELL_PROFILE: '
               || SQLCODE
               || ' ## '
               || SQLERRM;
            RETURN -1;
      END;
   EXCEPTION
      WHEN OTHERS
      THEN
         P_ERROR_COD := '4018';
         P_ERROR_MSG :=
               'Error al intentar consultar la tabla REG_CALL_PROFILE_DETAIL: '
            || SQLCODE
            || ' ## '
            || SQLERRM;
         RETURN 1;
   END F_INS_UPD_CELL_PROFILE;
/

