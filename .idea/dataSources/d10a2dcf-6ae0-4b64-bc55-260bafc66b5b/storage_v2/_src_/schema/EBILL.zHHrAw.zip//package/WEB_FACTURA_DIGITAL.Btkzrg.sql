create PACKAGE WEB_FACTURA_DIGITAL IS

  Function GetInfoAccount( PAcc_Id       IN  VARCHAR2,
                           PAcc_Clt_Id   OUT VARCHAR2,
                           PAcc_Cmp_Id   OUT VARCHAR2,
                           PAcc_Password OUT VARCHAR2 ) RETURN NUMBER;

  Function ValidaCluPassword ( bill_number     IN VARCHAR2,
                               password        IN VARCHAR2,
                               account_id      OUT VARCHAR2 ) RETURN NUMBER;

  Function GetAvailablePeriods( account      IN VARCHAR2,
                                periods_list OUT VARCHAR2,
                                periods_id   OUT VARCHAR2 ) RETURN NUMBER;

  Function ValidateSession ( account      IN VARCHAR2,
                             session_id   IN VARCHAR2,
                             session_time IN NUMBER ) RETURN NUMBER;

  Function InsertSession ( account    IN VARCHAR2,
                           session_id IN VARCHAR2 ) RETURN NUMBER;

  FUNCTION UpdateSessionTime( account    IN VARCHAR2,
                              session_id IN VARCHAR2 ) RETURN NUMBER;

  Function SecondsBetween ( date_1 IN DATE,
                            date_2 IN DATE) RETURN NUMBER;

  Function RefreshSessions( session_time IN NUMBER ) RETURN NUMBER;


END WEB_FACTURA_DIGITAL;
/

