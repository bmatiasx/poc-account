create PROCEDURE GRANT_OBJ_PRIVS (
   grantee    IN   VARCHAR2,
  privilege   IN   VARCHAR2,
  object      IN   user_objects.object_name%TYPE DEFAULT NULL
) IS
/*
   Program Name: Grant Object Privileges (for calling schema owner)
   Written By  : Javier H. Pflaum
   Description : Este modulo grantea privilegios especificados como parametro
                 El parametro String  de privilegios es ignorado para cierto
                 tipos de objetos para los cuales solo privilegios
                 determinados pueden ser asignados
                 Si el grantee especificado no es un usuario o rol valido,
                 una exception es levanata y se muestra un mensaje de error
                 Solo tablas, vistas, secuencias y procedures, funciones
                 y paquetes tipos de objetos validos para grantear.
                 La existencia de los objetos especificados son validados.

   Modification:
     V.001 05-NOV-2001 - jhp - Version Inicial
     V.002 29-NOv-2001 - jhp - Se quito el prametro de type para evitar privilege masivos.
     v.003 Ver el tema de solo grantear a roles....!!!!!!!!!!!!
     V.004 10-DIC-2001 - jhp - Se elimino de los objetos los Synonyms y los packages Bodies
     V.005 01-MAR-2002 - jhp  Redefinicion de objetos validos para dar grant. 
                              Aparecia error en las partions tables


*/

  -- cursors
  CURSOR get_objects
  (
     cobject  user_objects.object_name%TYPE,
    ctype     user_objects.object_type%TYPE
  ) IS
    SELECT object_name
      FROM user_objects
     WHERE object_name = cobject
       AND object_type = ctype;

  -- user-defined exceptions
  not_grantable     EXCEPTION;
  invalid_user      EXCEPTION;
  invalid_type      EXCEPTION;
  invalid_obj       EXCEPTION;
  invalid_grants    EXCEPTION;
  -- variables
  get_objects_rec   get_objects%ROWTYPE;
  local_grantee     dba_users.username%TYPE;
  local_type        user_objects.object_type%TYPE;
  local_obj         user_objects.object_name%TYPE;
  local_grants      VARCHAR2 ( 32767 );
  dyn_c             INTEGER;
  dyn_stmt          VARCHAR2 ( 32767 );
  status            NUMERIC;
  obj_privs         VARCHAR ( 16 );
BEGIN


  local_obj := UPPER ( RTRIM ( LTRIM ( object )));
  local_grantee := UPPER ( RTRIM ( LTRIM ( grantee )));
    DBMS_OUTPUT.put_line ( 'local Grants  "' || local_grantee || '"' );
  local_grants := UPPER ( RTRIM ( LTRIM ( privilege )));
  DBMS_OUTPUT.put_line ( 'Grants  "' || privilege || '"' );

  -- validate grants
  IF local_grants IS NULL THEN
    RAISE invalid_grants;
  ELSIF NOT
            (
               local_grants IN
                               (
                                  'SELECT',
                                 'INSERT',
                                 'UPDATE',
                                 'DELETE',
                                 'EXECUTE'
                               )
            ) THEN
    RAISE invalid_grants;
  END IF;

  -- validate grantee (could be user or role)
  IF ( local_grantee != 'PUBLIC' ) THEN
    BEGIN
      SELECT username
        INTO local_grantee
        FROM dba_users
       WHERE username = local_grantee
      UNION
      SELECT role
        FROM dba_roles
       WHERE role = local_grantee;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RAISE invalid_user;
    END;
  END IF;                                      -- check for valid user or role

  -- validate object name
  IF ( local_obj IS NOT NULL ) THEN                       -- get object's type
    BEGIN
      SELECT object_type
        INTO local_type
        FROM user_objects
       WHERE object_name = local_obj
         AND object_type IN ( 'TABLE',
                                'VIEW',
                                'SNAPSHOT',
                                'SEQUENCE',
                                'PROCEDURE',
                                'FUNCTION',
                                'PACKAGE' );

      IF NOT
             (
                local_type IN
                              (
                                 'TABLE',
                                'VIEW',
                                'SNAPSHOT',
                                'SEQUENCE',
                                'PROCEDURE',
                                'FUNCTION',
                                'PACKAGE'
                              )
             ) THEN
        BEGIN
          RAISE invalid_type;
        END;
      END IF;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RAISE invalid_obj;
    END;
  END IF;

  dyn_c := DBMS_SQL.open_cursor;



  FOR get_objects_rec IN get_objects ( local_obj, local_type ) LOOP

    BEGIN
      -- GRANT syntax (and privilege options) depends on object type
      IF ( local_type IN ( 'TABLE', 'VIEW' )) THEN    -- grant priv passed in
        dyn_stmt :=
          'GRANT ' || privilege || ' ON ' ||
            get_objects_rec.object_name ||
            ' TO ' ||
            local_grantee;
      ELSIF
            -- only select
            ( local_type IN ( 'SEQUENCE', 'SNAPSHOT' )) THEN
        dyn_stmt :=
          'GRANT SELECT ON ' || get_objects_rec.object_name ||
            ' TO ' ||
            local_grantee;
        local_grants := 'SELECT';
      ELSIF
            -- only grant EXECUTE
            ( local_type IN ( 'PROCEDURE', 'FUNCTION', 'PACKAGE' )) THEN
        dyn_stmt :=
          'GRANT EXECUTE ON ' || get_objects_rec.object_name ||
            ' TO ' ||
            local_grantee;
        local_grants := 'EXECUTE';
      END IF;                             -- test object type for grant syntax

      DBMS_OUTPUT.put_line ( dyn_stmt );
      

      DBMS_SQL.parse ( dyn_c, dyn_stmt, DBMS_SQL.native );

      status := SQLCODE;

      IF local_grants = 'SELECT' THEN
        obj_privs := '---------Y------';
      ELSIF local_grants = 'INSERT' THEN
        obj_privs := '------Y---------';
      ELSIF local_grants = 'UPDATE' THEN
        obj_privs := '----------Y-----';
      ELSIF local_grants = 'DELETE' THEN
        obj_privs := '---Y------------';
      ELSIF local_grants = 'EXECUTE' THEN
        obj_privs := '------------Y---';
      END IF;

      INSERT INTO audit_implementations
                  (
                    userid,
                    terminal,
                    timestamp#,
                    sessionid,
                    action#,
                    returncode,
                    owner,
                    object_name,
                    grantee,
                    obj_privileges
                  )
           VALUES
           (
              USER,
             SYS_CONTEXT ( 'USERENV', 'HOST' ),
             SYSDATE,
             SYS_CONTEXT ( 'USERENV', 'SESSIONID' ),
             17,                                            /* Grant Object */
             status,
             SYS_CONTEXT ( 'USERENV', 'CURRENT_SCHEMA' ),
             get_objects_rec.object_name,
             local_grantee,
             obj_privs
           );

      COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        status := SQLCODE;
        DBMS_OUTPUT.put_line ( '>>> Grant failed: ' || SQLERRM ( status ));
    END;
  END LOOP;                                                 -- process objects

  IF ( get_objects%ISOPEN ) THEN
    CLOSE get_objects;
  END IF;

  IF ( DBMS_SQL.is_open ( dyn_c )) THEN
    DBMS_SQL.close_cursor ( dyn_c );
  END IF;
EXCEPTION
  WHEN not_grantable THEN
    DBMS_OUTPUT.put_line ( local_type || ' NO es tipo de objeto GRANTABLE!' );
  WHEN invalid_user THEN
    DBMS_OUTPUT.put_line ( 'Usuario ' || grantee || ' NO existe!' );
  WHEN invalid_obj THEN
    DBMS_OUTPUT.put_line ( 'Objeto ' || object || ' NO existe!' );
  WHEN invalid_type THEN
    DBMS_OUTPUT.put_line
    (  'Tipo de Objeto ' || ' para ' || object || ' Invalido!'
    );
  WHEN invalid_grants THEN
    DBMS_OUTPUT.put_line ( 'Grants  ' || privilege || ' Invalido!' );
  WHEN OTHERS THEN
    BEGIN
      status := SQLCODE;
      DBMS_OUTPUT.put_line ( 'Error: ' || SQLERRM ( status ));

      IF ( get_objects%ISOPEN ) THEN
        CLOSE get_objects;
      END IF;

      IF ( DBMS_SQL.is_open ( dyn_c )) THEN
        DBMS_SQL.close_cursor ( dyn_c );
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;                                                   -- don't care
    END;
END;
/

