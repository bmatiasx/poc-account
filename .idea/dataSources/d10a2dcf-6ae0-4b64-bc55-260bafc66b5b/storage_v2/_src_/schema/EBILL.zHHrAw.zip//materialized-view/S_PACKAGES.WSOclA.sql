create materialized view S_PACKAGES
refresh force on demand
  as
    SELECT pkt_id, pkt_description, pkt_current_price, pkt_advance, pkt_canceled, pkt_inc_id, pkt_frt_id, pkt_start_date, pkt_end_date, pkt_prorration, pkt_syr_id, pkt_type, pkt_length, pkt_sms_infor_req_flag, pkt_digital_flag, pkt_audiotel_flag, pkt_inc_id_ld, pkt_validation_flag, pkt_checked_billing_flag, pkt_prepay_flag, pkt_classing, pkt_source, pkt_changing_type, pkt_mip_id_permanency, pkt_mip_id_new, pkt_second_ent_flag, pkt_second_ent_id, pkt_pfa_id, pkt_category, pkt_isg_id, pkt_ftr_isi,
pkt_length_days, pkt_parametro, pkt_enabled_clearing, pkt_can_ciclo, pkt_bajar_flag, pkt_web_description, pkt_visibility, pkt_help, pkt_work_as_prepay, pkt_charge_id, pkt_eventual_charge, pkt_quantity,pkt_cyclic
from packages@PROD
/

