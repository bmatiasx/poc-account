create package PA_LINE_PROFILE is

  -- Author  : LUCAS BONANSEA
  -- Created : 18/03/2015
  -- Purpose : Get a generic line profile
  -- Version 1.1.1

  /*
  Author Lucas Bonansea
  Version 1.3
  Last Modification: 05/11/2015
  Gets a basic line profile from cellular, accounts and client tables.
  */
  function Get_Basic_Profile(pio_bill_number    in out Varchar2,
                             pio_cellularNumber in out varchar2,
                             po_accountId       out varchar2,
                             po_companyId       out varchar2,
                             po_businessType    out varchar2,
                             po_clientId        out varchar2,
                             po_clientType      out varchar2,
                             po_clientCategory  out varchar2,
                             po_lineStatus      out varchar2,
                             po_codigo_error    out varchar2,
                             po_mensaje_error   out varchar2,
                             po_mensaje_salida  out varchar2) return NUMBER;
  /*
  Author Lucas Bonansea
  Version 1.1.0
  Last Modification: 18/3/2015
  Gets a complete line profile from cellular, accounts and client tables.
  Adds the following information to the basic line profile:
  Cellular Data:
           cellularReasonId,
           cellularType,
           claroClubStatus,
           password,
           serviceType,
           technology,
           mileageCategory
  Account Data:
          accountGeoUnit,
          accountBillContact,
          cycleDay,
          email,
          emailValidated,
          accFlag
  Client Data:
         clientBirthDate,
         clientCategory,
         clientFirstName,
         clientIdentificationNumber,
         clientLastName,
         clientClass
  */
  function Get_Complete_Profile(pio_bill_number    in out Varchar2,
                                pio_cellularNumber in out varchar2,
                                pi_get_email_validated in varchar2,
                                po_accountId       out varchar2,
                                po_companyId       out varchar2,
                                po_businessType    out varchar2,
                                po_clientId        out varchar2,
                                po_clientType      out varchar2,
                                po_clientCategory  out varchar2,
                                po_lineStatus      out varchar2,
                                po_cellular_data   out varchar2, --cellularReasonId, cellularType, claroClubStatus, password, serviceType, technology
                                po_client_data     out varchar2, --clientBirthDate, clientFirstName, clientIdentificationNumber, clientLastName, clientClass
                                po_account_data    out varchar2, --accountGeoUnit, accountBillContact, cycleDay, email, emailValidated, accFlag,
                                po_codigo_error    out varchar2,
                                po_mensaje_error   out varchar2,
                                po_mensaje_salida  out varchar2)
    return NUMBER;
  /*
  Author Lucas Bonansea
  Version 1.1.1
  Last Modification: 18/3/2015
  Extends the complete line profile adding information from other tables according
  to flags that indicate whether or not to obtain the info.
  Extended Data:
  Call Restriction Data:
          callRestrictionId,
          callRestrictionDesc
  Plan Data:
          planId,
          planType,
          lineBAM,
          planAdmiteFF
  Authorization Data:
         authorizationBillNumber,
         authorizationCellularNumber
  IVR Parametrized Data:
         sendSurvey,
         lineFixedMovile
  Other Data:
         Empty, available for future use
  */
  function Get_Extended_Profile(pio_bill_number            in out Varchar2,
                                pio_cellularNumber         in out varchar2,
                                pi_get_email_validated     in varchar2,
                                po_accountId               out varchar2,
                                po_companyId               out varchar2,
                                po_businessType            out varchar2,
                                po_clientId                out varchar2,
                                po_clientType              out varchar2,
                                po_clientCategory          out varchar2,
                                po_lineStatus              out varchar2,
                                po_cellular_data           out varchar2, --cellularReasonId, cellularType, claroClubStatus, password, serviceType, technology, mileageCategory
                                po_client_data             out varchar2, --clientId, clientBirthDate, clientCategory, clientFirstName, clientIdentificationNumber, clientLastName, clientClass
                                po_account_data            out varchar2, --accountGeoUnit, cycleDay, email, emailValidated, accflag
                                pio_call_restrictions_data in out varchar2, --callRestrictionId, callRestrictionDesc
                                pio_plan_data              in out varchar2, --planId, planType, lineBAM, planAdmiteFF
                                pio_authorization_data     in out varchar2, --billNumberAutorizante, cellularAutorizante,
                                pio_ivr_parameters         in out varchar2, --sendSurvey, lineFixedMovile
                                pio_other_data             in out varchar2, --
                                po_codigo_error            out varchar2,
                                po_mensaje_error           out varchar2,
                                po_mensaje_salida          out varchar2)
    return NUMBER;
 /*
  Author Gette Alan
  Version 1.0
  Last Modification: 03/12/2015
  Gets a line profile to be used on IVR's apps.
  Note: the value MileageCategory will be used in the future 
  */
  FUNCTION Get_Profile_Ivr(pio_billNumber          in out varchar2,
                           pio_cellularNumber      in out varchar2,
                           po_accountId            out varchar2,
                           po_accountType          out varchar2, 
                           po_accountClass         out varchar2, 
                           po_accountEntityId      out varchar2,
                           po_companyId            out varchar2,
                           po_businessType         out varchar2,
                           po_clientId             out varchar2,
                           po_clientType           out varchar2,
                           po_clientCategory       out varchar2,
                           po_clientClass	         out varchar2,
                           po_lineStatus           out varchar2,
                           po_cellularReasonId     out varchar2, 
                           po_reasonDescription    out varchar2, 
                           po_claroClubStatus      out varchar2, 
                           po_password             out varchar2, 
                           po_technology           out varchar2, 
                           po_mileageCategory      out varchar2,
                           po_serviceStatus        out varchar2,
                           po_lineFixedMovile      out varchar2,
                           po_callRestrictionId    out varchar2,
                           po_callRestrictionDesc  out varchar2,
                           po_callRestrictionClass out varchar2,
                           po_codigoError          out varchar2,
                           po_mensajeError         out varchar2,
                           po_mensajeSalida        out varchar2)
    RETURN NUMBER;
    
    END PA_LINE_PROFILE;
/

