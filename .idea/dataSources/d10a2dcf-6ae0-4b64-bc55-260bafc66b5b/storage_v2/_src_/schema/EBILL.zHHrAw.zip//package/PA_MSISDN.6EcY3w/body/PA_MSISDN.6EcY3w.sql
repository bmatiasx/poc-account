create PACKAGE BODY PA_MSISDN
IS
   /************************************************************************************************************************
   FUNCTION Get_Bill_Number --> Dado un MSISDN devuelve el nro. en formato Bill Number
   ************************************************************************************************************************/
   FUNCTION Get_Bill_Number (p_msisdn VARCHAR2)
      RETURN VARCHAR2
   IS
      v_BILL_NUMBER CELLULARS.clu_bill_number%Type;
      v_msisdn varchar(15) := trim(p_msisdn);
      v_cppLen number;
      v_mppLen number;
   BEGIN
      v_cpplen := length(v_prefijo_cpp);
      v_mppLen := length(v_prefijo_mpp);

      IF (SUBSTR(v_MSISDN,1, v_cppLen) = v_prefijo_cpp) THEN
         V_BILL_NUMBER := SUBSTR(v_MSISDN,v_cppLen + 1);
      ELSIF (SUBSTR(v_MSISDN,1, v_mppLen) = v_prefijo_mpp) THEN
         V_BILL_NUMBER := SUBSTR(v_MSISDN,v_mppLen + 1);
      ELSE
         v_BILL_NUMBER := null;
      END IF;
    RETURN V_BILL_NUMBER;
  END GET_BILL_NUMBER;


   /************************************************************************************************************************
   FUNCTION f_Get_Msisdn --> Dado un bill number evuelve el nro. en formato MSISDN
   ************************************************************************************************************************/
    FUNCTION f_Get_Msisdn (pin_clu_type IN VARCHAR2, pin_bill_number IN VARCHAR2)
      RETURN VARCHAR2
   IS
      v_msisdn   VARCHAR2 (20);
   BEGIN
      IF (pin_clu_type = 'CPP')
      THEN
         v_msisdn := v_prefijo_cpp || pin_bill_number;
      ELSE
         v_msisdn := v_prefijo_mpp || pin_bill_number;
      END IF;

      RETURN v_msisdn;
   END f_get_msisdn;


   /************************************************************************************************************************
   FUNCTION GET_SERVICE_DATA
   ************************************************************************************************************************/
   PROCEDURE GET_SERVICE_DATA (P_USUARIO OUT VARCHAR2, P_PASSWORD OUT VARCHAR2)
   IS
   BEGIN
      PA_TECNO_SERVICES.GET_SERVICE_DATA@CCARD (P_USUARIO, P_PASSWORD);
   EXCEPTION
      WHEN OTHERS
      THEN
         DBMS_OUTPUT.PUT_LINE ('Error: ' || SQLERRM);
   END GET_SERVICE_DATA;
BEGIN
   SELECT trim(par_value)
     INTO v_prefijo_cpp
     FROM PARAMETERS
    WHERE par_name = 'PREFIJOS_GSM_CPP';

   SELECT trim(par_value)
     INTO v_prefijo_mpp
     FROM PARAMETERS
    WHERE par_name = 'PREFIJOS_GSM_MPP';
END Pa_Msisdn;
/

