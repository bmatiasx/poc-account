create PACKAGE E_DETAIL_GROUPS IS
FUNCTION insert_account_group
        (p_ega_name       IN ed_group_accounts.ega_name%type,
        p_ega_description IN ed_group_accounts.ega_description%type,
        p_ega_clt_id      IN ed_group_accounts.ega_clt_id%type,
        p_message OUT varchar2)
    RETURN number;

    FUNCTION delete_account_group
        (p_ega_name       IN ed_group_accounts.ega_name%type,
        p_ega_clt_id      IN ed_group_accounts.ega_clt_id%type,
        p_message OUT varchar2)
    RETURN number;

    FUNCTION insert_account_ingroup
        (p_ega_name       IN ed_group_accounts.ega_name%type,
        p_ega_clt_id      IN ed_group_accounts.ega_clt_id%type,
        p_account_string  IN varchar2,
        p_message OUT varchar2)
    RETURN number;

    FUNCTION insert_lines_ingroup
        (p_ega_name       IN ed_group_accounts.ega_name%type,
        p_ega_clt_id      IN ed_group_accounts.ega_clt_id%type,
        p_lines_string    IN varchar2,
        p_message OUT varchar2)
    RETURN number;
END E_DETAIL_GROUPS;
/

