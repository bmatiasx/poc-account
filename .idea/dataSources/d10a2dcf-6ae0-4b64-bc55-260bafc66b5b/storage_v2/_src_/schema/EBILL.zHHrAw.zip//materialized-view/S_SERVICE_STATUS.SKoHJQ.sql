create materialized view S_SERVICE_STATUS
refresh force on demand
  as
    Select
sst_clu_cellular_number,
sst_service_status,
sst_start_date,
sst_tck_id,
sst_end_date,
sst_last_updated_date,
sst_add_date,
sst_usr_id,
sst_rsn_id
FROM "STL"."SERVICE_STATUS"@PROD.WORLD "SERVICE_STATUS"
/

