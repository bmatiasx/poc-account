create Package Body GLOBAL_PACKAGE_SERVICE is

Function valida_con_bill_number
    ( p_bill_number in varchar2,
      p_service in varchar2)
    return number IS

BEGIN

    RETURN stl.GLOBAL_PACKAGE_SERVICE.valida_con_bill_number@prod(p_bill_number,p_service);

EXCEPTION
    When Others then
        return sqlcode;
end;


Function valida_con_cellular_number
    ( p_cellular_number in varchar2,
      p_service in varchar2)
    return number IS
BEGIN

    RETURN stl.GLOBAL_PACKAGE_SERVICE.valida_con_cellular_number@prod(p_cellular_number,p_service);

EXCEPTION
    When Others then
        return sqlcode;
end;



END;
/

