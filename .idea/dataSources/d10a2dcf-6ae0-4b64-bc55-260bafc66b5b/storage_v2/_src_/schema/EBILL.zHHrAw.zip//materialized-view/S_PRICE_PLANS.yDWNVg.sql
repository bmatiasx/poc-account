create materialized view S_PRICE_PLANS
refresh fast on demand
  as
    SELECT "PRICE_PLANS"."PRP_ID",
"PRICE_PLANS"."PRP_DESCRIPTION"
FROM "STL"."PRICE_PLANS"@PROD.WORLD "PRICE_PLANS"
/

