create materialized view DETALLE_GESTIONES_WF
refresh force on demand
  as
    SELECT /*+ use_nl(reqp) use_nl(wfi) */
      req.req_id AS SOLICITUD,
       req.req_creation_date AS FECHA_ALTA,
       req.req_acc_id AS CUENTA,
       req.req_complete_date,
       req.req_clu_bill_number AS CELULAR,
       p.pbl_description AS PROBLEMA,
       SP.SBP_DESCRIPTION AS SUBPROBLEMA,
       wfi.begin_date AS FECHA_COMIENZO,
       wfi.end_date AS FECHA_FIN,
       req.req_observations AS OBSERVACION,
       req.req_usr_id AS USUARIO
  FROM STL.requests@prod req,
       STL.request_problems@prod reqp,
       owf_mgr.wf_items@prod wfi,
       STL.problems@prod p,
       STL.subproblems@prod sp
 WHERE     req.req_creation_date > (SELECT (SYSDATE - STL_CHAR_VALUE)
                                      FROM STL.STL_PARAMETERS@prod
                                     WHERE STL_ID = 'WWDGW')
       AND req.req_id = reqp.rqp_req_id
       AND wfi.item_type = reqp.rqp_item_type
       AND wfi.item_key = reqp.rqp_item_key
       AND reqp.rqp_pbl_id = p.pbl_id
       AND reqp.rqp_sbp_id = sp.sbp_id
/

