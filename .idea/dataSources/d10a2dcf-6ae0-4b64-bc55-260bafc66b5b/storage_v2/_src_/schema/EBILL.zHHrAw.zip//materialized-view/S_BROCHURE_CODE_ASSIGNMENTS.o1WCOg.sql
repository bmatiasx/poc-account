create materialized view S_BROCHURE_CODE_ASSIGNMENTS
refresh force on demand
  as
    SELECT bca_bro_id, bca_brc_id, bca_but_id,bca_start_date, bca_end_date
FROM Brochure_Code_Assignments@PROD
 
/

