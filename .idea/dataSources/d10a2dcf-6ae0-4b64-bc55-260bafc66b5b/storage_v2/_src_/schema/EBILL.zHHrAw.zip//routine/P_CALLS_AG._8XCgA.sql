create PROCEDURE P_CALLS_AG
 IS
/*
Luciano Namur 09/2014 version 1.0
*/

/*
Este procedure es llamado desde un .sql dentro de un plan de ejecucion en Control M
el objetivo es controlar si la ultima calls ha sido credo, si es asi, llama a la funcion
de EBILL que hara la recreacion de las vistas para consulta de consumo
*/


  v_exist        VARCHAR2(1);
  v_yyyy          VARCHAR2(10);
  v_mes           NUMBER;
  v_calls_3       VARCHAR2(15);
  v_calls_2       VARCHAR2(15);
  v_result        NUMBER;
  v_err_num       NUMBER;
  v_err_msg       VARCHAR(255);
  char_mes        CHAR(2);
BEGIN
  --aca controlo cual deberia ser la ultima vista
  SELECT to_char(sysdate+11,'YYYY'),to_char(sysdate+11,'MM')
    INTO v_yyyy ,v_mes
    FROM dual;

    IF length(v_mes) = 1  THEN
        char_mes := '0'||v_mes;
    ELSE
        char_mes := v_mes;
    END IF;
    DBMS_OUTPUT.PUT_LINE('Creacion de la  tabla CALLS_'||v_yyyy||char_mes||CHR(10));

   BEGIN
  /* primero se verifica que exista la CALLS_YYYYMM a crear*/
     SELECT 'S'
       INTO v_exist
       FROM USER_OBJECTS
      WHERE object_type = 'TABLE'
        AND object_name LIKE 'CALLS_%'||v_yyyy||'%'||char_mes||'';
   EXCEPTION
     WHEN no_data_found THEN
       v_exist := 'N';
   END;

   IF v_exist = 'S' THEN
      v_calls_3 := 'CALLS_%'||v_yyyy||'%'||char_mes||'';
      v_calls_2 := 'CALLS_'||to_char(to_date(substr(v_calls_3,7),'yyyymm')-1,'yyyymm');

      --llamo al procedure en ebill
      v_result := f_create_call_view@ebill(p_call_1  => v_calls_2,
                                           p_call_2  => v_calls_3,
                                           p_err_num => v_err_num,
                                           p_err_msg => v_err_msg);

      IF v_result <> 0 THEN
        dbms_output.put_line('Error en ebill: '||v_err_msg);
      END IF;
   ELSE
     dbms_output.put_line('No se crea la calls porque no existe');
   END IF;

EXCEPTION
  WHEN OTHERS THEN
    dbms_output.put_line('Error en call_ag: '||SQLERRM);

END;
/

