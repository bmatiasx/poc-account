create FUNCTION F_CHANGE_CR_CORPO

 (P_CELLULAR IN VARCHAR2
 ,P_DD_TYPE IN VARCHAR2
 ,P_DD_TYPE_NEW IN VARCHAR2
 ,P_REASON_CR IN VARCHAR2
 ,P_REASON_SI IN VARCHAR2
 ,P_CALL_DELIVERY IN VARCHAR2
 ,P_CALL_RESTRICTION OUT VARCHAR2
 ,P_ID OUT VARCHAR2
 ,P_DESCRIPTION OUT VARCHAR2
 ,P_VALUE OUT VARCHAR2
 ,P_ERR_NUM OUT VARCHAR2
 ,P_ERR_MSG OUT VARCHAR2
 )
 RETURN NUMBER
 IS
 V_CCR_CR_ID  VARCHAR2(15);
  V_RESULT     VARCHAR2(8);
  V_HABILITADO VARCHAR2(1) DEFAULT '1';
BEGIN

  IF P_DD_TYPE IS NULL THEN
    BEGIN
      SELECT CCR_CR_ID
        INTO V_CCR_CR_ID
        FROM CELLULAR_CALL_RESTRICTIONS
       WHERE CCR_CLU_CELLULAR_NUMBER = P_CELLULAR
         AND CCR_END_DATE IS NULL;

      IF V_CCR_CR_ID IN ('1', '2') THEN
        V_HABILITADO := '1';
      ELSE
        P_CALL_RESTRICTION := V_CCR_CR_ID;
        V_HABILITADO       := '0';
      END IF;

    EXCEPTION
      WHEN OTHERS THEN
        P_ERR_NUM := '2001';
        P_ERR_MSG := 'EL NUMERO INGRESADO NO TIENE CALL RESTRICTION';
        RETURN - 1;
    END;

  ELSE

    V_CCR_CR_ID := P_DD_TYPE;

  END IF;

  BEGIN
    IF V_HABILITADO = '1' THEN
      V_RESULT := F_CHANGE_CR(P_CELLULAR,
                              V_CCR_CR_ID,
                              P_DD_TYPE_NEW,
                              P_REASON_CR,
                              P_REASON_SI,
                              P_CALL_DELIVERY,
                              P_CALL_RESTRICTION,
                              P_ID,
                              P_DESCRIPTION,
                              P_VALUE,
                              P_ERR_NUM,
                              P_ERR_MSG);

      IF V_CCR_CR_ID = '2' THEN
        P_CALL_RESTRICTION := 'N';
      END IF;

      RETURN V_RESULT;

    ELSE
      P_ERR_NUM := '2002';
      P_ERR_MSG := 'LINEA NO HABILITADA PARA EL CAMBIO DE USO DOMÉSTICO.';
      RETURN 1;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN - 1;
  END;

END;
/

