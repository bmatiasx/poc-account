create PACKAGE BODY IVR_TRACE AS

---------------------------
l_tab tabla;
v_long_mapa NUMBER DEFAULT 0;
v_nodos     VARCHAR2 (255);
v_datos     VARCHAR2 (255);

----------------------------

TYPE process_dato_type
IS
TABLE OF infotraza%ROWTYPE INDEX BY PLS_INTEGER;
tabla_collect process_dato_type;

--------------------------------------------------

-- datos_matriz APEX_APPLICATION_GLOBAL.VC_ARR2; definicion anterior

datos_matriz tabla;
 ----------------------------------------------------
 
PROCEDURE validarNodo(p_nodo VARCHAR2,p_idApp NUMBER,v_idNodo NUMBER,id_ToNodo OUT NUMBER);

-----------------------------------------------------
 
 PROCEDURE insertar_flujo(
    llamada_id IN INTEGER,
    orden IN INTEGER,
    aplicacion_id INTEGER,
    nodo_id INTEGER,
    dato VARCHAR2);
 
 -------------------------------------------------------------

PROCEDURE insertar_llamada(
    p_id         IN NUMBER,
    fecha_inicio IN DATE,
    hora_inicio  IN DATE,
    fecha_fin    IN DATE,
    hora_fin     IN DATE,
    abandono     IN NUMBER,
    ani          IN VARCHAR2,
    dnis         IN VARCHAR2,
    ucid         IN VARCHAR2,
    aplicacion_id NUMBER,
    uui VARCHAR2);

-------------------------------------------
--definicion anterior
/*
FUNCTION parser (p_in_flujo CLOB) RETURN APEX_APPLICATION_GLOBAL.VC_ARR2 AS
  
  tabla_type APEX_APPLICATION_GLOBAL.VC_ARR2;
  
  BEGIN
  tabla_type := APEX_UTIL.STRING_TO_TABLE(TRIM(p_in_flujo), ';');
    RETURN tabla_type;
  END parser;
  */
------------------------------------------------------------------
  
FUNCTION parser (p_in_flujo CLOB) RETURN tabla AS

ind_coma  PLS_INTEGER;
puntero        PLS_INTEGER := 1;
 tabla_type         tabla := tabla();
  
  BEGIN

      LOOP
       ind_coma := INSTR(p_in_flujo, ';', puntero);--determino la posicion del caracter ; dentro de la variable de entrada
       EXIT WHEN ind_coma = 0;-- sino encuentra el caracter, sale 
       tabla_type.EXTEND;
       tabla_type(tabla_type.COUNT) := SUBSTR(p_in_flujo, puntero, ind_coma - puntero);-- tomo lo que va desde el primer caracter hasta el ;
       puntero := ind_coma + 1;-- busco el siguiente caracter, del siguiente sub-grupo, luego el proceso se repite
     END LOOP;
     
     RETURN tabla_type;

  END parser;  
  -------------------------------------------
  
  FUNCTION insertInfoTraza(
    in_aplicacion_id IN NUMBER,
    in_fecha_inicio    IN VARCHAR2,
    in_fecha_fin       IN VARCHAR2,
    in_hora_inicio     IN VARCHAR2,
    in_hora_fin        IN VARCHAR2,
    in_abandono        IN VARCHAR2,
    in_ani             IN VARCHAR2,
    in_dnis            IN VARCHAR2,
    in_ucid            IN VARCHAR2,
    in_uui             IN VARCHAR2,
    in_flujo           IN CLOB,
    out_error_text     OUT NOCOPY VARCHAR2
    ) RETURN NUMBER
 
IS
PROCEDURE insertTraza 
IS --procedimiento local..
  var_hora_inicio VARCHAR2 (20);
  var_hora_fin    VARCHAR2 (20);
  var_fecha_inicio DATE DEFAULT NULL;
  var_format_hora_inicio DATE DEFAULT NULL;
  var_fecha_fin DATE DEFAULT NULL;
  var_format_hora_fin DATE DEFAULT NULL;
  var_format_in_ani VARCHAR2(13 BYTE) DEFAULT NULL;
  var_format_in_dnis VARCHAR2(25 BYTE) DEFAULT NULL;
  var_format_in_uccid VARCHAR2(21 BYTE) DEFAULT NULL;
  var_format_in_uui VARCHAR2(96 BYTE) DEFAULT NULL;
  var_format_in_influjo CLOB DEFAULT NULL;
  
BEGIN
  var_hora_inicio := in_fecha_inicio || ' ' || in_hora_inicio;
  var_hora_fin    := in_fecha_fin || ' ' || in_hora_fin;
  var_fecha_inicio :=  TO_DATE (in_fecha_inicio, 'DDmmYYYY');
  var_format_hora_inicio :=  TO_DATE (var_hora_inicio, 'DDmmYYYY hh24:mi:ss');
  var_fecha_fin := TO_DATE (in_fecha_fin, 'DDmmYYYY');
  var_format_hora_fin := TO_DATE (var_hora_fin, 'DDmmYYYY hh24:mi:ss');
  var_format_in_ani :=  TRIM (SUBSTR (in_ani, 1, 13));
  var_format_in_dnis:=  TRIM (SUBSTR (in_dnis, 1, 25));
  var_format_in_uccid := TRIM (SUBSTR (in_ucid, 1, 21));
  var_format_in_uui := TRIM (SUBSTR (in_uui, 1, 96));
  var_format_in_influjo := TRIM (in_flujo);
 
  INSERT
  INTO infotraza
    VALUES
    (
      var_fecha_inicio,
      var_format_hora_inicio,
       var_fecha_fin,
       var_format_hora_fin,
      CASE in_abandono
        WHEN 'true'
        THEN 1
        ELSE 0
      END,
        var_format_in_ani,
      var_format_in_dnis,
      CASE in_ucid
        WHEN 'undefined'
        THEN ''
        ELSE  var_format_in_uccid
      END,
      in_aplicacion_id,
       var_format_in_uui,
      var_format_in_influjo
    );
END insertTraza;

BEGIN
  insertTraza;
  out_error_text := 'OK';
   COMMIT;
  return 0;
 
EXCEPTION
WHEN OTHERS THEN
  ROLLBACK;
  out_error_text := 'ERROR -->' || ' -- ' || SQLCODE || SQLERRM;
  RETURN (SQLCODE);
END insertInfoTraza;

--------------------------------------------------------------

FUNCTION procesarInfoTraza(out_error_text OUT NOCOPY VARCHAR2) RETURN NUMBER IS

 --r_parser APEX_APPLICATION_GLOBAL.VC_ARR2;
r_parser tabla;
aux NUMBER DEFAULT 0;

BEGIN

SELECT
    hora_inicio,
    fecha_inicio,
    fecha_fin,
    hora_fin,
    abandono,
    ani,
    dnis,
    ucid,
    aplicacion_id,
    uui,
    influjo BULK COLLECT
  INTO tabla_collect
  FROM infotraza;
  
  FOR i IN 1 .. tabla_collect.COUNT LOOP
  
     insertar_llamada (LLAMADAS_SEQ.NEXTVAL, tabla_collect (i).fecha_inicio, tabla_collect (i).hora_inicio, tabla_collect (i).fecha_fin, tabla_collect (i).hora_fin, tabla_collect (i).abandono, tabla_collect (i).ani, tabla_collect (i).dnis, tabla_collect(i).ucid, tabla_collect(i).aplicacion_id, tabla_collect (i).uui);

r_parser := parser(tabla_collect(i).influjo);

     FOR k IN r_parser.FIRST .. r_parser.LAST
      LOOP
        v_long_mapa := LENGTH (r_parser (k));
        IF r_parser(k) IS NOT NULL THEN
        v_nodos := SUBSTR (TRIM (r_parser (k)), 1, INSTR (TRIM (r_parser (k)), ':', 1) - 1);
        v_datos := SUBSTR (r_parser (k), INSTR (TRIM (r_parser (k)), ':', 1) + 1, v_long_mapa);
        validarNodo(v_nodos,tabla_collect(i).aplicacion_id,k,aux);
        insertar_flujo (LLAMADAS_SEQ.CURRVAL, k, tabla_collect(i).aplicacion_id,aux, v_datos);
        END IF;
      END LOOP;
END LOOP;
  out_error_text := 'OK ';
   COMMIT;
  RETURN (0);
  
EXCEPTION
WHEN NO_DATA_FOUND THEN
  ROLLBACK;
  out_error_text := out_error_text || ' -- ' || SQLCODE || SQLERRM;
  RETURN -1;
WHEN OTHERS THEN
  ROLLBACK;
  out_error_text := out_error_text || ' -- ' || SQLCODE || SQLERRM;
  RETURN (SQLCODE);
  
  
END procesarInfoTraza;

----------------------------------------------------------------------------------------------

 FUNCTION f_save_call_data(in_aplicacion_id IN NUMBER,
                          in_fecha_inicio IN VARCHAR2, 
                          in_fecha_fin IN VARCHAR2, 
                          in_hora_inicio IN VARCHAR2, 
                          in_hora_fin IN VARCHAR2, 
                          in_abandono IN VARCHAR2, 
                          in_ani IN VARCHAR2, 
                          in_dnis IN VARCHAR2, 
                          in_ucid IN VARCHAR2, 
                          in_uui IN VARCHAR2, 
                          in_flujo IN CLOB,
                          out_error_text OUT NOCOPY VARCHAR2)  
RETURN NUMBER IS

idNodoAux NUMBER DEFAULT 0;
var_hora_inicio VARCHAR2 (20);
  var_hora_fin    VARCHAR2 (20);
  var_fecha_inicio DATE DEFAULT NULL;
  var_format_hora_inicio DATE DEFAULT NULL;
  var_fecha_fin DATE DEFAULT NULL;
  var_format_hora_fin DATE DEFAULT NULL;
  var_format_in_ani VARCHAR2(13 BYTE) DEFAULT NULL;
  var_format_in_dnis VARCHAR2(25 BYTE) DEFAULT NULL;
  var_format_in_uccid VARCHAR2(21 BYTE) DEFAULT NULL;
  var_format_in_uui VARCHAR2(96 BYTE) DEFAULT NULL;
  var_format_in_influjo CLOB DEFAULT NULL;
  -- r_infoCall    APEX_APPLICATION_GLOBAL.VC_ARR2;
r_infoCall tabla;

BEGIN

var_hora_inicio := in_fecha_inicio || ' ' || in_hora_inicio;
var_hora_fin    := in_fecha_fin || ' ' || in_hora_fin;
var_fecha_inicio :=  TO_DATE (in_fecha_inicio, 'DDmmYYYY');
var_format_hora_inicio :=  TO_DATE (var_hora_inicio, 'DDmmYYYY hh24:mi:ss');
var_fecha_fin := TO_DATE (in_fecha_fin, 'DDmmYYYY');
var_format_hora_fin := TO_DATE (var_hora_fin, 'DDmmYYYY hh24:mi:ss');
var_format_in_ani :=  TRIM (SUBSTR (in_ani, 1, 13));
var_format_in_dnis:=  TRIM (SUBSTR (in_dnis, 1, 25));
var_format_in_uccid := TRIM (SUBSTR (in_ucid, 1, 21));
var_format_in_uui := TRIM (SUBSTR (in_uui, 1, 96));
var_format_in_influjo := TRIM (in_flujo);

insertar_llamada (LLAMADAS_SEQ.NEXTVAL, var_fecha_inicio, var_format_hora_inicio, var_fecha_fin, var_format_hora_fin, CASE in_abandono
        WHEN 'true'
        THEN 1
        ELSE 0
      END, in_ani, in_dnis,CASE in_ucid
        WHEN 'undefined'
        THEN ''
        ELSE  var_format_in_uccid
      END, in_aplicacion_id, in_uui);

IF in_flujo IS NOT NULL THEN
r_infoCall := parser(in_flujo);

    FOR k IN r_infoCall.FIRST .. r_infoCall.LAST
      LOOP
        v_long_mapa := LENGTH (r_infoCall (k));
        IF r_infoCall(k) IS NOT NULL THEN
        v_nodos := SUBSTR (TRIM (r_infoCall (k)), 1, INSTR (TRIM (r_infoCall (k)), ':', 1) - 1);
        v_datos := SUBSTR (r_infoCall (k), INSTR (TRIM (r_infoCall (k)), ':', 1) + 1, v_long_mapa);
        validarNodo(v_nodos,in_aplicacion_id,k,idNodoAux);
        insertar_flujo (LLAMADAS_SEQ.CURRVAL, k, in_aplicacion_id,idNodoAux, v_datos);
        END IF;
      END LOOP;
END IF;

  out_error_text := 'OK ';
   COMMIT;
  RETURN (0);
  
  EXCEPTION
WHEN NO_DATA_FOUND THEN
  ROLLBACK;
  out_error_text := out_error_text || ' -- ' || SQLCODE || SQLERRM;
  RETURN -1;
WHEN OTHERS THEN
  ROLLBACK;
  out_error_text := out_error_text || ' -- ' || SQLCODE || SQLERRM;
  RETURN (SQLCODE);

END f_save_call_data;

---------------------------------------------------------------------------------

PROCEDURE insertar_llamada
  (
    p_id         IN NUMBER,
    fecha_inicio IN DATE,
    hora_inicio  IN DATE,
    fecha_fin    IN DATE,
    hora_fin     IN DATE,
    abandono     IN NUMBER,
    ani          IN VARCHAR2,
    dnis         IN VARCHAR2,
    ucid         IN VARCHAR2,
    aplicacion_id NUMBER,
    uui VARCHAR2
  )
IS 
BEGIN
  INSERT
  INTO llamadas
    (
      id,
      fecha_inicio,
      hora_inicio,
      fecha_fin,
      hora_fin,
      abandono,
      ani,
      dnis,
      ucid,
      aplicacion_id,
      uui
    )
    VALUES
    (
      p_id,
      fecha_inicio,
      hora_inicio,
      fecha_fin,
      hora_fin,
      abandono,
      ani,
      dnis,
      ucid,
      aplicacion_id,
      uui
    );
  --  COMMIT;
END insertar_llamada;

---------------------------------------------------------------------------------------

PROCEDURE validarNodo(p_nodo VARCHAR2,p_idApp NUMBER,v_idNodo NUMBER,id_ToNodo OUT NUMBER) IS

aux NUMBER DEFAULT 0;

BEGIN
          SELECT id
          INTO aux
          FROM NODOS
          WHERE aplicacion_id    = p_idApp
          AND TRIM (descripcion) = trim(p_nodo);
          id_ToNodo := aux;
        EXCEPTION
        WHEN NO_DATA_FOUND THEN
          id_ToNodo := v_idNodo;
            INSERT
            INTO NODOS
              (
                aplicacion_id,
                id,
                descripcion
              )
              VALUES
              (
                p_idApp,
                v_idNodo,
                p_nodo
              );
  
  
  END validarNodo;
  
  PROCEDURE insertar_flujo
  (
    llamada_id IN INTEGER,
    orden IN INTEGER,
    aplicacion_id INTEGER,
    nodo_id INTEGER,
    dato VARCHAR2)
  
IS
BEGIN
  INSERT
  INTO FLUJOS
    (
      llamada_id,
      orden,
      aplicacion_id,
      nodo_id,
      dato
    )
    VALUES
    (
      llamada_id,
      orden,
      aplicacion_id,
      nodo_id,
      dato
    );
  
END insertar_flujo;

---------------------------------------------------------------------------------------

END IVR_TRACE;
/

