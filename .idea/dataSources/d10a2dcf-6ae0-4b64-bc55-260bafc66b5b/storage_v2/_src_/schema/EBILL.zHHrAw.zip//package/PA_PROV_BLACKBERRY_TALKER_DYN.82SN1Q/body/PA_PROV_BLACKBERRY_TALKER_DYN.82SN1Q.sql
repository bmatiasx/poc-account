create package body PA_PROV_BLACKBERRY_TALKER_DYN is


-- Function and procedure implementations

function f_get_next_transaction_id
         return number is
v_tx_id number;
begin
     execute immediate 'select STL.PA_PROV_BLACKBERRY_TALKER.f_get_next_transaction_id@prod from dual' into v_tx_id;
     return v_tx_id;
end;

procedure p_set_transaction_started(p_bbi_id number, p_transaction_id number) is
begin
     execute immediate
     'begin STL.PA_PROV_BLACKBERRY_TALKER.p_set_transaction_started@prod(:1, :2); end;'
     using p_bbi_id, p_transaction_id;
end;


procedure p_set_transaction_responsed(p_bbi_id number, p_status varchar2) is

  begin
       execute immediate
       'begin STL.PA_PROV_BLACKBERRY_TALKER.p_set_transaction_responsed@prod(:1, :2); end;'
       using p_bbi_id, p_status;
  end;

procedure p_save_ids_reply(p_bbi_id number, p_imei varchar2, p_msisdn varchar2) is
  begin
       execute immediate
       'begin STL.PA_PROV_BLACKBERRY_TALKER.p_save_ids_reply@prod(:1, :2, :3); end;'
       using p_bbi_id, p_imei, p_msisdn;
  end;

procedure p_save_reply(p_bbi_id number, p_service varchar2, p_code number, p_description varchar2) is
  begin
       execute immediate
       'begin STL.PA_PROV_BLACKBERRY_TALKER.p_save_reply@prod(:1, :2, :3, :4); end;'
       using p_bbi_id, p_service, p_code, p_description;
  end;

procedure p_save_error_code(p_bbi_id number, p_code number, p_description varchar2) is
  begin
       execute immediate
       'begin STL.PA_PROV_BLACKBERRY_TALKER.p_save_error_code@prod(:1, :2, :3); end;'
       using p_bbi_id, p_code, p_description;
  end;

function f_fetch_update_requests (p_max_fetch_size number)
         return ref_pending_services_cursor is
v_pending_cursor ref_pending_services_cursor;
begin
      open v_pending_cursor for 'select * from (select * from blackberry_interfaces@prod where bbi_status = ''' || c_PENDING || ''' and bbi_action <> ''' || c_REV || ''' order by bbi_id) where rownum <= ' || p_max_fetch_size;
      return v_pending_cursor;
end;

function f_fetch_review_requests (p_max_fetch_size number)
         return ref_pending_services_cursor is
v_pending_cursor ref_pending_services_cursor;
begin
      open v_pending_cursor for 'select * from (select * from blackberry_interfaces@prod where bbi_status = ''' || c_PENDING || ''' and bbi_action = ''' || c_REV || ''' order by bbi_id) where rownum <= ' || p_max_fetch_size;
      return v_pending_cursor;
end;

function f_fetch_assign_services (p_bbi_id number)
         return ref_assign_services_cursor is
v_assign_cursor ref_assign_services_cursor;
begin
     open v_assign_cursor for
     'select * from blackberry_assign_params@prod where bap_bbi_id = ' || p_bbi_id;
     return v_assign_cursor;
end;

procedure p_save_assign_reply(p_bap_id number, p_code number, p_description varchar2) is
begin
     execute immediate
     'begin STL.PA_PROV_BLACKBERRY_TALKER.p_save_assign_reply@prod(:1, :2, :3); end;'
     using p_bap_id, p_code, p_description;
end;


function f_listen_update_bbi
  return number is
  begin
       return f_listen_bbi(c_PIPE_UPDATE , c_LOCK_UPDATE);
  end;

function f_listen_review_bbi
  return number is
  begin
       return f_listen_bbi(c_PIPE_REVIEW, c_LOCK_REVIEW);
  end;


function f_listen_bbi(p_pipe_name varchar2, p_lock_id number)
   return number is

data_avaiable boolean := false;
result number;
data number := 1;
action number := 0;
v_bbl_value number;

begin

     --escuchar si hay nuevos datos
     while not data_avaiable loop
           execute immediate 'select dbms_pipe.receive_message@prod(:1, 30) from dual' into result using p_pipe_name;
           if result = c_PIPE_MESSAGE_RECEIVED then
              execute immediate 'begin dbms_pipe.unpack_message@prod(:1); end;' using out data;
              data_avaiable := true;
              --dbms_output.put_line( 'el mensaje recibido es:' || data);
              --limpiar el flag bbl_value del la tabla bb_locks con bbl_id = p_lock_id
              execute immediate 'select bbl_value from bb_locks@prod where bbl_id = :1 for update' into v_bbl_value using p_lock_id;
              execute immediate 'update bb_locks@prod set bbl_value = 0 where bbl_id = :1' using p_lock_id;
              commit;
           elsif result = c_PIPE_TIMEOUT then
                data_avaiable := false;
           else /* other */
               data_avaiable := true;
               action := 1;
           end if;
     end loop;
return action;
end;


function f_notify_update_bbi
         return number is

begin
     return f_notify_bbi(c_PIPE_UPDATE, c_LOCK_UPDATE);
end;

function f_notify_review_bbi
         return number is
begin
     return f_notify_bbi(c_PIPE_REVIEW, c_LOCK_REVIEW);
end;

function f_notify_bbi(p_pipe_name varchar2, p_lock_id number)
         return number is

result number;
action number := 0;
v_bbl_value number;
begin
      --lock register in table bb_locks
      execute immediate 'select bbl_value from bb_locks@prod where bbl_id = :1 for update' into v_bbl_value using p_lock_id;
      --si hay un mensaje encolado en el pipe, salir sin hacer nada
      --sino, mandar mensaje al pipe y actualizar bb_locks
      if v_bbl_value <> 1 then
         execute immediate 'begin dbms_pipe.pack_message@prod(1); end;';
         execute immediate 'select dbms_pipe.send_message@prod(:1, 120, 10) from dual' into result using p_pipe_name;
         if result = 0 then
                  execute immediate 'update bb_locks@prod set bbl_value = 1 where bbl_id = :1' using p_lock_id;
         else
                  action := 1;
         end if;
      end if;
      commit;
return action;
end;

end PA_PROV_BLACKBERRY_TALKER_DYN;

----------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------
/

