create materialized view S_SIMS
refresh force on demand
  as
    SELECT * FROM SIMS@PROD
/

