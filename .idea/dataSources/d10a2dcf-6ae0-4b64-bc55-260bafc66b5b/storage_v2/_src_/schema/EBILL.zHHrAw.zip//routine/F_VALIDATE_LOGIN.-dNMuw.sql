create FUNCTION F_VALIDATE_LOGIN(P_USER           IN VARCHAR2,
                                            P_PIN            IN VARCHAR2,
                                            P_HASH           IN VARCHAR2,
                                            P_CPR_PRF_ID     OUT NUMBER,
                                            P_CPR_TRY_FAILED OUT NUMBER,
                                            P_CPR_BLOCKED    OUT VARCHAR2,
                                            P_ERR_NUMBER     OUT NUMBER,
                                            P_ERR_MESSAGE    OUT VARCHAR2)
  RETURN INTEGER IS
  RESULT        INTEGER;
  V_HASH        VARCHAR2(100);
  V_FOUND       NUMBER := 0;
  V_PIN         VARCHAR2(10);
  L_RESULT      NUMBER;
  V_ERR_MESSAGE VARCHAR2(100);
  V_BILL        VARCHAR2(10); --BILLNUMBER
  V_LINE        VARCHAR2(10); --CELLULARNUMBER
  V_ERR_NUMBER  NUMBER;
  PARM_USER_ID  VARCHAR2(10) := USER;
  V_STATUS      VARCHAR2(2) := 'Y';

BEGIN

  V_ERR_MESSAGE := 0;
  V_ERR_MESSAGE := 'OK';
  /**SE CONSULTA LA TABLA DE USUARIOS PARA RECUPERAR EL HASH DEL USUARIO**/
  BEGIN
    SELECT U.UL_PASSWORD, UC.UC_BILLNUMBER, UC.UC_CELLULARNUMBER
      INTO V_HASH, V_BILL, V_LINE
      FROM USERS_LOGIN U, USERS_CELLULARS UC
     WHERE U.UL_USER = UC.UC_USUARIO
       AND UC.UC_USUARIO = P_USER;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      V_FOUND := 1;
      BEGIN
        SELECT S.CLU_PASSWORD, S.CLU_BILL_NUMBER, S.CLU_CELLULAR_NUMBER
          INTO V_PIN, V_BILL, V_LINE
          FROM S_CELLULARS S
         WHERE S.CLU_BILL_NUMBER = P_USER;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          RESULT        := 1;
          P_ERR_NUMBER  := 2;
          P_ERR_MESSAGE := 'LINEA ERRONEA';
          RETURN(RESULT);
      END;
  END;
  CASE V_FOUND
    WHEN 0 THEN
      /**SE COMPARA EL HASH OBTENIDO CON EL HASH INFORMADO**/
      IF V_HASH = P_HASH THEN
        RESULT := 0;
        V_STATUS := 'Y';
      ELSE
        RESULT := 1;
        P_ERR_NUMBER  := 2;
        P_ERR_MESSAGE := 'LINEA ERRONEA';
        V_STATUS := 'N';
      END IF;
    WHEN 1 THEN
      /**SE COMPARA EL PIN INFORMADO CON EL OBTENIDO DE LA TABLA EN CASO DE SER IGUALES SE INSERTA EN LA TABLA DE USUARIOS*/
      IF V_PIN = P_PIN THEN
        V_STATUS := 'Y';
        RESULT := 0;
        BEGIN
          INSERT INTO USERS_LOGIN
            (UL_USER, UL_PASSWORD, UL_CREATIONDATE, UL_CREATIONUSER)
          VALUES
            (V_BILL, P_HASH, SYSDATE, PARM_USER_ID);
        EXCEPTION
          WHEN OTHERS THEN
            RESULT := -1;
            P_ERR_NUMBER  := SQLCODE;
            P_ERR_MESSAGE := 'error insertando en tabla users_login';
            RETURN(RESULT);
        END;
        BEGIN
          INSERT INTO USERS_CELLULARS
            (UC_USUARIO,
             UC_BILLNUMBER,
             UC_CELLULARNUMBER,
             UC_CREATIONDATE,
             UC_CREATIONUSERS)
          VALUES
            (P_USER, V_BILL, V_LINE, SYSDATE, PARM_USER_ID);
        EXCEPTION
          WHEN OTHERS THEN
            RESULT := -1;
            P_ERR_NUMBER  := SQLCODE;
            P_ERR_MESSAGE := 'error insertando en tabla users_cellular';
            RETURN(RESULT);
        END;
      ELSE
        RESULT := 1;
        P_ERR_NUMBER  := 2;
        P_ERR_MESSAGE := 'LINEA ERRONEA';
        V_STATUS := 'N';
      END IF;
    
  END CASE;
  L_RESULT := F_VALIDATE_CELLULAR_LOCAL(V_LINE,
                                           V_STATUS,
                                           P_CPR_PRF_ID,
                                           P_CPR_TRY_FAILED,
                                           P_CPR_BLOCKED,
                                           V_ERR_NUMBER,
                                           V_ERR_MESSAGE);
  IF L_RESULT != 0 THEN
    RESULT        := L_RESULT;
    P_ERR_NUMBER  := V_ERR_NUMBER;
    P_ERR_MESSAGE := V_ERR_MESSAGE;
  END IF;
  RETURN(RESULT);
END F_VALIDATE_LOGIN;
/

