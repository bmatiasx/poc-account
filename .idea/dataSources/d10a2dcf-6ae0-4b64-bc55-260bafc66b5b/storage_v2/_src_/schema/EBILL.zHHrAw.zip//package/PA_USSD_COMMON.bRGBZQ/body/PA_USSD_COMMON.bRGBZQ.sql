create PACKAGE BODY PA_USSD_COMMON IS

  /* Esta funcion tiene como objectivo obtener un mensaje pretendido a deplegar al cliente. Inspirado en MESSAGES_SMS
  * @param PP_MSG_ID : codigo del mensaje que se pretende buscar
  * @return Retorna el mensaje a desplegar, sino encuentra el mensaje, devuelve uno por defecto
  */


  FUNCTION GET_MESSAGE_USSD(PP_MSG_ID IN VARCHAR2) RETURN VARCHAR2 IS
    v_msg_text MESSAGES_USSD.MSG_TEXT%TYPE;
  BEGIN
    BEGIN
      SELECT MSG_TEXT
        INTO v_msg_text
        FROM MESSAGES_USSD
       WHERE MSG_ID = PP_MSG_ID
         AND SYSDATE BETWEEN MSG_START_DATE AND
             NVL(MSG_END_DATE, TRUNC(SYSDATE + 1));
    
    EXCEPTION
      WHEN OTHERS THEN
        v_msg_text := 'Ha ocurrido un problema, disculpe las molestias. Por favor, intente mas tarde.'; --Mensaje por defecto
    END;
  
    RETURN v_msg_text;
  
  END GET_MESSAGE_USSD;

  /* Esta funcion tiene como objectivo obtener un mensaje pretendido a deplegar al cliente. Inspirado en MESSAGES_SMS
  * @param PP_MSG_ID : codigo del mensaje que se pretende buscar
  * @param PP_MSG_TEXT : mensaje que se desplegara al cliente
  * @param PP_ERR_CODE : Codigo de Error
  * @param PP_ERR_TEXT : El mensaje de error desplegado al cliente
  * @param PP_ERR_SQL : El error SQL en caso de EXCEPTION
  * @return Retorno 0 si todo OK, -1 en caso contrario
  */
  FUNCTION GET_MESSAGE_USSD(PP_MSG_ID   IN VARCHAR2,
                            PP_MSG_TEXT OUT VARCHAR2,
                            PP_ERR_CODE OUT PLS_INTEGER,
                            PP_ERR_TEXT OUT VARCHAR2) RETURN PLS_INTEGER IS
  
  BEGIN
  
    SELECT MSG_TEXT
      INTO PP_MSG_TEXT
      FROM MESSAGES_USSD
     WHERE MSG_ID = PP_MSG_ID
       AND SYSDATE BETWEEN MSG_START_DATE AND
           NVL(MSG_END_DATE, TRUNC(SYSDATE + 1));
  
    PP_ERR_CODE := 0;
    PP_ERR_TEXT := '';
  
    RETURN 0;
  
  EXCEPTION
    WHEN OTHERS THEN
      PP_ERR_CODE := -1;
      PP_ERR_TEXT := 'Ocurrio un error al buscar el mensaje ' || SQLCODE || ' ' ||
                     SQLERRM;
      PP_MSG_TEXT := 'Ha ocurrido un problema, disculpe las molestias. Por favor, intente mas tarde.'; --Mensaje por defecto
      RETURN 0;
  END GET_MESSAGE_USSD;

  /* Esta funcion tiene como objetivo devolver el bill number dado un msisdn
  * @param MSISDN : msisdn sobre el cual obtener el bill number
  * @return Retorna el bill number
  */
  FUNCTION GET_BILL_NUMBER(MSISDN IN VARCHAR2) RETURN VARCHAR2 IS
    COD_AREA_AR CONSTANT PLS_INTEGER := 549;
    COD_AREA_PY CONSTANT PLS_INTEGER := 595;
    COD_AREA_UY CONSTANT PLS_INTEGER := 598;
    BILL_NUMBER VARCHAR2(255);
  
  BEGIN
  
    IF ((MSISDN is NULL) OR (TRIM(MSISDN) = '')) THEN
      RAISE_APPLICATION_ERROR(-20000, 'MSISDN must be provided!');
    END IF;
  
    IF (SUBSTR(MSISDN, 1, 3) = COD_AREA_AR) THEN
      BILL_NUMBER := SUBSTR(MSISDN, 4);
    ELSIF (SUBSTR(MSISDN, 1, 3) = COD_AREA_PY) THEN
      BILL_NUMBER := SUBSTR(MSISDN, 4);
    ELSIF (SUBSTR(MSISDN, 1, 3) = COD_AREA_UY) THEN
      BILL_NUMBER := SUBSTR(MSISDN, 4);
    ELSE
      BILL_NUMBER := MSISDN;
    END IF;
  
    RETURN BILL_NUMBER;
  
  END GET_BILL_NUMBER;

  /* Esta funcion tiene como objetivo devolver el cellular number dado un bill number
  * @param BILL_NUMBER : bill number sobre el cual buscar el cellular number
  * @return Retorna el cellular number si existe, sino retorna -1
  */
  FUNCTION GET_CELLULAR_NUMBER(BILL_NUMBER IN VARCHAR2) RETURN VARCHAR2 IS
    CELULAR VARCHAR2(255);
  BEGIN
    SELECT CLU_CELLULAR_NUMBER
      INTO CELULAR
      FROM CELLULARS
     WHERE CLU_BILL_NUMBER = BILL_NUMBER;
    RETURN CELULAR;
  
  EXCEPTION
    WHEN OTHERS THEN
      RETURN - 1;
  END GET_CELLULAR_NUMBER;

  /*  Esta funcion sirve para convertir una lista de valores separados por # (POUND) y convertirlo en un XML
  *  con el formato <item>..</item> <item>..</item> <item>..</item> <total>x</total>
  *  @param LIST : Lista de valores separados por #
  *  @return Retorna el XML de la lista
  */
  FUNCTION LIST_TO_XML(LIST IN VARCHAR2) RETURN VARCHAR2 IS
    POINT      NUMBER;
    NEXT_POINT NUMBER;
    IT         NUMBER;
    TOKEN      VARCHAR2(255);
    TOTAL      NUMBER := 0;
    XML_ANSWER VARCHAR2(1500) := '';
  BEGIN
    IT    := 0;
    POINT := 1;
    LOOP
      NEXT_POINT := INSTR(LIST, '#', POINT);
      -- DBMS_OUTPUT.PUT_LINE('NEXT POINT ' || TO_CHAR(NEXT_POINT));
      IF (NEXT_POINT <> 0) THEN
        -- DBMS_OUTPUT.PUT_LINE('LIMITS' || POINT || ' ' || NEXT_POINT);
        TOKEN := SUBSTR(LIST, POINT, NEXT_POINT - POINT);
        IF ((TOKEN IS NOT NULL) AND (LENGTH(TOKEN) > 0)) THEN
          XML_ANSWER := XML_ANSWER || '<item>' || TOKEN || '</item>';
          --XML_ANSWER := XML_ANSWER || '<item valor="'|| TOKEN ||'">' || TOKEN || '</item>';
          TOTAL := TOTAL + 1;
        END IF;
        -- DBMS_OUTPUT.PUT_LINE('TOKEN ' || TOKEN);
        POINT := NEXT_POINT + 1;
      ELSE
        -- DBMS_OUTPUT.PUT_LINE('LIMITS' || POINT || ' ' || LENGTH(LIST));
        IF (POINT <= LENGTH(LIST)) THEN
          TOKEN := SUBSTR(LIST, POINT, LENGTH(LIST) - POINT + 1);
          IF ((TOKEN IS NOT NULL) AND (LENGTH(TOKEN) > 0)) THEN
            XML_ANSWER := XML_ANSWER || '<item>' || TOKEN || '</item>';
            --XML_ANSWER := XML_ANSWER || '<item valor="'|| TOKEN ||'">' || TOKEN || '</item>';
            TOTAL := TOTAL + 1;
          END IF;
          --DBMS_OUTPUT.PUT_LINE('TOKEN ' || TOKEN);
        END IF;
      END IF;
      IT := IT + 1;
      IF (IT > 50) THEN
        -- THIS IS TO PREVENT INFINITE LOOP!
        EXIT;
      END IF;
      EXIT WHEN NEXT_POINT = 0;
    END LOOP;
    XML_ANSWER := XML_ANSWER || '<total>' || TO_CHAR(TOTAL) || '</total>';
    --DBMS_OUTPUT.PUT_LINE('XML ' || XML_ANSWER);
    RETURN XML_ANSWER;
  END LIST_TO_XML;

  /*  Esta funcion sirve para enviar mensajes de texto.
  *  @param MSISDN: msisdn destino del mensaje de texto.
  *  @param PP_MULTI_SEND: Para enviar por mas de un metodo de envío de mensajes.
  *  @param PP_DATE_TO_SEND: Fecha a enviar el mensaje.
  *  @param PP_TEXT_TO_SEND: Texto que se enviará en el mensaje (no mas de 150 caracteres).
  *  @param PP_TEXT_SUBJECT: Asunto del mensaje.
  *  @param PP_TEXT_SOURCE: Remitente del mensaje.
  *  @param PP_TEXT_TYPE: Tipo de mensaje.
  *  @param PP_TEXT_PRIORITY: Prioridad del msj.
  *  @param PP_DO_COMMIT: Si tiene que commitiar o no.
  *  @param PP_ERR_CODE : Codigo de Error
  *  @param PP_ERR_TEXT : El mensaje de error desplegado al cliente
  *  @param PP_ERR_SQL : El error SQL en caso de EXCEPTION
  *  @return Retorno 0 si todo OK, -1 en caso contrario
  */
  FUNCTION SEND_SMS(MSISDN           IN VARCHAR2,
                    PP_MULTI_SEND    IN VARCHAR2 DEFAULT 'N',
                    PP_DATE_TO_SEND  IN DATE DEFAULT SYSDATE,
                    PP_TEXT_TO_SEND  IN VARCHAR2,
                    PP_TEXT_SUBJECT  IN VARCHAR2 DEFAULT NULL,
                    PP_TEXT_SOURCE   IN VARCHAR2,
                    PP_TEXT_TYPE     IN VARCHAR2 DEFAULT NULL,
                    PP_TEXT_PRIORITY IN NUMBER DEFAULT 0,
                    PP_DO_COMMIT     IN VARCHAR2 DEFAULT 'N',
                    PP_RAZON_ID      IN VARCHAR2,
                    PP_ERR_CODE      OUT NUMBER,
                    PP_ERR_TEXT      OUT VARCHAR2,
                    PP_SQL_CODE      OUT VARCHAR2) RETURN NUMBER IS
  
    v_bill_number      CELLULARS.clu_bill_number%TYPE;
    v_enable_db_send   VARCHAR2(1 BYTE);
    v_send_success     VARCHAR2(1 BYTE);
    v_http_url         VARCHAR2(400 BYTE);
    v_http_url_encoded VARCHAR2(500 BYTE);
    v_retorno          NUMBER;
    v_response         VARCHAR2(500 BYTE);
    v_sms_id           NUMBER;
    v_wiq_url          VARCHAR2(100 BYTE);
    v_min              VARCHAR2(15);
    v_salida           NUMBER;
  
  BEGIN
    v_send_success := 'N';
  
    BEGIN
      SELECT STL_CHAR_VALUE
        INTO v_enable_db_send
        FROM STL_PARAMETERS
       WHERE STL_ID = 'USMSDB'
         AND SYSDATE BETWEEN STL_START_DATE AND
             NVL(STL_END_DATE, SYSDATE + 1);
    EXCEPTION
      WHEN OTHERS THEN
        v_enable_db_send := 'Y';
    END;
  
    IF v_enable_db_send = 'Y' THEN
      v_bill_number := GET_BILL_NUMBER(MSISDN);
    
      BEGIN
        IF (SUBSTR(MSISDN, 1, 3) = '595' OR SUBSTR(MSISDN, 1, 3) = '598') THEN
          v_min := v_bill_number;
        ELSE
          SELECT CLU_CELLULAR_NUMBER
            INTO v_min
            FROM CELLULARS
           WHERE CLU_BILL_NUMBER = v_bill_number;
        END IF;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          v_min := v_bill_number;
      END;
    
      v_retorno := PA_SEND_SMS.SEND_SMS_BY_MIN(v_min,
                                               PP_TEXT_SUBJECT,
                                               PP_TEXT_TO_SEND,
                                               PP_TEXT_SOURCE,
                                               PP_TEXT_TYPE,
                                               PP_TEXT_PRIORITY,
                                               PP_DATE_TO_SEND,
                                               USER,
                                               v_sms_id,
                                               PP_SQL_CODE,
                                               PP_RAZON_ID);
    
      IF v_retorno = 0 THEN
        v_send_success := 'Y';
      END IF;
    END IF;
  
    IF v_send_success = 'N' OR PP_MULTI_SEND = 'Y' THEN
      -- INTENTO POR URL
      BEGIN
        SELECT STL_CHAR_VALUE
          INTO v_http_url
          FROM STL_PARAMETERS
         WHERE STL_ID = 'WIQURL'
           AND SYSDATE BETWEEN STL_START_DATE AND
               NVL(STL_END_DATE, SYSDATE + 1);
      EXCEPTION
        WHEN OTHERS THEN
          v_http_url := 'http://10.92.16.246/fcgi-bin/wIQpush?';
      END;
    
      v_http_url := v_http_url || 'dest=' || MSISDN;
      v_http_url := v_http_url || '&' || 'src=1234567890&' ||
                    'sessiontype=sms&' || 'response=1&' || 'data=txt';
      v_http_url := v_http_url || '&' || 'text=' || PP_TEXT_TO_SEND;
    
      BEGIN
        SELECT UTL_URL.ESCAPE(v_http_url)
          INTO v_http_url_encoded
          FROM dual;
        --dbms_output.put_line('URL: '||v_http_url_encoded);
        SELECT UTL_HTTP.REQUEST(v_http_url_encoded)
          INTO v_response
          FROM dual;
        IF INSTR(v_response, 'ERROR') > 0 OR
           INSTR(v_response, 'REJECTED') > 0 THEN
          v_send_success := 'N';
        ELSE
          v_send_success := 'Y';
        END IF;
        PP_SQL_CODE := v_response;
      EXCEPTION
        WHEN OTHERS THEN
          PP_SQL_CODE    := SQLERRM;
          v_send_success := 'N';
      END;
    END IF;
  
    /* IF v_send_success = 'N' OR PP_MULTI_SEND = 'Y' THEN -- INTENTO POR DAEMON
    INSERT INTO USSD_SMS_INTERFACE(USI_MSISDN, USI_STATUS, USI_MSG, USI_DATE_TO_SEND)
    VALUES(MSISDN, 'P', PP_TEXT_TO_SEND, PP_DATE_TO_SEND);
    
      v_send_success := 'Y';
    END IF; */
  
    IF PP_DO_COMMIT = 'Y' AND v_send_success = 'Y' THEN
      COMMIT;
    END IF;
  
    PP_ERR_CODE := 0;
    PP_ERR_TEXT := 'Ok.';
    RETURN 0;
  
  EXCEPTION
    WHEN OTHERS THEN
      IF PP_DO_COMMIT = 'Y' THEN
        ROLLBACK;
      END IF;
      PP_ERR_CODE := -100;
      PP_SQL_CODE := '[PA_USSD_COMMON.SEND_SMS] ' || SQLCODE || ' ' ||
                     SQLERRM;
      PP_ERR_TEXT := GET_MESSAGE_USSD('MSGERRGEN');
      RETURN - 1;
  END SEND_SMS;

  /*  Esta funcion sirve para darle un formato al monto segun el pais.
  *  @param P_MOUNT_NUMBER: Monto que se dara el formato en number.
  *  @param P_MOUNT_CHAR: Monto que se dara el formato en char.
  *  @param P_RESULT: resultado del monto ya formateado.
  *  @return Retorno 0 si todo OK, -1 en caso contrario
  */


  FUNCTION FORMAT_NUMBER(P_MOUNT_CHAR   IN VARCHAR2,
                         P_RESULT       OUT VARCHAR2) RETURN VARCHAR2 IS
  
    V_SEPARADOR VARCHAR2(30);
  
  BEGIN
  
    BEGIN
      SELECT 'NLS_NUMERIC_CHARACTERS = ,.' SEPARADOR
        INTO V_SEPARADOR
        FROM STL_PARAMETERS
       WHERE STL_ID LIKE ('DBPAIS')
         AND STL_CHAR_VALUE = 'PY';
    
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        V_SEPARADOR := 'NLS_NUMERIC_CHARACTERS = ,.';
    END;
  
    --
    IF P_MOUNT_CHAR IS NOT NULL THEN
      P_RESULT := TRIM(TO_CHAR(P_MOUNT_CHAR, '9G999G999D99', V_SEPARADOR));
      RETURN 0;
    END IF;
    
  EXCEPTION
    WHEN OTHERS THEN
         RETURN - 1;   
      
END FORMAT_NUMBER;  

FUNCTION CALCULATE_TAXES ( P_GEU_ID IN OUT accounts.acc_geu_id%TYPE
                          ,P_MONTO IN OUT VARCHAR2
                          ,P_ROAMING IN NUMBER
                          ,P_ERR_TEXT OUT VARCHAR2
                          ,P_ERR_CODE OUT NUMBER
                          ,P_SQL_CODE OUT VARCHAR2) RETURN NUMBER IS
V_GEO VARCHAR2(100);
V_IMP NUMBER(14,4);
V_GEO_ERR EXCEPTION;


BEGIN

 SELECT STL_CHAR_VALUE INTO V_GEO
 FROM   STL_PARAMETERS
 WHERE  STL_ID = 'USSDGE';


 IF P_ROAMING = 0 THEN
     -- SIN ROAMING
     SELECT TO_NUMBER(P_MONTO) * SUM(STL_VALUE) INTO V_IMP
     FROM   STL_PARAMETERS
     WHERE  STL_ID IN ('USSDIM', 'USSDII');
 ELSE
     -- CON ROAMING
     SELECT TO_NUMBER(P_MONTO) * STL_VALUE INTO V_IMP
     FROM   STL_PARAMETERS
     WHERE  STL_ID IN ('USSDIR');
 END IF;

--
  IF P_GEU_ID IS NULL THEN
     RAISE V_GEO_ERR;
  END IF;   

 IF INSTR('##'||P_GEU_ID||'##', V_GEO) >= 1 THEN
    -- CALCULO SIN IMPUESTO.
    P_MONTO:= ROUND(P_MONTO, 2);
    P_ERR_CODE:= 0;
    P_ERR_TEXT:= 'TERMINO OK SIN IMP';
    RETURN 0;
 ELSE  -- CALCULO CON IMPUESTOS.
    P_MONTO:= ROUND(P_MONTO + V_IMP, 2);  
    P_ERR_CODE:= 0;
    P_ERR_TEXT:= 'TERMINO OK CON IMP';
    RETURN 0;
 END IF;

EXCEPTION WHEN NO_DATA_FOUND THEN
          P_ERR_TEXT:= 'ERROR NO DATA FOUND';
          P_ERR_CODE:= -1;
          P_SQL_CODE:= SQLCODE || ' ' ||SQLERRM;
          RETURN -1;
          WHEN V_GEO_ERR THEN
          P_ERR_CODE:= -1;
          P_ERR_TEXT:= 'ERROR parametro P_GEU_ID NULL';
          RETURN -1;

END CALCULATE_TAXES;
 
END PA_USSD_COMMON;
/

