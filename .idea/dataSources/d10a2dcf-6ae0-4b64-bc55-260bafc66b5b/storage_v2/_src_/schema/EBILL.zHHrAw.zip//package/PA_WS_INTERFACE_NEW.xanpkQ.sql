create PACKAGE PA_WS_INTERFACE_NEW IS
-- Author  :  Franco, Gaby
  -- Created : 21/03/2016
  -- Purpose : interface de servicio, inicio de ecomerce
  -- Updates:
  /* DATE                      USR                                JIRA
     -
  */
  PROCEDURE p_ws_interface(p_circuito           IN VARCHAR2,
                           p_tipo_opera         IN VARCHAR2,
                           p_transaccion        IN VARCHAR2,
                           p_parametros         IN OUT type_tab_ws_param,
                           p_client_historic    OUT sys_refcursor,
                           p_order_tracking     OUT sys_refcursor,
                           p_domicilios         OUT sys_refcursor,
                           p_planes             OUT sys_refcursor,
                           p_matrix             OUT sys_refcursor,
                           p_prod_prices        OUT sys_refcursor,
                           p_transaction_status OUT sys_refcursor,
                           p_cod_error          OUT VARCHAR2,
                           p_result             OUT NUMBER);
  FUNCTION f_valida_parametros(p_circuito    IN VARCHAR2,
                               p_tipo_opera  IN VARCHAR2,
                               p_transaccion IN VARCHAR2,
                               p_parametros  IN OUT TYPE_TAB_WS_PARAM,
                               p_cod_error   OUT VARCHAR2,
                               p_msg_error   OUT VARCHAR2) RETURN NUMBER;
  FUNCTION f_ws_call_process(p_circuito       IN VARCHAR2,
                             p_tipo_operacion IN VARCHAR2,
                             p_transaccion    IN VARCHAR2) RETURN NUMBER;
  FUNCTION f_gestor_error_rechazo(p_resultado_pam IN NUMBER) RETURN NUMBER;
  FUNCTION f_set_parametros_salida(p_parametros IN OUT type_tab_ws_param)
    RETURN NUMBER;
  PROCEDURE p_grabo_error(p_error_code IN NUMBER DEFAULT NULL,
                          p_error_text IN VARCHAR2 DEFAULT NULL,
                          p_sentence   IN VARCHAR2 DEFAULT NULL,
                          p_comment    IN VARCHAR2 DEFAULT NULL);
  PROCEDURE p_add_campo(p_key IN VARCHAR2, p_value IN VARCHAR2);
  FUNCTION f_get_campo(p_key IN VARCHAR2) RETURN VARCHAR2;
  PROCEDURE p_set_error(p_error_code IN VARCHAR2 DEFAULT NULL,
                        p_error_text IN VARCHAR2 DEFAULT NULL,
                        p_sentence   IN VARCHAR2 DEFAULT NULL,
                        p_comment    IN VARCHAR2 DEFAULT NULL);
  PROCEDURE p_add_flag(p_flag   IN VARCHAR2,
                       p_status IN VARCHAR2,
                       p_codigo IN VARCHAR2 DEFAULT NULL);
  FUNCTION f_get_tab_domicilios return type_tab_domicilios;
  PROCEDURE p_add_tab_domicilios(p_tab_domicilios IN TYPE_REC_DOMICILIOS);
  FUNCTION f_get_tab_prod_prices return type_tab_prod_prices;
  PROCEDURE p_add_tab_prod_prices(p_tab_prices IN TYPE_REC_PROD_PRICES);
  FUNCTION f_get_tab_planes return type_tab_plans;
  PROCEDURE p_add_tab_planes(p_tab_planes IN TYPE_REC_PLANS);
  FUNCTION f_get_tab_matrix return type_tab_matriz;
  PROCEDURE p_add_tab_matrix(p_tab_matrix IN type_rec_matriz);
  FUNCTION f_get_tab_client_historial return type_tab_client_historial;
  PROCEDURE p_add_tab_client_historial(p_tab_client_historial IN type_rec_client_historial);
  FUNCTION f_get_tab_order_tracking return type_tab_order_tracking;
  PROCEDURE p_add_tab_order_tracking(p_tab_order_tracking IN type_rec_order_tracking);
END PA_WS_INTERFACE_NEW;


/

