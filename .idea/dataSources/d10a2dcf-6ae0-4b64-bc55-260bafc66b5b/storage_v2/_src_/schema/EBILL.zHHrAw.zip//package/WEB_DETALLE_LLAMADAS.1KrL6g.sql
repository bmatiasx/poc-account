create PACKAGE WEB_DETALLE_LLAMADAS IS


-- evento: 49592 Factura Electrónica en Ar
      -- autor : Gallardo Fabián
      -- Proposito: Se modificó la parametrización FC en AR por una consulta
      -- Fecha modificación:  29/05/2007


--Valida el celular que se esta logueando.
-- Chequea que tenga los packs de factura electrónica y que el password sea correcto
-- Retorna: 0: cuando se loguea ok
--         1: no existe el celular
--         2: no tiene el pack
--         3: el password es incorrecto
--         4: la linea no esta activa
Function Validate_Cellular( p_Bill_Number   in  Varchar2,
                            p_Clt_Password  in  Varchar2,
                            p_Clt_Id        out Varchar2,
                            p_Clt_Surname   out Varchar2,
                            p_Error_Text    out Varchar2 ) Return Number;


--Devuelve la lista de cuentas de un cliente
--Retorna: 0: Si encuentra la(s) cuanta(s)
--         1: Sin ocurre algun error
Function Get_Client_Accounts( p_Clt_Id        in  Varchar2,
                              p_Separator     in  Varchar2,
                              p_List_Accounts out Varchar2,
                              p_Error_Text    out Varchar2 ) Return Number;


--Devuelve la lista de periodos disponibles y la lista de documents id´s
--Retorna: 0: si no hay errores
--         1: si no encuentra datos
--         2: por cualquier otro error
Function Get_Available_Periods_combo( P_Account        In  Varchar2,
                                P_Shedulers_list Out Varchar2,
                                P_Periods_list   Out Varchar2
                                ) Return Number;


--Graba un archivo con las llamadas realizadas por toda una cuenta o por una
--linea en particular
--Retorna: 0: si no hay errores
--         -1: si hay error
Function Get_calls( p_Bill_Number   in Varchar2 default null,
                    p_Clt_ID        in  Varchar2,
                    p_SCH_ID_Begin  in  Varchar2,
                    p_SCH_ID_End    in  Varchar2,
                    p_Separator     in  Varchar2,
                    p_rec_number   out NUMBER,
                    p_FileName      out  Varchar2,
                    p_Error_Text    out Varchar2
                  )Return Number;


Function Get_Output_Path( P_Output_Path OUT Varchar2,
                          P_Error_Msg   OUT Varchar2 ) Return Number;


Function get_Bill_Info(P_ACC_ID        in varchar2,
                       P_SCH_ID        in varchar2,
                       P_DOC_ID        out varchar2,
                       P_DOCUMENT_DATE out varchar2,
                       P_ERROR_MSG     out varchar2
                      ) return number;
END WEB_DETALLE_LLAMADAS;
/

