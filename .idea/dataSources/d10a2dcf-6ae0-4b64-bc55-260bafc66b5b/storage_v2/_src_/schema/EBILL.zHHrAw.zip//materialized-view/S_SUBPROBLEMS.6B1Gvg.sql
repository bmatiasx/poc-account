create materialized view S_SUBPROBLEMS
refresh complete on demand
  as
    SELECT SBP_ID,
       SBP_PBL_ID,
	   SBP_DESCRIPTION,
	   SBP_START_DATE,
	   SBP_END_DATE,
	   SBP_FLAG_CORPO
FROM STL.SUBPROBLEMS@PROD

/

