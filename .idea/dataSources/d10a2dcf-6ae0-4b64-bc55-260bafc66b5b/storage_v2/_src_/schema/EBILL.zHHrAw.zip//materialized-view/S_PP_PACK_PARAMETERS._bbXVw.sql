create materialized view S_PP_PACK_PARAMETERS
refresh complete on demand
  as
    SELECT ppp_tipo_pack,
ppp_identificador,
ppp_pkt_id,
ppp_vigencia_desde,
ppp_vigencia_hasta
from pp_pack_parameters@ccard
/

