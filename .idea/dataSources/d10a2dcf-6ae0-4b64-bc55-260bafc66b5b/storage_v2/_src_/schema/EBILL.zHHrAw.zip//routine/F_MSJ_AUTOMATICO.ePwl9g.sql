create FUNCTION F_MSJ_AUTOMATICO

 (P_ID_IVR OUT NUMBER
 ,P_DESCRIPCION OUT VARCHAR2
 ,ERR_CODE OUT VARCHAR2
 )
 RETURN NUMBER
 IS
 FALLAR             EXCEPTION;
BEGIN
   --if p_tipo IS NOT NULL then
      begin
          select mi.id, mi.descripcion
            into p_id_ivr, p_descripcion
            from msj_automaticos ma, msj_ivr mi
           where ma.id_ivr = mi.id
             --and ma.tipo = p_tipo
             and (ma.fecha_hasta is null or ma.fecha_hasta > sysdate);
      exception
           when no_data_found then
               eRR_CODE :='No hay ningun registro vigente';
               RETURN -1;
               RAISE FALLAR;
           when others then
               eRR_CODE := SQLCODE;
               RETURN -1;
      end;
   /*else
       eRR_CODE :='El parametro TIPO es obligatorio';
       RETURN -1;
       RAISE FALLAR;
   --end if;*/
    eRR_CODE := '0K';
    RETURN 0;
EXCEPTION
   WHEN FALLAR THEN
       eRR_CODE := eRR_CODE || SQLCODE;
       RETURN -1;
END;
/

