create materialized view S_MILEAGE_CATEGORY
refresh fast on demand
  as
    SELECT MIC_CELLULAR_NUMBER,
       MIC_CREATION_DATE,
       MIC_LAST_UPDATE_DATE,
       MIC_CATEGORY,
       MIC_OBSERVATION
  FROM MILEAGE_CATEGORY@ardstl.world
/

