create FUNCTION       F_INSERT_WEB_TRANSACTIONS
 (P_NUMBER IN VARCHAR2
 ,P_DESCRIPTION IN VARCHAR2
 ,P_TRA_ID IN NUMBER
 ,P_TYPE IN VARCHAR2
 ,P_CHANNEL IN VARCHAR
 ,P_ERR_NUMBER OUT NUMBER
 ,P_ERR_MESSAGE OUT VARCHAR2
 )
 RETURN INTEGER
 IS
BEGIN
  IF P_TYPE = 'M' THEN
    INSERT INTO cellular_transactions
      (ctt_id,
       ctt_description,
       ctt_clu_cellular_number,
       ctt_tra_id,
       ctt_start_date,
       ctt_channel)
    VALUES
      (seq_ctt_id.nextval,
       P_DESCRIPTION,
       P_NUMBER,
       P_TRA_ID,
       sysdate,
       P_CHANNEL);
  ELSIF P_TYPE = 'C' THEN
    INSERT INTO account_transactions
      (att_id,
       att_description,
       att_acc_id,
       att_tra_id,
       att_start_date,
       att_channel)
    VALUES
      (seq_att_id.nextval,
       P_DESCRIPTION,
       P_NUMBER,
       P_TRA_ID,
       sysdate,
       P_CHANNEL);
  ELSE
    p_err_number := '-1000';
    p_err_message := 'P_TYPE debe ser M o C.';
    return 1;
  END IF;

  p_err_number  := '0';
  p_err_message := 'OK';
  RETURN 0;

EXCEPTION
  WHEN OTHERS THEN
    p_err_number  := SQLCODE;
    p_err_message := SQLERRM;
    RETURN - 1;
END;
/

