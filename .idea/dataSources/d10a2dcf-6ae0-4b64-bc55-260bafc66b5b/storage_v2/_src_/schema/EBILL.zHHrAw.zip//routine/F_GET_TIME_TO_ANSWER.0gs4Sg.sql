create FUNCTION F_GET_TIME_TO_ANSWER

 (P_TYPE_SURVEY IN VARCHAR2
 ,P_ENQUIRY IN NUMBER
 ,P_CELLULAR_NUMBER IN VARCHAR2
 ,P_DIAS OUT NUMBER
 ,P_ERR_NUMBER OUT NUMBER
 ,P_ERR_MESSAGE OUT VARCHAR2
 )
 RETURN NUMBER
 IS
v_retorno     number;
v_value       number;
v_answer      varchar2(10);
v_cant_rptas  number;
v_date        date;
v_dias        number;
begin

   v_retorno:= f_get_parameter(
      P_STL_ID => 'AUT012',
      P_STL_VALUE => v_value, -- valor en dias
      P_STL_CHAR_VALUE => v_answer,
      PP_ERRTXT => p_err_message);

    if v_retorno != 0 then
      return -1;
    end if;

    select  trunc(nvl(sysdate - max(icl_date_start),v_value)), max(icl_date_start)
      into  v_dias, v_date
      from  inquiry_client a
      where   a.icl_clu_cellular_number = p_cellular_number
      and     a.icl_type_survey = p_type_survey
      and     a.icl_inq_id_inquiry = p_enquiry;


-- Si devuelve 0 OK
-- Si devuelve 1 no satisface la condicion
-- si devuelve -1 otros problemas

    if v_dias >= v_value then
      p_dias:=0;
      return 0;
    else
      p_dias:= v_value - v_dias;
      return 1;
    end if;
  exception
    when others then
      return -1;
end f_get_time_to_answer ;
/

