create FUNCTION F_UPDATE_PIN_CORPO
 (P_ACC_ID IN VARCHAR2
 ,P_CLT_PASSWORD IN VARCHAR2
 ,P_ERR_NUMBER OUT NUMBER
 ,P_ERR_MESSAGE OUT VARCHAR2
 )
 RETURN NUMBER
 IS

  v_result NUMBER;
  v_prf_id NUMBER;
  V_2 NUMBER;
  V_3 NUMBER;
  V_4 NUMBER;
  V_5 NUMBER;
  V_6 NUMBER;
  V_PRF_HST VARCHAR2 (2);
BEGIN

  BEGIN
    v_result := F_UPDATE_PIN_CORPO@PROD(P_ACC_ID,
                                  P_CLT_PASSWORD,
                                  P_ERR_NUMBER,
                                  P_ERR_MESSAGE);

    IF v_result = 0 THEN

                SELECT ACP_PRF_ID, ACP_PRF_HST
                INTO V_PRF_ID, V_PRF_HST
                FROM ACCOUNT_PROFILES
                WHERE ACP_ACC_ID=P_ACC_ID;

                SELECT STL_VALUE
                INTO V_2
                FROM S_STL_PARAMETERS
                WHERE STL_ID = 'ACPRLK';

                SELECT STL_VALUE
                INTO V_6
                FROM S_STL_PARAMETERS
                WHERE STL_ID = 'ACPREX';

                IF V_PRF_ID=V_2 OR V_PRF_ID = V_6 THEN

                               IF V_PRF_HST='Y' THEN

                                               SELECT STL_VALUE
                                               INTO V_3

                                               FROM S_STL_PARAMETERS
                                               WHERE STL_ID LIKE 'ACPRGR';

                                               UPDATE account_profiles
                                               SET acp_try_failed = 0, acp_prf_id = V_3, ACP_PASS_LAST_UPDATED = SYSDATE
                                               WHERE acp_acc_id = p_acc_id;
                               ELSE

                                                  IF V_PRF_HST='N' THEN

                                                               SELECT STL_VALUE
                                                               INTO V_4
                                                               FROM S_STL_PARAMETERS
                                                               WHERE STL_ID LIKE 'ACPRBK';

                                                               UPDATE account_profiles
                                                               SET acp_try_failed = 0, acp_prf_id = V_4
                                                               WHERE acp_acc_id = P_ACC_ID;
                                                               
                                                 
                                               ELSE
                                                 IF V_PRF_HST='C' THEN

                                                               SELECT STL_VALUE
                                                               INTO V_4
                                                               FROM S_STL_PARAMETERS
                                                               WHERE STL_ID LIKE 'ACPCLD';

                                                               UPDATE account_profiles
                                                               SET acp_try_failed = 0, acp_prf_id = V_4
                                                               WHERE acp_acc_id = P_ACC_ID;
                                                               
                                                               ELSE
                                                               
                                                               SELECT STL_VALUE
                                                               INTO V_5
                                                               FROM S_STL_PARAMETERS
                                                               WHERE STL_ID LIKE 'ACPRAT';

                                                               UPDATE account_profiles
                                                               SET acp_try_failed = 0, acp_prf_id = V_5
                                                               WHERE acp_acc_id = P_ACC_ID;
                                               END IF;
                               END IF;
                               
                            END IF;
                ELSE

                               UPDATE account_profiles
                               SET acp_try_failed = 0
                               WHERE acp_acc_id = P_ACC_ID;

                END IF;


      P_ERR_NUMBER  := 0;
      P_ERR_MESSAGE := 'OK';
      return 0;

     ELSE IF v_result=1 THEN
              P_ERR_NUMBER  := -1001;
              P_ERR_MESSAGE := 'El numero de cuenta ingresado no existe.';
              RETURN 1;
          ELSE
              P_ERR_MESSAGE := 'error en F_UPDATE_PIN: ' || P_ERR_MESSAGE;
              return - 1;
          END IF;
     END IF;
    
EXCEPTION

    WHEN OTHERS THEN
      P_ERR_NUMBER  := SQLCODE;
      P_ERR_MESSAGE := SQLERRM;
      RETURN - 1;

  
  END;

END;
/

