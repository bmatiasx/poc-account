create package PA_PROV_WSMS is

  -- Author  : NBCORAR76
  -- Created : 22/07/2016 09:03:04 a.m.
  -- Purpose : proporcionar datos de las lineas a la plataforma mobileum
  
  -- Public type declarations
 TYPE T_CURSOR IS REF CURSOR;
  
  -- Public constant declarations
  c_package_name  constant VARCHAR2(20)  := 'PA_ROV_WSMS.';
  c_function_name constant VARCHAR2(20)  := 'GET_DATA ';
  -- Public variable declarations


  -- Public function and procedure declarations
FUNCTION  GET_DATA(pin_imsi VARCHAR2,
                  /* pout_cellular_number OUT VARCHAR2,
                   pout_msisdn          OUT VARCHAR2,
                   pout_iccid           OUT VARCHAR2
                   */
                   POUT_CURSOR_DATA OUT T_CURSOR,
                   Pinout_message       IN OUT  VARCHAR2) return NUMBER;
                   
            
                   

end PA_PROV_WSMS;
/

