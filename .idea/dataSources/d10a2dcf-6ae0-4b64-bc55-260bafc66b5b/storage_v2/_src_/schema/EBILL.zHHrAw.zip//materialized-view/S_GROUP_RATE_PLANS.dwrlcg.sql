create materialized view S_GROUP_RATE_PLANS
refresh complete on demand
  as
    SELECT rrp_rpl_id,
rrp_grp_id,
rrp_start_date,
rrp_end_date
FROM STL.group_rate_plans@PROD
  WHERE rrp_start_date <  GET_DATE
AND NVL(rrp_end_date,GET_DATE+1) > GET_DATE

/

