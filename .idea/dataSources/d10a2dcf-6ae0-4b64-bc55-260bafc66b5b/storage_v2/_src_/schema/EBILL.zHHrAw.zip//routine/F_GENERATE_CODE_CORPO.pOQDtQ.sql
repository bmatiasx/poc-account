create FUNCTION F_GENERATE_CODE_CORPO
 (P_CELLULAR IN VARCHAR2
 ,P_OPERATION_CODE IN VARCHAR2
 ,P_PIN OUT VARCHAR2
 ,P_ERR_NUMBER OUT NUMBER
 ,P_ERR_MESSAGE OUT VARCHAR2
 )
 RETURN NUMBER
 IS
V_RESULT    NUMBER;
V_OPERATION_ID VARCHAR2(10);
BEGIN

    V_RESULT := PA_OPERATION_CODE.F_VALIDATE_CELLULAR_OPERATION (p_operation_code => P_OPERATION_CODE,
                                                                 p_operation_id => V_OPERATION_ID ,
                                                                 p_err_number => P_ERR_NUMBER,
                                                                 p_err_msg => P_ERR_MESSAGE );
    IF V_RESULT <> 0 THEN
      RETURN V_RESULT;
    END IF;

 P_PIN:= TRUNC(dbms_random.value(1000, 9999));


   V_RESULT := PA_OPERATION_CODE.f_generate_operation_code(p_cellular_change => p_cellular,
                                                           p_operation_id => V_OPERATION_ID,
                                                           p_approval_code => p_pin,
                                                           p_cellular_request => p_cellular,
                                                           p_err_number => p_err_number,
                                                           p_err_msg => p_err_message);



    IF V_RESULT <> 0 THEN
      RETURN V_RESULT;
    END IF;


  RETURN 0;


EXCEPTION
  WHEN OTHERS THEN
    P_ERR_NUMBER := -1001;
    P_ERR_MESSAGE := 'Error al generar su clave ';
    RETURN - 1;
END;
/

