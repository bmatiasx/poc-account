create materialized view S_RATE_PLAN_GROUP_TYPES
refresh complete on demand
  as
    SELECT rpt_rpl_id,
rpt_stg_id,
rpt_cbt_id
FROM STL.rate_plan_group_types@PROD

/

