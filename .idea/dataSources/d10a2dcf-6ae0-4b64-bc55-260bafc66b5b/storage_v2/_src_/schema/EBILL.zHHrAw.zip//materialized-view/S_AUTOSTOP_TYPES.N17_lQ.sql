create materialized view S_AUTOSTOP_TYPES
refresh force on demand
  as
    SELECT aut_id, aut_description, aut_stop_flag ,aut_fixed_charge_flag, aut_minimum_plan_percent, aut_maximum_credit_percent, aut_minimum_fixed_charge, aut_priority
FROM STL.autostop_types@PROD

/

