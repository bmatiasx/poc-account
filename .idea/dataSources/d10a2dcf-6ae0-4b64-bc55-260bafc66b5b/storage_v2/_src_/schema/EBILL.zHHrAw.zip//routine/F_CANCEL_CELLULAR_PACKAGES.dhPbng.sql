create FUNCTION F_CANCEL_CELLULAR_PACKAGES

 (P_CELLULAR_NUMBER IN VARCHAR2
 ,P_PKT_ID IN VARCHAR2
 ,P_CANCEL_DATE IN DATE
 ,P_TCK_ID IN VARCHAR2
 ,P_PRM_ID IN VARCHAR2
 ,P_ACT_DATE IN DATE
 ,P_USER_DELETED IN VARCHAR2
 ,P_AUDIOTEL_FLAG IN VARCHAR2
 ,P_INSERT_SWITCH IN VARCHAR2
 ,P_PACK_ISI OUT VARCHAR2
 ,P_PROCESS IN VARCHAR2
 ,P_CHECK_TASK IN VARCHAR2
 ,P_RAZON IN VARCHAR2
 ,P_LOGIC IN VARCHAR2
 ,P_ERR_NUMBER OUT NUMBER
 ,P_ERR_MESSAGE OUT VARCHAR2
 )
 RETURN NUMBER
 IS
/******************************************************************************************************************************************/
/*    Fecha             desarrollador            PC_CD/JIRA          Version              Descripcion                                     */
/******************************************************************************************************************************************/
/* 27/10/2015       Paula L. Santarrosa                                1.0       Se Migra la funcion de Prod a EBill.Se quita group by        */
/*                                                                                porque no corresponde.Se actualiza mensaje acorde.      */
/*                                                                                                                                        */
/******************************************************************************************************************************************/
v_restriction VARCHAR2(6);
v_status VARCHAR2(1);
v_acc_id VARCHAR2(10);
v_available VARCHAR2(1);
v_cbt_id VARCHAR2(2);
BEGIN
    BEGIN
        SELECT clu.clu_status, clu.clu_acc_id, clu.clu_cbt_id
        INTO v_status, v_acc_id, v_cbt_id
        FROM s_cellulars clu
        WHERE clu.clu_cellular_number = p_cellular_number;
    EXCEPTION
        WHEN OTHERS THEN
            p_err_number := SQLCODE;
            p_err_message := 'Error al consultar el snapshot S_CELLULARS.'||SQLERRM;
            RETURN -1;
    END;

    IF v_status = 'C' THEN
        p_err_number := -1001;
        p_err_message := 'No se puede quitar un paquete para una linea cancelada.';
        RETURN 1;
    END IF;

    IF v_status = 'S' THEN
        p_err_number := -1002;
        p_err_message := 'No se puede quitar un paquete para una linea suspendida.';
        RETURN 1;
    END IF;

    BEGIN
        SELECT ccr_cr_id
        INTO v_restriction
        FROM s_cellular_call_restrictions
        WHERE ccr_clu_cellular_number = p_cellular_number
        AND ccr_start_date < SYSDATE
        AND NVL(ccr_end_date,SYSDATE+1) > SYSDATE;
    EXCEPTION
        WHEN OTHERS THEN
            p_err_number := SQLCODE;
            p_err_message := 'Error al consultar el snapshot S_CELLULAR_CALL_RESTRICTIONS.'||SQLERRM;
            RETURN -1;
    END;

    IF v_restriction IN ('5','7') THEN
        p_err_number := -1003;
        p_err_message := 'No se puede quitar un paquete para una linea presuspendida.';
        RETURN 1;
    END IF;

    BEGIN
        SELECT prp.prp_available_down
        INTO v_available
        FROM s_accounts acc,
        s_client clt,
        s_package_restriction_op prp
        WHERE acc.acc_id = v_acc_id
        AND acc.acc_clt_id = clt.clt_id
        AND prp.prp_pkt_id = p_pkt_id
       AND (prp.prp_clt_type = clt.clt_type or prp.prp_clt_type is null)
        AND prp.prp_clt_category = clt.clt_category
        AND prp.prp_cbt_id = v_cbt_id
        AND prp.prp_start_date < SYSDATE
        AND NVL(prp.prp_end_date,SYSDATE+1) > SYSDATE;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            v_available := 'N';
        WHEN OTHERS THEN
            p_err_number := SQLCODE;
            p_err_message := 'Error al consultar el snapshot S_PACKAGE_RESTRICTION_OP.'||SQLERRM;
            RETURN -1;
    END;

    IF v_available = 'N' THEN
        p_err_number := -1004;
        p_err_message := 'El paquete '||p_pkt_id||' no esta disponible para quitar.';
        RETURN 1;
    END IF;

     TEST.pa_packages.cancel_cellular_packages@PROD.WORLD(
        pkt => p_pkt_id,
        can_date => SYSDATE,
        cellular => p_cellular_number,
        tck_id => p_tck_id,
        prm_id => p_prm_id,
        act_date => P_ACT_DATE,
        usr_deleted => USER,
        audiotel_flag => p_audiotel_flag,
        err_code => p_err_number,
        err_txt => p_err_message,
        p_insert_switch => p_insert_switch,
        p_pack_isi => p_pack_isi,
        p_process => p_process,
        check_task => p_check_task,
        p_razon => p_razon ,
        p_logic=> p_logic );

    IF p_err_number <> 0 THEN
        RETURN 1;
    END IF;
       COMMIT;
    RETURN 0;
EXCEPTION
    WHEN OTHERS THEN
        p_err_number := SQLCODE;
        p_err_message := SQLERRM;
        RETURN -1;
END;


/

