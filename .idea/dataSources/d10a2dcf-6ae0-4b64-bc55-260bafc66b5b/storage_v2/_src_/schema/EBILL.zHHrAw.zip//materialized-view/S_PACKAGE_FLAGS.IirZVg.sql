create materialized view S_PACKAGE_FLAGS
refresh fast on demand
  as
    SELECT PFL_ID,
       PFL_DESCRIPTION,
       PFL_END_DATE,
       PFL_START_DATE,
       PFL_PKT_ID,
       PFL_INC_ID,
       PFL_INC_ID_LD
FROM TEST.PACKAGE_FLAGS@ARDSTL.WORLD
/

