create view V_FIL_CON as
  select  f.fil_id,
	f.clt_id,
	f.fil_des,
	c.con_id,
	c.con_des,
	c.con_desl,
	fc.fil_con_val,
	gc.gro_con_des
from
	fe_filters_user f,
	fe_fil_cons fc,
	fe_constraints c,
	fe_group_cons gc
where	f.fil_id = fc.fil_id
and	fc.con_id = c.con_id
and	c.gro_con_id = gc.gro_con_id
/

