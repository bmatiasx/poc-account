create FUNCTION WEB_ONLINE_CALLS

 (NIM IN VARCHAR2
 ,P_FILE_NAME OUT VARCHAR2
 ,ERR_MSG OUT VARCHAR2
 )
 RETURN NUMBER
 IS
path            VARCHAR2(500);
   file_name       VARCHAR2(80) ;
   file_handle     UTL_FILE.FILE_TYPE;
   v_country       varchar2(2);
   value_parameter number;
   counter         number:=0;
   v_existe        number:=0;

 /*  Obtengo todas las llamadas de un celular ordenadas por fecha  */
 CURSOR calls_online(pnim varchar2) is
SELECT  RPAD(NVL(CAL_DIALED_NUMBER, ' '), 18, ' ') ||';'||
        RPAD(NVL(to_char(CAL_DATE, 'yyyymmddhh24miss'), ' '), 16, ' ') ||';'||
        LPAD(TO_CHAR(case when (bitand(CAL_FEATURES, 16777216 ) <> 0) then 'VL' else '' END), 10, ' ') ||';'||
        RPAD(NVL(CAL_LOCATION, ' '), 15, ' ') ||';'||
        RPAD(NVL(CAL_DIRECTION, ' '), 1, ' ') ||';'||
        RPAD(NVL(CAL_CALL_STATUS, ' '), 1, ' ') ||';'||
        trim(to_char(trunc(mod(nvl(CAL_DURATION,0),3600)/60),'09')) ||':'|| trim(to_char(mod(mod(nvl(CAL_DURATION,0),3600),60),'09')) ||';'||
        trim(to_char(trunc(mod(nvl(CAL_EXTENDED_DURATION,0),3600)/60),'09')) ||':'|| trim(to_char(mod(mod(nvl(CAL_EXTENDED_DURATION,0),3600),60),'09')) ||';'||
        LPAD(TO_CHAR(NVL(CAL_ORIGINATING_NUMBER, 0)), 4, ' ') ||';'||
        RPAD(NVL(CAL_TRANSFERED_NUMBER,  ' '), 18, ' ') ||';'||
        LPAD(TO_CHAR(NVL(CAL_AIR_CHARGE,  0.0000),'0d99'), 14, ' ') ||';'||
        LPAD(TO_CHAR(NVL(CAL_AIR_PERIODS, 0.0000)), 10, ' ') ||';'||
        LPAD(TO_CHAR(NVL(CAL_LAND_CHARGE, 0.0000), '0d99'), 14, ' ') ||';'||
        LPAD(TO_CHAR(NVL(CAL_LAND_PERIODS,0.0000)), 10, ' ') ||';'||
        RPAD(NVL(CAL_LOCATION, ' '), 15, ' ') registro
    FROM CALLS c
   WHERE CAL_CLU_CELLULAR_NUMBER = nim
     AND CAL_DATE > (SYSDATE - value_parameter)
   ORDER BY CAL_DATE DESC;
BEGIN


 /*Verifico si tiene el pack Factura Electronica*/
 SELECT  count(*)
 INTO v_existe
 FROM cellulars, cellular_packages, ed_packages_edetails
/* WHERE clu_bill_number = p_celular*/
 WHERE clu_cellular_number = nim
 AND clu_cellular_number = cpk_clu_cellular_number
 AND cpk_pkt_id = epe_pkt_id
 AND sysdate BETWEEN cpk_activation_date AND NVL(cpk_canceled_date,sysdate+1)
 AND sysdate BETWEEN epe_start_date AND NVL(epe_end_date,sysdate+1);


 /*  Identifico el país  */
 SELECT STL_CHAR_VALUE
   INTO v_country
   FROM STL_PARAMETERS
  WHERE STL_ID = 'CTI_DB';

 /*  Busco el PATH y el valor del parametro donde se creará el archivo  */
 SELECT nvl(stl_value,1), stl_char_value
   INTO value_parameter, path
   FROM stl_parameters
  WHERE stl_id = 'WWIPAT';

  /*Controlo si tiene el pack*/
  if (v_existe=0) then
     err_msg:='No tiene el pack Factura Electronica';
     p_file_name := 'El archivo no se genero';
     return 1;
   end if;

 /* Controlo la cantidad de nros ingresados para cada país*/
  IF ((v_country = 'AR' and Length(nim)!=10) OR
      (v_country = 'UY' and Length(nim)!=9)  OR
      (v_country = 'PY' and Length(nim)!=8)) THEN
       err_msg := 'NIM incorrecto';
       p_file_name := 'El archivo no se genero';
       return 1;
  END IF;

  /*  nombro y abro el archivo  */
  file_name := 'online_calls'||'_'||nim||'_';
  IF NOT UTL_FILE.IS_OPEN (file_handle) THEN
    file_name := file_name||to_char(sysdate,'yyyymmdd')||'.txt';
    file_handle := UTL_FILE.FOPEN('DIR_DETAIL',file_name,'W');
  END IF;
  /*  grabo cada registro en el archivo  */
  for co in calls_online(nim) loop
    UTL_FILE.PUTF(file_handle, '%s\n', co.registro);
    counter := counter + 1;
  end loop;

  /*  cierro el archivo  */
  UTL_FILE.FCLOSE(file_handle);
  p_file_name := file_name;


  /*La consulta no trajo records*/
  IF counter < 1 Then
     err_msg := 'La consulta no tiene registros';
     utl_file.fremove('DIR_DETAIL', file_name);
     p_file_name:='El archivo no se genero';

     return 1;
  END IF;
  err_msg := 'OK';
  return 0;
EXCEPTION
   when others then
         dbms_output.put_line('Error: '||sqlerrm);
         err_msg := sqlerrm;
         return sqlcode;
END;
/

