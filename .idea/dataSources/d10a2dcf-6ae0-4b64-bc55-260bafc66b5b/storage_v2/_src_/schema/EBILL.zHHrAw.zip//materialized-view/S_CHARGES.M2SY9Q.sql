create materialized view S_CHARGES
refresh force on demand
  as
    SELECT chr_id, chr_description, chr_type, chr_inc_id, chr_advance, chr_canceled, chr_free_period, chr_start_date, chr_end_date, chr_rui_id, chr_out_inc, chr_prorration, chr_rate_plan,  chr_min_amount, chr_max_amount,       chr_update_amount, chr_cht_id, chr_inc_id_ld, chr_checked_billing_flag, chr_fty_id, chr_inc_id_internet, chr_cfa_id
 from charges@PROD


/

