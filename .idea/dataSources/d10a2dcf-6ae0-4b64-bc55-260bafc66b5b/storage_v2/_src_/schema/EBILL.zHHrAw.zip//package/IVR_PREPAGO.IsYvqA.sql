create PACKAGE IVR_PREPAGO IS

  -- Author  : EMANUEL
  -- Created : 10/08/2015 12:08:16
  -- Purpose :  
  
FUNCTION area_numero
        (p_clu_cellular_number IN S_CELLULARS.clu_cellular_number%TYPE,
         p_cod_area            OUT VARCHAR2,
         p_numero              OUT VARCHAR2,
         p_mensaje             OUT VARCHAR2)
    RETURN NUMBER;

end IVR_PREPAGO;
/

