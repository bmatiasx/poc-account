create FUNCTION F_VALIDATE_CODE_CORPO
 (P_ACC_ID IN VARCHAR2
 ,P_APPROVAL_CODE IN NUMBER
 ,P_OPERATION_CODE IN VARCHAR2
 ,P_ERR_NUMBER OUT NUMBER
 ,P_ERR_MSG OUT VARCHAR2
 )
 RETURN NUMBER
 IS
V_RESULT    NUMBER;
V_OPERATION_ID VARCHAR2(10);
BEGIN
  
    V_RESULT := PA_OPERATION_CODE.F_VALIDATE_CELLULAR_OPERATION (p_operation_code => P_OPERATION_CODE ,
                                                                 p_operation_id => V_OPERATION_ID ,
                                                                 p_err_number => P_ERR_NUMBER,
                                                                 p_err_msg => P_ERR_MSG );
                                                                 
                                                                 
    IF V_RESULT <> 0 THEN
    RETURN V_RESULT;
    END IF;                                                             
                                                                 

    V_RESULT := PA_OPERATION_CODE.f_validate_operation_code_acc(p_acc_id => P_ACC_ID,
                                                                p_operation_id => V_OPERATION_ID,
                                                                p_approval_code => P_APPROVAL_CODE,
                                                                p_err_number => P_ERR_NUMBER,
                                                                p_err_msg => P_ERR_MSG);

    IF V_RESULT <> 0 THEN
      RETURN V_RESULT;
    END IF;


  RETURN 0;


EXCEPTION
  WHEN OTHERS THEN
    P_ERR_NUMBER := -1001;
    P_ERR_MSG := 'Error al validar la clave';
    RETURN - 1;
END;
/

