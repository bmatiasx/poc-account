create view VW_AUT_FEATURES_ASSOCIATIONS as
  SELECT Sfs_Ftr_Id ,
Sfs_Crm_Service,
Sfs_Service,
Custom2,
Custom5,
Custom7,
Custom10
From S_Swp_Feature_Services,
( select* from
(Select ASP_SERVICE,
ASP_NE_SERVICE,
ASP_PARAM_NAME,
ASP_PARAM_VALUE
From S_Swp_Add_Service_Parameters)
Pivot(Max(Asp_Param_Value)
For Asp_Param_Name In('CUSTOM2' Custom2,
'CUSTOM5' Custom5,
'CUSTOM7' Custom7,
'CUSTOM9' Custom9,
'CUSTOM10' Custom10))),
S_SWP_PROVISIONING_ACTIONS spa
WHERE Asp_Service = Sfs_Service
AND spa.Spa_Crm_Service = sfs_crm_service
AND ASP_NE_SERVICE = spa.spa_ne_service
 
/

