create view CURRENT_PLAN_LDI_INFORMATION as
  (SELECT
        DISTINCT PRA_DSC_ID,
                 DSC_DESCRIPTION
         FROM   s_DISTANCE_CODES,
                s_PRICE_ASSIGNMENTS
         WHERE   DSC_ID = PRA_DSC_ID
         AND PRA_RPL_ID IN (SELECT  RPA_RPL_ID_ASSIGNMENT
                           FROM   s_RATE_PLAN_ASSIGNMENTS,
                                  s_RATE_PLANS
                           WHERE  RPL_ID = RPA_RPL_ID_AIR
                                  AND RPA_START_DATE <= SYSDATE
                                  AND NVL(RPA_END_DATE, SYSDATE + 1) > SYSDATE
                                  AND RPA_STG_ID = 'TT')
          AND PRA_START_DATE < SYSDATE
          AND NVL(PRA_END_DATE, SYSDATE + 1) > SYSDATE
)
/

comment on table CURRENT_PLAN_LDI_INFORMATION
is 'Contiene todos los planes de larga distancia Internacional que se est¿n utilizando actualmente en los planes vigentes'
/

