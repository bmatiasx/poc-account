create materialized view S_ACTION_REASONS
refresh complete on demand
  as
    select * from (
SELECT AR_RSN_ID,
       AR_ACT_ID,
       AR_NEGATIVE_NUMBER,
       AR_HOT_LINE_NUMBER,
       AR_DELETED_FLAG,
       AR_ACTIVATION_FLAG,
       AR_UGR_ID,
       AR_START_DATE,
       AR_END_DATE,
       AR_CHARGE_FLAG,
       AR_MAV_CHARGE_FLAG,
       AR_UNIT_BUSINESS_FOLLOW_FLAG,
       AR_PREPAY_FLAG,
       AR_CTP_ID,
       AR_TCS_STATUS_INDICATOR,
       AR_TCS_TRANSACTION_CODE,
       AR_NOTIFY_ABD_FLAG,
       AR_VOID_CHARGE_FLAG,
       AR_CANCELED_DATE,
       AR_CANCELED_REASONS,
       AR_BILLING_FLAG,
       AR_PBL_ID,
       AR_SBP_ID,
       AR_WGR_ID,
       AR_WF_RESULT_CODE,
       AR_DAYS_BEFORE_DELETE,
       AR_TICKLER_SWITCHES,
       AR_NO_SIMLOCK,
       AR_PRIORITY_SAP,
       AR_STATE,
       AR_REASON_STATE,
       AR_USR_ID,
       AR_MODIF_DATE
  FROM STL.ACTION_REASONS@PROD.WORLD
 WHERE     ar_start_date < GET_DATE
       AND NVL (ar_end_date, GET_DATE + 1) > GET_DATE
	 )
/

