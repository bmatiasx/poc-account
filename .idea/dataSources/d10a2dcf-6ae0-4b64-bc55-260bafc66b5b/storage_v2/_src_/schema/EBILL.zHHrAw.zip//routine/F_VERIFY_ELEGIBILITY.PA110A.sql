create FUNCTION F_Verify_Elegibility(p_account_id   IN  Accounts.acc_id%TYPE,
                                p_sum_order    IN  Cloud_Subscriptions.cls_sum_order%TYPE,
                                p_sum_mrr      IN  Cloud_Subscriptions.cls_sum_mrr%TYPE,
                                p_sum_setup    IN  Cloud_Subscriptions.cls_sum_setup%TYPE,
                                p_skus         IN  Cloud_Subscriptions.cls_sku_list%TYPE,
                                p_sales_id     IN  Users.usr_id%TYPE,
                                p_sales_branch IN  A_Entidades.ent_id%TYPE,
                                p_order_type   IN  Cloud_Subscriptions.cls_order_type%TYPE,
                                p_message      OUT VARCHAR2,
                                p_error_code   OUT NUMBER,
                                p_validation   OUT VARCHAR2) RETURN NUMBER IS
    skuList t_sku;
    v_err_code NUMBER;
    v_err_message VARCHAR2(200);
    v_result NUMBER  := 0;
    v_add_cuserr VARCHAR2(1) := 'N';
    v_status     VARCHAR2(1);
  BEGIN
    DBMS_APPLICATION_INFO.SET_CLIENT_INFO(client_info => 'CLOUD');
    p_message := 'PA_PROV_CLOUD.F_VERIFY_ELEGIBILITY -  ';
    BEGIN
      v_result := VALID_CREDIT_CLOUD(P_CUENTA => p_account_id,
                                     P_MONTO_COMPRA => p_sum_order,
                                     P_MONTO_COMPRADO => p_sum_mrr,
                                     P_COSTO_INST => p_sum_setup,
                                     P_ORIGEN => p_sales_id,
                                     P_CANAL => p_sales_branch,
                                     P_DESCRIP => p_validation);
      IF v_result <> 0 THEN
         p_error_code := c_claroexp_code;
         p_message := 'PA_PROV_CLOUD.F_VERIFY_ELEGIBILITY: Error llamando a VALID_CREDIT_CLOUD.';
         RETURN c_claroexp_code;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        p_error_code :=  c_claroexp_code;
        p_message := p_message || ' - Error ('||SQLCODE||'-'||SQLERRM||')';
        RETURN c_claroexp_code;
    END;

    IF (p_validation = 'YES') THEN
       p_message := 'PA_PROV_CLOUD.F_VERIFY_ELEGIBILITY - Calling F_MakeSkuList ';
       skuList := F_MAKE_SKU_LIST(p_in_string => p_skus,
                                  p_delim     => ',');
       FOR i IN skuList.FIRST .. skuList.LAST LOOP
         p_message := 'PA_PROV_CLOUD.F_VERIFY_ELEGIBILITY - Calling PA_CLOUD.CREAR_ACCOUNT_SERVICES ';
         v_result := PA_CLOUD.CREAR_ACCOUNT_SERVICES(p_acc_id     => p_account_id,
                                                     p_asd_id     => skulist(i),
                                                     p_usr_id     => p_sales_id,
                                                     p_ent_id     => p_sales_branch,
                                                     p_order_type => p_order_type,
                                                     p_err_code   => v_err_code,
                                                     p_err_txt    => v_err_message);
         IF v_result <> 0 THEN
           --si da error alguna de las llamadas a customer
           v_add_cuserr := 'Y';
           EXIT;
         END IF;
       END LOOP;
     END IF;
      IF v_add_cuserr = 'Y' THEN
         v_status := c_cce_pri_status;
      ELSE
         v_status := '0';
         v_err_code := 0;
         v_err_message := 'OK';
      END IF;
      p_message := 'PA_PROV_CLOUD.F_VERIFY_ELEGIBILITY - Calling P_ADD_VERIFY_ELEGIBILITY ';
      P_ADD_VERIFY_ELEGIBILITY(p_status       => v_status,
                               p_err_message  => v_err_message,
                               p_acc_id       => p_account_id,
                               p_err_code     => v_err_code,
                               p_sum_order    => p_sum_order,
                               p_sum_mrr      => p_sum_mrr,
                               p_sum_setup    => p_sum_setup,
                               p_sku_list     => p_skus,
                               p_sales_id     => p_sales_id,
                               p_sales_branch => p_sales_branch,
                               p_add_cuserr   => v_add_cuserr,
                               p_lco_status   => p_validation,
                               p_order_type   => p_order_type);
      p_message := 'OK';
      COMMIT;
      RETURN 0;

  EXCEPTION
    WHEN OTHERS THEN
      p_error_code := c_claroexp_code;
      p_message := 'PA_PROV_CLOUD.F_VERIFY_ELEGIBILITY: ('||SQLCODE||'-'||SQLERRM||')';
      RETURN c_claroexp_code;
  END F_Verify_Elegibility;
/

