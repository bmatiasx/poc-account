create FUNCTION F_CONS_PERFIL_CONSUMO_PP(P_CELLULAR       IN VARCHAR2,
                                                    P_ID_PERFIL_PP   OUT VARCHAR2,
                                                    P_ID_CATEGORY_PP OUT CHAR,
                                                    P_DESC_CATEGORY  OUT VARCHAR2,
                                                    P_CODE_ERROR     OUT NUMBER,
                                                    P_ERROR_TEXT     OUT VARCHAR2)
  RETURN NUMBER IS
  /*
  Función que recibe el clu_cellular_number  de una línea PP y devuleve el Perfil de consumo de la línea y la caetgoría
  de acuerdo a la segmentación realizada sobre la base de líneas PP sgún el perfil de consumo. La segmentación es a nivel de
  línea no de cuenta ni de cliente.
  Si corrió ok devuelve 0 si hubo error devuelve -1
  */
  /****************************************************************************************************************************************/
  /**    FECHA                  EVENTO                   DESARROLLADOR                         DESCRIPCIÓN                               **/
  /** 10/05/2011         PC51100_CD62424             SANTARROSA, PAULA        Función que devuelve el perfil de Consumo de una línea PP  **/
  /**                                                                                                                                    **/
  /****************************************************************************************************************************************/
  V_PCE_HANDLE NUMBER(10);
  --V_ID_CATEGORY_PP CHAR(1);
BEGIN
  BEGIN
    P_ERROR_TEXT := 'Buscando el Handle para de la línea PP.';
  
    SELECT PCE_HANDLE
      INTO V_PCE_HANDLE
      FROM PREPAY_CELLULARS PC
     WHERE PC.PCE_CLU_CELLULAR_NUMBER = P_CELLULAR;
  
    P_ERROR_TEXT := 'Buscando la categoría y el Perfil de la línea PP.';
  
    SELECT PSL_ID_CATEGORY, PSC_CATEGORY_DESCRIPTION, PSL_ID_PERFIL
      INTO P_ID_CATEGORY_PP, P_DESC_CATEGORY, P_ID_PERFIL_PP
      FROM PP_SEGMENTACION_LINEAS@CCARD.WORLD     PSL,
           PP_SEGMENTACION_CATEGORIAS@CCARD.WORLD PSC
     WHERE PSL.PSL_PCE_HANDLE = V_PCE_HANDLE
       AND PSL.PSL_PROCESS_DATE =
           (SELECT MAX(PSL_PROCESS_DATE)
              FROM PP_SEGMENTACION_LINEAS@Ccard.world PSL1
             WHERE PSL1.PSL_PCE_HANDLE = V_PCE_HANDLE)
       AND PSL.PSL_ID_CATEGORY = PSC.PSC_ID_CATEGORY;
  
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      BEGIN
        P_ERROR_TEXT := 'Buscando la categoría para Sin Perfil.';
        SELECT PSC_ID_CATEGORY, PSC_CATEGORY_DESCRIPTION
          INTO P_ID_CATEGORY_PP, P_DESC_CATEGORY
          FROM PP_SEGMENTACION_CATEGORIAS@Ccard.world
         WHERE PSC_ID_CATEGORY = '0';
        --        v_ID_CATEGORY_PP:=V_ID_CATEGORY_PP;
      
        P_ID_PERFIL_PP := '0';
      
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          P_ERROR_TEXT := 'No se encontró la categoría';
          P_CODE_ERROR := SQLCODE;
          RETURN - 1;
        
      END;
  END;

  RETURN 0;
EXCEPTION
  WHEN OTHERS THEN
    P_ERROR_TEXT := 'Error: ' || P_ERROR_TEXT || '-' || SQLERRM;
    P_CODE_ERROR := SQLCODE;
    RETURN - 1;
END;
/

