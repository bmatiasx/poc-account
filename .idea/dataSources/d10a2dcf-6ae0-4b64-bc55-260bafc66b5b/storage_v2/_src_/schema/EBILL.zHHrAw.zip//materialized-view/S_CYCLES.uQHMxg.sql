create materialized view S_CYCLES
refresh force on demand
  as
    SELECT cyc_id,
       cyc_description,
       cyc_cmp_id,
       cyc_valid_flag,
       cyc_invoice_flag,
       cyc_invoice_generation_flag,
       cyc_end_date,
       cyc_system_code,
       cyc_inv_gen_generation_flag,
       cyc_cyc_id,
       cyc_region
  FROM cycles@PROD
/

