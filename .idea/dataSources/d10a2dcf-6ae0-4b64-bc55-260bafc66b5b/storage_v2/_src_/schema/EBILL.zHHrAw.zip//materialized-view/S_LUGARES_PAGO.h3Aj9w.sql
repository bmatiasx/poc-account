create materialized view S_LUGARES_PAGO
refresh complete on demand
  as
    SELECT provincia,
               localidad,
               tipo,
              direccion
FROM stl.lugares_pago@PROD
/

