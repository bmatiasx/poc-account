create Package BODY Web_Asesor_App_Ebill IS
FUNCTION insert_aaf(  	  	   p_clientId IN NUMBER,
		                       p_cuentaId IN VARCHAR2,
		                       p_frecuencia IN NUMBER)
  RETURN NUMBER IS
	BEGIN
	RETURN stl.Web_Asesor_App.insert_aaf@prod(p_clientId => p_clientId,
		                       p_cuentaId => p_cuentaId,
		                       p_frecuencia => p_frecuencia);
	EXCEPTION
	        WHEN OTHERS THEN
	            RETURN SQLCODE;
END;
FUNCTION update_aaf(	   	   p_id IN NUMBER,
		                       p_frecuencia IN NUMBER)
  RETURN NUMBER IS
	BEGIN
	RETURN stl.Web_Asesor_App.update_aaf@prod(  p_id => p_id, p_frecuencia => p_frecuencia); --algun error retorno el sqlcode
	EXCEPTION
	        WHEN OTHERS THEN
	            RETURN SQLCODE;
END;
FUNCTION update_mail(	   	   p_cuentaId IN  VARCHAR2,
		                       p_mail IN VARCHAR2)
   RETURN NUMBER IS
	BEGIN
	RETURN stl.Web_Asesor_App.update_mail@prod(	p_cuentaId => p_cuentaId,
		                       				p_mail => p_mail);
	EXCEPTION
	        WHEN OTHERS THEN
	            RETURN SQLCODE;
END;
FUNCTION upd(		   		   p_id IN NUMBER,
		                       p_frecuencia IN NUMBER,
							   p_cuentaId IN  VARCHAR2,
		                       p_mail IN VARCHAR2)
	  RETURN NUMBER
	IS
		v_ret_upd_aaf	NUMBER;
		v_ret_upd_mail	NUMBER;
	BEGIN
	RETURN stl.Web_Asesor_App.upd@prod( p_id => p_id,
		                       p_frecuencia => p_frecuencia,
							   p_cuentaId  => p_cuentaId,
		                       p_mail  => p_mail);
	--algun error retorno el
	EXCEPTION
	        WHEN OTHERS THEN
	             RETURN  -1;
END;
FUNCTION ins(	 		 	   p_clientId IN NUMBER,
		                       p_cuentaId IN VARCHAR2,
		                       p_frecuencia IN NUMBER,
		                       p_mail IN VARCHAR2)
	  RETURN NUMBER
  	IS
	BEGIN
	RETURN stl.Web_Asesor_App.ins@prod( p_clientId => p_clientId,
		                            p_cuentaId => p_cuentaId,
		                       		p_frecuencia => p_frecuencia,
		                       		p_mail => p_mail);
	--algun error retorno el
	EXCEPTION
	        WHEN OTHERS THEN
	             RETURN  -1;
END;
FUNCTION getAccountByIdCuenta(
		p_CuentaId IN  VARCHAR2,
		p_Id OUT NUMBER,
		p_ClientId OUT NUMBER,
		p_FrequencyId OUT NUMBER,
		p_mail OUT VARCHAR2)
	RETURN NUMBER IS
	BEGIN
	RETURN stl.Web_Asesor_App.getAccountByIdCuenta@prod(
		p_CuentaId => p_CuentaId,
		p_Id => p_Id,
		p_ClientId => p_ClientId,
		p_FrequencyId => p_FrequencyId,
		p_mail => p_mail);
	--algun error retorno el sqlcode
	EXCEPTION
	        WHEN OTHERS THEN
	            RETURN SQLCODE;
END;
FUNCTION insert_o_update(
		 p_CuentaId IN VARCHAR2,
         p_Id OUT NUMBER)
	RETURN NUMBER IS
	BEGIN
	RETURN stl.Web_Asesor_App.insert_o_update@prod(
		 p_CuentaId => p_CuentaId,
         p_Id => p_Id);
	EXCEPTION
	        WHEN OTHERS THEN
	            RETURN SQLCODE;
END;
END;
/

