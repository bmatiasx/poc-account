create materialized view S_CELLULAR_SPECIAL_NUMBERS
refresh complete on demand
  as
    SELECT csn_prm_id,
       csn_start_cellular_number,
       csn_start_dialed_number,
       csn_start_date,
       csn_end_date,
       csn_description,
       csn_last_updated_date,
       csn_tck_id,
       csn_start_dialed_number_new,
       csn_usr_id,
       csn_best_friend,
       csn_prm_type,
       csn_presuspe,
       csn_pais,
       csn_prefijo,
       csn_end_date_ff,
       csn_flag_fixed
  FROM STL.cellular_special_numbers@PROD A
 WHERE NVL (csn_end_date, TO_DATE ('10-FEB-2013', 'dd-mON-yyyy')) >
          TO_DATE ('09-FEB-2013', 'dd-mON-yyyy')
/

