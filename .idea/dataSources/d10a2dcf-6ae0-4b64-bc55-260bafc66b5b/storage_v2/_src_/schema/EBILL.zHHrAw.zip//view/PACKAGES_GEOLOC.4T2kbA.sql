create view PACKAGES_GEOLOC as
  select  pag_pkt_id,
  	pag_start_date,
  	pag_end_date
from packages_geoloc@prod
/

