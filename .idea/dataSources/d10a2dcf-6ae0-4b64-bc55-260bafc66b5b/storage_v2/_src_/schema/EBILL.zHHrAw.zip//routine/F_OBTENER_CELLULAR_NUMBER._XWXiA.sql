create FUNCTION F_OBTENER_CELLULAR_NUMBER

 (P_BILL_NUMBER IN VARCHAR2
 ,P_CELLULAR_NUMBER OUT VARCHAR2
 )
 RETURN NUMBER
 IS
v_result number;
BEGIN
  BEGIN
    SELECT clu_cellular_number
      INTO p_cellular_number
      FROM s_cellulars
     WHERE clu_bill_number = p_bill_number;
    return 0;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN 1;
    WHEN OTHERS THEN
      return - 1;
  end;
end;
/

