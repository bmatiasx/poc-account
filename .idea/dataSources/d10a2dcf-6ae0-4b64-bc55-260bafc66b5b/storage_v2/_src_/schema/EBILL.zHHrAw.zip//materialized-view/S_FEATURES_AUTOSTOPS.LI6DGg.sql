create materialized view S_FEATURES_AUTOSTOPS
refresh force on demand
  as
    SELECT fea_aut_id,fea_ftr_id, fea_start_date,fea_end_date
from STL.features_autostops@PROD

/

