create materialized view S_CHARGE_PLANS
refresh complete on demand
  as
    SELECT CHP_RPL_ID,
       CHP_CHR_ID,
       CHP_FRT_ID,
       CHP_AMOUNT,
       CHP_DAYS,
       CHP_START_DATE,
       CHP_USAGES,
       CHP_END_DATE,
       CHP_USER,
       CHP_ADD_DATE
  FROM STL.CHARGE_PLANS@PROD
/

