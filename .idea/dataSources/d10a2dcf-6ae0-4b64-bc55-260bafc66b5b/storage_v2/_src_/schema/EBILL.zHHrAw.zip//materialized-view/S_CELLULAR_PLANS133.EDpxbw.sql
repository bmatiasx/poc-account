create materialized view S_CELLULAR_PLANS133
refresh fast on demand
  as
    SELECT cpl_clu_cellular_number,
       cpl_stg_id,
       cpl_rpl_id,
       cpl_start_date,
       cpl_end_date,
       cpl_due_date,
       cpl_tck_id,
       cpl_usr_id,
       cpl_last_updated_date,
       cpl_add_date,
       cpl_ent_id,
       cpl_cfe_sds_id,
       cpl_rpl_online
  FROM stl.cellular_plans@PROD A
 WHERE NVL (cpl_end_date, TO_DATE ('01022015', 'ddmmyyyy')) >
          TO_DATE ('31012015', 'ddmmyyyy')
/

