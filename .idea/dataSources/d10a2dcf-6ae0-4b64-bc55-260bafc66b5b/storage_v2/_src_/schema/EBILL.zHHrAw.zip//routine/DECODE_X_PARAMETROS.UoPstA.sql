create FUNCTION DECODE_X_PARAMETROS
 (CLAVEADECODIFICAR VARCHAR2
 ,CLAVEPARAMETROS VARCHAR2)
 RETURN VARCHAR2
 IS
  v_cadena s_stl_parameters.stl_char_value%TYPE;
  v_posin NUMBER;
begin
  SELECT instr(stl_char_value,'#'||ClaveADecodificar||'#'), stl_char_value
    INTO v_posin, v_cadena --de paso me traigo la cadena para no ir de nuevo a la stl_parameters
    FROM s_stl_parameters
   WHERE stl_id= ClaveParametros;

  IF v_posin > 0 THEN --valido si hay ocurrencia, si no, segun el decode, ira null
    v_cadena:= substr(v_cadena,instr(v_cadena,'#'||ClaveADecodificar||'#')+length('#'||ClaveADecodificar||'#'), length(v_cadena));
    v_cadena:= substr(v_cadena,1,instr(v_cadena,'#')-1);
    dbms_output.put_line('cadena: '||v_cadena);
  ELSE
    return null;
  END IF;
  --Result := v_cadena;
  return(v_cadena);
end;
/

