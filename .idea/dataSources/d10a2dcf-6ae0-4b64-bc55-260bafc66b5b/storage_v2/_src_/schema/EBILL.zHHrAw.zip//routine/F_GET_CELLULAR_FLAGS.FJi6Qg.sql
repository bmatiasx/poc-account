create FUNCTION F_GET_CELLULAR_FLAGS
 (P_CELLULAR IN VARCHAR2
 ,P_CR_ID IN VARCHAR2
 ,P_ID OUT VARCHAR2
 ,P_VALUE OUT VARCHAR2
 ,P_DESCRIPTION OUT VARCHAR2
 ,P_ERROR_TXT OUT VARCHAR2
 )
 RETURN NUMBER
 IS
  V_RESULT      NUMBER;
  V_ID          VARCHAR2(500) := '';
  V_DESCRIPTION VARCHAR2(500) := '';
  V_VALUE       VARCHAR2(500) := '';
  V_FID         NUMBER;

  V_REG_FLAG PA_CALL_RESTRICTIONS.V_REC_FLAG_REST;
BEGIN
  V_RESULT := PA_CALL_RESTRICTIONS.CELLULAR_FLAGS(P_CELLULAR,
                                                  P_CR_ID,
                                                  V_REG_FLAG,
                                                  P_ERROR_TXT,
                                                  SYSDATE);


  V_FID := 1;

  LOOP
    FOR i IN 0 .. 4 LOOP
      IF V_REG_FLAG(i).RFR_CR_ID = V_FID THEN
        V_ID          := V_ID || V_REG_FLAG(i).RFR_CR_ID || '##';
        V_DESCRIPTION := V_DESCRIPTION || V_REG_FLAG(i).RFR_FCR_DEFINITION || '##';
        V_VALUE       := V_VALUE || V_REG_FLAG(i).RFR_FLD_VALUE || '##';
        V_FID := V_FID + 1;
      END IF;
      EXIT WHEN V_FID > 3;
    END LOOP;
    EXIT WHEN V_FID > 3;
  END LOOP;


  P_ID          := V_ID;
  P_VALUE       := V_VALUE;
  P_DESCRIPTION := V_DESCRIPTION;

  RETURN V_RESULT;

EXCEPTION
  WHEN OTHERS THEN
    P_ERROR_TXT := SQLERRM;
    RETURN - 1;
END;
/

