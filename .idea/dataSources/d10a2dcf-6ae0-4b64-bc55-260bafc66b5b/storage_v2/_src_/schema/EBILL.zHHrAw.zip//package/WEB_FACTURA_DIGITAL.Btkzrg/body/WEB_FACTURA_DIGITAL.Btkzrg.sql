create PACKAGE BODY WEB_FACTURA_DIGITAL IS
--NOTA
--Para poner productiva en la base ebill de Galio descomentar: --@prod
  FUNCTION GetInfoAccount( PAcc_Id       IN  VARCHAR2,
                           PAcc_Clt_Id   OUT VARCHAR2,
                           PAcc_Cmp_Id   OUT VARCHAR2,
                           PAcc_Password OUT VARCHAR2 ) RETURN NUMBER IS
  BEGIN
      SELECT Acc_Clt_Id, Acc_Cmp_Id, Acc_Password
      INTO PAcc_Clt_Id, PAcc_Cmp_Id, PAcc_Password
      FROM Accounts
      Where Acc_Id = PAcc_Id;
      RETURN 0;
  EXCEPTION
      WHEN NO_DATA_FOUND THEN
          RETURN 2;
      WHEN OTHERS THEN
          RETURN SQLCODE;
  END;
  FUNCTION ValidaCluPassword ( bill_number     IN VARCHAR2,
                               password        IN VARCHAR2,
                               account_id      OUT VARCHAR2 ) RETURN NUMBER IS
  BEGIN
      SELECT acc_id
      INTO account_id
      FROM CELLULARS, --@prod,
           ACCOUNTS --@prod
      WHERE clu_acc_id = acc_id AND
            clu_bill_number = bill_number AND
            clu_password = LTRIM(RTRIM( password ));
      RETURN 0;
  EXCEPTION
      WHEN NO_DATA_FOUND THEN
          RETURN 2;
      WHEN OTHERS THEN
          RETURN SQLCODE;
  END;
  Function GetAvailablePeriods( account      IN VARCHAR2,
                                periods_list OUT VARCHAR2,
                                periods_id   OUT VARCHAR2 ) RETURN NUMBER IS
  add_date date;
  cycle Accounts.Acc_Cyc_Id%Type;
  idate date;
  edate date;
  periods number := 3;
  last_period number := 0;
  BEGIN
      SELECT Acc_Add_Date, Acc_Cyc_Id
      INTO add_date, cycle
      FROM ACCOUNTS --@prod --Para poner productiva en la base ebill de Galio descomentar: --@prod
      WHERE Acc_Id = account;
      cycle := Substr(cycle, Length(cycle)-1, 2);
      --Si se supero en el mes el cierre del ciclo, incluir este mes
      If to_char( sysdate, 'dd' ) > cycle Then
         periods := periods - 1;
         last_period := last_period - 1;
      End If;
      Loop
          idate := add_months( sysdate, -periods-1 );
          idate := to_date( cycle || '-' || to_char( idate, 'mm-yyyy' ), 'dd-mm-yyyy' ) + 1;
          edate := add_months( sysdate, -periods );
          edate := to_date( cycle || '-' || to_char( edate, 'mm-yyyy' ), 'dd-mm-yyyy' );
          If add_date <= edate Then
             periods_list := periods_list || to_char(idate,'dd-mm-yyyy') || ' - ' || to_char(edate,'dd-mm-yyyy') || '#';
             periods_id := periods_id || to_char(edate,'yyyymm') || '#';
          End If;
          periods := periods - 1;
          Exit When periods = last_period;
      End Loop;
      RETURN 0;
  EXCEPTION
      WHEN NO_DATA_FOUND THEN
          RETURN 2;
      WHEN OTHERS THEN
          RETURN SQLCODE;
  END;
  --Verifica que la sesión exista y este dentro del límite de tiempo especificado por WEB_SESSION_TIME
  FUNCTION ValidateSession ( account      IN VARCHAR2,
                             session_id   IN VARCHAR2,
                             session_time IN NUMBER ) RETURN NUMBER IS
  conn_date Date;
  diff      Number;
  BEGIN
      SELECT Was_Connection_Date
      INTO conn_date
      FROM Web_Active_Sessions
      WHERE Was_Acc_Id = account  AND Was_Session_Id = session_id;
      diff := SecondsBetween( conn_date, sysdate );
      IF( diff <= session_time ) THEN
         RETURN 0;   -- Sesión válida
      END IF;
      RETURN 3;      -- Sesión no válida. Tiempo expirado
  EXCEPTION
      WHEN NO_DATA_FOUND THEN
          RETURN 2;  -- Sesión no válida. Sin datos
      WHEN OTHERS THEN
          RETURN SQLCODE;
  END;
  FUNCTION InsertSession ( account    IN VARCHAR2,
                           session_id IN VARCHAR2 ) RETURN NUMBER IS
  BEGIN
      INSERT INTO Web_Active_Sessions (Was_Acc_Id, Was_Session_Id, Was_Connection_Date)
      VALUES ( account, session_id, sysdate );
      COMMIT;
      RETURN 0;
    EXCEPTION
      WHEN OTHERS THEN
           ROLLBACK;
           RETURN SQLCODE;
  END;
  --Elimina todas las sessiones que esten expiradas segun el valor de WEB_SESSION_TIME
  FUNCTION RefreshSessions( session_time IN NUMBER ) RETURN NUMBER IS
  BEGIN
      DELETE FROM Web_Active_Sessions
      WHERE SecondsBetween( Was_Connection_Date, Sysdate ) > session_time;
      COMMIT;
      RETURN 0;
    EXCEPTION
      WHEN OTHERS THEN
           ROLLBACK;
           RETURN SQLCODE;
  END;
  FUNCTION UpdateSessionTime( account    IN VARCHAR2,
                              session_id IN VARCHAR2 ) RETURN NUMBER IS
  BEGIN
      UPDATE Web_Active_Sessions
      SET Was_Connection_Date = Sysdate
      WHERE Was_Acc_Id = account  AND Was_Session_Id = session_id;
      COMMIT;
      RETURN 0;
    EXCEPTION
      WHEN OTHERS THEN
           ROLLBACK;
           RETURN SQLCODE;
  END;
  FUNCTION SecondsBetween ( date_1 IN DATE,
                            date_2 IN DATE) RETURN NUMBER IS
  days_1 NUMBER;
  days_2 NUMBER;
  nsecond_1 NUMBER(5,0);
  nsecond_2 NUMBER(5,0);
  BEGIN
    days_1 := TO_NUMBER(TO_CHAR(date_1, 'J'));
    days_2 := TO_NUMBER(TO_CHAR(date_2, 'J'));
    nsecond_1 := TO_NUMBER(TO_CHAR(date_1, 'SSSSS'));
    nsecond_2 := TO_NUMBER(TO_CHAR(date_2, 'SSSSS'));
    RETURN (((days_2 - days_1) * 86400) + (nsecond_2 - nsecond_1));
  END;
END WEB_FACTURA_DIGITAL;
/

