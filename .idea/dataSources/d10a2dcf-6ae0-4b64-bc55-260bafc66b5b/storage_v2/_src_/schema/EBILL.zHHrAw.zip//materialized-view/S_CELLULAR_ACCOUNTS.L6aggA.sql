create materialized view S_CELLULAR_ACCOUNTS
refresh force on demand
  as
    SELECT "CAC_ID",
       "CAC_CLU_CELLULAR_NUMBER",
       "CAC_ACC_ID",
       "CAC_START_DATE",
       "CAC_END_DATE",
       "CAC_TCK_ID",
       "CAC_USR_ID",
       "CAC_LAST_UPDATED_DATE",
       "CAC_ADD_DATE"
  FROM "CELLULAR_ACCOUNTS"@PROD.WORLD "CELLULAR_ACCOUNTS"
/

