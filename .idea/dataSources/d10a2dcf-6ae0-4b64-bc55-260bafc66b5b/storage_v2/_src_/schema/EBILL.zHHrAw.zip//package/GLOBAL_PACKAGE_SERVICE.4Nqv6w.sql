create Package GLOBAL_PACKAGE_SERVICE
  IS

function valida_con_bill_number
    ( p_bill_number in varchar2,
      p_service in varchar2)
    return number;


function valida_con_cellular_number
    ( p_cellular_number in varchar2,
      p_service in varchar2)
    return number;

END; -- Package spec
/

