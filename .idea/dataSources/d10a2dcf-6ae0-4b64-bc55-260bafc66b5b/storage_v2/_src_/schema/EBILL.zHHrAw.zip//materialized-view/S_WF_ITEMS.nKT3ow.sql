create materialized view S_WF_ITEMS
refresh force on demand
  as
    SELECT ITEM_TYPE,
                ITEM_KEY,
                ROOT_ACTIVITY,
                ROOT_ACTIVITY_VERSION,
                USER_KEY,
                OWNER_ROLE,
                PARENT_ITEM_TYPE,
                PARENT_ITEM_KEY,
                PARENT_CONTEXT,
                BEGIN_DATE,
                END_DATE,
                HA_MIGRATION_FLAG,
                SECURITY_GROUP_ID
FROM OWF_MGR.WF_ITEMS@PROD
  WHERE begin_date >= add_months(sysdate,-2)

/

