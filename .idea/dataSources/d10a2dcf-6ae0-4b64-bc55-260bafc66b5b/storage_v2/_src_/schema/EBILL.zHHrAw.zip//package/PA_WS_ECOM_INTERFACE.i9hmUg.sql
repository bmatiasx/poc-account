create package PA_WS_ECOM_INTERFACE is

  -- Author  : DVILLALON
  -- Created : 24/08/2016 11:22:01 a.m.
  -- Purpose : contiene la lógica necesaria para registrar los datos de un pedido.
  
 -- Registrar los datos del cliente
  function F_INTERFACE_CLIENTS(P_INC_INO_ORH_ID NUMBER,
                               P_INC_TYPE_DOC   VARCHAR2,
                               P_INC_NRO_DOC    NUMBER,
                               P_INC_LAST_NAME  VARCHAR2,
                               P_INC_FIRST_NAME VARCHAR2,
                               P_INC_BIRTH_DATE DATE,
                               P_INC_TELEPHONE  VARCHAR2,
                               P_INC_TYPE       VARCHAR2) return number;

-- Registrar los domicilios FAC y ENT                            
  function F_INTERFACE_ADDRESS(P_INA_INO_ORH_ID  NUMBER,
                               P_INA_STREET      VARCHAR2,
                               P_INA_NUMBER      VARCHAR2,
                               P_INA_FLOOR       VARCHAR2,
                               P_INA_FLAT        VARCHAR2,
                               P_INA_APARTMENT   VARCHAR2,
                               P_INA_DISTRICT    VARCHAR2,
                               P_INA_CITY        VARCHAR2,
                               P_INA_OBSERVATION VARCHAR2,
                               P_INA_CPA         VARCHAR2,
                               P_INA_ZIP_CODE    VARCHAR2,
                               P_INA_PROVINCE    VARCHAR2,
                               P_INA_TYPE        VARCHAR2) return number;

-- Registrar el IMEI y la SIM                             
  function F_INTERFACE_EQUIPEMENTS(P_INE_ID          NUMBER,
                                   P_INE_INO_ORH_ID  NUMBER,
                                   P_INE_PRODUCT_ID  VARCHAR2,
                                   P_INE_RPL_ID      VARCHAR2,
                                   P_INE_PRICE_LEVEL VARCHAR2,
                                   P_INE_EST_ID      VARCHAR2,
                                   P_INE_ZIP_CODE    VARCHAR2,
                                   P_INE_TYPE        VARCHAR2) return number;
                                   
                                   -- Registrar la tarjeta de crédito  
  function F_INTERFACE_CREDIT_CARD(P_INCC_INO_ORH_ID         NUMBER,
                                   P_INCC_CREDIT_CARD_NUMBER VARCHAR2,
                                   P_INCC_ECO_ID             NUMBER)
    return number;

-- Registrar los datos principales de un pedido 
  function F_INTERFACE_ORDERS(P_INO_ORH_ID          NUMBER,
                              P_INO_CLT_ID          NUMBER,
                              P_INO_ACC_ID          VARCHAR2,
                              P_INO_TIME_ADMISSION  DATE,
                              P_INO_HOUR_WINDOW     NUMBER,
                              P_INO_USR_ID          VARCHAR2,
                              P_INO_CELLULAR_NUMBER VARCHAR2,
                              P_INO_BUSINESS_TYPE   VARCHAR2,
                              P_INO_SPC_ID          VARCHAR2,
                              P_INO_ENTITY          NUMBER,
                              P_INO_ID_ECOM         NUMBER,
                              P_INO_CREATION_DATE   DATE,
                              P_INO_TYPE            VARCHAR2) return number;

-- Registrar los cargos generados                                 
  FUNCTION F_INTERFACE_CHARGE(p_inca_ino_orh_id    NUMBER,
                              p_inca_price_sale    NUMBER,
                              p_inca_price_without NUMBER,
                              p_inca_discount      NUMBER,
                              p_inca_ine_id        NUMBER) RETURN NUMBER;
                              
                              
                                -- registrar los datos para hacer cambio de plan
  FUNCTION F_INTERFACE_CHARGE_PLANS(p_incp_ino_orh_id          NUMBER,
                                    p_incp_plan                VARCHAR2,
                                    p_incp_plan_new            VARCHAR2,
                                    p_incp_start_date_cyc      DATE,
                                    p_incp_end_date_cyc        DATE,
                                    p_incp_flag_change         VARCHAR2,
                                    p_incp_change_bonification VARCHAR2,
                                    p_incp_amount_charge       NUMBER,
                                    p_incp_stg_id              VARCHAR2,
                                    p_incp_module              VARCHAR2,
                                    p_incp_flag_ff             VARCHAR2)
    RETURN NUMBER;


  -- registrar el estado del pedido
  FUNCTION F_INTERFACE_STATUS(p_ins_ino_orh_id NUMBER,
                              p_ins_status     VARCHAR2) RETURN NUMBER;

  -- actualizar el estado del pedido
  FUNCTION F_UPDATE_INTERFACE_STATUS(p_ins_ino_orh_id NUMBER,
                                     p_ins_status     VARCHAR2) RETURN NUMBER; 
 

end PA_WS_ECOM_INTERFACE;
/

