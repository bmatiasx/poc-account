create package operaciones is
  function operar(parametro1     in varchar2,
                  parametro2     in varchar2,
                  suma           out varchar2,
                  multiplicacion out varchar2) return number;

end operaciones;
/

