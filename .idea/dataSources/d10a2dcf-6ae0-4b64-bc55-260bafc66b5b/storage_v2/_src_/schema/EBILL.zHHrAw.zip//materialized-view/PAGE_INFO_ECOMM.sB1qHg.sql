create materialized view PAGE_INFO_ECOMM
refresh force on demand
  as
    SELECT "PAGE_INFO_ECOMM"."PIE_ID"                        "PIE_ID",
"PAGE_INFO_ECOMM"."PIE_DESCRIPTION"               "PIE_DESCRIPTION",
"PAGE_INFO_ECOMM"."PIE_TEXT"                      "PIE_TEXT",
"PAGE_INFO_ECOMM"."PIE_IMAGE"                     "PIE_IMAGE",
"PAGE_INFO_ECOMM"."PIE_START_DATE"                "PIE_START_DATE",
"PAGE_INFO_ECOMM"."PIE_END_DATE"                  "PIE_END_DATE"
FROM "PAGE_INFO_ECOMM"@WMAV "PAGE_INFO_ECOMM"
/

