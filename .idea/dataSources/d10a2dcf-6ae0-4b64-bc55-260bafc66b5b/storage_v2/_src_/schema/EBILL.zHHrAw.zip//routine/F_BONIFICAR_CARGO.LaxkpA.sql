create FUNCTION f_bonificar_cargo(p_chr_id     in varchar2,
                                             p_cellular     in varchar2,
                                             p_account      in varchar2,
                                             p_costoRep     in varchar2,
                                             p_err_txt    out varchar2,
                                             p_err_number out number)

 RETURN NUMBER IS
  v_otc_amount number;
  v_errtxt     varchar2(200);
  v_retorno    number;
  v_chr_id     varchar2(20);
  v_p_pch_id   number;

BEGIN
  v_chr_id  := p_chr_id;
  v_errtxt  := 'Buscando el cargo correcto';
  v_retorno := f_get_tax_equivalent_subsidy(p_chr_id     => 'REPAR', --cargo que se bonifica
                                            p_sub_chr_id => v_chr_id, --cargo de bonificacion
                                            p_pay_id     => 1, --forma de pago
                                            p_errmsg     => p_err_txt);
  IF nvl(v_retorno, 0) <> 0 THEN
    p_err_txt := p_err_txt || ' - ' || v_errtxt || ' - ' || sqlerrm;
    p_err_number:='-1000';
    return - 1;
  END IF;

  v_errtxt := 'Buscando el monto del cargo';
  select otc_amount
    into v_otc_amount
    from other_charges h
   where h.otc_chr_id = v_chr_id;

  if p_costoRep >= (v_otc_amount * -1) then
    null;
  else
    v_otc_amount := (p_costoRep * -1);
  end if;

  v_retorno := generar_cargos_fact(p_ctd_cuotas      => 1,
                                   p_base_iva_1      => (v_otc_amount),
                                   p_base_iva        => (v_otc_amount),
                                   p_monto_cta       => (v_otc_amount),
                                   p_fecha_cargo     => sysdate,
                                   p_acc_id          => p_account,
                                   p_ciclo           => NULL,
                                   p_cellular_number => p_cellular,
                                   p_pay_id          => 1,
                                   p_chr_id          => v_chr_id, -- cargo de bonif correcto de bonif.
                                   p_tck_id          => NULL,
                                   p_dlr_id          => NULL,
                                   p_bill_due_date   => NULL,
                                   p_pch_id          => v_p_pch_id, 
                                   p_pch_pch_id      => NULL
                                   );

  if v_retorno = 1 then
    update cellular_mileages
       set cem_rep_nse = 'PO'
     where cem_clu_cellular_number = p_cellular
       and cem_movement_type = 'D'
       and cem_rep_nse = 'PE';
    p_err_txt := null;
  else
    p_err_number:='-1001';
    p_err_txt := v_retorno;
    return - 1;
  end if;
  return 0;
exception
  when OTHERS then
    p_err_number:='-1002';
    p_err_txt := v_errtxt || ' - ' || sqlerrm;
    return - 1;

end;
/

