create materialized view S_CHARGE_STATUS
refresh force on demand
  as
    SELECT CHS_ID,
       CHS_DESCRIPTION,
       CHS_USE_IN,
       CHS_PENDING_FLAG,
       CHS_STG_ID,
       CHS_SEQUENCE
  FROM STL.CHARGE_STATUS@PROD
/

