create package body PA_USSD_MAIN_MENU is
  /*
  Author Bertorello Pablo Gabriel
  Version 1.0
  Last Modification: 29/12/2015
  Adaptacion de PA_LINE_PROFILE para menu principal dinamico de USSD
  */
FUNCTION Get_Basic_Profile(  MSISDN             in  varchar2,
                             po_businessType    out varchar2,
                             po_codigo_error    out varchar2,
                             po_mensaje_error   out varchar2,
                             po_mensaje_salida  out varchar2) return NUMBER is
 v_result number;
 v_nim varchar2(15);
 v_cellularNumber varchar2(15);
 v_errCode varchar2(100);
 v_errText varchar2(100);
 v_sqlCode varchar2(100);
 v_reponse varchar2(600);

 
BEGIN
    po_codigo_error   := 0;
    po_mensaje_error  := 'OK';
    po_mensaje_salida := 'OK';
    
    v_nim:= Pa_Ussd_Common.GET_CELLULAR_NUMBER(BILL_NUMBER => Pa_Ussd_Common.GET_BILL_NUMBER(MSISDN => MSISDN));
 
    SELECT 
           CLU_CBT_ID
      INTO po_businessType
           
      FROM S_CELLULARS
     
     WHERE CLU_CELLULAR_NUMBER = v_nim;
       

    RETURN 0;
    
EXCEPTION
    WHEN no_data_found THEN
      po_codigo_error   := SQLCODE;
      po_mensaje_error  := SUBSTR(SQLERRM, 1, 100);
      po_mensaje_salida := 'NOTFOUND';
      RETURN 1;
      
      WHEN OTHERS THEN
      po_codigo_error   := SQLCODE;
      po_mensaje_error  := SUBSTR(SQLERRM, 1, 100);
      po_mensaje_salida := 'Se produjo un error al intentar obtener datos basicos de cliente';
      raise_application_error (-20025,'FALLO PA_USSD_MAIN_MENU.Get_Basic_Profile: '||SQLCODE || ' ' || SQLERRM);
      RETURN - 1;
  END Get_Basic_Profile;

END PA_USSD_MAIN_MENU;

/

