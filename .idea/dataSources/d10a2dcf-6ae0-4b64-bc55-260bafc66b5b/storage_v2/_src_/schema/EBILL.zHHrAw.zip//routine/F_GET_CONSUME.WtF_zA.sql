create FUNCTION F_GET_CONSUME

 (P_ACC_ID IN VARCHAR2
 ,P_CBT_ID IN VARCHAR2
 ,P_CELLULAR_NUMBER IN VARCHAR2
 ,P_PLAN_CYCLE OUT VARCHAR2
 ,P_PLAN_BEGIN_DATE OUT DATE
 ,P_PLAN_END_DATE OUT DATE
 ,P_USED_AMOUNT OUT NUMBER
 ,P_FREE_AMOUNT OUT NUMBER
 ,P_ERR_TXT OUT VARCHAR2
 ,P_ERR_NUMBER OUT NUMBER
 )
 RETURN NUMBER
 IS
  v_result varchar2(5);
begin

  v_result := f_get_cycle_dates@PROD.WORLD(p_plan_cycle,
                                p_acc_id,
                                p_plan_begin_date,
                                p_plan_end_date,
                                p_err_txt,
                                p_err_number);

  if v_result <> 0 then
    p_err_number := -1011;
    p_err_txt    := 'Error en f_get_cycle_dates: ' || p_err_txt;
    return - 1;
  end if;

  if (p_cbt_id like 'CR') then
    v_result := f_get_used_amount_CR(p_cellular_number,
                                     p_used_amount, --monto utilizado
                                     p_free_amount, --saldo total que posee en el ciclo
                                     p_err_txt,
                                     p_err_number);

    if v_result <> 0 then
      p_err_number := -1012;
      p_err_txt    := 'Error en f_get_used_amount_CR: ' || p_err_txt;
      return - 1;
    end if;

  elsif (p_cbt_id like 'CO') then
    v_result := f_get_used_amount_CO(p_cellular_number,
                                     p_free_amount, --abono
                                     p_used_amount, --consumo
                                     p_err_number,
                                     p_err_txt);
    if v_result <> 0 then
      p_err_number := -1013;
      p_err_txt    := 'Error en f_get_used_amount_CO: ' || p_err_txt;
      return - 1;
    end if;

  end if;

  p_err_number := -0000;
  p_err_txt    := 'OK';
  return 0;

exception
  when no_data_found then
    p_err_number := -1000;
    p_err_txt    := 'No se encontraron datos. Error: ' || SQLERRM;
    return 1;
  when others then
    p_err_number := SQLCODE;
    p_err_txt    := SQLERRM;
    return - 1;

end;
/

