create FUNCTION F_CONSULTA_GRAL_PUNTOS

 (P_NIM IN OUT VARCHAR2
 ,P_BILL_NUMBER IN OUT VARCHAR2
 ,P_ACC_ID OUT VARCHAR2
 ,P_CLT_ID OUT NUMBER
 ,P_CLT_SURNAME OUT VARCHAR2
 ,P_CLT_NAME OUT VARCHAR2
 ,P_BALANCE OUT VARCHAR2
 ,P_OBTENIDOS OUT NUMBER
 ,P_CANJEADOS OUT NUMBER
 ,P_AVENCER OUT NUMBER
 ,P_CADENA OUT CLOB
 ,P_FECHA_PROX_VTO OUT DATE
 ,P_ERR_TXT OUT VARCHAR2
 ,CODIGO_ERROR OUT NUMBER
 )
 RETURN NUMBER
 IS
P_CEM_RECORD PKG_MILLAJE.REC_CELL_MIL@prod.world;
V_IDX NUMBER;
V_CADENA_TEMP VARCHAR2(32767);
V_CADENA_CHAR VARCHAR2(32767);
V_FLAG NUMBER;
BEGIN
  P_CADENA := '';
  V_CADENA_CHAR := '';
  V_CADENA_TEMP := '';
  V_IDX := 0;
  V_FLAG := 1;
  
	PA_WEB_MILLAJE.CONSULTA_GRAL_PUNTOS@prod.world (
		p_nim	=>	p_nim,
		p_bill_number	=>	p_bill_number,
		p_acc_id	=>	p_acc_id,
		p_clt_id	=>	p_clt_id,
		p_clt_surname	=>	p_clt_surname,
		p_clt_name	=>	p_clt_name,
		p_balance	=>	p_balance,
		p_obtenidos	=>	p_obtenidos,
		p_canjeados	=>	p_canjeados,
		p_avencer	=>	p_avencer,
		p_cadena	=>	P_CEM_RECORD,
		p_fecha_prox_vto	=>	p_fecha_prox_vto,
		p_err_txt	=>	p_err_txt,
		codigo_error	=>	codigo_error
	);
  
  IF codigo_error NOT IN (0,1) THEN
    RETURN -1;
  ELSE
    IF codigo_error = 1 THEN
       p_err_txt := 'Tu línea no registra movimientos en los últimos 6 meses';
    END IF;
    RETURN codigo_error;
  END IF;
    P_ERR_TXT:='antes de leer';
  V_IDX := P_CEM_RECORD.FIRST;
  P_ERR_TXT := 'Verificamos si el cursor vino vacio o no.';
  IF NVL(V_IDX,-1) <> -1 THEN
  P_ERR_TXT := 'Antes de comenzar a recorrer el cursor.';
  FOR I IN P_CEM_RECORD.FIRST..P_CEM_RECORD.LAST LOOP
    P_ERR_TXT := 'Dentro del Loop - Asignando a P_CADENA los valores del cursor';
    
    V_CADENA_TEMP := P_CEM_RECORD(V_IDX).CEM_MIP_ID || '##'
                               || P_CEM_RECORD(V_IDX).CEM_MEC_MAP_ID || '##'
                               || TO_CHAR(P_CEM_RECORD(V_IDX).CEM_MOVEMENT_DATE,'DD/MM/YY') || '##'
                               || P_CEM_RECORD(V_IDX).CEM_MOVEMENT_TYPE || '##'
                               || P_CEM_RECORD(V_IDX).CEM_QUANTITY || '##'
                               || P_CEM_RECORD(V_IDX).CEM_BALANCE || '##'
                               || P_CEM_RECORD(V_IDX).CEM_COMMENTS || '##'
                               || P_CEM_RECORD(V_IDX).CEM_MIP_DESC || '##'
                               || P_CEM_RECORD(V_IDX).CEM_PIN || '||';
    IF LENGTH(V_CADENA_CHAR) + LENGTH(V_CADENA_TEMP) <= 32767 THEN
      V_CADENA_CHAR := V_CADENA_CHAR || V_CADENA_TEMP;
      IF V_IDX = P_CEM_RECORD.LAST THEN
        P_CADENA := TO_CLOB(V_CADENA_CHAR); 
      END IF;
    ELSE 
      IF V_FLAG = 1 THEN
        P_CADENA := TO_CLOB(V_CADENA_CHAR);  
      END IF;
      P_CADENA := P_CADENA || TO_CLOB(V_CADENA_TEMP);
      V_FLAG := 0;                                                        
    END IF;                       
    V_IDX := V_IDX + 1;
    END LOOP;    
	END IF;
EXCEPTION
	WHEN OTHERS THEN
        RETURN - 1;
END f_consulta_gral_puntos;
/

