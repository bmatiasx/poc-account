create PACKAGE BODY WEB_DETALLE_LLAMADAS IS


  -- evento: 49592 Factura Electrónica en Ar
  -- autor : Gallardo Fabián
  -- Proposito: Se modificó la parametrización FC en AR por una consulta
  -- Fecha modificación:  29/05/2007

  -- CD: 4782 Detalle Llamada en Ar
  -- autor : Franco, Pablo A.
  -- Proposito: Se modificó campo devuelto en select CLT_SURNAME por CLT_NAME
  -- Fecha modificación:  30/10/2007

  FUNCTION VALIDATE_CELLULAR(P_BILL_NUMBER  IN VARCHAR2,
                             P_CLT_PASSWORD IN VARCHAR2,
                             P_CLT_ID       OUT VARCHAR2,
                             P_CLT_SURNAME  OUT VARCHAR2,
                             P_ERROR_TEXT   OUT VARCHAR2) RETURN NUMBER IS

    RESULT                NUMBER;
    V_ERROR               NUMBER := 0;
    V_CLU_CELLULAR_NUMBER VARCHAR2(10);
    V_LISTA_CUENTAS       VARCHAR2(250);
    V_STATUS              VARCHAR2(2);
    V_CLT_PASSWORD        VARCHAR2(100);

  BEGIN
    BEGIN
      SELECT CLU_CELLULAR_NUMBER, CLU_STATUS
        INTO V_CLU_CELLULAR_NUMBER, V_STATUS
        FROM CELLULARS
       WHERE CLU_BILL_NUMBER = P_BILL_NUMBER;
    EXCEPTION
      WHEN OTHERS THEN
        P_ERROR_TEXT := 'La línea no existe';
        RETURN 1;
    END;

    IF V_STATUS != 'A' THEN
      P_ERROR_TEXT := 'La línea no esta activa';
      RETURN 4;
    END IF;

    IF LTRIM(RTRIM(P_CLT_PASSWORD)) = '' OR P_CLT_PASSWORD IS NULL THEN
      P_CLT_ID     := NULL;
      P_ERROR_TEXT := 'Password nulo';
      RETURN - 1;
    END IF;

    SELECT CLT_PASSWORD,
           CLT_ID,
           LTRIM(RTRIM(CLT_NAME)) || ' ' || LTRIM(RTRIM(CLT_SURNAME))
      INTO V_CLT_PASSWORD, P_CLT_ID, P_CLT_SURNAME
      FROM CLIENT, ACCOUNTS, CELLULARS
     WHERE ACC_CLT_ID = CLT_ID
       AND ACC_ID = CLU_ACC_ID
       AND CLU_CELLULAR_NUMBER = V_CLU_CELLULAR_NUMBER;

    IF LTRIM(RTRIM(V_CLT_PASSWORD)) <> LTRIM(RTRIM(P_CLT_PASSWORD)) OR
       V_CLT_PASSWORD IS NULL THEN
      P_CLT_ID     := NULL;
      P_ERROR_TEXT := 'Password incorrecto';
      RETURN 3;
    END IF;
    P_CLT_SURNAME := LTRIM(RTRIM(P_CLT_SURNAME));

    SELECT /*+ ordered */
     COUNT(*)
      INTO RESULT
      FROM CELLULARS, CELLULAR_PACKAGES, ED_PACKAGES_EDETAILS
     WHERE CLU_BILL_NUMBER = P_BILL_NUMBER
       AND CLU_CELLULAR_NUMBER = CPK_CLU_CELLULAR_NUMBER
       AND CPK_PKT_ID = EPE_PKT_ID
       AND SYSDATE BETWEEN CPK_ACTIVATION_DATE AND
           NVL(CPK_CANCELED_DATE,
               SYSDATE + 1)
       AND SYSDATE BETWEEN EPE_START_DATE AND
           NVL(EPE_END_DATE,
               SYSDATE + 1);

    IF RESULT = 0 THEN
      P_ERROR_TEXT := 'No tiene pack';
      RETURN 2;
    END IF;

    P_ERROR_TEXT := 'OK';
    RETURN 0;

  EXCEPTION
    WHEN OTHERS THEN
      RETURN(SQLCODE);
  END;

  FUNCTION GET_CLIENT_ACCOUNTS(P_CLT_ID        IN VARCHAR2,
                               P_SEPARATOR     IN VARCHAR2,
                               P_LIST_ACCOUNTS OUT VARCHAR2,
                               P_ERROR_TEXT    OUT VARCHAR2) RETURN NUMBER IS

    V_RESULT        NUMBER := 0;
    V_LIST_ACCOUNTS VARCHAR2(5000) := NULL;
    V_ERROR_TEXT    VARCHAR2(200) := NULL;
    V_ACC_ID        VARCHAR2(10);

  BEGIN
    V_RESULT := WEB_CONCEPTS_DETAILS.GET_CLIENT_ACCOUNTS(P_CLT_ID,
                                                         P_SEPARATOR,
                                                         V_LIST_ACCOUNTS,
                                                         V_ERROR_TEXT);

    IF (V_RESULT <> 0) THEN
      P_ERROR_TEXT := V_ERROR_TEXT;
      RETURN - 1;
    END IF;
    P_LIST_ACCOUNTS := V_LIST_ACCOUNTS;
    P_ERROR_TEXT    := 'OK';
    RETURN 0;
  EXCEPTION
    WHEN OTHERS THEN
      P_ERROR_TEXT := 'Error buscando cuentas: ' || SQLERRM || ' - ' ||
                      SQLCODE;
      RETURN 1;
  END;

  FUNCTION GET_AVAILABLE_PERIODS_COMBO(P_ACCOUNT        IN VARCHAR2,
                                       P_SHEDULERS_LIST OUT VARCHAR2,
                                       P_PERIODS_LIST   OUT VARCHAR2)
    RETURN NUMBER IS
    ADD_DATE    DATE;
    IDATE       DATE;
    EDATE       DATE;
    PERIODS     NUMBER := 3;
    LAST_PERIOD NUMBER := 0;
    SDATE       DATE := SYSDATE;
    CYCLE       VARCHAR2(2);
    V_CYC_ID    VARCHAR2(6);
    V_SCH_ID    NUMBER(8);
    V_DOC_ID    VARCHAR(15);
    P_SEPARATOR VARCHAR2(2);

  BEGIN

    SELECT ACC_ADD_DATE, ACC_CYC_ID
      INTO ADD_DATE, V_CYC_ID
      FROM ACCOUNTS
     WHERE ACC_ID = P_ACCOUNT;

    CYCLE       := SUBSTR(V_CYC_ID,
                          LENGTH(V_CYC_ID) - 1,
                          2);
    P_SEPARATOR := '##';

    --Si se supero en el mes el cierre del ciclo, incluir este mes
    IF TO_CHAR(SDATE,
               'dd') > CYCLE THEN
      PERIODS     := PERIODS - 1;
      LAST_PERIOD := LAST_PERIOD - 1;
    END IF;

    LOOP
      IDATE := ADD_MONTHS(SDATE,
                          -PERIODS - 1);
      IDATE := TO_DATE(CYCLE || '-' || TO_CHAR(IDATE,
                                               'mm-yyyy'),
                       'dd-mm-yyyy') + 1;

      EDATE := ADD_MONTHS(SDATE,
                          -PERIODS);
      EDATE := TO_DATE(CYCLE || '-' || TO_CHAR(EDATE,
                                               'mm-yyyy'),
                       'dd-mm-yyyy');

      IF ADD_DATE <= EDATE THEN
        SELECT SCH_ID
          INTO V_SCH_ID
          FROM SCHEDULERS
         WHERE SCH_CYC_ID = V_CYC_ID
           AND SCH_END_DATE = EDATE;

        P_PERIODS_LIST   := P_PERIODS_LIST ||
                            TO_CHAR(IDATE,
                                    'dd-mm-yyyy') || ' - ' ||
                            TO_CHAR(EDATE,
                                    'dd-mm-yyyy') || P_SEPARATOR;
        P_SHEDULERS_LIST := P_SHEDULERS_LIST || V_SCH_ID || P_SEPARATOR;
      END IF;

      PERIODS := PERIODS - 1;
      EXIT WHEN PERIODS = LAST_PERIOD;

    END LOOP;

    RETURN 0;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN 1;
    WHEN OTHERS THEN
      RETURN 2;
  END;

  -- CD: 4782 Detalle Llamada en Ar
  -- autor : Franco, Pablo A.
  -- Proposito: Se modificó para que tenga el tratamiento de Video Call Diferenciado
  -- Fecha modificación:  30/10/2007

  FUNCTION GET_CALLS(P_BILL_NUMBER  IN VARCHAR2 DEFAULT NULL,
                     P_CLT_ID       IN VARCHAR2,
                     P_SCH_ID_BEGIN IN VARCHAR2,
                     P_SCH_ID_END   IN VARCHAR2,
                     P_SEPARATOR    IN VARCHAR2,
                     P_REC_NUMBER   OUT NUMBER,
                     P_FILENAME     OUT VARCHAR2,
                     P_ERROR_TEXT   OUT VARCHAR2) RETURN NUMBER IS

    RESULT              NUMBER;
    V_ERROR             NUMBER := 0;
    V_EXISTE            NUMBER := 0;
    V_NUMBER_ROWS       NUMBER := 0;
    V_CLU_BILL_NUMBER   VARCHAR2(100);
    V_CAL_DATE          VARCHAR2(100);
    V_CAL_HORA          VARCHAR2(100);
    V_CAL_LOCATION      VARCHAR2(100);
    V_CALL_TYPE         VARCHAR2(100);
    V_CAL_DIRECTION     VARCHAR2(100);
    V_CAL_DIALED_NUMBER VARCHAR2(100);
    V_CAL_TPT_ID        VARCHAR2(100);
    V_CAL_AIR_CHARGE    VARCHAR2(100);
    V_CAL_LAND_CHARGE   VARCHAR2(100);
    V_TOTAL_CHARGE      VARCHAR2(100);
    V_CAL_DURATION      VARCHAR2(100);
    V_CAL_ACC_ID        VARCHAR2(100);
    V_CAL_FEATURE       VARCHAR2(10);

    V_FORMAT VARCHAR2(15) := '9999999900D00';

    FILE_NAME   VARCHAR2(80);
    FILE_HANDLE UTL_FILE.FILE_TYPE;

    CURSOR CALLS_ONLINE_CLT(C_CLT_ID IN VARCHAR2, C_SCH_ID_B IN VARCHAR2, C_SCH_ID_E IN VARCHAR2) IS
      SELECT FCD_CLU_BILL_NUMBER,
             FCD_CAL_DATE FECHA,
             CASE
               WHEN (BITAND(FCD_CAL_FEATURES,
                            16777216) <> 0) THEN
                'VL'
               ELSE
                ''
             END AS TIPO,
             /*tiene video call */
             TO_CHAR(FCD_CAL_DATE,
                     'HH24:MI:SS') HORA,
             FCD_CAL_LOCATION,
             FCD_CALL_TYPE,
             FCD_CAL_DIRECTION,
             FCD_CAL_DIALED_NUMBER,
             FCD_CAL_TPT_ID_AIR FCD_CAL_TPT_ID,
             FCD_CAL_AIR_CHARGE,
             FCD_CAL_LAND_CHARGE,
             (FCD_CAL_AIR_CHARGE + FCD_CAL_LAND_CHARGE) FCD_TOTAL_CHARGE,
             FCD_CAL_AIR_PERIODS,
             FCD_CAL_ACC_ID
        FROM FE_CALL_DETAIL P
       WHERE FCD_CLT_ID = P_CLT_ID
         AND FCD_CAL_SCH_ID BETWEEN P_SCH_ID_BEGIN AND P_SCH_ID_END
       ORDER BY FCD_CAL_ACC_ID, FCD_CLU_BILL_NUMBER;

    CURSOR CALLS_ONLINE_BILL(C_BILL_NUMBER IN VARCHAR2, C_CLT_ID IN VARCHAR2, C_SCH_ID_B IN VARCHAR2, C_SCH_ID_E IN VARCHAR2) IS
      SELECT FCD_CLU_BILL_NUMBER,
             FCD_CAL_DATE FECHA,
             CASE
               WHEN (BITAND(FCD_CAL_FEATURES,
                            16777216) <> 0) THEN
                'VL'
               ELSE
                ''
             END AS TIPO,
             /*tiene video call */
             TO_CHAR(FCD_CAL_DATE,
                     'HH24:MI:SS') HORA,
             FCD_CAL_LOCATION,
             FCD_CALL_TYPE,
             FCD_CAL_DIRECTION,
             FCD_CAL_DIALED_NUMBER,
             FCD_CAL_TPT_ID_AIR FCD_CAL_TPT_ID,
             FCD_CAL_AIR_CHARGE,
             FCD_CAL_LAND_CHARGE,
             (FCD_CAL_AIR_CHARGE + FCD_CAL_LAND_CHARGE) FCD_TOTAL_CHARGE,
             FCD_CAL_AIR_PERIODS,
             FCD_CAL_ACC_ID
        FROM FE_CALL_DETAIL
       WHERE FCD_CLU_BILL_NUMBER = C_BILL_NUMBER
         AND FCD_CLT_ID = P_CLT_ID
         AND FCD_CAL_SCH_ID BETWEEN P_SCH_ID_BEGIN AND P_SCH_ID_END
       ORDER BY FCD_CAL_ACC_ID, FCD_CLU_BILL_NUMBER;
BEGIN

    --Cambiar el nombre del archivo
    FILE_NAME := 'detalle_llamadas' || '_' || P_CLT_ID || '_';
    IF NOT UTL_FILE.IS_OPEN(FILE_HANDLE) THEN
      FILE_NAME   := FILE_NAME || TO_CHAR(SYSDATE,
                                          'yyyymmdd') || '.txt';
      FILE_HANDLE := UTL_FILE.FOPEN('DIR_CALL_DETAIL',
                                    FILE_NAME,
                                    'W');
    END IF;

    /*  grabo cada registro en el archivo  */

    IF P_BILL_NUMBER IS NULL THEN
      OPEN CALLS_ONLINE_CLT(P_CLT_ID,
                            P_SCH_ID_BEGIN,
                            P_SCH_ID_END);
      LOOP
        FETCH CALLS_ONLINE_CLT
          INTO V_CLU_BILL_NUMBER, V_CAL_DATE, V_CAL_FEATURE, V_CAL_HORA, V_CAL_LOCATION, V_CALL_TYPE, V_CAL_DIRECTION, V_CAL_DIALED_NUMBER, V_CAL_TPT_ID, V_CAL_AIR_CHARGE, V_CAL_LAND_CHARGE, V_TOTAL_CHARGE, V_CAL_DURATION, V_CAL_ACC_ID;
        EXIT WHEN CALLS_ONLINE_CLT%NOTFOUND;
        --               UTL_FILE.PUTF(file_handle, '%s\n', v_clu_bill_number ||p_Separator|| v_cal_date||p_Separator||v_cal_hora||p_Separator||v_cal_location||p_Separator||v_call_type||p_Separator||v_cal_direction||p_Separator||v_cal_dialed_number||p_Separator||v_cal_tpt_id||p_Separator||v_cal_air_charge||p_Separator||v_cal_land_charge||p_Separator||v_total_charge||p_Separator||v_cal_duration||p_Separator||v_cal_acc_id);
        UTL_FILE.PUTF(FILE_HANDLE,
                      '%s\n',
                      V_CLU_BILL_NUMBER || P_SEPARATOR || V_CAL_DATE ||
                      P_SEPARATOR || TRIM(TO_CHAR(V_CAL_FEATURE)) ||
                      P_SEPARATOR || V_CAL_HORA || P_SEPARATOR ||
                      V_CAL_LOCATION || P_SEPARATOR || V_CAL_DIALED_NUMBER ||
                      P_SEPARATOR || V_CAL_TPT_ID || P_SEPARATOR ||
                      V_CAL_DURATION || P_SEPARATOR ||
                      TRIM(TO_CHAR(TO_NUMBER(V_CAL_AIR_CHARGE),
                                   V_FORMAT)) || P_SEPARATOR ||
                      TRIM(TO_CHAR(TO_NUMBER(V_CAL_LAND_CHARGE),
                                   V_FORMAT)) || P_SEPARATOR || '0' ||
                      P_SEPARATOR || TRIM(TO_CHAR(TO_NUMBER(V_TOTAL_CHARGE),
                                                  V_FORMAT)));
        V_NUMBER_ROWS := V_NUMBER_ROWS + 1;
      END LOOP;
      CLOSE CALLS_ONLINE_CLT;
    ELSE
      OPEN CALLS_ONLINE_BILL(P_BILL_NUMBER,
                             P_CLT_ID,
                             P_SCH_ID_BEGIN,
                             P_SCH_ID_END);
      LOOP
        FETCH CALLS_ONLINE_BILL
          INTO V_CLU_BILL_NUMBER, V_CAL_DATE, V_CAL_FEATURE, V_CAL_HORA, V_CAL_LOCATION, V_CALL_TYPE, V_CAL_DIRECTION, V_CAL_DIALED_NUMBER, V_CAL_TPT_ID, V_CAL_AIR_CHARGE, V_CAL_LAND_CHARGE, V_TOTAL_CHARGE, V_CAL_DURATION, V_CAL_ACC_ID;
        EXIT WHEN CALLS_ONLINE_BILL%NOTFOUND;
        UTL_FILE.PUTF(FILE_HANDLE,
                      '%s\n',
                      V_CLU_BILL_NUMBER || P_SEPARATOR || V_CAL_DATE ||
                      P_SEPARATOR || TRIM(TO_CHAR(V_CAL_FEATURE)) ||
                      P_SEPARATOR || V_CAL_HORA || P_SEPARATOR ||
                      V_CAL_LOCATION || P_SEPARATOR || V_CAL_DIALED_NUMBER ||
                      P_SEPARATOR || V_CAL_TPT_ID || P_SEPARATOR ||
                      V_CAL_DURATION || P_SEPARATOR ||
                      TO_CHAR(TO_NUMBER(V_CAL_AIR_CHARGE),
                              V_FORMAT) || P_SEPARATOR ||
                      TO_CHAR(TO_NUMBER(V_CAL_LAND_CHARGE),
                              V_FORMAT) || P_SEPARATOR ||
                      TO_CHAR(TO_NUMBER(V_TOTAL_CHARGE),
                              V_FORMAT));
      END LOOP;
      CLOSE CALLS_ONLINE_BILL;
    END IF;

    UTL_FILE.FCLOSE(FILE_HANDLE);
    P_FILENAME   := FILE_NAME;
    P_REC_NUMBER := V_NUMBER_ROWS;
    RETURN 0;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      P_ERROR_TEXT := 'Error ' || P_ERROR_TEXT;
      RETURN - 1;
    WHEN OTHERS THEN
      P_ERROR_TEXT := SQLERRM || '  sqlcode=' || SQLCODE;
      RETURN - 2;
  END;

  FUNCTION GET_OUTPUT_PATH(P_OUTPUT_PATH OUT VARCHAR2,
                           P_ERROR_MSG   OUT VARCHAR2) RETURN NUMBER IS
  BEGIN

    SELECT DIRECTORY_PATH
      INTO P_OUTPUT_PATH
      FROM ALL_DIRECTORIES
     WHERE DIRECTORY_NAME = 'DIR_CALL_DETAIL';

    P_ERROR_MSG := 'OK';
    RETURN 0;

  EXCEPTION
    WHEN OTHERS THEN
      P_ERROR_MSG := 'No se encuentra DIR_CALL_DETAIL en All_Directories.';
      RETURN 1;
  END;

  -- CD: 4782 Detalle Llamada en Ar
  -- autor : Franco, Pablo A.
  -- Proposito: Se modificó para que devuelva nro doc completo.
  -- Fecha modificación:  30/10/2007

  FUNCTION GET_BILL_INFO(P_ACC_ID        IN VARCHAR2,
                         P_SCH_ID        IN VARCHAR2,
                         P_DOC_ID        OUT VARCHAR2,
                         P_DOCUMENT_DATE OUT VARCHAR2,
                         P_ERROR_MSG     OUT VARCHAR2) RETURN NUMBER IS

    V_DOC_ID        DOCUMENTS.DOC_ID%TYPE;
    V_DOCUMENT_DATE DOCUMENTS.DOC_DOCUMENT_DATE%TYPE;
    V_DCT_ID        DOCUMENTS.DOC_DCT_ID%TYPE;
    V_CMP_ID        DOCUMENTS.DOC_CMP_ID%TYPE;

    V_PRINT_TYPE  DOCUMENT_TYPES.DCT_PRINT_TYPE%TYPE;
    V_SYSTEM_CODE DOCUMENT_TYPES.DCT_SYSTEM_CODE%TYPE;
    V_POS_ID      POINT_OF_SALES.POS_ID%TYPE;

  BEGIN

    SELECT DOC_ID, DOC_DOCUMENT_DATE, DOC_DCT_ID, DOC_CMP_ID
      INTO V_DOC_ID, V_DOCUMENT_DATE, V_DCT_ID, V_CMP_ID -- nro doc,fecha, tipo doc, cia
      FROM DOCUMENTS
     WHERE DOC_ACC_ID = P_ACC_ID
       AND DOC_DCT_ID IN
           (SELECT DCT_ID FROM DOCUMENT_TYPES WHERE DCT_DCT_ID = 'FC') --FC y FCE
       AND DOC_SCH_ID = P_SCH_ID;

    -- obtengo datos de tipo de documento
    SELECT DCT_PRINT_TYPE, DCT_SYSTEM_CODE
    -- P:papel E:electronica /// S:ciclica C:eventual
      INTO V_PRINT_TYPE, V_SYSTEM_CODE
      FROM DOCUMENT_TYPES
     WHERE DCT_ID = V_DCT_ID;

    -- obtengo punto de venta
    SELECT PS.POS_ID
      INTO V_POS_ID
      FROM POINT_OF_SALES PS
     WHERE PS.POS_PRINT_TYPE = V_PRINT_TYPE -- 'P'
       AND PS.POS_CMP_ID = V_CMP_ID
       AND PS.POS_SYSTEM_CODE = V_SYSTEM_CODE;

    IF V_DOC_ID IS NULL OR V_DOCUMENT_DATE IS NULL THEN
      P_ERROR_MSG := 'No hay datos para la cuenta';
      RETURN 1;
    END IF;

    P_ERROR_MSG := 'OK';

    -- armo nro de documento punto de venta + nro documento
    P_DOC_ID        := V_POS_ID || '-' || V_DOC_ID;
    P_DOCUMENT_DATE := TO_CHAR(V_DOCUMENT_DATE,
                               'DD/MM/YYYY');

    RETURN 0;

  EXCEPTION
    WHEN OTHERS THEN
      P_ERROR_MSG := 'Error al traer los datos de la factura';
      RETURN 1;
  END;
END WEB_DETALLE_LLAMADAS;
/

