create PACKAGE BODY PA_CONSUMPTION_INFORMATION IS
  -- Author  : EXB23639
  -- Created : 07/07/2016

  -----------------------------------------------------------------------------------------------------------------
  /*     Fecha               Desarrollador                Pedido de Cambio                 */
  /*     07/07/2016          EXB23639                     WMASIVO-1639                     */
  /*     19/09/2017          EXB23639                     WMASIVO-4727                     */
  ------------------------------------------------------------------------------------------------------------------
  FUNCTION F_GET_CONSUMPTION_INFORMATION(p_nim                   IN VARCHAR2,
                                         P_KEYWORD               IN VARCHAR2,
                                         P_PACKAGE               OUT VARCHAR2,
                                         P_MAIN_QUOTA_NAME       OUT VARCHAR2,
                                         P_DAILY_QUOTA_NAME      OUT VARCHAR2,
                                         P_ADDITIONAL_QUOTA_NAME OUT VARCHAR2,
                                         P_SIZE_MAIN             OUT NUMBER,
                                         P_SIZE_DAILY            OUT NUMBER,
                                         P_SIZE_ADDITIONAL       OUT NUMBER,
                                         P_PKT_CYCLIC            OUT VARCHAR2,
                                         P_LIMIT_CYCLE           OUT NUMBER,
                                         P_LIMIT_DAY             OUT NUMBER,
                                         P_COUNT_CYCLE           OUT NUMBER,
                                         P_COUNT_DAY             OUT NUMBER,
                                         P_BUY_COST              OUT NUMBER,
                                         P_VIEW_PACK_WEB         OUT VARCHAR2,
                                         P_BUY_PACK_WEB          OUT VARCHAR2,
                                         P_BUY_REASON            OUT VARCHAR2,
                                         P_ERR_TEXT              OUT VARCHAR2,
                                         P_ERR_NUM               OUT NUMBER)

   RETURN NUMBER IS

    V_CELLULAR_NUMBER      S_CELLULARS.clu_cellular_number%TYPE;
    V_CATEGORY             S_CLIENT.Clt_Category%TYPE;
    V_TYPE                 S_CLIENT.Clt_Type%TYPE;
    V_CBT_ID               S_CELLULARS.clu_cbt_id%Type;
    V_RPL_ID               S_RATE_PLANS.rpl_id%TYPE;
    V_RPL_RTY_ID           S_RATE_PLANS.RPL_RTY_ID%TYPE;
    V_FEATURE_ID           S_FEATURES.ftr_id%TYPE;
    V_SPECIAL_SERVICE_DATA S_SS_SPECIAL_SERVICE_PROFILE.SSP_SPECIAL_SERVICE_ID%TYPE;
    V_ACTION_SERVICE_ID    S_SS_ACTION_SPECIAL_SERVICE.ASE_ACTION_SERVICE_ID%TYPE;
    V_MCC                  VARCHAR2(1000) := '000';
    V_MNC                  VARCHAR2(1000) := '00';
    V_TYPE_SERVICE_STR     VARCHAR2(1000) := 'DATOS';
    V_SMS_ID               VARCHAR2(1000) := '';
    V_ERROR_TEXT           VARCHAR2(5000) := '';
    V_TEMP                 VARCHAR2(50) := 'INTERNET';

  BEGIN
    IF P_KEYWORD IS NOT NULL THEN
      V_TEMP := P_KEYWORD;
    END IF;

    P_GET_DATA_CELLULAR(P_BILL_NUMBER            => P_NIM,
                        POUT_CELLULAR_NUMBER     => V_CELLULAR_NUMBER,
                        POUT_CELLULAR_CATEGORY   => V_CATEGORY,
                        POUT_CELLULAR_TYPE       => V_TYPE,
                        POUT_CELLULAR_CBT_ID     => V_CBT_ID,
                        POUT_CELLULAR_RPL_ID     => V_RPL_ID,
                        POUT_CELLULAR_RPL_RTY_ID => V_RPL_RTY_ID,
                        POUT_SMS_ID              => V_SMS_ID,
                        POUT_ERROR_TEXT          => V_ERROR_TEXT,
                        POUT_ERROR_CODE          => P_ERR_NUM);
    IF P_ERR_NUM <> 0 THEN
      P_ERR_TEXT := 'ERROR:' || V_ERROR_TEXT || CHR(13) || P_ERR_TEXT;
      RETURN P_ERR_NUM;
    END IF;
    IF V_CBT_ID = 'CO' THEN
      P_INTERNET_WEB_NAMES(P_CELLULAR_NUMBER          => V_CELLULAR_NUMBER,
                           POUT_FEATURE_ID            => V_FEATURE_ID,
                           POUT_PACKAGE_ID            => P_PACKAGE,
                           POUT_PACKAGE_CYCLIC        => P_PKT_CYCLIC,
                           POUT_MAIN_QUOTA_NAME       => P_MAIN_QUOTA_NAME,
                           POUT_DAILY_QUOTA_NAME      => P_DAILY_QUOTA_NAME,
                           POUT_ADDITIONAL_QUOTA_NAME => P_ADDITIONAL_QUOTA_NAME,
                           POUT_VIEW_WEB              => P_VIEW_PACK_WEB,
                           POUT_SMS_ID                => V_SMS_ID,
                           POUT_ERROR_TEXT            => V_ERROR_TEXT,
                           POUT_ERROR_CODE            => P_ERR_NUM);
      IF P_ERR_NUM <> 0 THEN
        P_ERR_TEXT := 'ERROR:' || V_ERROR_TEXT || CHR(13) || P_ERR_TEXT;
        RETURN P_ERR_NUM;
      END IF;
      P_INTERNET_WEB_SIZES(P_FEATURE_ID         => V_FEATURE_ID,
                           POUT_SIZE_MAIN       => P_SIZE_MAIN,
                           POUT_SIZE_DAILY      => P_SIZE_DAILY,
                           POUT_SIZE_ADDITIONAL => P_SIZE_ADDITIONAL,
                           POUT_ERROR_TEXT      => V_ERROR_TEXT,
                           POUT_ERROR_CODE      => P_ERR_NUM);
      IF P_ERR_NUM <> 0 THEN
        P_ERR_TEXT := 'ERROR:' || V_ERROR_TEXT || CHR(13) || P_ERR_TEXT;
        RETURN P_ERR_NUM;
      END IF;
    ELSE
      P_GET_TN3_SIZE(P_CELLULAR_NUMBER    => V_CELLULAR_NUMBER,
                     POUT_REPURCHASE_SIZE => P_SIZE_ADDITIONAL,
                     POUT_MAIN_SIZE       => P_SIZE_MAIN,
                     POUT_SMS_ID          => V_SMS_ID,
                     POUT_ERROR_TEXT      => V_ERROR_TEXT,
                     POUT_ERROR_CODE      => P_ERR_NUM);

      IF P_ERR_NUM <> 0 THEN
        P_ERR_TEXT := 'ERROR:' || V_ERROR_TEXT || CHR(13) || P_ERR_TEXT;
        RETURN P_ERR_NUM;
      END IF;
    END IF;
    /*OBTIENE LOS DATOS delete from SERVICIO ESPECIAL ASOSIADO por PACK, POR PLAN o por TIPO DE PLAN*/
    P_GET_SPECIAL_SERVICE_DATA(P_CELLULAR_NUMBER            => V_CELLULAR_NUMBER,
                               P_CELLULAR_CATEGORY          => V_CATEGORY,
                               P_CELLULAR_TYPE              => V_TYPE,
                               P_CELLULAR_CBT_ID            => V_CBT_ID,
                               P_CELLULAR_RPL_ID            => V_RPL_ID,
                               P_CELLULAR_RPL_RTY_ID        => V_RPL_RTY_ID,
                               P_MCC                        => V_MCC,
                               P_MNC                        => V_MNC,
                               P_TYPE_SERVICE_STR           => V_TYPE_SERVICE_STR,
                               P_KEYWORD                    => V_TEMP,
                               P_BUY_COST                   => P_BUY_COST,
                               P_SSP_LIMIT_AMOUNT_PER_CYCLE => P_LIMIT_CYCLE,
                               P_SSP_LIMIT_AMOUNT_PER_DAY   => P_LIMIT_DAY,
                               P_SPECIAL_SERVICE_ID         => V_SPECIAL_SERVICE_DATA,
                               POUT_ACTION_SERVICE_ID       => V_ACTION_SERVICE_ID,
                               POUT_SMS_ID                  => V_SMS_ID,
                               POUT_ERROR_TEXT              => V_ERROR_TEXT,
                               POUT_ERROR_CODE              => P_ERR_NUM);

    P_VALIDATE_LIMIT_ACTION_SS(P_CELLULAR_NUMBER    => V_CELLULAR_NUMBER,
                               P_SPECIAL_SERVICE_ID => V_SPECIAL_SERVICE_DATA,
                               P_ACTION_SERVICE_ID  => V_ACTION_SERVICE_ID,
                               P_LIMIT_AMOUNT_CYCLE => P_LIMIT_CYCLE,
                               P_LIMIT_AMOUNT_DAY   => P_LIMIT_DAY,
                               P_COUNT_LIMIT_DAY    => P_COUNT_DAY,
                               P_COUNT_LIMIT_CYCLE  => P_COUNT_CYCLE,
                               POUT_SMS_ID          => V_SMS_ID,
                               POUT_ERROR_TEXT      => P_BUY_REASON,
                               POUT_ERROR_CODE      => P_BUY_PACK_WEB);

    IF V_CATEGORY = 'M' THEN
      P_VIEW_PACK_WEB := 'Y';
    ELSE
      P_VIEW_PACK_WEB := 'N';
    END IF;

    IF P_BUY_PACK_WEB = 0 THEN
      P_BUY_PACK_WEB := 'Y';
      P_ERR_TEXT     := 'valid ok';
    ELSE
      P_BUY_PACK_WEB := 'N';
    END IF;

    RETURN 0;
  EXCEPTION
    WHEN OTHERS THEN
      P_ERR_NUM  := SQLCODE;
      P_ERR_TEXT := SQLERRM;
      RETURN - 1;
  END F_GET_CONSUMPTION_INFORMATION;

  /****************************************************************************************************************/
  /* Nueva funcion para consultar todos los datos de GPRS con recompra multiple.                                  */
  /****************************************************************************************************************/

  /****************************************************************************************************************/
  FUNCTION F_GPRS_INFORMATION_COMPLETE(P_NIM                   IN VARCHAR2,
                                       P_KEYWORD               IN VARCHAR2,
                                       P_CHANNEL               IN VARCHAR2,
                                       P_PACKAGE               OUT VARCHAR2,
                                       P_FEATURE_ID            OUT VARCHAR2,
                                       P_SPECIAL_SERVICE_DATA  OUT VARCHAR2,
                                       P_ACTION_SERVICE_ID     OUT VARCHAR2,
                                       P_MAIN_QUOTA_NAME       OUT VARCHAR2,
                                       P_DAILY_QUOTA_NAME      OUT VARCHAR2,
                                       P_ADDITIONAL_QUOTA_NAME OUT VARCHAR2,
                                       P_SIZE_MAIN             OUT NUMBER,
                                       P_SIZE_DAILY            OUT NUMBER,
                                       P_SIZE_ADDITIONAL       OUT NUMBER,
                                       P_REPURCHASED_SIZE      OUT NUMBER,
                                       P_REPURCHASED_UNIT      OUT VARCHAR2,
                                       P_PKT_CYCLIC            OUT VARCHAR2,
                                       P_COUNT_CYCLE           OUT NUMBER,
                                       P_COUNT_DAY             OUT NUMBER,
                                       P_OPTION_EXCHANGE_RATE  OUT VARCHAR2,
                                       P_BUY_COST              OUT VARCHAR2,
                                       P_OPTION_LIMIT_CYCLE    OUT VARCHAR2,
                                       P_OPTION_LIMIT_DAY      OUT VARCHAR2,
                                       P_OPTION_ROAMING_GROUPS OUT VARCHAR2,
                                       P_OPTION_CAPACITY_ID    OUT VARCHAR2,
                                       P_OPTION_VOLUME         OUT VARCHAR2,
                                       P_OPTION_VOLUME_UNITY   OUT VARCHAR2,
                                       P_OPTION_CHANNEL        OUT VARCHAR2,
                                       P_VIEW_PACK_WEB         OUT VARCHAR2,
                                       P_BUY_PACK_WEB          OUT VARCHAR2,
                                       P_BUY_REASON            OUT VARCHAR2,
                                       P_ERR_TEXT              OUT VARCHAR2,
                                       P_ERR_NUM               OUT NUMBER)

   RETURN NUMBER IS

    V_CELLULAR_NUMBER  S_CELLULARS.clu_cellular_number%TYPE;
    V_CATEGORY         S_CLIENT.Clt_Category%TYPE;
    V_TYPE             S_CLIENT.Clt_Type%TYPE;
    V_CBT_ID           S_CELLULARS.clu_cbt_id%Type;
    V_RPL_ID           S_RATE_PLANS.rpl_id%TYPE;
    V_RPL_RTY_ID       S_RATE_PLANS.RPL_RTY_ID%TYPE;
    V_MCC              VARCHAR2(1000) := '000';
    V_MNC              VARCHAR2(1000) := '00';
    V_TYPE_SERVICE_STR VARCHAR2(1000) := 'DATOS';
    V_SMS_ID           VARCHAR2(1000) := '';
    V_ERROR_TEXT       VARCHAR2(5000) := '';
    V_TEMP             VARCHAR2(50) := 'INTERNET';

  BEGIN
    IF P_KEYWORD IS NOT NULL THEN
      V_TEMP := P_KEYWORD;
    END IF;

    P_GET_DATA_CELLULAR(P_BILL_NUMBER            => P_NIM,
                        POUT_CELLULAR_NUMBER     => V_CELLULAR_NUMBER,
                        POUT_CELLULAR_CATEGORY   => V_CATEGORY,
                        POUT_CELLULAR_TYPE       => V_TYPE,
                        POUT_CELLULAR_CBT_ID     => V_CBT_ID,
                        POUT_CELLULAR_RPL_ID     => V_RPL_ID,
                        POUT_CELLULAR_RPL_RTY_ID => V_RPL_RTY_ID,
                        POUT_SMS_ID              => V_SMS_ID,
                        POUT_ERROR_TEXT          => V_ERROR_TEXT,
                        POUT_ERROR_CODE          => P_ERR_NUM);
    IF P_ERR_NUM <> 0 THEN
      P_ERR_TEXT := 'ERROR:' || V_ERROR_TEXT || CHR(13) || P_ERR_TEXT;
      RETURN P_ERR_NUM;
    END IF;
    IF V_CBT_ID = 'CO' THEN
      P_INTERNET_WEB_NAMES_MULT(P_CELLULAR_NUMBER          => V_CELLULAR_NUMBER,
                                POUT_FEATURE_ID            => P_FEATURE_ID,
                                POUT_PACKAGE_ID            => P_PACKAGE,
                                POUT_PACKAGE_CYCLIC        => P_PKT_CYCLIC,
                                POUT_MAIN_QUOTA_NAME       => P_MAIN_QUOTA_NAME,
                                POUT_DAILY_QUOTA_NAME      => P_DAILY_QUOTA_NAME,
                                POUT_ADDITIONAL_QUOTA_NAME => P_ADDITIONAL_QUOTA_NAME,
                                POUT_SMS_ID                => V_SMS_ID,
                                POUT_ERROR_TEXT            => V_ERROR_TEXT,
                                POUT_ERROR_CODE            => P_ERR_NUM);

      IF P_ERR_NUM <> 0 THEN
        P_ERR_TEXT := 'ERROR:' || V_ERROR_TEXT || CHR(13) || P_ERR_TEXT;
        RETURN P_ERR_NUM;
      END IF;
      P_INTERNET_WEB_SIZES(P_FEATURE_ID         => P_FEATURE_ID,
                           POUT_SIZE_MAIN       => P_SIZE_MAIN,
                           POUT_SIZE_DAILY      => P_SIZE_DAILY,
                           POUT_SIZE_ADDITIONAL => P_SIZE_ADDITIONAL,
                           POUT_ERROR_TEXT      => V_ERROR_TEXT,
                           POUT_ERROR_CODE      => P_ERR_NUM);
      IF P_ERR_NUM <> 0 THEN
        P_ERR_TEXT := 'ERROR:' || V_ERROR_TEXT || CHR(13) || P_ERR_TEXT;
        RETURN P_ERR_NUM;
      END IF;
    ELSE
      P_GET_TN3_SIZE(P_CELLULAR_NUMBER    => V_CELLULAR_NUMBER,
                     POUT_REPURCHASE_SIZE => P_SIZE_ADDITIONAL,
                     POUT_MAIN_SIZE       => P_SIZE_MAIN,
                     POUT_SMS_ID          => V_SMS_ID,
                     POUT_ERROR_TEXT      => V_ERROR_TEXT,
                     POUT_ERROR_CODE      => P_ERR_NUM);

      IF P_ERR_NUM <> 0 THEN
        P_ERR_TEXT := 'ERROR:' || V_ERROR_TEXT || CHR(13) || P_ERR_TEXT;
        RETURN P_ERR_NUM;
      END IF;
    END IF;
    /*OBTIENE LOS DATOS delete from SERVICIO ESPECIAL ASOSIADO por PACK, POR PLAN o por TIPO DE PLAN*/
    P_GET_SERVICE_DATA_MULT(P_CELLULAR_NUMBER            => V_CELLULAR_NUMBER,
                            P_CELLULAR_CATEGORY          => V_CATEGORY,
                            P_CELLULAR_TYPE              => V_TYPE,
                            P_CELLULAR_CBT_ID            => V_CBT_ID,
                            P_CELLULAR_RPL_ID            => V_RPL_ID,
                            P_CELLULAR_RPL_RTY_ID        => V_RPL_RTY_ID,
                            P_MCC                        => V_MCC,
                            P_MNC                        => V_MNC,
                            P_TYPE_SERVICE_STR           => V_TYPE_SERVICE_STR,
                            P_KEYWORD                    => V_TEMP,
                            P_CHANNEL                    => P_CHANNEL,
                            P_SPECIAL_SERVICE_ID         => P_SPECIAL_SERVICE_DATA,
                            P_ACTION_SERVICE_ID          => P_ACTION_SERVICE_ID,
                            P_SSP_EXCHANGE_RATE          => P_OPTION_EXCHANGE_RATE,
                            P_BUY_COST                   => P_BUY_COST,
                            P_SSP_LIMIT_AMOUNT_PER_CYCLE => P_OPTION_LIMIT_CYCLE,
                            P_SSP_LIMIT_AMOUNT_PER_DAY   => P_OPTION_LIMIT_DAY,
                            P_SSP_APPLIES_ROAMING_GROUPS => P_OPTION_ROAMING_GROUPS,
                            P_SSP_CAPACITY_OPTION_ID     => P_OPTION_CAPACITY_ID,
                            P_SSP_VOLUME                 => P_OPTION_VOLUME,
                            P_SSP_VOLUME_UNITY           => P_OPTION_VOLUME_UNITY,
                            P_SSP_ORIGEN_CHANNEL         => P_OPTION_CHANNEL,
                            POUT_SMS_ID                  => V_SMS_ID,
                            POUT_ERROR_TEXT              => V_ERROR_TEXT,
                            POUT_ERROR_CODE              => P_ERR_NUM);

    P_LIMIT_ACTION_INFORMATION(P_CELLULAR_NUMBER    => V_CELLULAR_NUMBER,
                               P_SPECIAL_SERVICE_ID => P_SPECIAL_SERVICE_DATA,
                               P_ACTION_SERVICE_ID  => P_ACTION_SERVICE_ID,
                               P_LIMIT_AMOUNT_CYCLE => P_OPTION_LIMIT_CYCLE,
                               P_LIMIT_AMOUNT_DAY   => P_OPTION_LIMIT_DAY,
                               P_COUNT_LIMIT_DAY    => P_COUNT_DAY,
                               P_COUNT_LIMIT_CYCLE  => P_COUNT_CYCLE,
                               P_SIZE_BUYED         => P_REPURCHASED_SIZE,
                               P_UNIT_BUYED         => P_REPURCHASED_UNIT,
                               POUT_SMS_ID          => V_SMS_ID,
                               POUT_ERROR_TEXT      => P_BUY_REASON,
                               POUT_ERROR_CODE      => P_BUY_PACK_WEB);

    IF V_CATEGORY = 'M' THEN
      P_VIEW_PACK_WEB := 'Y';
    ELSE
      P_VIEW_PACK_WEB := 'N';
    END IF;
    IF P_BUY_PACK_WEB = 0 THEN
      P_BUY_PACK_WEB := 'Y';
      P_BUY_REASON   := 'Puede realizar recompra.';
      P_ERR_TEXT     := 'valid ok';
    ELSIF (P_BUY_PACK_WEB = -1 OR P_BUY_PACK_WEB = -2) THEN
      P_BUY_PACK_WEB := 'N';
      P_BUY_REASON   := P_BUY_REASON;
    ELSE
      P_BUY_PACK_WEB := 'N';
      P_ERR_TEXT     := P_BUY_REASON || CHR(13) || P_ERR_TEXT;
    END IF;

    RETURN 0;
  EXCEPTION
    WHEN OTHERS THEN
      P_ERR_NUM  := SQLCODE;
      P_ERR_TEXT := SQLERRM;
      RETURN - 1;
  END F_GPRS_INFORMATION_COMPLETE;

  /***************************************************************************************************************/
  /*Se obtienen todos los datos que se necesitan de un Linea para trabajar                                       */
  /***************************************************************************************************************/

  PROCEDURE P_GET_DATA_CELLULAR(P_BILL_NUMBER            IN S_CELLULARS.Clu_Bill_Number%TYPE,
                                POUT_CELLULAR_NUMBER     OUT S_CELLULARS.clu_cellular_number%TYPE,
                                POUT_CELLULAR_CATEGORY   OUT S_CLIENT.Clt_Category%TYPE,
                                POUT_CELLULAR_TYPE       OUT S_CLIENT.Clt_Type%TYPE,
                                POUT_CELLULAR_CBT_ID     OUT S_CELLULARS.Clu_Cbt_Id%TYPE,
                                POUT_CELLULAR_RPL_ID     OUT S_RATE_PLANS.RPL_RPL_ID%TYPE,
                                POUT_CELLULAR_RPL_RTY_ID OUT S_RATE_PLANS.RPL_RTY_ID%TYPE,
                                POUT_SMS_ID              OUT VARCHAR2,
                                POUT_ERROR_TEXT          OUT VARCHAR2,
                                POUT_ERROR_CODE          OUT NUMBER) IS
    V_ERROR_DESC VARCHAR2(1000) := '';
    V_STG_ID              S_CELLULARS.CLU_STG_ID%TYPE;
    V_FUTURE_RPL_ID       VARCHAR2(1000) := '';
    V_FUTURE_DATE         VARCHAR2(1000) := '';
    V_CURRENT_RPL_ID      VARCHAR2(1000) := '';
    V_CURRENT_DATE        VARCHAR2(1000) := '';
    V_RPL_RTY_ID          VARCHAR2(1000) := '';
    V_ONLINE              VARCHAR2(1) := '';
    V_MSG_ERR             VARCHAR2(1000) := '';
    V_RESULT            VARCHAR2(1) := '';
  BEGIN
    V_ERROR_DESC := 'P_GET_DATA_CELLULAR(' || P_BILL_NUMBER || ')';
    -- Esto se hace para que si el dato que viene es el cellular_number en lugar del bill_number
    -- igualmente obtenga los datos de forma correcta.
    BEGIN
      SELECT CLU.clu_cellular_number,
             CLU.Clu_Stg_Id,
             CLT.clt_category,
             CLT.Clt_Type,
             CLU.Clu_Cbt_Id
        INTO POUT_CELLULAR_NUMBER,
             V_STG_ID,
             POUT_CELLULAR_CATEGORY,
             POUT_CELLULAR_TYPE,
             POUT_CELLULAR_CBT_ID
        FROM S_CELLULARS      CLU,
             S_ACCOUNTS       ACC,
             S_CLIENT         CLT
       WHERE ACC.ACC_ID = CLU.CLU_ACC_ID
         AND ACC.acc_clt_id = CLT.clt_id
         AND CLU.CLU_CELLULAR_NUMBER = P_BILL_NUMBER
         AND CLU.clu_status = 'A';
      POUT_ERROR_CODE := 0;
      POUT_ERROR_TEXT := 'OK: ' || V_ERROR_DESC;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        SELECT CLU.clu_cellular_number,
               CLU.Clu_Stg_Id,
               CLT.clt_category,
               CLT.Clt_Type,
               CLU.Clu_Cbt_Id
          INTO POUT_CELLULAR_NUMBER,
               V_STG_ID,
               POUT_CELLULAR_CATEGORY,
               POUT_CELLULAR_TYPE,
               POUT_CELLULAR_CBT_ID
          FROM S_CELLULARS      CLU,
               S_ACCOUNTS       ACC,
               S_CLIENT         CLT
         WHERE ACC.ACC_ID = CLU.CLU_ACC_ID
           AND ACC.acc_clt_id = CLT.clt_id
           AND CLU.CLU_BILL_NUMBER = P_BILL_NUMBER
           AND CLU.clu_status = 'A';
        POUT_ERROR_CODE := 0;
        POUT_ERROR_TEXT := 'OK: ' || V_ERROR_DESC;
        END;
        BEGIN
      -- Se va realizar la llamada a la funcion de prepago para obtener si la linea tiene un cambio
    -- de plan online.
       V_RESULT := PA_RATE_PLANS.F_GET_RPL_ID (P_CELLULAR_NUMBER  => POUT_CELLULAR_NUMBER,
                                         P_STG_ID              => V_STG_ID, --> NO ES OBLIGATORIO INGRESARLO.
                                         P_FUTURE_RPL_ID       => V_FUTURE_RPL_ID,
                                         P_FUTURE_DATE         => V_FUTURE_DATE,
                                         P_CURRENT_RPL_ID      => V_CURRENT_RPL_ID,
                                         P_CURRENT_DATE        => V_CURRENT_DATE,
                                         P_RPL_RTY_ID          => V_RPL_RTY_ID,
                                         P_ONLINE              => V_ONLINE,
                                         P_MSG_ERR             => V_MSG_ERR);
      IF V_RESULT <> 0 THEN
         POUT_ERROR_TEXT:= V_MSG_ERR;
         RETURN;
     ELSE
        POUT_CELLULAR_RPL_RTY_ID := V_RPL_RTY_ID;
        IF V_ONLINE = 'Y' THEN
           POUT_CELLULAR_RPL_ID  := V_FUTURE_RPL_ID;
        ELSE
           POUT_CELLULAR_RPL_ID  := V_CURRENT_RPL_ID;
        END IF;
       END IF;
  END;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      POUT_SMS_ID     := 'ERROR_DATA';
      POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC ||
                         '--> No se encontraron los datos de la Linea';
      POUT_ERROR_CODE := -20160;
      RETURN;
    WHEN OTHERS THEN
      POUT_SMS_ID     := 'ERROR_DATA';
      POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC || '-->' || SQLERRM;
      POUT_ERROR_CODE := SQLCODE;
      RETURN;
  END P_GET_DATA_CELLULAR;

  /*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

  PROCEDURE P_INTERNET_WEB_NAMES(P_CELLULAR_NUMBER          IN S_CELLULARS.clu_cellular_number%TYPE,
                                 POUT_FEATURE_ID            OUT S_FEATURES.ftr_id%TYPE,
                                 POUT_PACKAGE_ID            OUT S_PACKAGES.pkt_id%TYPE,
                                 POUT_PACKAGE_CYCLIC        OUT S_PACKAGES.Pkt_Cyclic%TYPE,
                                 POUT_MAIN_QUOTA_NAME       OUT VW_AUT_FEATURES_ASSOCIATIONS.CUSTOM2%TYPE,
                                 POUT_DAILY_QUOTA_NAME      OUT VW_AUT_FEATURES_ASSOCIATIONS.CUSTOM7%TYPE,
                                 POUT_ADDITIONAL_QUOTA_NAME OUT VW_AUT_FEATURES_ASSOCIATIONS.CUSTOM10%TYPE,
                                 POUT_VIEW_WEB              OUT VARCHAR2,
                                 POUT_SMS_ID                OUT VARCHAR2,
                                 POUT_ERROR_TEXT            OUT VARCHAR2,
                                 POUT_ERROR_CODE            OUT NUMBER) IS
    V_ERROR_DESC       VARCHAR2(1000) := '';
    V_CUSTOM_NO_DATA   S_STL_PARAMETERS.stl_char_value%TYPE;
    V_PACKAGE_VIEW_WEB S_STL_PARAMETERS.stl_char_value%TYPE;
  BEGIN
    V_ERROR_DESC  := 'P_QUOTE_PACK(' || P_CELLULAR_NUMBER || ')';
    POUT_VIEW_WEB := 'N';
    BEGIN
      SELECT ST.stl_char_value
        INTO V_CUSTOM_NO_DATA
        FROM S_STL_PARAMETERS ST
       WHERE ST.stl_id = 'PCRFND';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        POUT_SMS_ID     := 'ERROR_DATA';
        POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC ||
                           '-->No se encontro en STL_PARAMETER STL_ID=PCRFND';
        POUT_ERROR_CODE := SQLCODE;
      WHEN OTHERS THEN
        POUT_SMS_ID     := 'ERROR_DATA';
        POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC || '-->' || SQLERRM;
        POUT_ERROR_CODE := SQLCODE;
    END;
    BEGIN
      select FP.pks_ftr_id,
             PK.pkt_id,
             PK.pkt_cyclic,
             fta.CUSTOM2,
             fta.CUSTOM7,
             fta.CUSTOM10
        INTO POUT_FEATURE_ID,
             POUT_PACKAGE_ID,
             POUT_PACKAGE_CYCLIC,
             POUT_MAIN_QUOTA_NAME,
             POUT_DAILY_QUOTA_NAME,
             POUT_ADDITIONAL_QUOTA_NAME
        from S_CELLULAR_PACKAGES          CP,
             S_PACKAGES                   PK,
             S_FEATURE_PACKAGES           FP,
             VW_AUT_FEATURES_ASSOCIATIONS FTA
       WHERE CP.cpk_pkt_id = FP.pks_pkt_id
         AND CP.CPK_PKT_ID = PK.PKT_ID
         AND fta.sfs_ftr_id = fp.pks_ftr_id
         AND CP.cpk_clu_cellular_number = P_CELLULAR_NUMBER
         AND fta.sfs_service = 'PCRF'
         AND 'EMBLACOM' NOT LIKE '%' || FTA.CUSTOM2 || '%' -- Para que no tome los que nos son de Datos como por ejemplo EMBLACOM
         AND SYSDATE BETWEEN CP.cpk_activation_date AND
             NVL(CP.cpk_canceled_date, SYSDATE + 1)
         AND ROWNUM = 1; -- Se toma el ROWNUM 1 por si llegan erroneamente a asgnar dos pack con feature de cuota a PCRF.
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        POUT_SMS_ID     := 'ERROR_DATA';
        POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC ||
                           '-->No se encontro PACK de datos controlado por PCRF';
        POUT_ERROR_CODE := SQLCODE;
        RETURN;
      WHEN OTHERS THEN
        POUT_SMS_ID     := 'ERROR_DATA';
        POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC || '-->' || SQLERRM;
        POUT_ERROR_CODE := SQLCODE;
        RETURN;
    END;
    BEGIN
      SELECT ST.stl_char_value
        INTO V_PACKAGE_VIEW_WEB
        FROM S_STL_PARAMETERS ST
       WHERE ST.stl_id = 'PKONW';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        POUT_VIEW_WEB := 'Y';
      WHEN OTHERS THEN
        POUT_SMS_ID     := 'ERROR_DATA';
        POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC || '-->' || SQLERRM;
        POUT_ERROR_CODE := SQLCODE;
        RETURN;
    END;
    IF POUT_VIEW_WEB = 'N' THEN
      BEGIN
        SELECT 'Y'
          INTO POUT_VIEW_WEB
          FROM DUAL
         WHERE V_PACKAGE_VIEW_WEB LIKE '%' || POUT_PACKAGE_ID || '%';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          POUT_VIEW_WEB := 'N';
        WHEN OTHERS THEN
          POUT_SMS_ID     := 'ERROR_DATA';
          POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC || '-->' || SQLERRM;
          POUT_ERROR_CODE := SQLCODE;
          RETURN;
      END;
    END IF;
    POUT_ERROR_CODE := 0;
    POUT_ERROR_TEXT := 'OK: ' || V_ERROR_DESC;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      POUT_SMS_ID     := 'ERROR_DATA';
      POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC ||
                         '-->No se encontro un Pack con cuota para PCRF';
      POUT_ERROR_CODE := SQLCODE;
    WHEN OTHERS THEN
      POUT_SMS_ID     := 'ERROR_DATA';
      POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC || '-->' || SQLERRM;
      POUT_ERROR_CODE := SQLCODE;
  END P_INTERNET_WEB_NAMES;

  /*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

  PROCEDURE P_INTERNET_WEB_SIZES(P_FEATURE_ID         IN S_FEATURES.ftr_id%TYPE,
                                 POUT_SIZE_MAIN       OUT AUT_QUOTA_SIZE.QTS_SIZE_MB%TYPE,
                                 POUT_SIZE_DAILY      OUT AUT_QUOTA_SIZE.QTS_SIZE_MB%TYPE,
                                 POUT_SIZE_ADDITIONAL OUT AUT_QUOTA_SIZE.QTS_SIZE_MB%TYPE,
                                 POUT_ERROR_TEXT      OUT VARCHAR2,
                                 POUT_ERROR_CODE      OUT NUMBER) IS
    V_ERROR_DESC VARCHAR2(1000) := '';
  BEGIN
    select Recompra, Diaria, Mensual
      into POUT_SIZE_ADDITIONAL, POUT_SIZE_DAILY, POUT_SIZE_MAIN
      from ((select 'Recompra' QTS_TIME, QTS_SIZE_MB
               from VW_AUT_FEATURES_ASSOCIATIONS, AUT_QUOTA_SIZE
              where SFS_FTR_ID = P_FEATURE_ID
                and CUSTOM10 = QTS_QUOTA_NAME
             UNION
             select 'Diaria' QTS_TIME, QTS_SIZE_MB
               from VW_AUT_FEATURES_ASSOCIATIONS, AUT_QUOTA_SIZE
              where SFS_FTR_ID = P_FEATURE_ID
                and CUSTOM7 = QTS_QUOTA_NAME
             UNION
             select 'Mensual' QTS_TIME, QTS_SIZE_MB
               from VW_AUT_FEATURES_ASSOCIATIONS, AUT_QUOTA_SIZE
              where SFS_FTR_ID = P_FEATURE_ID
                and CUSTOM2 = QTS_QUOTA_NAME)
            Pivot(Max(QTS_SIZE_MB) For
                  QTS_TIME In
                  ('Recompra' Recompra, 'Diaria' Diaria, 'Mensual' Mensual)))
     WHERE (Recompra is not null or Diaria is not null or
           Mensual is not null);
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC ||
                         '--> No se encontraron totales para los Quota_Names con ese feature';
      POUT_ERROR_CODE := SQLCODE;
      RETURN;
    WHEN OTHERS THEN
      POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC || '-->' || SQLERRM;
      POUT_ERROR_CODE := SQLCODE;
      RETURN;
  END P_INTERNET_WEB_SIZES;

  /*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

  PROCEDURE P_GET_SPECIAL_SERVICE_DATA(P_CELLULAR_NUMBER            IN S_CELLULARS.CLU_CELLULAR_NUMBER%TYPE,
                                       P_CELLULAR_CATEGORY          IN S_CLIENT.Clt_Category%TYPE,
                                       P_CELLULAR_TYPE              IN S_CLIENT.Clt_Type%TYPE,
                                       P_CELLULAR_CBT_ID            IN S_CELLULARS.Clu_Cbt_Id%TYPE,
                                       P_CELLULAR_RPL_ID            IN S_RATE_PLANS.RPL_RPL_ID%TYPE,
                                       P_CELLULAR_RPL_RTY_ID        IN S_RATE_PLANS.RPL_RTY_ID%TYPE,
                                       P_MCC                        IN S_SS_ROAMING_GROUPS.SRG_COP_MCC_ID%TYPE,
                                       P_MNC                        IN S_SS_ROAMING_GROUPS.SRG_COP_MNC_ID%TYPE,
                                       P_TYPE_SERVICE_STR           IN S_SS_ACTION_SPECIAL_SERVICE.ase_type_of_service%TYPE, -- Siempre es DATOS
                                       P_KEYWORD                    IN VARCHAR2,
                                       P_BUY_COST                   OUT VARCHAR2,
                                       P_SSP_LIMIT_AMOUNT_PER_CYCLE OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_LIMIT_AMOUNT_PER_CYCLE%TYPE,
                                       P_SSP_LIMIT_AMOUNT_PER_DAY   OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_LIMIT_AMOUNT_PER_DAY%TYPE,
                                       P_SPECIAL_SERVICE_ID         OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_SPECIAL_SERVICE_ID%TYPE,
                                       POUT_ACTION_SERVICE_ID       OUT S_SS_ACTION_SPECIAL_SERVICE.ASE_ACTION_SERVICE_ID%TYPE,
                                       POUT_SMS_ID                  OUT VARCHAR2,
                                       POUT_ERROR_TEXT              OUT VARCHAR2,
                                       POUT_ERROR_CODE              OUT NUMBER) IS

    V_SSP_EXCHANGE_RATE          S_SS_SPECIAL_SERVICE_PROFILE.SSP_EXCHANGE_RATE%TYPE;
    V_ASE_ACTION_SERVICE_ID      S_SS_ACTION_SPECIAL_SERVICE.ASE_ACTION_SERVICE_ID%TYPE;
    V_SSP_CLT_TYPE               S_SS_SPECIAL_SERVICE_PROFILE.SSP_CLT_TYPE%TYPE;
    V_SSP_CLT_CATEGORY           S_SS_SPECIAL_SERVICE_PROFILE.SSP_CLT_CATEGORY%TYPE;
    V_SSP_APPLIES_ROAMING_GROUPS S_SS_SPECIAL_SERVICE_PROFILE.SSP_APPLIES_ROAMING_GROUPS%TYPE;
    V_CHARGE_VALUE_W_OUT_TAXES   S_SS_SPECIAL_SERVICE_PROFILE.SSP_CHARGE_VALUE_WITHOUT_TAXES%TYPE;
    V_CHARGE_VALUE_W_TAXES       S_SS_SPECIAL_SERVICE_PROFILE.SSP_CHARGE_VALUE_WITH_TAXES%TYPE;
    V_ERROR_DESC                 VARCHAR2(1000) := '';

  BEGIN
    BEGIN
      V_ERROR_DESC := 'P_GET_ACTION_SPECIAL_SERVICE(' || P_KEYWORD || ')';
      SELECT ASE_ACTION_SERVICE_ID
        INTO V_ASE_ACTION_SERVICE_ID
        FROM S_SS_ACTION_SPECIAL_SERVICE ASE
       WHERE ASE.ASE_KEYWORD = P_KEYWORD;
      POUT_ERROR_CODE := 0;
      POUT_ERROR_TEXT := 'OK: ' || V_ERROR_DESC;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        POUT_SMS_ID     := 'INVALID_KEYWORD';
        POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC ||
                           '--> KEYWORD No Encontrado';
        POUT_ERROR_CODE := -20180;
      WHEN OTHERS THEN
        POUT_SMS_ID     := 'ERROR_DATA';
        POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC || '-->' || SQLERRM;
        POUT_ERROR_CODE := SQLCODE;
    END;
    POUT_ACTION_SERVICE_ID := V_ASE_ACTION_SERVICE_ID;
    V_ERROR_DESC           := 'P_GET_SPECIAL_SERVICE_DATA(' ||
                              P_CELLULAR_NUMBER || ',' ||
                              P_SPECIAL_SERVICE_ID || ',' ||
                              P_CELLULAR_CATEGORY || ',' || P_CELLULAR_TYPE || ',' ||
                              P_CELLULAR_CBT_ID || ',' || P_CELLULAR_RPL_ID || ',' ||
                              P_CELLULAR_RPL_RTY_ID || ',' || P_MCC || ',' ||
                              P_MNC || ')';
    /*Busca el Servicio Especial asociado a la linea*/
    P_GET_SPEC_SERV_ASSOCIATE(P_CELLULAR_NUMBER       => P_CELLULAR_NUMBER,
                              P_RPL_ID                => P_CELLULAR_RPL_ID,
                              P_RPL_RTY_ID            => P_CELLULAR_RPL_RTY_ID,
                              P_TYPE_SERVICE_STR      => P_TYPE_SERVICE_STR,
                              POUT_SPECIAL_SERVICE_ID => P_SPECIAL_SERVICE_ID,
                              POUT_SMS_ID             => POUT_SMS_ID,
                              POUT_ERROR_TEXT         => POUT_ERROR_TEXT,
                              POUT_ERROR_CODE         => POUT_ERROR_CODE);
    IF POUT_ERROR_CODE <> 0 THEN
      POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC || CHR(13) ||
                         POUT_ERROR_TEXT;
      RETURN;
    END IF;
    /*Busca los datos de la la accion para el servicio especial de la linea*/
    P_GET_SPEC_SERV_PARAMETERS(P_SPECIAL_SERVICE_ID         => P_SPECIAL_SERVICE_ID,
                               P_ACTION_SERVICE_ID          => V_ASE_ACTION_SERVICE_ID,
                               P_CATEGORY_REAL              => P_CELLULAR_CATEGORY,
                               P_TYPE_REAL                  => P_CELLULAR_TYPE,
                               P_CBT_ID_REAL                => P_CELLULAR_CBT_ID,
                               P_SSP_EXCHANGE_RATE          => V_SSP_EXCHANGE_RATE,
                               P_CHARGE_VALUE_W_OUT_TAXES   => V_CHARGE_VALUE_W_OUT_TAXES,
                               P_CHARGE_VALUE_W_TAXES       => V_CHARGE_VALUE_W_TAXES,
                               P_SSP_LIMIT_AMOUNT_PER_CYCLE => P_SSP_LIMIT_AMOUNT_PER_CYCLE,
                               P_SSP_LIMIT_AMOUNT_PER_DAY   => P_SSP_LIMIT_AMOUNT_PER_DAY,
                               P_SSP_APPLIES_ROAMING_GROUPS => V_SSP_APPLIES_ROAMING_GROUPS,
                               P_SSP_CLT_TYPE               => V_SSP_CLT_TYPE,
                               P_SSP_CLT_CATEGORY           => V_SSP_CLT_CATEGORY,
                               POUT_SMS_ID                  => POUT_SMS_ID,
                               POUT_ERROR_TEXT              => POUT_ERROR_TEXT,
                               POUT_ERROR_CODE              => POUT_ERROR_CODE);
    IF POUT_ERROR_CODE <> 0 THEN
      POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC || CHR(13) ||
                         POUT_ERROR_TEXT;
      RETURN;
    END IF;
    IF V_SSP_APPLIES_ROAMING_GROUPS = 'Y' THEN
      P_GET_RE_CHARGE_SPEC_SERV_G(P_MCC                      => P_MCC,
                                  P_MNC                      => P_MNC,
                                  P_SPECIAL_SERVICE_ID       => P_SPECIAL_SERVICE_ID,
                                  P_ASE_ACTION_SERVICE_ID    => V_ASE_ACTION_SERVICE_ID,
                                  P_SSP_CLT_TYPE             => V_SSP_CLT_TYPE,
                                  P_CELLULAR_CBT_ID          => P_CELLULAR_CBT_ID,
                                  P_SSP_EXCHANGE_RATE        => V_SSP_EXCHANGE_RATE,
                                  P_CHARGE_VALUE_W_OUT_TAXES => V_CHARGE_VALUE_W_OUT_TAXES,
                                  P_CHARGE_VALUE_W_TAXES     => V_CHARGE_VALUE_W_TAXES,
                                  POUT_SMS_ID                => POUT_SMS_ID,
                                  POUT_ERROR_TEXT            => POUT_ERROR_TEXT,
                                  POUT_ERROR_CODE            => POUT_ERROR_CODE);
      IF POUT_ERROR_CODE <> 0 THEN
        POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC || CHR(13) ||
                           POUT_ERROR_TEXT;
        RETURN;
      END IF;
    END IF;
    IF V_CHARGE_VALUE_W_TAXES > 0 THEN
      P_BUY_COST := V_CHARGE_VALUE_W_TAXES;
    ELSE
      P_BUY_COST := V_CHARGE_VALUE_W_OUT_TAXES;
    END IF;
    POUT_ERROR_CODE := 0;
    POUT_ERROR_TEXT := 'OK: ' || V_ERROR_DESC;
  EXCEPTION
    WHEN OTHERS THEN
      POUT_SMS_ID     := 'ERROR_DATA';
      POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC || '-->' || SQLERRM ||
                         CHR(13);
      POUT_ERROR_CODE := SQLCODE;

  END P_GET_SPECIAL_SERVICE_DATA;

  /*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

  PROCEDURE P_GET_SPEC_SERV_PARAMETERS(P_SPECIAL_SERVICE_ID         IN S_SS_SPECIAL_SERVICE_PROFILE.SSP_SPECIAL_SERVICE_ID%TYPE,
                                       P_ACTION_SERVICE_ID          IN S_SS_ACTION_SPECIAL_SERVICE.ASE_ACTION_SERVICE_ID%TYPE,
                                       P_CATEGORY_REAL              IN S_CLIENT.Clt_Category%TYPE,
                                       P_TYPE_REAL                  IN S_CLIENT.Clt_Type%TYPE,
                                       P_CBT_ID_REAL                IN S_CELLULARS.Clu_Cbt_Id%TYPE,
                                       P_SSP_EXCHANGE_RATE          OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_EXCHANGE_RATE%TYPE,
                                       P_CHARGE_VALUE_W_OUT_TAXES   OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_CHARGE_VALUE_WITHOUT_TAXES%TYPE,
                                       P_CHARGE_VALUE_W_TAXES       OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_CHARGE_VALUE_WITH_TAXES%TYPE,
                                       P_SSP_LIMIT_AMOUNT_PER_CYCLE OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_LIMIT_AMOUNT_PER_CYCLE%TYPE,
                                       P_SSP_LIMIT_AMOUNT_PER_DAY   OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_LIMIT_AMOUNT_PER_DAY%TYPE,
                                       P_SSP_APPLIES_ROAMING_GROUPS OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_APPLIES_ROAMING_GROUPS%TYPE,
                                       P_SSP_CLT_TYPE               OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_CLT_TYPE%TYPE,
                                       P_SSP_CLT_CATEGORY           OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_CLT_CATEGORY%TYPE,
                                       POUT_SMS_ID                  OUT VARCHAR2,
                                       POUT_ERROR_TEXT              OUT VARCHAR2,
                                       POUT_ERROR_CODE              OUT NUMBER) IS
    V_CATEGORY   S_CLIENT.Clt_Category%TYPE;
    V_TYPE       S_CLIENT.Clt_Type%TYPE;
    V_CBT_ID     S_CELLULARS.Clu_Cbt_Id%TYPE;
    V_FIND_DATA  VARCHAR2(1) := 'N';
    V_ERROR_DESC VARCHAR2(1000) := '';
  BEGIN
    V_ERROR_DESC := 'P_GET_SPEC_SERV_PARAMETERS(' || P_SPECIAL_SERVICE_ID || ',' ||
                    P_ACTION_SERVICE_ID || ',' || P_CATEGORY_REAL || ',' ||
                    P_TYPE_REAL || ',' || P_CBT_ID_REAL || ')';
    -- Establece el orden de prioridad de busqueda que esta cargado en la tabla SS_SEARCH_ORDER
    FOR item IN (SELECT FO.sor_clt_category,
                        FO.sor_clt_type,
                        FO.sor_clu_cbt_id
                   FROM S_SS_SEARCH_ORDER FO
                  WHERE FO.SOR_SOURCE = 'SS_SPECIAL_SERVICE_PROFILE'
                  ORDER BY FO.SOR_ORDER) LOOP
      IF ITEM.SOR_CLT_CATEGORY = 'VALOR' THEN
        V_CATEGORY := P_CATEGORY_REAL;
      ELSE
        V_CATEGORY := ITEM.SOR_CLT_CATEGORY;
      END IF;
      IF ITEM.SOR_CLT_TYPE = 'VALOR' THEN
        V_TYPE := P_TYPE_REAL;
      ELSE
        V_TYPE := ITEM.SOR_CLT_TYPE;
      END IF;
      IF ITEM.SOR_CLU_CBT_ID = 'VALOR' THEN
        V_CBT_ID := P_CBT_ID_REAL;
      ELSE
        V_CBT_ID := ITEM.SOR_CLU_CBT_ID;
      END IF;
      P_EXEC_SPEC_SERV_PARAMETERS(P_SPECIAL_SERVICE_ID         => P_SPECIAL_SERVICE_ID,
                                  P_ACTION_SERVICE_ID          => P_ACTION_SERVICE_ID,
                                  P_CATEGORY_SEARCH            => V_CATEGORY,
                                  P_TYPE_SEARCH                => V_TYPE,
                                  P_CBT_ID_SEARCH              => V_CBT_ID,
                                  P_SSP_EXCHANGE_RATE          => P_SSP_EXCHANGE_RATE,
                                  P_CHARGE_VALUE_W_OUT_TAXES   => P_CHARGE_VALUE_W_OUT_TAXES,
                                  P_CHARGE_VALUE_W_TAXES       => P_CHARGE_VALUE_W_TAXES,
                                  P_SSP_LIMIT_AMOUNT_PER_CYCLE => P_SSP_LIMIT_AMOUNT_PER_CYCLE,
                                  P_SSP_LIMIT_AMOUNT_PER_DAY   => P_SSP_LIMIT_AMOUNT_PER_DAY,
                                  P_SSP_APPLIES_ROAMING_GROUPS => P_SSP_APPLIES_ROAMING_GROUPS,
                                  P_SSP_CLT_TYPE               => P_SSP_CLT_TYPE,
                                  P_SSP_CLT_CATEGORY           => P_SSP_CLT_CATEGORY,
                                  POUT_FIND_DATA               => V_FIND_DATA,
                                  POUT_SMS_ID                  => POUT_SMS_ID,
                                  POUT_ERROR_TEXT              => POUT_ERROR_TEXT,
                                  POUT_ERROR_CODE              => POUT_ERROR_CODE);
      IF POUT_ERROR_CODE = 0 THEN
        IF V_FIND_DATA = 'Y' THEN
          EXIT; -- Salgo del FOR por que se encontraron los datos y no es necesario seguir buscando
        END IF;
      END IF;
    END LOOP;
    IF V_FIND_DATA = 'Y' THEN
      IF P_SSP_EXCHANGE_RATE = 'DOLARES' THEN
        P_GET_PESOS_DOLAR(POUT_CHARGE_VALUE_WITH_TAXES => P_CHARGE_VALUE_W_TAXES,
                          POUT_CHARGE_VALUE_WITHOUT_T  => P_CHARGE_VALUE_W_OUT_TAXES,
                          POUT_SMS_ID                  => POUT_SMS_ID,
                          POUT_ERROR_TEXT              => POUT_ERROR_TEXT,
                          POUT_ERROR_CODE              => POUT_ERROR_CODE);
        P_SSP_EXCHANGE_RATE := 'PESOS';
        IF POUT_ERROR_CODE <> 0 THEN
          RETURN;
        END IF;
      END IF;
      POUT_ERROR_CODE := 0;
      POUT_ERROR_TEXT := 'OK: ' || V_ERROR_DESC || CHR(13) ||
                         POUT_ERROR_TEXT;
    ELSE
      POUT_SMS_ID     := 'NO_ASSOCIATE_SERVICE';
      POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC ||
                         'NO se encontraron datos para el SERVICO ESPECIAL' ||
                         CHR(13) || POUT_ERROR_TEXT;
      POUT_ERROR_CODE := -20190;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      POUT_SMS_ID     := 'ERROR_DATA';
      POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC || '-->' || SQLERRM ||
                         CHR(13) || POUT_ERROR_TEXT;
      POUT_ERROR_CODE := SQLCODE;
  END P_GET_SPEC_SERV_PARAMETERS;

  /*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

  PROCEDURE P_GET_SPEC_SERV_ASSOCIATE(P_CELLULAR_NUMBER       IN S_CELLULARS.clu_cellular_number%TYPE,
                                      P_RPL_ID                IN S_RATE_PLANS.RPL_RPL_ID%TYPE,
                                      P_RPL_RTY_ID            IN S_RATE_PLANS.RPL_RTY_ID%TYPE,
                                      P_TYPE_SERVICE_STR      IN S_SS_ACTION_SPECIAL_SERVICE.ase_type_of_service%TYPE,
                                      POUT_SPECIAL_SERVICE_ID OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_SPECIAL_SERVICE_ID%TYPE,
                                      POUT_SMS_ID             OUT VARCHAR2,
                                      POUT_ERROR_TEXT         OUT VARCHAR2,
                                      POUT_ERROR_CODE         OUT NUMBER) IS

    V_ERROR_DESC VARCHAR2(1000) := '';
  BEGIN
    --(*PRINCIPAL*)
    V_ERROR_DESC := 'P_GET_SPEC_SERV_ASSOCIATE(' || P_CELLULAR_NUMBER || ',' ||
                    P_RPL_ID || ',' || P_RPL_RTY_ID || ')';
    BEGIN
      -- (*1*)
      SELECT ASS.ass_special_service_id
        INTO POUT_SPECIAL_SERVICE_ID
        FROM (SELECT *
                FROM S_CELLULAR_PACKAGES            CP,
                     SS_ASSOCIATE_SPECIAL_SERVICE@prod ASS
               WHERE CP.cpk_pkt_id = ASS.ASS_PKT_ID
                 AND CP.cpk_clu_cellular_number = P_CELLULAR_NUMBER
                 AND NVL(ASS.ASS_TYPE_SERVICE, 'DATOS') = P_TYPE_SERVICE_STR
                 AND SYSDATE BETWEEN CP.cpk_activation_date AND
                     NVL(CP.cpk_canceled_date, SYSDATE + 1)
                 AND SYSDATE BETWEEN ASS.ass_start_date AND
                     NVL(ASS.ass_end_date, SYSDATE + 1)
               ORDER BY CP.cpk_activation_date) ASS
       WHERE ROWNUM = 1;
    EXCEPTION
      -- (*1*)
      WHEN NO_DATA_FOUND THEN
        -- Sino lo encuentra con un Package de la Linea lo Busca por PLAN
        BEGIN
          -- (*2*)
          SELECT ASS.ass_special_service_id
            INTO POUT_SPECIAL_SERVICE_ID
            FROM (SELECT *
                    FROM S_SS_ASSOCIATE_SPECIAL_SERVICE ASS
                   WHERE ASS.ass_rpl_id = P_RPL_ID
                     AND SYSDATE BETWEEN ASS.ass_start_date AND
                         NVL(ASS.ass_end_date, SYSDATE + 1)
                   ORDER BY ASS.ass_start_date) ASS
           WHERE ROWNUM = 1;
        EXCEPTION
          -- (*2*)
          WHEN NO_DATA_FOUND THEN
            -- Sino lo encuentra con un PLAN de la Linea lo Busca por TIPO PLAN
            BEGIN
              -- (*3*)
              SELECT ASS.ass_special_service_id
                INTO POUT_SPECIAL_SERVICE_ID
                FROM (SELECT *
                        FROM S_SS_ASSOCIATE_SPECIAL_SERVICE ASS
                       WHERE ASS.ass_rpl_rty_id = P_RPL_RTY_ID
                         AND SYSDATE BETWEEN ASS.ass_start_date AND
                             NVL(ASS.ass_end_date, SYSDATE + 1)
                       ORDER BY ASS.ass_start_date) ASS
               WHERE ROWNUM = 1;
            EXCEPTION
              -- (*3*)
              WHEN NO_DATA_FOUND THEN
                POUT_SPECIAL_SERVICE_ID := 'SS_DEFAULT';
              WHEN OTHERS THEN
                POUT_SMS_ID     := 'ERROR_DATA';
                POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC || '-->' ||
                                   SQLERRM;
                POUT_ERROR_CODE := SQLCODE;
                RETURN;
            END; -- (*3*)
          WHEN OTHERS THEN
            --(*2*)
            POUT_SMS_ID     := 'ERROR_DATA';
            POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC || '-->' || SQLERRM;
            POUT_ERROR_CODE := SQLCODE;
            RETURN;
        END; -- (*2*)
      WHEN OTHERS THEN
        -- (*1*)
        POUT_SMS_ID     := 'ERROR_DATA';
        POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC || '-->' || SQLERRM;
        POUT_ERROR_CODE := SQLCODE;
        RETURN;
    END; -- (*1*)
    POUT_ERROR_CODE := 0;
    POUT_ERROR_TEXT := 'OK: ' || V_ERROR_DESC;
  EXCEPTION
    --(*PRINCIPAL*)
    WHEN OTHERS THEN
      POUT_SMS_ID     := 'ERROR_DATA';
      POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC || '-->' || SQLERRM;
      POUT_ERROR_CODE := SQLCODE;

  END P_GET_SPEC_SERV_ASSOCIATE;

  /*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

  PROCEDURE P_EXEC_SPEC_SERV_PARAMETERS(P_SPECIAL_SERVICE_ID         IN S_SS_SPECIAL_SERVICE_PROFILE.SSP_SPECIAL_SERVICE_ID%TYPE,
                                        P_ACTION_SERVICE_ID          IN S_SS_ACTION_SPECIAL_SERVICE.ASE_ACTION_SERVICE_ID%TYPE,
                                        P_CATEGORY_SEARCH            IN S_CLIENT.Clt_Category%TYPE,
                                        P_TYPE_SEARCH                IN S_CLIENT.Clt_Type%TYPE,
                                        P_CBT_ID_SEARCH              IN S_CELLULARS.Clu_Cbt_Id%TYPE,
                                        P_SSP_EXCHANGE_RATE          OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_EXCHANGE_RATE%TYPE,
                                        P_CHARGE_VALUE_W_OUT_TAXES   OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_CHARGE_VALUE_WITHOUT_TAXES%TYPE,
                                        P_CHARGE_VALUE_W_TAXES       OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_CHARGE_VALUE_WITH_TAXES%TYPE,
                                        P_SSP_LIMIT_AMOUNT_PER_CYCLE OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_LIMIT_AMOUNT_PER_CYCLE%TYPE,
                                        P_SSP_LIMIT_AMOUNT_PER_DAY   OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_LIMIT_AMOUNT_PER_DAY%TYPE,
                                        P_SSP_APPLIES_ROAMING_GROUPS OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_APPLIES_ROAMING_GROUPS%TYPE,
                                        P_SSP_CLT_TYPE               OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_CLT_TYPE%TYPE,
                                        P_SSP_CLT_CATEGORY           OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_CLT_CATEGORY%TYPE,
                                        POUT_FIND_DATA               OUT VARCHAR2,
                                        POUT_SMS_ID                  OUT VARCHAR2,
                                        POUT_ERROR_TEXT              OUT VARCHAR2,
                                        POUT_ERROR_CODE              OUT NUMBER) IS
    V_ERROR_DESC VARCHAR2(1000) := '';
  BEGIN
    V_ERROR_DESC := 'P_EXEC_SPEC_SERV_PARAMETERS(' || P_SPECIAL_SERVICE_ID || ';' ||
                    P_ACTION_SERVICE_ID || ',' || P_CATEGORY_SEARCH || ',' ||
                    P_TYPE_SEARCH || ',' || P_CBT_ID_SEARCH || ')';
    SELECT SSP.Ssp_Exchange_Rate,
           ssp.ssp_charge_value_without_taxes,
           ssp.ssp_charge_value_with_taxes,
           ssp.ssp_limit_amount_per_cycle,
           ssp.ssp_limit_amount_per_day,
           ssp.ssp_applies_roaming_groups,
           ssp.SSP_CLT_TYPE,
           ssp.SSP_CLT_CATEGORY
      INTO P_SSP_EXCHANGE_RATE,
           P_CHARGE_VALUE_W_OUT_TAXES,
           P_CHARGE_VALUE_W_TAXES,
           P_SSP_LIMIT_AMOUNT_PER_CYCLE,
           P_SSP_LIMIT_AMOUNT_PER_DAY,
           P_SSP_APPLIES_ROAMING_GROUPS,
           P_SSP_CLT_TYPE,
           P_SSP_CLT_CATEGORY
      FROM S_SS_SPECIAL_SERVICE_PROFILE SSP
     WHERE SSP.ssp_special_service_id = P_SPECIAL_SERVICE_ID
       AND SSP.ssp_ase_action_service_id = P_ACTION_SERVICE_ID
       AND SSP.ssp_clt_category = P_CATEGORY_SEARCH
       AND SSP.ssp_clt_type = P_TYPE_SEARCH
       AND SSP.ssp_clu_cbt_id = P_CBT_ID_SEARCH
       AND SYSDATE BETWEEN SSP.ssp_start_date AND
           NVL(SSP.ssp_end_date, SYSDATE + 1)
       AND ROWNUM = 1;
    POUT_FIND_DATA  := 'Y';
    POUT_ERROR_CODE := 0;
    POUT_ERROR_TEXT := 'OK: ' || V_ERROR_DESC;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      POUT_FIND_DATA := 'N';
    WHEN OTHERS THEN
      POUT_SMS_ID     := 'ERROR_DATA';
      POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC || '-->' || SQLERRM;
      POUT_ERROR_CODE := SQLCODE;
  END P_EXEC_SPEC_SERV_PARAMETERS;

  /*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

  PROCEDURE P_GET_RE_CHARGE_SPEC_SERV_G(P_MCC                      IN S_SS_ROAMING_GROUPS.SRG_COP_MCC_ID%TYPE,
                                        P_MNC                      IN S_SS_ROAMING_GROUPS.SRG_COP_MNC_ID%TYPE,
                                        P_SPECIAL_SERVICE_ID       IN S_SS_SPECIAL_SERVICE_PROFILE.SSP_SPECIAL_SERVICE_ID%TYPE,
                                        P_ASE_ACTION_SERVICE_ID    IN S_SS_ACTION_SPECIAL_SERVICE.ASE_ACTION_SERVICE_ID%TYPE,
                                        P_SSP_CLT_TYPE             IN S_SS_SPECIAL_SERVICE_PROFILE.SSP_CLT_TYPE%TYPE,
                                        P_CELLULAR_CBT_ID          IN S_CELLULARS.Clu_Cbt_Id%TYPE,
                                        P_SSP_EXCHANGE_RATE        IN OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_EXCHANGE_RATE%TYPE,
                                        P_CHARGE_VALUE_W_OUT_TAXES IN OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_CHARGE_VALUE_WITHOUT_TAXES%TYPE,
                                        P_CHARGE_VALUE_W_TAXES     IN OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_CHARGE_VALUE_WITH_TAXES%TYPE,
                                        POUT_SMS_ID                OUT VARCHAR2,
                                        POUT_ERROR_TEXT            OUT VARCHAR2,
                                        POUT_ERROR_CODE            OUT NUMBER) IS
    V_MCC        S_SS_ROAMING_GROUPS.SRG_COP_MCC_ID%TYPE;
    V_MNC        S_SS_ROAMING_GROUPS.Srg_Cop_Mnc_Id%TYPE;
    V_FIND_DATA  VARCHAR2(1) := 'N';
    V_ERROR_DESC VARCHAR2(1000) := '';
    V_ERROR_TEXT VARCHAR2(5000) := '';
  BEGIN
    V_ERROR_DESC := 'P_GET_RE_CHARGE_SPEC_SERV(' || P_MCC || ',' || P_MNC || ')';
    FOR i IN 1 .. 3 LOOP
      -- Opciones para Grupos de Roaming, Pais/Operadoa; Cualquier Operadora de un pais; todos los paises
      CASE i
        WHEN 1 THEN
          V_MCC := P_MCC;
          V_MNC := P_MNC;
        WHEN 2 THEN
          V_MCC := P_MCC;
          V_MNC := '*';
        WHEN 3 THEN
          V_MCC := '*';
          V_MNC := '*';
      END CASE;
      P_EXCE_PAYMENT_ROAMING(P_MCC                      => V_MCC,
                             P_MNC                      => V_MNC,
                             P_SPECIAL_SERVICE_ID       => P_SPECIAL_SERVICE_ID,
                             P_ASE_ACTION_SERVICE_ID    => P_ASE_ACTION_SERVICE_ID,
                             P_SSP_CLT_TYPE             => P_SSP_CLT_TYPE,
                             P_SSP_CLT_CATEGORY         => P_CELLULAR_CBT_ID,
                             P_CELLULAR_CBT_ID          => P_CELLULAR_CBT_ID,
                             P_SSP_EXCHANGE_RATE        => P_SSP_EXCHANGE_RATE,
                             P_CHARGE_VALUE_W_OUT_TAXES => P_CHARGE_VALUE_W_OUT_TAXES,
                             P_CHARGE_VALUE_W_TAXES     => P_CHARGE_VALUE_W_TAXES,
                             POUT_FIND_DATA             => V_FIND_DATA,
                             POUT_SMS_ID                => POUT_SMS_ID,
                             POUT_ERROR_TEXT            => POUT_ERROR_TEXT,
                             POUT_ERROR_CODE            => POUT_ERROR_CODE);
      IF POUT_ERROR_CODE = 0 THEN
        IF V_FIND_DATA = 'Y' THEN
          EXIT; -- Salgo del FOR por que se encontro el registro que se buscaba
        END IF;
      END IF;
    END LOOP;
    IF V_FIND_DATA = 'Y' THEN
      IF P_SSP_EXCHANGE_RATE = 'DOLARES' THEN
        P_GET_PESOS_DOLAR(POUT_CHARGE_VALUE_WITH_TAXES => P_CHARGE_VALUE_W_TAXES,
                          POUT_CHARGE_VALUE_WITHOUT_T  => P_CHARGE_VALUE_W_OUT_TAXES,
                          POUT_SMS_ID                  => POUT_SMS_ID,
                          POUT_ERROR_TEXT              => POUT_ERROR_TEXT,
                          POUT_ERROR_CODE              => POUT_ERROR_CODE);
        P_SSP_EXCHANGE_RATE := 'PESOS';
        POUT_ERROR_TEXT     := POUT_ERROR_TEXT || V_ERROR_TEXT || CHR(13);
        IF POUT_ERROR_CODE <> 0 THEN
          RETURN;
        END IF;
      END IF;
      POUT_ERROR_CODE := 0;
      POUT_ERROR_TEXT := 'OK: ' || V_ERROR_DESC;
    ELSE
      POUT_SMS_ID     := 'ERROR_ZONA_ROAMING';
      POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC ||
                         '--> No Se encontro un Grupo de Roaming para los Cargos';
      POUT_ERROR_CODE := -1;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC || '-->' || SQLERRM;
      POUT_ERROR_CODE := SQLCODE;
  END P_GET_RE_CHARGE_SPEC_SERV_G;

  /*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

  PROCEDURE P_GET_PESOS_DOLAR(POUT_CHARGE_VALUE_WITH_TAXES IN OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_CHARGE_VALUE_WITH_TAXES%TYPE,
                              POUT_CHARGE_VALUE_WITHOUT_T  IN OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_CHARGE_VALUE_WITHOUT_TAXES%TYPE,
                              POUT_SMS_ID                  OUT VARCHAR2,
                              POUT_ERROR_TEXT              OUT VARCHAR2,
                              POUT_ERROR_CODE              OUT NUMBER) IS
    V_COTIZACION NUMBER;
    V_ERROR_DESC VARCHAR2(1000) := '';
  BEGIN
    V_ERROR_DESC := 'P_GET_PESOS_DOLAR(' || POUT_CHARGE_VALUE_WITH_TAXES || ',' ||
                    POUT_CHARGE_VALUE_WITHOUT_T || ')';
    SELECT DI.dei_index_value
      INTO V_COTIZACION
      FROM S_DEVALUATION_INDEXES DI
     WHERE DI.dei_id = 'ROAM'
       AND SYSDATE BETWEEN DI.dei_start_date AND
           NVL(DI.dei_end_date, SYSDATE);
    IF V_COTIZACION > 0 THEN
      POUT_CHARGE_VALUE_WITH_TAXES := POUT_CHARGE_VALUE_WITH_TAXES *
                                      V_COTIZACION;
      POUT_CHARGE_VALUE_WITHOUT_T  := POUT_CHARGE_VALUE_WITHOUT_T *
                                      V_COTIZACION;
    ELSE
      POUT_SMS_ID     := 'ERROR_DATA';
      POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC ||
                         '--> La Cotizacion en DOLARES esta en 0 (Cero)';
      POUT_ERROR_CODE := -20150;
      RETURN;
    END IF;
    POUT_ERROR_CODE := 0;
    POUT_ERROR_TEXT := 'OK: ' || V_ERROR_DESC;
  EXCEPTION
    WHEN OTHERS THEN
      POUT_SMS_ID     := 'ERROR_DATA';
      POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC || '-->' || SQLERRM;
      POUT_ERROR_CODE := SQLCODE;
  END P_GET_PESOS_DOLAR;

  /*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

  PROCEDURE P_EXCE_PAYMENT_ROAMING(P_MCC                      IN S_SS_ROAMING_GROUPS.SRG_COP_MCC_ID%TYPE,
                                   P_MNC                      IN S_SS_ROAMING_GROUPS.SRG_COP_MNC_ID%TYPE,
                                   P_SPECIAL_SERVICE_ID       IN S_SS_SPECIAL_SERVICE_PROFILE.SSP_SPECIAL_SERVICE_ID%TYPE,
                                   P_ASE_ACTION_SERVICE_ID    IN S_SS_ACTION_SPECIAL_SERVICE.ASE_ACTION_SERVICE_ID%TYPE,
                                   P_SSP_CLT_TYPE             IN S_SS_SPECIAL_SERVICE_PROFILE.SSP_CLT_TYPE%TYPE,
                                   P_SSP_CLT_CATEGORY         IN S_SS_SPECIAL_SERVICE_PROFILE.SSP_CLT_CATEGORY%TYPE,
                                   P_CELLULAR_CBT_ID          IN S_CELLULARS.Clu_Cbt_Id%TYPE,
                                   P_SSP_EXCHANGE_RATE        IN OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_EXCHANGE_RATE%TYPE,
                                   P_CHARGE_VALUE_W_OUT_TAXES IN OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_CHARGE_VALUE_WITHOUT_TAXES%TYPE,
                                   P_CHARGE_VALUE_W_TAXES     IN OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_CHARGE_VALUE_WITH_TAXES%TYPE,
                                   POUT_FIND_DATA             OUT VARCHAR2,
                                   POUT_SMS_ID                OUT VARCHAR2,
                                   POUT_ERROR_TEXT            OUT VARCHAR2,
                                   POUT_ERROR_CODE            OUT NUMBER) IS
    V_ERROR_DESC VARCHAR2(1000) := '';
  BEGIN
    V_ERROR_DESC := 'P_EXCE_PAYMENT_ROAMING(' || P_MCC || ',' || P_MNC || ')';
    SELECT PRG.prg_exchange_rate,
           PRG.prg_charge_value_with_taxes,
           PRG.prg_charge_value_without_taxes
      INTO P_SSP_EXCHANGE_RATE,
           P_CHARGE_VALUE_W_TAXES,
           P_CHARGE_VALUE_W_OUT_TAXES
      FROM S_SS_PAYMENT_ROAMING_GROUPS PRG
     WHERE PRG.PRG_SPECIAL_SERVICE_ID = P_SPECIAL_SERVICE_ID
       AND PRG.PRG_ASE_ACTION_SERVICE_ID = P_ASE_ACTION_SERVICE_ID
       AND PRG.PRG_CLT_CATEGORY = P_SSP_CLT_CATEGORY
       AND PRG.PRG_CLT_TYPE = P_SSP_CLT_TYPE
       AND PRG.PRG_CLU_CBT_ID = P_CELLULAR_CBT_ID
       AND SYSDATE BETWEEN PRG.prg_start_date AND
           NVL(PRG.prg_end_date, SYSDATE + 1)
       AND PRG.prg_rgs_roaming_group_id IN
           (SELECT RG.srg_roaming_group_id
              FROM S_SS_ROAMING_GROUPS RG
             WHERE RG.srg_cop_mcc_id = P_MCC
               AND RG.srg_cop_mnc_id = P_MNC)
       AND ROWNUM = 1;
    POUT_FIND_DATA  := 'Y';
    POUT_ERROR_CODE := 0;
    POUT_ERROR_TEXT := 'OK: ' || V_ERROR_DESC;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      POUT_FIND_DATA := 'N';
    WHEN OTHERS THEN
      POUT_SMS_ID     := 'ERROR_DATA';
      POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC || '-->' || SQLERRM;
      POUT_ERROR_CODE := SQLCODE;
  END P_EXCE_PAYMENT_ROAMING;

  /*--------------------------------------------------------------------------------------------------------*/

  PROCEDURE P_VALIDATE_LIMIT_ACTION_SS(P_CELLULAR_NUMBER    IN S_CELLULARS.clu_cellular_number%TYPE,
                                       P_SPECIAL_SERVICE_ID IN S_SS_SPECIAL_SERVICE_PROFILE.ssp_special_service_id%TYPE,
                                       P_ACTION_SERVICE_ID  IN S_SS_ACTION_SPECIAL_SERVICE.ase_action_service_id%TYPE,
                                       P_LIMIT_AMOUNT_CYCLE IN S_SS_SPECIAL_SERVICE_PROFILE.ssp_limit_amount_per_cycle%TYPE,
                                       P_LIMIT_AMOUNT_DAY   IN S_SS_SPECIAL_SERVICE_PROFILE.ssp_limit_amount_per_day%TYPE,
                                       P_COUNT_LIMIT_DAY    OUT NUMBER,
                                       P_COUNT_LIMIT_CYCLE  OUT NUMBER,
                                       POUT_SMS_ID          OUT VARCHAR2,
                                       POUT_ERROR_TEXT      OUT VARCHAR2,
                                       POUT_ERROR_CODE      OUT NUMBER) IS
    V_ERROR_DESC       VARCHAR2(1000) := '';
    V_START_CYCLE      DATE;
    V_END_CYCLE        DATE;
    V_ROWID            ROWID;
    V_LAST_ACTION_DATE DATE;
    V_DIA_HOY          NUMBER;
    V_DIA_LAST_UPDATE  NUMBER;
    V_FIND_DATA        VARCHAR2(1) := 'N';
  BEGIN
    V_ERROR_DESC := 'P_VALIDATE_LIMIT_ACTION_SS(' || P_CELLULAR_NUMBER || ',' ||
                    P_SPECIAL_SERVICE_ID || ',' || P_ACTION_SERVICE_ID || ',' ||
                    P_LIMIT_AMOUNT_CYCLE || ',' || P_LIMIT_AMOUNT_DAY || ')';
    PA_SPECIAL_SERVICE_MANAGER.P_GET_CYCLE_ACCOUNT(P_CELLULAR_NUMBER => P_CELLULAR_NUMBER,
                                                   P_START_CYCLE     => V_START_CYCLE,
                                                   P_END_CYCLE       => V_END_CYCLE,
                                                   POUT_SMS_ID       => POUT_SMS_ID,
                                                   POUT_ERROR_TEXT   => POUT_ERROR_TEXT,
                                                   POUT_ERROR_CODE   => POUT_ERROR_CODE);
    IF POUT_ERROR_CODE <> 0 THEN
      RETURN;
    END IF;
    PA_SPECIAL_SERVICE_MANAGER.P_GET_COUNT_LIMIT_ACTION_SS(P_CELLULAR_NUMBER      => P_CELLULAR_NUMBER,
                                                           P_SPECIAL_SERVICE_ID   => P_SPECIAL_SERVICE_ID,
                                                           P_ACTION_SERVICE_ID    => P_ACTION_SERVICE_ID,
                                                           P_START_CYCLE          => V_START_CYCLE,
                                                           P_END_CYCLE            => V_END_CYCLE,
                                                           POUT_FIND_DATA         => V_FIND_DATA,
                                                           POUT_ROWID             => V_ROWID,
                                                           POUT_COUNT_LIMIT_DAY   => P_COUNT_LIMIT_DAY,
                                                           POUT_COUNT_LIMIT_CYCLE => P_COUNT_LIMIT_CYCLE,
                                                           POUT_LAST_ACTION_DATE  => V_LAST_ACTION_DATE,
                                                           POUT_DIA_HOY           => V_DIA_HOY,
                                                           POUT_DIA_LAST_UPDATE   => V_DIA_LAST_UPDATE,
                                                           POUT_SMS_ID            => POUT_SMS_ID,
                                                           POUT_ERROR_TEXT        => POUT_ERROR_TEXT,
                                                           POUT_ERROR_CODE        => POUT_ERROR_CODE);
    IF POUT_ERROR_CODE <> 0 THEN
      RETURN;
    END IF;
    IF V_FIND_DATA = 'Y' OR V_ROWID = '0' THEN
      IF (P_COUNT_LIMIT_DAY >= NVL(P_LIMIT_AMOUNT_DAY, 9999)) AND
         (trunc(SYSDATE) = trunc(V_LAST_ACTION_DATE)) THEN
        POUT_SMS_ID     := 'LIMIT_DAY';
        POUT_ERROR_TEXT := 'LLEGO AL LIMITE POR DIA';
        POUT_ERROR_CODE := -1;
      ELSE
        IF (P_COUNT_LIMIT_CYCLE >= NVL(P_LIMIT_AMOUNT_CYCLE, 9999)) AND
           (trunc(V_LAST_ACTION_DATE) >= trunc(V_START_CYCLE)) THEN
          POUT_SMS_ID     := 'LIMIT_CYCLE';
          POUT_ERROR_TEXT := 'LLEGO AL LIMITE POR CICLO';
          POUT_ERROR_CODE := -2;
        ELSE
          POUT_ERROR_TEXT := 'Puede realizar recompra';
          POUT_ERROR_CODE := 0;
        END IF;
      END IF;
    ELSE
      POUT_ERROR_CODE := 0;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      POUT_SMS_ID     := 'ERROR_DATA';
      POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC || '-->' || SQLERRM;
      POUT_ERROR_CODE := SQLCODE;
  END P_VALIDATE_LIMIT_ACTION_SS;

  /*--------------------------------------------------------------------------------------------------*/

  PROCEDURE P_GET_TN3_SIZE(P_CELLULAR_NUMBER    IN S_CELLULARS.clu_cellular_number%TYPE,
                           POUT_REPURCHASE_SIZE OUT S_SERVICE_PACK_PARAMETERS.sep_units_in%TYPE,
                           POUT_MAIN_SIZE       OUT S_SERVICE_PACK_PARAMETERS.sep_units_in%TYPE,
                           POUT_SMS_ID          OUT VARCHAR2,
                           POUT_ERROR_TEXT      OUT VARCHAR2,
                           POUT_ERROR_CODE      OUT NUMBER) IS
    V_ERROR_DESC VARCHAR2(1000) := '';
  BEGIN
    V_ERROR_DESC := 'P_GET_TN3_SIZE(' || P_CELLULAR_NUMBER || ')';
    -- Busca en la tabla de prepago las unidades que le corresponden al PACK.
    SELECT NVL(SPP.sep_units_repurchase, SPP.sep_units_in),
           SPP.sep_units_in
      INTO POUT_REPURCHASE_SIZE, POUT_MAIN_SIZE
      FROM S_SERVICE_PACK_PARAMETERS SPP, S_CELLULAR_PACKAGES CP
     WHERE sep_pkt_id = CP.cpk_pkt_id
       AND SPP.sep_gspr_id = '8'
       AND SYSDATE BETWEEN SPP.sep_start_date AND
           NVL(SPP.sep_end_date, SYSDATE + 1)
       AND SYSDATE BETWEEN CP.cpk_activation_date AND
           NVL(CP.cpk_canceled_date, SYSDATE + 1)
       AND CP.cpk_clu_cellular_number = P_CELLULAR_NUMBER;
    POUT_ERROR_CODE := 0;
    POUT_ERROR_TEXT := 'OK: ' || V_ERROR_DESC;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      POUT_SMS_ID     := 'ERROR_DATA';
      POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC || '-->' || SQLERRM;
      POUT_ERROR_CODE := -1;
    WHEN OTHERS THEN
      POUT_SMS_ID     := 'ERROR_DATA';
      POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC || '-->' || SQLERRM;
      POUT_ERROR_CODE := SQLCODE;
  END P_GET_TN3_SIZE;

  /***************************************************************************************************************/
  /*Obtiene el Cliclo de la cuenta*/
  /***************************************************************************************************************/
  PROCEDURE P_GET_CYCLE_ACCOUNT(P_CELLULAR_NUMBER IN S_CELLULARS.clu_cellular_number%TYPE,
                                P_START_CYCLE     OUT DATE,
                                P_END_CYCLE       OUT DATE,
                                POUT_SMS_ID       OUT VARCHAR2,
                                POUT_ERROR_TEXT   OUT VARCHAR2,
                                POUT_ERROR_CODE   OUT NUMBER) IS
    V_ERROR_DESC VARCHAR2(1000) := '';
  BEGIN
    V_ERROR_DESC := 'P_GET_CYCLE_ACCOUNT(' || P_CELLULAR_NUMBER || ')';
    SELECT SCH.sch_start_date, SCH.sch_end_date
      INTO P_START_CYCLE, P_END_CYCLE
      FROM S_SCHEDULERS SCH, S_CYCLE_STATUS CYS, S_CELLULARS CLU
     WHERE SCH.sch_cyc_id = CYS.cst_cyc_id
       AND CYS.cst_acc_id = clu.clu_acc_id
       AND TRUNC(SYSDATE) BETWEEN SCH.sch_start_date AND
           NVL(SCH.sch_end_date, SYSDATE + 1)
       AND SYSDATE BETWEEN CYS.cst_start_date AND
           NVL(CYS.cst_end_date, SYSDATE + 1)
       AND clu.clu_cellular_number = P_CELLULAR_NUMBER;
    POUT_ERROR_CODE := 0;
    POUT_ERROR_TEXT := 'OK: ' || V_ERROR_DESC;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      POUT_SMS_ID     := 'ERROR_DATA';
      POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC || '-->' || SQLERRM;
      POUT_ERROR_CODE := -20110;
    WHEN OTHERS THEN
      POUT_SMS_ID     := 'ERROR_DATA';
      POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC || '-->' || SQLERRM;
      POUT_ERROR_CODE := SQLCODE;
  END P_GET_CYCLE_ACCOUNT;

  /***************************************************************************************************************/
  /*Obtiene Las cantidad de acciones realizadas */
  /***************************************************************************************************************/
  PROCEDURE P_GET_COUNT_LIMIT_ACTION_SS(P_CELLULAR_NUMBER      IN S_CELLULARS.clu_cellular_number%TYPE,
                                        P_SPECIAL_SERVICE_ID   IN S_SS_SPECIAL_SERVICE_PROFILE.ssp_special_service_id%TYPE,
                                        P_ACTION_SERVICE_ID    IN S_SS_ACTION_SPECIAL_SERVICE.ase_action_service_id%TYPE,
                                        POUT_FIND_DATA         OUT VARCHAR2,
                                        POUT_ROWID             OUT ROWID,
                                        POUT_COUNT_LIMIT_DAY   OUT S_SS_COUNT_LIMIT_ACTION.cla_count_limit_day%TYPE,
                                        POUT_COUNT_LIMIT_CYCLE OUT S_SS_COUNT_LIMIT_ACTION.cla_count_limit_cycle%TYPE,
                                        POUT_LAST_ACTION_DATE  OUT S_SS_COUNT_LIMIT_ACTION.cla_last_action_date%TYPE,
                                        POUT_SIZE_BUYED        OUT VARCHAR2,
                                        POUT_UNIT_BUYED        OUT S_SS_COUNT_LIMIT_ACTION.cla_volume_unit%TYPE,
                                        POUT_DIA_HOY           OUT NUMBER,
                                        POUT_DIA_LAST_UPDATE   OUT NUMBER,
                                        POUT_SMS_ID            OUT VARCHAR2,
                                        POUT_ERROR_TEXT        OUT VARCHAR2,
                                        POUT_ERROR_CODE        OUT NUMBER) IS
    V_ERROR_DESC VARCHAR2(1000) := '';
  BEGIN
    V_ERROR_DESC := 'P_GET_COUNT_LIMIT_ACTION_SS(' || P_CELLULAR_NUMBER || ',' ||
                    P_SPECIAL_SERVICE_ID || ',' || P_ACTION_SERVICE_ID || ')';
    SELECT ROWID,
           CLA.cla_count_limit_day,
           CLA.cla_count_limit_cycle,
           CLA.cla_last_action_date,
           CLA.cla_volume,
           CLA.cla_volume_unit,
           TO_CHAR(SYSDATE, 'DD'),
           TO_CHAR(CLA.cla_last_action_date, 'DD')
      INTO POUT_ROWID,
           POUT_COUNT_LIMIT_DAY,
           POUT_COUNT_LIMIT_CYCLE,
           POUT_LAST_ACTION_DATE,
           POUT_SIZE_BUYED,
           POUT_UNIT_BUYED,
           POUT_DIA_HOY,
           POUT_DIA_LAST_UPDATE
      FROM S_SS_COUNT_LIMIT_ACTION CLA
     WHERE CLA.cla_cellular_number = P_CELLULAR_NUMBER
       AND CLA.cla_special_service_id = P_SPECIAL_SERVICE_ID
       AND CLA.cla_action_service_id = P_ACTION_SERVICE_ID
       AND SYSDATE BETWEEN CLA.cla_start_date AND
           NVL(CLA.cla_end_date, SYSDATE + 1);
    POUT_FIND_DATA  := 'Y';
    POUT_ERROR_CODE := 0;
    POUT_ERROR_TEXT := 'OK: ' || V_ERROR_DESC;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      POUT_ROWID             := '0';
      POUT_ERROR_CODE        := 0;
      POUT_ERROR_TEXT        := 'OK: ' || V_ERROR_DESC;
      POUT_FIND_DATA         := 'N';
      POUT_COUNT_LIMIT_DAY   := 0;
      POUT_COUNT_LIMIT_CYCLE := 0;
      POUT_LAST_ACTION_DATE  := SYSDATE;
      POUT_DIA_HOY           := TO_CHAR(SYSDATE, 'DD');
      POUT_DIA_LAST_UPDATE   := TO_CHAR(SYSDATE, 'DD');
    WHEN OTHERS THEN
      POUT_SMS_ID     := 'ERROR_DATA';
      POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC || '-->' || SQLERRM;
      POUT_ERROR_CODE := SQLCODE;
      POUT_FIND_DATA  := 'N';
  END P_GET_COUNT_LIMIT_ACTION_SS;

  /*--------------------------------------------------------------------------------------------------------*/

  PROCEDURE P_LIMIT_ACTION_INFORMATION(P_CELLULAR_NUMBER    IN S_CELLULARS.clu_cellular_number%TYPE,
                                       P_SPECIAL_SERVICE_ID IN S_SS_SPECIAL_SERVICE_PROFILE.ssp_special_service_id%TYPE,
                                       P_ACTION_SERVICE_ID  IN S_SS_ACTION_SPECIAL_SERVICE.ase_action_service_id%TYPE,
                                       P_LIMIT_AMOUNT_CYCLE IN S_SS_SPECIAL_SERVICE_PROFILE.ssp_limit_amount_per_cycle%TYPE,
                                       P_LIMIT_AMOUNT_DAY   IN S_SS_SPECIAL_SERVICE_PROFILE.ssp_limit_amount_per_day%TYPE,
                                       P_COUNT_LIMIT_DAY    OUT NUMBER,
                                       P_COUNT_LIMIT_CYCLE  OUT NUMBER,
                                       P_SIZE_BUYED         OUT NUMBER,
                                       P_UNIT_BUYED         OUT VARCHAR2,
                                       POUT_SMS_ID          OUT VARCHAR2,
                                       POUT_ERROR_TEXT      OUT VARCHAR2,
                                       POUT_ERROR_CODE      OUT NUMBER) IS
    V_ERROR_DESC       VARCHAR2(1000) := '';
    V_START_CYCLE      DATE;
    V_END_CYCLE        DATE;
    V_ROWID            ROWID;
    V_LAST_ACTION_DATE DATE;
    V_DIA_HOY          NUMBER;
    V_DIA_LAST_UPDATE  NUMBER;
    V_SIZE             VARCHAR2(50);
    V_FIND_DATA        VARCHAR2(1) := 'N';
  BEGIN
    V_ERROR_DESC := 'P_LIMIT_ACTION_INFORMATION(' || P_CELLULAR_NUMBER || ',' ||
                    P_SPECIAL_SERVICE_ID || ',' || P_ACTION_SERVICE_ID || ',' ||
                    P_LIMIT_AMOUNT_CYCLE || ',' || P_LIMIT_AMOUNT_DAY || ')';
    P_GET_CYCLE_ACCOUNT(P_CELLULAR_NUMBER => P_CELLULAR_NUMBER,
                        P_START_CYCLE     => V_START_CYCLE,
                        P_END_CYCLE       => V_END_CYCLE,
                        POUT_SMS_ID       => POUT_SMS_ID,
                        POUT_ERROR_TEXT   => POUT_ERROR_TEXT,
                        POUT_ERROR_CODE   => POUT_ERROR_CODE);
    IF POUT_ERROR_CODE <> 0 THEN
      RETURN;
    END IF;
    P_GET_COUNT_LIMIT_ACTION_SS(P_CELLULAR_NUMBER      => P_CELLULAR_NUMBER,
                                P_SPECIAL_SERVICE_ID   => P_SPECIAL_SERVICE_ID,
                                P_ACTION_SERVICE_ID    => P_ACTION_SERVICE_ID,
                                POUT_FIND_DATA         => V_FIND_DATA,
                                POUT_ROWID             => V_ROWID,
                                POUT_COUNT_LIMIT_DAY   => P_COUNT_LIMIT_DAY,
                                POUT_COUNT_LIMIT_CYCLE => P_COUNT_LIMIT_CYCLE,
                                POUT_LAST_ACTION_DATE  => V_LAST_ACTION_DATE,
                                POUT_SIZE_BUYED        => V_SIZE,
                                POUT_UNIT_BUYED        => P_UNIT_BUYED,
                                POUT_DIA_HOY           => V_DIA_HOY,
                                POUT_DIA_LAST_UPDATE   => V_DIA_LAST_UPDATE,
                                POUT_SMS_ID            => POUT_SMS_ID,
                                POUT_ERROR_TEXT        => POUT_ERROR_TEXT,
                                POUT_ERROR_CODE        => POUT_ERROR_CODE);
    IF POUT_ERROR_CODE <> 0 THEN
      RETURN;
    END IF;

    IF(V_SIZE IS NOT NULL) then
    BEGIN
    P_SIZE_BUYED := to_number(v_size);
    exception when others then
      if(v_size like '%,%' ) then
                P_SIZE_BUYED := to_number(replace(v_size, ',','.'));
      else
                P_SIZE_BUYED := to_number(replace(v_size, '.',','));
        end if;
    END;
    end if;

    IF V_FIND_DATA = 'Y' OR V_ROWID = '0' THEN
      IF (P_COUNT_LIMIT_DAY >= NVL(P_LIMIT_AMOUNT_DAY, 9999)) AND
         (trunc(SYSDATE) = trunc(V_LAST_ACTION_DATE)) THEN
        POUT_SMS_ID     := 'LIMIT_DAY';
        POUT_ERROR_TEXT := 'LLEGO AL LIMITE POR DIA';
        POUT_ERROR_CODE := -1;
      ELSE
        IF (P_COUNT_LIMIT_CYCLE >= NVL(P_LIMIT_AMOUNT_CYCLE, 9999)) AND
           (trunc(V_LAST_ACTION_DATE) >= trunc(V_START_CYCLE)) THEN
          POUT_SMS_ID     := 'LIMIT_CYCLE';
          POUT_ERROR_TEXT := 'LLEGO AL LIMITE POR CICLO';
          POUT_ERROR_CODE := -2;
        ELSE
          POUT_ERROR_TEXT := 'Puede realizar recompra';
          POUT_ERROR_CODE := 0;
        END IF;
      END IF;
    ELSE
      POUT_ERROR_CODE := 0;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      POUT_SMS_ID     := 'ERROR_DATA';
      POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC || '-->' || SQLERRM;
      POUT_ERROR_CODE := SQLCODE;
  END P_LIMIT_ACTION_INFORMATION;

  /* --------------------------------- NEW PROCEDURES FOR MULTIPLE OPTIONS REPURCHASE -------------------------*/

  /*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

  PROCEDURE P_GET_SERVICE_DATA_MULT(P_CELLULAR_NUMBER            IN S_CELLULARS.CLU_CELLULAR_NUMBER%TYPE,
                                    P_CELLULAR_CATEGORY          IN S_CLIENT.Clt_Category%TYPE,
                                    P_CELLULAR_TYPE              IN S_CLIENT.Clt_Type%TYPE,
                                    P_CELLULAR_CBT_ID            IN S_CELLULARS.Clu_Cbt_Id%TYPE,
                                    P_CELLULAR_RPL_ID            IN S_RATE_PLANS.RPL_RPL_ID%TYPE,
                                    P_CELLULAR_RPL_RTY_ID        IN S_RATE_PLANS.RPL_RTY_ID%TYPE,
                                    P_MCC                        IN S_SS_ROAMING_GROUPS.SRG_COP_MCC_ID%TYPE,
                                    P_MNC                        IN S_SS_ROAMING_GROUPS.SRG_COP_MNC_ID%TYPE,
                                    P_TYPE_SERVICE_STR           IN S_SS_ACTION_SPECIAL_SERVICE.ase_type_of_service%TYPE, -- Siempre es DATOS
                                    P_KEYWORD                    IN VARCHAR2,
                                    P_CHANNEL                    IN VARCHAR2,
                                    P_SPECIAL_SERVICE_ID         OUT VARCHAR2,
                                    P_ACTION_SERVICE_ID          OUT VARCHAR2,
                                    P_SSP_EXCHANGE_RATE          OUT VARCHAR2,
                                    P_BUY_COST                   OUT VARCHAR2,
                                    P_SSP_LIMIT_AMOUNT_PER_CYCLE OUT VARCHAR2,
                                    P_SSP_LIMIT_AMOUNT_PER_DAY   OUT VARCHAR2,
                                    P_SSP_APPLIES_ROAMING_GROUPS OUT VARCHAR2,
                                    P_SSP_CAPACITY_OPTION_ID     OUT VARCHAR2,
                                    P_SSP_VOLUME                 OUT VARCHAR2,
                                    P_SSP_VOLUME_UNITY           OUT VARCHAR2,
                                    P_SSP_ORIGEN_CHANNEL         OUT VARCHAR2,
                                    POUT_SMS_ID                  OUT VARCHAR2,
                                    POUT_ERROR_TEXT              OUT VARCHAR2,
                                    POUT_ERROR_CODE              OUT NUMBER) IS

    V_ASE_ACTION_SERVICE_ID S_SS_ACTION_SPECIAL_SERVICE.ASE_ACTION_SERVICE_ID%TYPE;
    V_ERROR_DESC            VARCHAR2(1000) := '';

  BEGIN
    BEGIN
      V_ERROR_DESC := 'P_GET_ACTION_SPECIAL_SERVICE(' || P_KEYWORD || ')';
      SELECT ASE_ACTION_SERVICE_ID
        INTO V_ASE_ACTION_SERVICE_ID
        FROM S_SS_ACTION_SPECIAL_SERVICE ASE
       WHERE ASE.ASE_KEYWORD = P_KEYWORD;
      POUT_ERROR_CODE := 0;
      POUT_ERROR_TEXT := 'OK: ' || V_ERROR_DESC;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        POUT_SMS_ID     := 'INVALID_KEYWORD';
        POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC ||
                           '--> KEYWORD No Encontrado';
        POUT_ERROR_CODE := -20180;
      WHEN OTHERS THEN
        POUT_SMS_ID     := 'ERROR_DATA';
        POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC || '-->' || SQLERRM;
        POUT_ERROR_CODE := SQLCODE;
    END;
    P_ACTION_SERVICE_ID := V_ASE_ACTION_SERVICE_ID;
    V_ERROR_DESC        := 'P_GET_SPECIAL_SERVICE_DATA(' ||
                           P_CELLULAR_NUMBER || ',' || P_SPECIAL_SERVICE_ID || ',' ||
                           P_CELLULAR_CATEGORY || ',' || P_CELLULAR_TYPE || ',' ||
                           P_CELLULAR_CBT_ID || ',' || P_CELLULAR_RPL_ID || ',' ||
                           P_CELLULAR_RPL_RTY_ID || ',' || P_MCC || ',' ||
                           P_MNC || ')';
    /*Busca el Servicio Especial asociado a la linea*/
    P_GET_SPEC_SERV_ASSOCIATE(P_CELLULAR_NUMBER       => P_CELLULAR_NUMBER,
                              P_RPL_ID                => P_CELLULAR_RPL_ID,
                              P_RPL_RTY_ID            => P_CELLULAR_RPL_RTY_ID,
                              P_TYPE_SERVICE_STR      => P_TYPE_SERVICE_STR,
                              POUT_SPECIAL_SERVICE_ID => P_SPECIAL_SERVICE_ID,
                              POUT_SMS_ID             => POUT_SMS_ID,
                              POUT_ERROR_TEXT         => POUT_ERROR_TEXT,
                              POUT_ERROR_CODE         => POUT_ERROR_CODE);
    IF POUT_ERROR_CODE <> 0 THEN
      POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC || CHR(13) ||
                         POUT_ERROR_TEXT;
      RETURN;
    END IF;
    /*Busca los datos de la la accion para el servicio especial de la linea*/
    /*CAMBIAR*/
    P_GET_SPEC_MULT(P_SPECIAL_SERVICE_ID         => P_SPECIAL_SERVICE_ID,
                    P_ACTION_SERVICE_ID          => P_ACTION_SERVICE_ID,
                    P_CATEGORY_REAL              => P_CELLULAR_CATEGORY,
                    P_TYPE_REAL                  => P_CELLULAR_TYPE,
                    P_CBT_ID_REAL                => P_CELLULAR_CBT_ID,
                    P_MCC                        => P_MCC,
                    P_MNC                        => P_MNC,
                    P_CHANNEL                    => P_CHANNEL,
                    P_SSP_EXCHANGE_RATE          => P_SSP_EXCHANGE_RATE,
                    P_BUY_COST                   => P_BUY_COST,
                    P_SSP_LIMIT_AMOUNT_PER_CYCLE => P_SSP_LIMIT_AMOUNT_PER_CYCLE,
                    P_SSP_LIMIT_AMOUNT_PER_DAY   => P_SSP_LIMIT_AMOUNT_PER_DAY,
                    P_SSP_APPLIES_ROAMING_GROUPS => P_SSP_APPLIES_ROAMING_GROUPS,
                    P_SSP_CAPACITY_OPTION_ID     => P_SSP_CAPACITY_OPTION_ID,
                    P_SSP_VOLUME                 => P_SSP_VOLUME,
                    P_SSP_VOLUME_UNITY           => P_SSP_VOLUME_UNITY,
                    P_SSP_ORIGEN_CHANNEL         => P_SSP_ORIGEN_CHANNEL,
                    POUT_SMS_ID                  => POUT_SMS_ID,
                    POUT_ERROR_TEXT              => POUT_ERROR_TEXT,
                    POUT_ERROR_CODE              => POUT_ERROR_CODE);
    IF POUT_ERROR_CODE <> 0 THEN
      POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC || CHR(13) ||
                         POUT_ERROR_TEXT;
      RETURN;
    END IF;
    POUT_ERROR_CODE := 0;
    POUT_ERROR_TEXT := 'OK: ' || V_ERROR_DESC;
  EXCEPTION
    WHEN OTHERS THEN
      POUT_SMS_ID     := 'ERROR_DATA';
      POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC || '-->' || SQLERRM ||
                         CHR(13);
      POUT_ERROR_CODE := SQLCODE;

  END P_GET_SERVICE_DATA_MULT;

  /*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

  PROCEDURE P_GET_SPEC_MULT(P_SPECIAL_SERVICE_ID         IN S_SS_SPECIAL_SERVICE_PROFILE.SSP_SPECIAL_SERVICE_ID%TYPE,
                            P_ACTION_SERVICE_ID          IN S_SS_ACTION_SPECIAL_SERVICE.ASE_ACTION_SERVICE_ID%TYPE,
                            P_CATEGORY_REAL              IN S_CLIENT.Clt_Category%TYPE,
                            P_TYPE_REAL                  IN S_CLIENT.Clt_Type%TYPE,
                            P_CBT_ID_REAL                IN S_CELLULARS.Clu_Cbt_Id%TYPE,
                            P_MCC                        IN VARCHAR2,
                            P_MNC                        IN VARCHAR2,
                            P_CHANNEL                    IN VARCHAR2,
                            P_SSP_EXCHANGE_RATE          OUT VARCHAR2,
                            P_BUY_COST                   OUT VARCHAR2,
                            P_SSP_LIMIT_AMOUNT_PER_CYCLE OUT VARCHAR2,
                            P_SSP_LIMIT_AMOUNT_PER_DAY   OUT VARCHAR2,
                            P_SSP_APPLIES_ROAMING_GROUPS OUT VARCHAR2,
                            P_SSP_CAPACITY_OPTION_ID     OUT VARCHAR2,
                            P_SSP_VOLUME                 OUT VARCHAR2,
                            P_SSP_VOLUME_UNITY           OUT VARCHAR2,
                            P_SSP_ORIGEN_CHANNEL         OUT VARCHAR2,
                            POUT_SMS_ID                  OUT VARCHAR2,
                            POUT_ERROR_TEXT              OUT VARCHAR2,
                            POUT_ERROR_CODE              OUT NUMBER) IS
    V_CATEGORY                   S_CLIENT.Clt_Category%TYPE;
    V_TYPE                       S_CLIENT.Clt_Type%TYPE;
    V_CBT_ID                     S_CELLULARS.Clu_Cbt_Id%TYPE;
    V_FIND_DATA                  VARCHAR2(1) := 'N';
    V_ERROR_DESC                 VARCHAR2(1000) := '';
    V_ERROR_CODE                 NUMBER := 0;
    V_SSP_EXCHANGE_RATE          S_SS_SPECIAL_SERVICE_PROFILE.SSP_EXCHANGE_RATE%TYPE;
    V_CHARGE_VALUE_W_OUT_TAXES   S_SS_SPECIAL_SERVICE_PROFILE.SSP_CHARGE_VALUE_WITHOUT_TAXES%TYPE;
    V_CHARGE_VALUE_W_TAXES       S_SS_SPECIAL_SERVICE_PROFILE.SSP_CHARGE_VALUE_WITH_TAXES%TYPE;
    V_SSP_LIMIT_AMOUNT_PER_CYCLE S_SS_SPECIAL_SERVICE_PROFILE.SSP_LIMIT_AMOUNT_PER_CYCLE%TYPE;
    V_SSP_LIMIT_AMOUNT_PER_DAY   S_SS_SPECIAL_SERVICE_PROFILE.SSP_LIMIT_AMOUNT_PER_DAY%TYPE;
    V_SSP_APPLIES_ROAMING_GROUPS S_SS_SPECIAL_SERVICE_PROFILE.SSP_APPLIES_ROAMING_GROUPS%TYPE;
    V_SSP_CLT_TYPE               S_SS_SPECIAL_SERVICE_PROFILE.SSP_CLT_TYPE%TYPE;
    V_SSP_CLT_CATEGORY           S_SS_SPECIAL_SERVICE_PROFILE.SSP_CLT_CATEGORY%TYPE;
    V_SSP_CAPACITY_OPTION_ID     S_SS_SPECIAL_SERVICE_PROFILE.SSP_CAPACITY_OPTION_ID%TYPE;
    V_SSP_VOLUME                 S_SS_SPECIAL_SERVICE_PROFILE.SSP_VOLUME%TYPE;
    V_SSP_VOLUME_UNITY           S_SS_SPECIAL_SERVICE_PROFILE.SSP_VOLUME_UNITY%TYPE;
    V_SSP_ORIGEN_CHANNEL         S_SS_SPECIAL_SERVICE_PROFILE.SSP_ORIGEN_CHANNEL%TYPE;

    CURSOR OPTIONS_REPURCHASE(P_SPECIAL_SERVICE_ID S_SS_SPECIAL_SERVICE_PROFILE.ssp_special_service_id%TYPE,
                              P_ACTION_SERVICE_ID  S_SS_SPECIAL_SERVICE_PROFILE.ssp_ase_action_service_id%TYPE,
                              P_CATEGORY_SEARCH    S_SS_SPECIAL_SERVICE_PROFILE.ssp_clt_category%TYPE,
                              P_TYPE_SEARCH        S_SS_SPECIAL_SERVICE_PROFILE.ssp_clt_type%TYPE,
                              P_CBT_ID_SEARCH      S_SS_SPECIAL_SERVICE_PROFILE.ssp_clu_cbt_id%TYPE) IS
      SELECT SSP.Ssp_Exchange_Rate,
             ssp.ssp_charge_value_without_taxes,
             ssp.ssp_charge_value_with_taxes,
             ssp.ssp_limit_amount_per_cycle,
             ssp.ssp_limit_amount_per_day,
             ssp.ssp_applies_roaming_groups,
             ssp.SSP_CLT_TYPE,
             ssp.SSP_CLT_CATEGORY,
             ssp.SSP_CAPACITY_OPTION_ID,
             to_char(ssp.SSP_VOLUME),
             ssp.SSP_VOLUME_UNITY,
             ssp.SSP_ORIGEN_CHANNEL
        FROM S_SS_SPECIAL_SERVICE_PROFILE SSP
       WHERE SSP.ssp_special_service_id = P_SPECIAL_SERVICE_ID
         AND SSP.ssp_ase_action_service_id = P_ACTION_SERVICE_ID
         AND SSP.ssp_clt_category = P_CATEGORY_SEARCH
         AND SSP.ssp_clt_type = P_TYPE_SEARCH
         AND SSP.ssp_clu_cbt_id = P_CBT_ID_SEARCH
         AND (SSP.SSP_ORIGEN_CHANNEL LIKE '%*%' or
             UPPER(SSP_ORIGEN_CHANNEL) LIKE '%' || UPPER(P_CHANNEL) || '%')
         AND SYSDATE BETWEEN SSP.ssp_start_date AND
             NVL(SSP.ssp_end_date, SYSDATE + 1);

  BEGIN
    P_SSP_LIMIT_AMOUNT_PER_CYCLE := '0';
    P_SSP_LIMIT_AMOUNT_PER_DAY   := '0';
    V_ERROR_DESC                 := 'P_GET_SPEC_SERV_PARAMETERS(' ||
                                    P_SPECIAL_SERVICE_ID || ',' ||
                                    P_ACTION_SERVICE_ID || ',' ||
                                    P_CATEGORY_REAL || ',' || P_TYPE_REAL || ',' ||
                                    P_CBT_ID_REAL || ')';
    -- Establece el orden de prioridad de busqueda que esta cargado en la tabla SS_SEARCH_ORDER
    FOR item IN (SELECT FO.sor_clt_category,
                        FO.sor_clt_type,
                        FO.sor_clu_cbt_id
                   FROM S_SS_SEARCH_ORDER FO
                  WHERE FO.SOR_SOURCE = 'SS_SPECIAL_SERVICE_PROFILE'
                  ORDER BY FO.SOR_ORDER) LOOP
      IF ITEM.SOR_CLT_CATEGORY = 'VALOR' THEN
        V_CATEGORY := P_CATEGORY_REAL;
      ELSE
        V_CATEGORY := ITEM.SOR_CLT_CATEGORY;
      END IF;
      IF ITEM.SOR_CLT_TYPE = 'VALOR' THEN
        V_TYPE := P_TYPE_REAL;
      ELSE
        V_TYPE := ITEM.SOR_CLT_TYPE;
      END IF;
      IF ITEM.SOR_CLU_CBT_ID = 'VALOR' THEN
        V_CBT_ID := P_CBT_ID_REAL;
      ELSE
        V_CBT_ID := ITEM.SOR_CLU_CBT_ID;
      END IF;
      OPEN OPTIONS_REPURCHASE(P_SPECIAL_SERVICE_ID,
                              P_ACTION_SERVICE_ID,
                              V_CATEGORY,
                              V_TYPE,
                              V_CBT_ID);
      LOOP
        FETCH OPTIONS_REPURCHASE
          INTO V_SSP_EXCHANGE_RATE,
               V_CHARGE_VALUE_W_OUT_TAXES,
               V_CHARGE_VALUE_W_TAXES,
               V_SSP_LIMIT_AMOUNT_PER_CYCLE,
               V_SSP_LIMIT_AMOUNT_PER_DAY,
               V_SSP_APPLIES_ROAMING_GROUPS,
               V_SSP_CLT_TYPE,
               V_SSP_CLT_CATEGORY,
               V_SSP_CAPACITY_OPTION_ID,
               V_SSP_VOLUME,
               V_SSP_VOLUME_UNITY,
               V_SSP_ORIGEN_CHANNEL;

        EXIT WHEN OPTIONS_REPURCHASE%NOTFOUND;
        V_ERROR_CODE := 0;
        V_ERROR_DESC := '';
        IF V_SSP_APPLIES_ROAMING_GROUPS = 'Y' THEN
          P_GET_RE_CHARGE_MULT(P_MCC                      => P_MCC,
                               P_MNC                      => P_MNC,
                               P_SPECIAL_SERVICE_ID       => P_SPECIAL_SERVICE_ID,
                               P_ASE_ACTION_SERVICE_ID    => P_ACTION_SERVICE_ID,
                               P_SSP_CLT_TYPE             => P_TYPE_REAL,
                               P_CELLULAR_CBT_ID          => P_CBT_ID_REAL,
                               P_SSP_EXCHANGE_RATE        => V_SSP_EXCHANGE_RATE,
                               P_CHARGE_VALUE_W_OUT_TAXES => V_CHARGE_VALUE_W_OUT_TAXES,
                               P_CHARGE_VALUE_W_TAXES     => V_CHARGE_VALUE_W_TAXES,
                               POUT_SMS_ID                => POUT_SMS_ID,
                               POUT_ERROR_TEXT            => V_ERROR_DESC,
                               POUT_ERROR_CODE            => V_ERROR_CODE);
          IF V_ERROR_CODE <> 0 THEN
            V_ERROR_DESC := 'ERROR:' || V_ERROR_DESC || CHR(13) ||
                            V_ERROR_DESC;
          END IF;
        END IF;

        IF V_SSP_EXCHANGE_RATE = 'DOLARES' AND V_ERROR_CODE = 0 THEN
          P_GET_PESOS_DOLAR(POUT_CHARGE_VALUE_WITH_TAXES => V_CHARGE_VALUE_W_TAXES,
                            POUT_CHARGE_VALUE_WITHOUT_T  => V_CHARGE_VALUE_W_OUT_TAXES,
                            POUT_SMS_ID                  => POUT_SMS_ID,
                            POUT_ERROR_TEXT              => V_ERROR_DESC,
                            POUT_ERROR_CODE              => V_ERROR_CODE);
          V_SSP_EXCHANGE_RATE := 'PESOS';
          IF V_ERROR_CODE <> 0 THEN
            V_ERROR_DESC := 'ERROR:' || V_ERROR_DESC || CHR(13) ||
                            V_ERROR_DESC;
          END IF;
        END IF;

        IF V_ERROR_CODE = 0 THEN
          /*---------- CONCATENO LOS RESULTADOS --------*/
          IF V_SSP_EXCHANGE_RATE is null THEN
            V_SSP_EXCHANGE_RATE := ' ';
          END IF;
          P_SSP_EXCHANGE_RATE := P_SSP_EXCHANGE_RATE || V_SSP_EXCHANGE_RATE || '##';

          IF V_CHARGE_VALUE_W_TAXES is not null and
             V_CHARGE_VALUE_W_TAXES > 0 THEN
            P_BUY_COST := P_BUY_COST || V_CHARGE_VALUE_W_TAXES || '##';
          ELSIF V_CHARGE_VALUE_W_OUT_TAXES is not null THEN
            P_BUY_COST := P_BUY_COST || V_CHARGE_VALUE_W_OUT_TAXES || '##';
          ELSE
            P_BUY_COST := P_BUY_COST || ' ##';
          END IF;

          IF V_SSP_LIMIT_AMOUNT_PER_CYCLE is not null AND
             (TO_NUMBER(V_SSP_LIMIT_AMOUNT_PER_CYCLE) >
             TO_NUMBER(P_SSP_LIMIT_AMOUNT_PER_CYCLE)) THEN
            P_SSP_LIMIT_AMOUNT_PER_CYCLE := V_SSP_LIMIT_AMOUNT_PER_CYCLE;
          END IF;

          IF V_SSP_LIMIT_AMOUNT_PER_DAY is not null AND
             (TO_NUMBER(V_SSP_LIMIT_AMOUNT_PER_DAY) >
             TO_NUMBER(P_SSP_LIMIT_AMOUNT_PER_DAY)) THEN
            P_SSP_LIMIT_AMOUNT_PER_DAY := V_SSP_LIMIT_AMOUNT_PER_DAY;
          END IF;
          IF V_SSP_APPLIES_ROAMING_GROUPS is null THEN
            V_SSP_APPLIES_ROAMING_GROUPS := ' ';
          END IF;
          P_SSP_APPLIES_ROAMING_GROUPS := P_SSP_APPLIES_ROAMING_GROUPS ||
                                          V_SSP_APPLIES_ROAMING_GROUPS || '##';

          IF V_SSP_CAPACITY_OPTION_ID is null THEN
            V_SSP_CAPACITY_OPTION_ID := ' ';
          END IF;
          P_SSP_CAPACITY_OPTION_ID := P_SSP_CAPACITY_OPTION_ID ||
                                      V_SSP_CAPACITY_OPTION_ID || '##';

          IF V_SSP_VOLUME is not null THEN
            P_SSP_VOLUME := P_SSP_VOLUME ||
                            TO_CHAR(V_SSP_VOLUME,
                                    'FM99990D09999999999999999') || '##';
          ELSE
            P_SSP_VOLUME := P_SSP_VOLUME || ' ##';
          END IF;

          IF V_SSP_VOLUME_UNITY is null THEN
            V_SSP_VOLUME_UNITY := ' ';
          END IF;
          P_SSP_VOLUME_UNITY := P_SSP_VOLUME_UNITY || V_SSP_VOLUME_UNITY || '##';

          IF V_SSP_ORIGEN_CHANNEL is null THEN
            V_SSP_ORIGEN_CHANNEL := ' ';
          END IF;
          P_SSP_ORIGEN_CHANNEL := P_SSP_ORIGEN_CHANNEL ||
                                  V_SSP_ORIGEN_CHANNEL || '##';
          V_FIND_DATA          := 'Y'; --- BANDERA QUE INDICA QUE SE REGISTRO UN DATO AL MENOS
        END IF;
        /*----------  /CONCATENO LOS RESULTADOS --------*/
      END LOOP;
      CLOSE OPTIONS_REPURCHASE;
      IF V_FIND_DATA = 'Y' THEN
        EXIT; -- Salgo del FOR por que se encontraron los datos y no es necesario seguir buscando
      END IF;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      POUT_SMS_ID     := 'ERROR_DATA';
      POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC || '-->' || SQLERRM ||
                         CHR(13) || POUT_ERROR_TEXT;
      POUT_ERROR_CODE := SQLCODE;
  END P_GET_SPEC_MULT;

  /*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

  PROCEDURE P_GET_RE_CHARGE_MULT(P_MCC                      IN S_SS_ROAMING_GROUPS.SRG_COP_MCC_ID%TYPE,
                                 P_MNC                      IN S_SS_ROAMING_GROUPS.SRG_COP_MNC_ID%TYPE,
                                 P_SPECIAL_SERVICE_ID       IN S_SS_SPECIAL_SERVICE_PROFILE.SSP_SPECIAL_SERVICE_ID%TYPE,
                                 P_ASE_ACTION_SERVICE_ID    IN S_SS_ACTION_SPECIAL_SERVICE.ASE_ACTION_SERVICE_ID%TYPE,
                                 P_SSP_CLT_TYPE             IN S_SS_SPECIAL_SERVICE_PROFILE.SSP_CLT_TYPE%TYPE,
                                 P_CELLULAR_CBT_ID          IN S_CELLULARS.Clu_Cbt_Id%TYPE,
                                 P_SSP_EXCHANGE_RATE        IN OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_EXCHANGE_RATE%TYPE,
                                 P_CHARGE_VALUE_W_OUT_TAXES IN OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_CHARGE_VALUE_WITHOUT_TAXES%TYPE,
                                 P_CHARGE_VALUE_W_TAXES     IN OUT S_SS_SPECIAL_SERVICE_PROFILE.SSP_CHARGE_VALUE_WITH_TAXES%TYPE,
                                 POUT_SMS_ID                OUT VARCHAR2,
                                 POUT_ERROR_TEXT            OUT VARCHAR2,
                                 POUT_ERROR_CODE            OUT NUMBER) IS
    V_MCC        S_SS_ROAMING_GROUPS.SRG_COP_MCC_ID%TYPE;
    V_MNC        S_SS_ROAMING_GROUPS.Srg_Cop_Mnc_Id%TYPE;
    V_FIND_DATA  VARCHAR2(1) := 'N';
    V_ERROR_DESC VARCHAR2(1000) := '';
  BEGIN
    V_ERROR_DESC := 'P_GET_RE_CHARGE_SPEC_SERV(' || P_MCC || ',' || P_MNC || ')';
    FOR i IN 1 .. 3 LOOP
      -- Opciones para Grupos de Roaming, Pais/Operadoa; Cualquier Operadora de un pais; todos los paises
      CASE i
        WHEN 1 THEN
          V_MCC := P_MCC;
          V_MNC := P_MNC;
        WHEN 2 THEN
          V_MCC := P_MCC;
          V_MNC := '*';
        WHEN 3 THEN
          V_MCC := '*';
          V_MNC := '*';
      END CASE;
      P_EXCE_PAYMENT_ROAMING(P_MCC                      => V_MCC,
                             P_MNC                      => V_MNC,
                             P_SPECIAL_SERVICE_ID       => P_SPECIAL_SERVICE_ID,
                             P_ASE_ACTION_SERVICE_ID    => P_ASE_ACTION_SERVICE_ID,
                             P_SSP_CLT_TYPE             => P_SSP_CLT_TYPE,
                             P_SSP_CLT_CATEGORY         => P_CELLULAR_CBT_ID,
                             P_CELLULAR_CBT_ID          => P_CELLULAR_CBT_ID,
                             P_SSP_EXCHANGE_RATE        => P_SSP_EXCHANGE_RATE,
                             P_CHARGE_VALUE_W_OUT_TAXES => P_CHARGE_VALUE_W_OUT_TAXES,
                             P_CHARGE_VALUE_W_TAXES     => P_CHARGE_VALUE_W_TAXES,
                             POUT_FIND_DATA             => V_FIND_DATA,
                             POUT_SMS_ID                => POUT_SMS_ID,
                             POUT_ERROR_TEXT            => POUT_ERROR_TEXT,
                             POUT_ERROR_CODE            => POUT_ERROR_CODE);
      IF POUT_ERROR_CODE = 0 THEN
        IF V_FIND_DATA = 'Y' THEN
          POUT_ERROR_TEXT := 'OK: ' || V_ERROR_DESC;
          EXIT; -- Salgo del FOR por que se encontro el registro que se buscaba
        END IF;
      END IF;
    END LOOP;
    IF V_FIND_DATA = 'N' THEN
      POUT_SMS_ID     := 'ERROR_ZONA_ROAMING';
      POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC ||
                         '--> No Se encontro un Grupo de Roaming para los Cargos';
      POUT_ERROR_CODE := -1;

    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC || '-->' || SQLERRM;
      POUT_ERROR_CODE := SQLCODE;
  END P_GET_RE_CHARGE_MULT;
  /*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

  PROCEDURE P_INTERNET_WEB_NAMES_MULT(P_CELLULAR_NUMBER          IN S_CELLULARS.clu_cellular_number%TYPE,
                                      POUT_FEATURE_ID            OUT S_FEATURES.ftr_id%TYPE,
                                      POUT_PACKAGE_ID            OUT S_PACKAGES.pkt_id%TYPE,
                                      POUT_PACKAGE_CYCLIC        OUT S_PACKAGES.Pkt_Cyclic%TYPE,
                                      POUT_MAIN_QUOTA_NAME       OUT VW_AUT_FEATURES_ASSOCIATIONS.CUSTOM2%TYPE,
                                      POUT_DAILY_QUOTA_NAME      OUT VW_AUT_FEATURES_ASSOCIATIONS.CUSTOM7%TYPE,
                                      POUT_ADDITIONAL_QUOTA_NAME OUT VW_AUT_FEATURES_ASSOCIATIONS.CUSTOM10%TYPE,
                                      POUT_SMS_ID                OUT VARCHAR2,
                                      POUT_ERROR_TEXT            OUT VARCHAR2,
                                      POUT_ERROR_CODE            OUT NUMBER) IS

    V_ERROR_DESC VARCHAR2(1000) := 'P_QUOTE_PACK(' || P_CELLULAR_NUMBER || ')';
  BEGIN
    select FP.pks_ftr_id,
           PK.pkt_id,
           PK.pkt_cyclic,
           fta.CUSTOM2,
           fta.CUSTOM7,
           fta.CUSTOM10
      INTO POUT_FEATURE_ID,
           POUT_PACKAGE_ID,
           POUT_PACKAGE_CYCLIC,
           POUT_MAIN_QUOTA_NAME,
           POUT_DAILY_QUOTA_NAME,
           POUT_ADDITIONAL_QUOTA_NAME
      from S_CELLULAR_PACKAGES          CP,
           S_PACKAGES                   PK,
           S_FEATURE_PACKAGES           FP,
           VW_AUT_FEATURES_ASSOCIATIONS FTA
     WHERE CP.cpk_pkt_id = FP.pks_pkt_id
       AND CP.CPK_PKT_ID = PK.PKT_ID
       AND fta.sfs_ftr_id = fp.pks_ftr_id
       AND CP.cpk_clu_cellular_number = P_CELLULAR_NUMBER
       AND fta.sfs_service = 'PCRF'
       AND 'EMBLACOM' NOT LIKE '%' || FTA.CUSTOM2 || '%' -- Para que no tome los que nos son de Datos como por ejemplo EMBLACOM
       AND SYSDATE BETWEEN CP.cpk_activation_date AND
           NVL(CP.cpk_canceled_date, SYSDATE + 1)
       AND ROWNUM = 1; -- Se toma el ROWNUM 1 por si llegan erroneamente a asgnar dos pack con feature de cuota a PCRF.
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      POUT_SMS_ID     := 'ERROR_DATA';
      POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC ||
                         '-->No se encontro PACK de datos controlado por PCRF';
      POUT_ERROR_CODE := SQLCODE;
      RETURN;
    WHEN OTHERS THEN
      POUT_SMS_ID     := 'ERROR_DATA';
      POUT_ERROR_TEXT := 'ERROR:' || V_ERROR_DESC || '-->' || SQLERRM;
      POUT_ERROR_CODE := SQLCODE;
      RETURN;
  END P_INTERNET_WEB_NAMES_MULT;

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
END PA_CONSUMPTION_INFORMATION;

/

