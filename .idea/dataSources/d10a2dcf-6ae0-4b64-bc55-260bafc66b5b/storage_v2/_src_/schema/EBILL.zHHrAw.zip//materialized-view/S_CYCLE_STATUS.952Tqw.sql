create materialized view S_CYCLE_STATUS
refresh fast on demand
  as
    SELECT cst_acc_id,
cst_cyc_id,
cst_start_date,
cst_tck_id,
cst_usr_id,
cst_end_date,
cst_add_date,
cst_last_update_date
from stl.cycle_status@prod
/

