create materialized view S_CELLULAR_BUSINESS_TYPES
refresh complete on demand
  as
    SELECT CBT_ID,
       CBT_DESCRIPTION,
       CBT_ACT_ID,
       CBT_RSN_ID,
       CBT_RPL_ID,
       CBT_PACKAGE_CANCELED_FLAG,
       CBT_RATE_PLAN_DATE,
       CBT_CELLULAR_DAYS,
       CBT_BUT_ID,
       CBT_ASSIGNMENT,
       CBT_DELIVERY,
       CBT_PROCESS_CIBER,
       CBT_BUS_ID,
       CBT_NOTIFY_ABD_FLAG,
       CBT_SYS_CODE_ID,
       CBT_SEG_BUT_ID,
       CBT_INSERT_NEG,
       CBT_MESSAGE_FLAG,
       CBT_BEST_FIT_FLAG,
       CBT_GENERATION_CHARGE_FLAG,
       CBT_CREDIT_LIMIT_TPP_FLAG,
       CBT_FIRST_INVOICE_FLAG,
       CBT_TRANSFER_FLAG
  FROM STL.cellular_business_types@prod
/

