create FUNCTION F_INSERT_INQUIRY_CLIENT_SCORE

 (P_ID_ANSWER IN NUMBER
 ,P_ID_SATISFACTOR IN NUMBER
 ,P_ID_ATTRIBUTE IN NUMBER
 ,P_SCORE IN NUMBER
 ,P_ERR_NUMBER OUT NUMBER
 ,P_ERR_MESSAGE OUT VARCHAR2
 )
 RETURN NUMBER
 IS
BEGIN

  Insert into inquiry_client_score (
                ICS_ICL_ID_ANSWER,
                ICS_ISF_ID_SATISFACTOR,
                ICS_IAT_ID_ATTRIBUTE,
                ICS_IQF_SCORE)
  values (p_id_answer,
          p_id_satisfactor,
          p_id_attribute,
          p_score);

  RETURN 0;

  EXCEPTION
        WHEN OTHERS THEN
            p_err_number := SQLCODE;
            p_err_message := SQLERRM;
            RETURN -1;
END F_INSERT_INQUIRY_CLIENT_SCORE;
/

