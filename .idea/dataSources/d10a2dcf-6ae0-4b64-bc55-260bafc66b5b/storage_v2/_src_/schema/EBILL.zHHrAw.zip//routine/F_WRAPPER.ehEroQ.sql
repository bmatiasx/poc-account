create FUNCTION f_wrapper(P_CALL_1 IN VARCHAR2
 ,P_CALL_2 IN VARCHAR2
 ,P_ERR_NUM OUT NUMBER
 ,P_ERR_MSG OUT VARCHAR2
 )
 RETURN NUMBER
 IS

v_result NUMBER;

BEGIN

v_result := f_create_call_view(p_call_1 => p_call_1,
                                      p_call_2 => p_call_2,
                                      p_err_num => p_err_num,
                                      p_err_msg => p_err_msg);

IF v_result <> 0 THEN
  RETURN -1;
END IF;  

RETURN 0;
EXCEPTION
  WHEN OTHERS THEN
   p_err_num := SQLCODE;
   p_err_msg := 'Error wrapper: '||SQLERRM;
   RETURN -1;
END;
/

