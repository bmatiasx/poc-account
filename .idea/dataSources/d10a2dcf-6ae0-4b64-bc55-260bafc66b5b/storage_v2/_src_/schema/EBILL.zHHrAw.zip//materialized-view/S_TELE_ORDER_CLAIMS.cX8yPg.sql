create materialized view S_TELE_ORDER_CLAIMS
refresh fast on demand
  as
    SELECT OCL_ID,
       OCL_DATE,
       OCL_COMMENT,
       OCL_ACC_ID,
       OCL_ORH_ID
  FROM stl.tele_order_claims@prod
  WHERE ocl_date >= to_date('01/01/2013','dd/mm/yyyy')
/

