create PACKAGE BODY Web_Bill
IS
PROCEDURE ObtenerCellularNumber(bill_number IN VARCHAR2,
                        celular OUT VARCHAR2,
                        codigo_error OUT NUMBER) IS
BEGIN
    codigo_error:= web_consumo.ObtenerCellularNumber@prod(bill_number, celular);
EXCEPTION
    WHEN OTHERS THEN
        codigo_error := SQLCODE;
END;
FUNCTION ValidaPassClient(
           p_cellular_number IN VARCHAR2,
           p_password IN VARCHAR2,
           p_clt_id OUT client.clt_id%TYPE,
           p_client_name OUT VARCHAR2
           )
RETURN NUMBER IS
   v_clt_password  client.clt_password%TYPE;
BEGIN
   SELECT clt_password, clt_id,
   LTRIM(RTRIM(clt_name)) || ' ' || LTRIM(RTRIM(CLT_SURNAME))
   INTO v_clt_password, p_clt_id, p_client_name
   FROM client, accounts, cellulars
   WHERE acc_clt_id = clt_id
   AND acc_id = clu_acc_id
   AND clu_cellular_number = p_cellular_number;
   IF LTRIM(RTRIM(v_clt_password)) <> LTRIM(RTRIM(p_password))
      OR v_clt_password IS NULL THEN
           p_clt_id := NULL;
           RETURN -1;
   END IF;
   p_client_name := LTRIM(RTRIM(p_client_name));
   RETURN 0;
EXCEPTION
   WHEN OTHERS THEN
           p_clt_id := NULL;
           RETURN SQLCODE;
END;
FUNCTION F_GET_ACC_CLU(p_clt_id IN CLIENT.CLT_ID%TYPE,
						ACC_ID OUT T_ACC,
						CLU_ID OUT T_CLU)
	RETURN NUMBER
IS
	i	BINARY_INTEGER := 1;
	CURSOR C_ACC_CLU(v_clt_id CLIENT.CLT_ID%TYPE) IS
		SELECT ACC_ID, CLU_CELLULAR_NUMBER
		FROM ACCOUNTS, CELLULARS
		WHERE ACC_ID = CLU_ACC_ID
		AND ACC_CLT_ID = v_clt_id
		ORDER BY ACC_ID, CLU_CELLULAR_NUMBER;
BEGIN
	FOR ACC_CLU IN C_ACC_CLU(p_clt_id) LOOP
		ACC_ID(i) := ACC_CLU.ACC_ID;
		CLU_ID(i) := ACC_CLU.CLU_CELLULAR_NUMBER;
		i := i + 1;
	END LOOP;
	RETURN (i - 1);
EXCEPTION
	WHEN OTHERS THEN
		RETURN -1;
END; -- F_GET_ACC_CLU
PROCEDURE P_GET_ACC_CLU(p_clt_id IN CLIENT.CLT_ID%TYPE,
						ACC_ID OUT T_ACC,
						CLU_ID OUT T_CLU)
IS
	i	BINARY_INTEGER := 1;
	CURSOR C_ACC_CLU(v_clt_id CLIENT.CLT_ID%TYPE) IS
		SELECT ACC_ID, CLU_CELLULAR_NUMBER
		FROM ACCOUNTS, CELLULARS
		WHERE ACC_ID = CLU_ACC_ID
		AND ACC_CLT_ID = v_clt_id
		ORDER BY ACC_ID, CLU_CELLULAR_NUMBER;
BEGIN
	FOR ACC_CLU IN C_ACC_CLU(p_clt_id) LOOP
		ACC_ID(i) := ACC_CLU.ACC_ID;
		CLU_ID(i) := ACC_CLU.CLU_CELLULAR_NUMBER;
		i := i + 1;
	END LOOP;
EXCEPTION
	WHEN OTHERS THEN
		NULL;
END; -- P_GET_ACC_CLU
FUNCTION F_GET_DOC(
			P_CLT_ID		IN CLIENT.CLT_ID%TYPE,
			P_PERIODOS		IN NUMBER,
			DOC_ID			OUT T_DOC,
			DOC_CMP_ID		OUT T_DOC_CMP,
			DOC_LETTER		OUT T_DOC_LETTER,
			SCH_START_DATE	OUT T_DATE,
			SCH_END_DATE	OUT T_DATE,
			DOC_ACC_ID		OUT T_ACC,
			SCH_ID			OUT T_SCH)
	RETURN NUMBER
IS
	i NUMBER := 1;
	CURSOR C_DOC(v_clt_id IN CLIENT.CLT_ID%TYPE,
				v_periodos IN NUMBER) IS
		SELECT DOC_ID, DOC_CMP_ID, DOC_LETTER, SCH_START_DATE,
			SCH_END_DATE, DOC_ACC_ID, SCH_ID
		FROM DOCUMENTS d, SCHEDULERS s, ACCOUNTS a
		WHERE	DOC_ACC_ID = ACC_ID
		AND	ACC_CLT_ID = v_clt_id
		AND	DOC_DCT_ID = 'FC'
		AND	DOC_SCH_ID = SCH_ID
		AND	SCH_END_DATE < SYSDATE
		AND	SCH_END_DATE > ADD_MONTHS(SYSDATE, (-1*v_periodos))
		ORDER BY SCH_END_DATE;
BEGIN
	FOR cur_doc IN C_DOC(p_clt_id, p_periodos) LOOP
		DOC_ID(i) := cur_doc.DOC_ID;
		DOC_CMP_ID(i) := cur_doc.DOC_CMP_ID;
		DOC_LETTER(i) := cur_doc.DOC_LETTER;
		SCH_START_DATE(i) := cur_doc.SCH_START_DATE;
		SCH_END_DATE(i) := cur_doc.SCH_END_DATE;
		DOC_ACC_ID(i) := cur_doc.DOC_ACC_ID;
		SCH_ID(i) := cur_doc.SCH_ID;
		i := i + 1;
	END LOOP;
	RETURN (i - 1);
EXCEPTION
	WHEN OTHERS THEN
		RETURN -1;
END; -- F_GET_DOC
END; -- PACKAGE BODY
/

