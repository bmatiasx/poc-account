create PACKAGE BODY PA_CALL_PROFILE IS
TYPE_NEW_EXCEPTION   EXCEPTION;

   FUNCTION F_INSERT_REG_CALL_PROF_DETAIL (
      P_RCPD_CELLULAR_NUMBER   IN     VARCHAR2,
      P_RCPD_STATUS            IN     VARCHAR2,
      P_RCPD_GENERIC_MSG       IN     VARCHAR2,
      P_RCPD_ORIGINAL_MSG      IN     VARCHAR2,
      P_RCPD_MOVE_TYPE         IN     VARCHAR2,
      P_RCPD_CR_ID             IN     VARCHAR2,
      P_ERROR_COD                 OUT VARCHAR2,
      P_ERROR_MSG                 OUT VARCHAR2)
      RETURN NUMBER
   IS
      PRAGMA AUTONOMOUS_TRANSACTION;
      V_RCPD_RCP_ID   NUMBER;
   BEGIN
      IF (P_RCPD_CELLULAR_NUMBER IS NULL OR P_RCPD_CR_ID IS NULL)
      THEN
         BEGIN
            RAISE TYPE_NEW_EXCEPTION;
         EXCEPTION
            WHEN TYPE_NEW_EXCEPTION
            THEN
               P_ERROR_COD := '1000';
               P_ERROR_MSG :=
                  'Los parametro P_RCPD_CELLULAR_NUMBER, P_RCPD_CR_ID no pueden ser nulo.';
               RETURN 1;
         END;
      ELSE
         BEGIN
            BEGIN
               SELECT TO_CHAR (MAX (TO_NUMBER (RCP_ID)))
                 INTO V_RCPD_RCP_ID
                 FROM REG_CALL_PROFILE;
            EXCEPTION
               WHEN OTHERS
               THEN
                  P_ERROR_COD := '1001';
                  P_ERROR_MSG :=
                     'Error al insertar en la tabla REG_CALL_PROFILE_DETAIL :';
                  RETURN 1;
                  ROLLBACK;
            END;

            INSERT INTO REG_CALL_PROFILE_DETAIL (RCPD_ID,
                                                 RCPD_RCP_ID,
                                                 RCPD_CELLULAR_NUMBER,
                                                 RCPD_EXECUTE_DATE,
                                                 RCPD_STATUS,
                                                 RCPD_GENERIC_MSG,
                                                 RCPD_ORIGINAL_MSG,
                                                 RCPD_MOVE_TYPE,
                                                 RCPD_CR_ID)
                 VALUES (CALL_PROFILE_DETAIL_SEQ.NEXTVAL,

                         V_RCPD_RCP_ID,
                         P_RCPD_CELLULAR_NUMBER,
                         SYSDATE,
                         P_RCPD_STATUS,
                         P_RCPD_GENERIC_MSG,
                         P_RCPD_ORIGINAL_MSG,
                         P_RCPD_MOVE_TYPE,
                         P_RCPD_CR_ID);

            COMMIT;
            RETURN 0;
         EXCEPTION
            WHEN OTHERS
            THEN
               P_ERROR_COD := '1002';
               P_ERROR_MSG :=
                     'Error al insertar en la tabla REG_CALL_PROFILE_DETAIL : '
                  || SQLERRM;
               RETURN 1;
               ROLLBACK;
         END;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         P_ERROR_COD := '1003';
         P_ERROR_MSG :=
               'Error al realizar la operacion solicitada en la tabla REG_CALL_PROFILE_DETAIL : '
            || ' ## '
            || SQLERRM;
         RETURN -1;
         ROLLBACK;
   END F_INSERT_REG_CALL_PROF_DETAIL;

   FUNCTION F_INSERT_REG_CALL_PROF (P_RCP_STATUS            IN     VARCHAR2,
                                    P_RCP_LINES             IN     NUMBER,
                                    P_RCP_ERROR_LINES       IN     NUMBER,
                                    P_RCP_ACTIVE_LINES      IN     NUMBER,
                                    P_RCP_ACC_ID            IN     VARCHAR2,
                                    P_RCP_STATUS_DELIVERY   IN     VARCHAR2,
                                    P_RCP_ORIGIN            IN     VARCHAR2,
                                    P_ERROR_COD                OUT VARCHAR2,
                                    P_ERROR_MSG                OUT VARCHAR2)
      RETURN NUMBER
   IS
      PRAGMA AUTONOMOUS_TRANSACTION;
   BEGIN
      IF (   P_RCP_ACC_ID IS NULL
          OR P_RCP_STATUS IS NULL
          OR P_RCP_STATUS_DELIVERY IS NULL)
      THEN
         BEGIN
            RAISE TYPE_NEW_EXCEPTION;
         EXCEPTION
            WHEN TYPE_NEW_EXCEPTION
            THEN
               P_ERROR_COD := '2000';
               P_ERROR_MSG :=
                  'Los parametro P_RCP_ACC_ID, P_RCP_STATUS, P_RCP_STATUS_DELIVERY no pueden ser nulo.';
               ROLLBACK;
               RETURN 1;
         END;
      ELSE
         BEGIN
            INSERT INTO REG_CALL_PROFILE (RCP_ID,
                                          RCP_START_DATE,
                                          RCP_STATUS,
                                          RCP_LINES,
                                          RCP_ERROR_LINES,
                                          RCP_ACTIVE_LINES,
                                          RCP_ACC_ID,
                                          RCP_STATUS_DELIVERY,
                                          RCP_ORIGIN)
                 VALUES (CALL_PROFILE_SEQ.NEXTVAL,
                         SYSDATE,
                         P_RCP_STATUS,
                         P_RCP_LINES,
                         P_RCP_ERROR_LINES,
                         P_RCP_ACTIVE_LINES,
                         P_RCP_ACC_ID,
                         P_RCP_STATUS_DELIVERY,
                         P_RCP_ORIGIN);

            COMMIT;
            RETURN 0;
         EXCEPTION
            WHEN OTHERS
            THEN
               P_ERROR_COD := '2001';
               P_ERROR_MSG :=
                     'Error al insertar en la tabla REG_CALL_PROFILE : '
                  || SQLERRM;

               RETURN 1;
               ROLLBACK;
         END;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         P_ERROR_COD := '2002';
         P_ERROR_MSG :=
               'Error al realizar la operacion solicitada en la tabla REG_CALL_PROFILE : '
            || ' ## '
            || SQLERRM;
         RETURN -1;
         ROLLBACK;
   END F_INSERT_REG_CALL_PROF;

  PROCEDURE P_REGISTER_CALL_PROFILE (P_RESULT_OK	  OUT VARCHAR2,
									                   P_ERROR_COD      OUT VARCHAR2,
                                     P_ERROR_MSG      OUT VARCHAR2)
   IS
       V_COUNT_LINES          REG_CALL_PROFILE.RCP_LINES%TYPE;
      V_ARS_RCP_ID           REG_CALL_PROFILE.RCP_ID%TYPE;
      V_RCPD_ID              VARCHAR2(200);
      V_CCR_CR_ID            CELLULAR_CALL_RESTRICTIONS.CCR_CR_ID%TYPE;
      V_EXCEPCION_PROPIA     EXCEPTION;
      V_COUNT_ERROR_LINES    NUMBER := 0;
      V_COUNT_ACTIVE_LINES   NUMBER := 0;
      
      CURSOR C_LINES
      IS      
         SELECT (SELECT CLU.CLU_CELLULAR_NUMBER
                   FROM CELLULARS CLU
                  WHERE CLU.CLU_CELLULAR_NUMBER = RCPD.RCPD_CELLULAR_NUMBER)
                   CELLULAR_NUMBER,
                RCPD.RCPD_ID,
                RCPD.RCPD_CR_ID CR_ID
          FROM REG_CALL_PROFILE_DETAIL RCPD
          WHERE RCPD.RCPD_RCP_ID = (SELECT TO_CHAR (MAX (TO_NUMBER (RCP_ID)))
                                     FROM REG_CALL_PROFILE);

      V_CURSOR_LINES         C_LINES%ROWTYPE;    
                                     
      PRAGMA AUTONOMOUS_TRANSACTION;
   BEGIN
         SELECT TO_CHAR (MAX (TO_NUMBER (RCP_ID)))
         INTO V_RCPD_ID
         FROM REG_CALL_PROFILE;
      
         BEGIN
           BEGIN      
               SELECT RGP.RCP_LINES, RGP.RCP_ID
                 INTO V_COUNT_LINES, V_ARS_RCP_ID
                 FROM REG_CALL_PROFILE RGP
                WHERE RGP.RCP_ID = V_RCPD_ID;
            EXCEPTION
               WHEN NO_DATA_FOUND
               THEN
                  P_ERROR_COD := '3001';
                  P_ERROR_MSG :=
                     'No existe operacion con el RCPD_ID ingresado.';
            END;

            BEGIN
               BEGIN
                  OPEN C_LINES;

                  LOOP
                     BEGIN
                        FETCH C_LINES INTO V_CURSOR_LINES;

                        EXIT WHEN C_LINES%NOTFOUND;

                        SELECT CCR.CCR_CR_ID
                          INTO V_CCR_CR_ID
                          FROM CELLULAR_CALL_RESTRICTIONS CCR
                         WHERE     CCR.CCR_CLU_CELLULAR_NUMBER =
                                      V_CURSOR_LINES.CELLULAR_NUMBER
                               AND CCR.CCR_END_DATE IS NULL;

                        IF (V_CURSOR_LINES.CR_ID = V_CCR_CR_ID)
                        THEN
                           UPDATE REG_CALL_PROFILE_DETAIL RCPD
                              SET RCPD.RCPD_STATUS = 'E',
                                  RCPD.RCPD_GENERIC_MSG =
                                     'La linea ya posee el perfil seleccionado.',
                                  RCPD.RCPD_ORIGINAL_MSG =
                                     'La linea ya posee el perfil seleccionado.'
                            WHERE     RCPD.RCPD_CELLULAR_NUMBER =
                                         V_CURSOR_LINES.CELLULAR_NUMBER
                                  AND RCPD.RCPD_RCP_ID = V_ARS_RCP_ID;

                           COMMIT;

                           V_COUNT_ERROR_LINES := V_COUNT_ERROR_LINES + 1;
                        ELSE
                           UPDATE REG_CALL_PROFILE_DETAIL RCPD
                              SET RCPD.RCPD_EXECUTE_DATE = SYSDATE,
                                  RCPD.RCPD_STATUS = 'OK',
                                  RCPD.RCPD_GENERIC_MSG =
                                     'Se realizo con exito el cambio de profile para la linea.',
                                  RCPD.RCPD_ORIGINAL_MSG = 'OK'
                            WHERE     RCPD.RCPD_CELLULAR_NUMBER =
                                         V_CURSOR_LINES.CELLULAR_NUMBER
                                  AND RCPD.RCPD_RCP_ID = V_ARS_RCP_ID;

                           COMMIT;

                           V_COUNT_ACTIVE_LINES := V_COUNT_ACTIVE_LINES + 1;
                        END IF;
                     EXCEPTION
                        WHEN NO_DATA_FOUND
                        THEN
                           UPDATE REG_CALL_PROFILE_DETAIL RCPD
                              SET RCPD.RCPD_EXECUTE_DATE = SYSDATE,
                                  RCPD.RCPD_STATUS = 'E',
                                  RCPD.RCPD_GENERIC_MSG =
                                     'La linea no se encuentra en la tabla CELLULAR_CALL_RESTRICTIONS.',
                                  RCPD.RCPD_ORIGINAL_MSG =
                                     'La linea no se encuentra en la tabla CELLULAR_CALL_RESTRICTIONS.'
                            WHERE     RCPD.RCPD_CELLULAR_NUMBER =
                                         V_CURSOR_LINES.CELLULAR_NUMBER
                                  AND RCPD.RCPD_RCP_ID = V_ARS_RCP_ID;

                           COMMIT;

                           V_COUNT_ERROR_LINES := V_COUNT_ERROR_LINES + 1;
                     END;
                  END LOOP;

                  CLOSE C_LINES;
               EXCEPTION
                  WHEN OTHERS
                  THEN
                     P_ERROR_COD := '3003';
                     P_ERROR_MSG :=
                        'No se pudo realizar la actualizacion correspondiente.';
               END;

               V_COUNT_LINES := V_COUNT_ACTIVE_LINES + V_COUNT_ERROR_LINES;

               BEGIN
                  UPDATE REG_CALL_PROFILE RCP
                     SET RCP.RCP_STATUS = 'T',
                         RCP.RCP_LINES = V_COUNT_LINES,
                         RCP.RCP_ERROR_LINES = V_COUNT_ERROR_LINES,
                         RCP.RCP_ACTIVE_LINES = V_COUNT_ACTIVE_LINES
                   WHERE RCP.RCP_ID = V_RCPD_ID;

                  COMMIT;
               EXCEPTION
                  WHEN OTHERS
                  THEN
                     P_ERROR_COD := '3004';
                     P_ERROR_MSG :=
                           'No se pudo realizar la actualizacion correspondiente.'
                        || ' ## '
                        || SQLERRM
                        || ' ## '
                        || SQLCODE;
               END;
               
               P_RESULT_OK := 'Se realizo con exito la tarea de F_REGISTER_CALL_PROFILE.';
           
            END;
         END;
   EXCEPTION
      WHEN OTHERS
      THEN
         P_ERROR_COD := '3005';
         P_ERROR_MSG := SQLERRM;
         ROLLBACK;
   END P_REGISTER_CALL_PROFILE;

   FUNCTION F_INS_UPD_CELL_PROFILE (P_CELLULAR      IN     VARCHAR2,
                                    P_DD_TYPE_NEW   IN     VARCHAR2,
                                    P_RESULT_OK        OUT VARCHAR2,
                                    P_ERROR_COD        OUT VARCHAR2,
                                    P_ERROR_MSG        OUT VARCHAR2)
      RETURN NUMBER
   IS
      V_CCR_ID    VARCHAR2 (15);
      V_CED_ID    VARCHAR2 (15);
      V_DD_TYPE   VARCHAR2 (20);
    
      PRAGMA AUTONOMOUS_TRANSACTION;
    
   BEGIN
      BEGIN
         SELECT CED_DDI_TYPE
           INTO V_DD_TYPE
           FROM CELLULAR_DDI_TYPES
          WHERE CED_CLU_CELLULAR_NUMBER = P_CELLULAR 
          AND CED_END_DATE IS NULL;
          
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
              INSERT INTO CELLULAR_DDI_TYPES (CED_ID,
                                              CED_CLU_CELLULAR_NUMBER,
                                              CED_DDI_TYPE,
                                              CED_USER,
                                              CED_APPROVAL_REQUIRED,
                                              CED_START_DATE)
                     VALUES (CED_SEQ.NEXTVAL,
                             P_CELLULAR,
                             P_DD_TYPE_NEW,
                             USER,
                             'N',
                             SYSDATE);
                             
               P_RESULT_OK := 'Su transaccion fue realizada correctamente.';
               COMMIT;
               RETURN 0;
               
               
         WHEN OTHERS
         THEN
            P_ERROR_COD := '4001';
            P_ERROR_MSG :=
                  'Error al intentar consultar CELLULAR_DDI_TYPES: '
               || SQLCODE
               || ' ## '
               || SQLERRM;
            RETURN 1;
      END;

      BEGIN
         --Si es DDN, DDI Común, DDI Full
         IF V_DD_TYPE IN ('N', 'C', 'F') AND P_DD_TYPE_NEW IN ('N', 'C', 'F')
         THEN
            --## Ingresa con el parametro V_DD_TYPE como DDN (Discado Directo Nacional)
            IF V_DD_TYPE = 'N'
            THEN
               IF P_DD_TYPE_NEW IS NULL
               THEN
                  BEGIN
                     RAISE TYPE_NEW_EXCEPTION;
                  EXCEPTION
                     WHEN TYPE_NEW_EXCEPTION
                     THEN
                        P_ERROR_COD := '4002';
                        P_ERROR_MSG :=
                           'El parametro P_DD_TYPE_NEW no debe ser nulo.';
                           RETURN 1;
                        ROLLBACK;
                        
                  END;
               ELSIF P_DD_TYPE_NEW = 'N'
               THEN
                  BEGIN
                     RAISE TYPE_NEW_EXCEPTION;
                  EXCEPTION
                     WHEN TYPE_NEW_EXCEPTION
                     THEN
                        P_ERROR_COD := '4003';
                        P_ERROR_MSG :=
                           'La linea ya posee el profile que intenta agregar.';
                           RETURN 1;
                        ROLLBACK;
                        
                  END;
               --Actualiza en C o F el tipo de DDI (Discado Directo Internacional)
               ELSIF P_DD_TYPE_NEW IN ('C', 'F')
               THEN
                  BEGIN
                     SELECT CED_ID
                       INTO V_CED_ID
                       FROM CELLULAR_DDI_TYPES
                      WHERE     CED_CLU_CELLULAR_NUMBER = P_CELLULAR
                            AND CED_END_DATE IS NULL;

                     UPDATE CELLULAR_DDI_TYPES
                        SET CED_END_DATE = SYSDATE
                      WHERE CED_ID = V_CED_ID;

                     INSERT INTO CELLULAR_DDI_TYPES (CED_ID,
                                                     CED_CLU_CELLULAR_NUMBER,
                                                     CED_DDI_TYPE,
                                                     CED_USER,
                                                     CED_APPROVAL_REQUIRED,
                                                     CED_START_DATE)
                          VALUES (CED_SEQ.NEXTVAL,
                                  P_CELLULAR,
                                  P_DD_TYPE_NEW,
                                  USER,
                                  'N',
                                  SYSDATE);
                                  COMMIT;
                     
                  EXCEPTION
                     WHEN NO_DATA_FOUND
                     THEN
                        --Lo carga en CELLULAR_DDI_TYPES
                        --en caso de ser la primera vez que tiene algun cambio a DDI
                        INSERT
                          INTO CELLULAR_DDI_TYPES (CED_ID,
                                                   CED_CLU_CELLULAR_NUMBER,
                                                   CED_DDI_TYPE,
                                                   CED_USER,
                                                   CED_APPROVAL_REQUIRED,
                                                   CED_START_DATE)
                        VALUES (CED_SEQ.NEXTVAL,
                                P_CELLULAR,
                                P_DD_TYPE_NEW,
                                USER,
                                'N',
                                SYSDATE);                      

                        P_RESULT_OK :=
                           'Su transaccion fue realizada correctamente.';
                           COMMIT;
                        RETURN 0;
                    
                     WHEN OTHERS
                     THEN
                        P_ERROR_COD := '4004';
                        P_ERROR_MSG :=
                              'No se pudo realizar la actualizacion de la tabla CELLULAR_DDI_TYPES: '
                           || SQLCODE
                           || ' ## '
                           || SQLERRM;
                           
                           RETURN 1;
                        ROLLBACK;
                        
                  END;
               END IF;
         
               P_RESULT_OK := 'Su transaccion fue realizada correctamente.';
               RETURN 0;
               COMMIT;
         
            ELSIF V_DD_TYPE = 'C'
            THEN
               IF P_DD_TYPE_NEW IS NULL
               THEN
                  BEGIN
                     RAISE TYPE_NEW_EXCEPTION;
                  EXCEPTION
                     WHEN TYPE_NEW_EXCEPTION
                     THEN
                        P_ERROR_COD := '4005';
                        P_ERROR_MSG :=
                           'El parametro P_DD_TYPE_NEW no debe ser nulo.';
                           RETURN 1;
                        ROLLBACK;
                        
                  END;
               ELSIF P_DD_TYPE_NEW = 'C'
               THEN
                  BEGIN
                     RAISE TYPE_NEW_EXCEPTION;
                  EXCEPTION
                     WHEN TYPE_NEW_EXCEPTION
                     THEN
                        P_ERROR_COD := '4006';
                        P_ERROR_MSG :=
                           'La linea ya posee el profile que intenta agregar.';
                           RETURN 1;
                        ROLLBACK;
                        
                  END;
               ELSIF P_DD_TYPE_NEW = 'N'
               THEN
                  --## Ingresa con el parametro V_DD_TYPE como DDN (Discado Directo Nacional)
                  BEGIN
                     SELECT CCR_ID
                       INTO V_CCR_ID
                       FROM CELLULAR_CALL_RESTRICTIONS
                      WHERE     CCR_CLU_CELLULAR_NUMBER = P_CELLULAR
                            AND CCR_END_DATE IS NULL;

                     UPDATE CELLULAR_CALL_RESTRICTIONS
                        SET CCR_LAST_UPDATED_DATE = SYSDATE,
                            CCR_END_DATE = SYSDATE
                      WHERE CCR_ID = V_CCR_ID;

                     INSERT
                       INTO CELLULAR_CALL_RESTRICTIONS (
                               CCR_ID,
                               CCR_CR_ID,
                               CCR_START_DATE,
                               CCR_CLU_CELLULAR_NUMBER,
                               CCR_LAST_UPDATED_DATE,
                               CCR_RSN_ID)
                     VALUES (CCR_SEQ.NEXTVAL,
                             '2',
                             SYSDATE,
                             P_CELLULAR,
                             SYSDATE,
                             NULL);
                             COMMIT;
                  EXCEPTION
                     WHEN OTHERS
                     THEN
                        P_ERROR_COD := '4007';
                        P_ERROR_MSG :=
                              'No se pudo actualizar la tabla CELLULAR_CALL_RESTRICTIONS: '
                           || SQLCODE
                           || ' ## '
                           || SQLERRM;
                           RETURN 1;
                        ROLLBACK;
                        
                  END;        
                  P_RESULT_OK :=
                     'Su transaccion fue realizada correctamente.';
                     RETURN 0;
                     COMMIT;
              ELSIF P_DD_TYPE_NEW = 'F'
               THEN
                  -- Ingresa con el parametro V_DD_TYPE como DDI Full
                  -- (Discado Directo Internacional Full)
                  BEGIN
                     SELECT CED_ID
                       INTO V_CED_ID
                       FROM CELLULAR_DDI_TYPES
                      WHERE     CED_CLU_CELLULAR_NUMBER = P_CELLULAR
                            AND CED_END_DATE IS NULL;

                     UPDATE CELLULAR_DDI_TYPES
                        SET CED_END_DATE = SYSDATE
                      WHERE CED_ID = V_CED_ID;

                     INSERT INTO CELLULAR_DDI_TYPES (CED_ID,
                                                     CED_CLU_CELLULAR_NUMBER,
                                                     CED_DDI_TYPE,
                                                     CED_USER,
                                                     CED_APPROVAL_REQUIRED,
                                                     CED_START_DATE)
                          VALUES (CED_SEQ.NEXTVAL,
                                  P_CELLULAR,
                                  P_DD_TYPE_NEW,
                                  USER,
                                  'N',
                                  SYSDATE);
                                  COMMIT;
                    
                  EXCEPTION
                     --Se inserta el registro para el caso de que
                     --no se encuentre en la tabla CELLULAR_DDI_TYPES.
                     WHEN NO_DATA_FOUND
                     THEN
                        INSERT
                          INTO CELLULAR_DDI_TYPES (CED_ID,
                                                   CED_CLU_CELLULAR_NUMBER,
                                                   CED_DDI_TYPE,
                                                   CED_USER,
                                                   CED_APPROVAL_REQUIRED,
                                                   CED_START_DATE)
                        VALUES (CED_SEQ.NEXTVAL,
                                P_CELLULAR,
                                P_DD_TYPE_NEW,
                                USER,
                                'N',
                                SYSDATE);

                         P_RESULT_OK :=
                     'Su transaccion fue realizada correctamente.';
                      RETURN 0;  
                         COMMIT;
                               
                     WHEN OTHERS
                     THEN
                        P_ERROR_COD := '4008';
                        P_ERROR_MSG :=
                              'Error al intentar actualizar la tabla CELLULAR_DDI_TYPES: '
                           || SQLCODE
                           || ' ## '
                           || SQLERRM;
                           
                           RETURN 1;
                        ROLLBACK;
                        
                  END;

                  P_RESULT_OK :=
                     'Su transaccion fue realizada correctamente.';
                     RETURN 0;
                     COMMIT;
                    
               END IF;
            ELSIF V_DD_TYPE = 'F'
            THEN
               IF P_DD_TYPE_NEW IS NULL
               THEN
                  BEGIN
                     RAISE TYPE_NEW_EXCEPTION;
                  EXCEPTION
                     WHEN TYPE_NEW_EXCEPTION
                     THEN
                        P_ERROR_COD := '4009';
                        P_ERROR_MSG :=
                           'El parametro P_DD_TYPE_NEW no debe ser nulo.';
                           RETURN 1;
                        ROLLBACK;
                        
                  END;
               ELSIF P_DD_TYPE_NEW = 'F'
               THEN
                  BEGIN
                     RAISE TYPE_NEW_EXCEPTION;
                  EXCEPTION
                     WHEN TYPE_NEW_EXCEPTION
                     THEN
                        P_ERROR_COD := '4010';
                        P_ERROR_MSG :=
                           'La linea ya posee el profile que intenta agregar.';
                           RETURN 1;
                        ROLLBACK;
                        
                  END;
               ELSIF P_DD_TYPE_NEW = 'N'
               THEN
                  -- (Discado Directo Internacional Full), se pasa a DDN (Discado Directo Nacional)
                  -- Viene con DDI Full, se pasa a DDN
                  BEGIN
                     SELECT CCR_ID
                       INTO V_CCR_ID
                       FROM CELLULAR_CALL_RESTRICTIONS
                      WHERE     CCR_CLU_CELLULAR_NUMBER = P_CELLULAR
                            AND CCR_END_DATE IS NULL;

                     UPDATE CELLULAR_CALL_RESTRICTIONS
                        SET CCR_LAST_UPDATED_DATE = SYSDATE,
                            CCR_END_DATE = SYSDATE
                      WHERE CCR_ID = V_CCR_ID;

                     INSERT
                       INTO CELLULAR_CALL_RESTRICTIONS (
                               CCR_ID,
                               CCR_CR_ID,
                               CCR_START_DATE,
                               CCR_CLU_CELLULAR_NUMBER,
                               CCR_LAST_UPDATED_DATE,
                               CCR_RSN_ID)
                     VALUES (CCR_SEQ.NEXTVAL,
                             '2',
                             SYSDATE,
                             P_CELLULAR,
                             SYSDATE,
                             NULL);
                             
                            P_RESULT_OK :=
                              'Su transaccion fue realizada correctamente.';
                              COMMIT;
                              RETURN 0;          
                    
                  EXCEPTION
                     WHEN OTHERS
                     THEN
                        P_ERROR_COD := '4011';
                        P_ERROR_MSG :=
                              'No se pudo actualizar la tabla CELLULAR_CALL_RESTRICTIONS: '
                           || SQLCODE
                           || ' ## '
                           || SQLERRM;
                        ROLLBACK;
                        RETURN 1;
                  END;
                  
               ELSIF P_DD_TYPE_NEW = 'C'
               THEN
                  -- (Discado Directo Internacional Full), se pasa a DDI (Discado Directo Internacional)
                  BEGIN
                     SELECT CED_ID
                       INTO V_CED_ID
                       FROM CELLULAR_DDI_TYPES
                      WHERE     CED_CLU_CELLULAR_NUMBER = P_CELLULAR
                            AND CED_END_DATE IS NULL;

                     UPDATE CELLULAR_DDI_TYPES
                        SET CED_END_DATE = SYSDATE
                      WHERE CED_ID = V_CED_ID;

                     INSERT INTO CELLULAR_DDI_TYPES (CED_ID,
                                                     CED_CLU_CELLULAR_NUMBER,
                                                     CED_DDI_TYPE,
                                                     CED_USER,
                                                     CED_APPROVAL_REQUIRED,
                                                     CED_START_DATE)
                          VALUES (CED_SEQ.NEXTVAL,
                                  P_CELLULAR,
                                  P_DD_TYPE_NEW,
                                  USER,
                                  'N',
                                  SYSDATE);                   
                  EXCEPTION
                     WHEN OTHERS
                     THEN
                        P_ERROR_COD := '4012';
                        P_ERROR_MSG :=
                              'No se pudo actualizar la tabla CELLULAR_DDI_TYPES: '
                           || SQLCODE
                           || ' ## '
                           || SQLERRM;
                        
                        RETURN 1;
                        ROLLBACK;
                  END;

                  P_RESULT_OK :=
                     'Su transaccion fue realizada correctamente.';
                      RETURN 0;
                     COMMIT;
                 
         END IF;
            END IF;
         ELSE
            P_ERROR_COD := '4013';
            P_ERROR_MSG :=
               'El o los parametros ingresados P_DD_TYPE_NEW no son validos.';
            RETURN 1;
         END IF;
      EXCEPTION
         WHEN OTHERS
         THEN
            P_ERROR_COD := '4014';
            P_ERROR_MSG :=
                  'Error en F_INS_UPD_CELL_PROFILE: '
               || SQLCODE
               || ' ## '
               || SQLERRM;
            RETURN -1;
      END;
   EXCEPTION
      WHEN OTHERS
      THEN
         P_ERROR_COD := '4015';
         P_ERROR_MSG :=
               'Error al intentar consultar la tabla REG_CALL_PROFILE_DETAIL: '
            || SQLCODE
            || ' ## '
            || SQLERRM;
         RETURN 1;
   END F_INS_UPD_CELL_PROFILE;
END PA_CALL_PROFILE;
/

