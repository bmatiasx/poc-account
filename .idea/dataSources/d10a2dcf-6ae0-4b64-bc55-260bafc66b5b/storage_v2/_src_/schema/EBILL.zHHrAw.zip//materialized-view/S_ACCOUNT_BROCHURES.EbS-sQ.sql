create materialized view S_ACCOUNT_BROCHURES
refresh force on demand
  as
    SELECT acb_acc_id, acb_bro_id, acb_end_date
FROM account_brochures@PROD
WHERE NVL(acb_end_date, SYSDATE + 1 ) > SYSDATE
/

