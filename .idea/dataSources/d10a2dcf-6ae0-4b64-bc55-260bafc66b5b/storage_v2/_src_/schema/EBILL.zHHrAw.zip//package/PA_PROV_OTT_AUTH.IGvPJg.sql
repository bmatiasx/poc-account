create PACKAGE PA_PROV_OTT_AUTH IS

/*                      HISTORIAL DE CAMBIOS                                             */
/* Fecha       Desarrollador            Pedido de cambio      Descripcion                */
/* 01/03/2016  Diego Bystazanowsky      PC106329_CD125742     Claro_Video_WS_ClaroOAuth  */


FUNCTION f_ClaroOAuth ( p_country_id        VARCHAR2,
                        p_provider_id       VARCHAR2,
                        p_ott_id            VARCHAR2,
                        p_bill_number       VARCHAR2,
                        p_password          VARCHAR2,
                        p_msisdn        OUT VARCHAR2,
                        p_msg           OUT  VARCHAR2 ) RETURN NUMBER;


FUNCTION f_GetCellularData ( p_country_id         VARCHAR2,
                             p_provider_id        VARCHAR2,
                             p_ott_id             VARCHAR2,
                             p_bill_number        VARCHAR2,
                             p_category      OUT  VARCHAR2,
                             p_clu_password  OUT  VARCHAR2,
                             p_clt_password  OUT  VARCHAR2,
                             p_msisdn        OUT  VARCHAR2,
                             p_msg           OUT  VARCHAR2,
                             p_log_msg       OUT  VARCHAR2 ) RETURN NUMBER;
                        
                        
FUNCTION f_Encriptar3Des ( p_password   VARCHAR2 ) RETURN VARCHAR2;

                        
END PA_PROV_OTT_AUTH;
/

