create PACKAGE BODY PA_USSD_FRIENDS_AND_FAMILY IS
/*************************************************************************************************************
  Version Inicial del Package PA_USSD_FRIENDS_AND_FAMILY que permite la carga y canje de numeros 
  en FF y la consulta de los mismos.  
**************************************************************************************************************/
/** FECHA             EVENTO           DESARROLLADOR           DESCRIPCION                                  **/
/** 19/06/2014        CTIU100103518    Giuga, Mariano Luis     1.0 - Friends and Family - USSD               */
/** 25/01/2016        USSD-84    Bertorello, Pablo Gabriel     1.1 - Friends and Family - USSD               */ 
/** 22/04/2016        USSD-290    Bertorello, Pablo Gabriel     1.2 - Friends and Family - USSD               */ 
/*************************************************************************************************************/


/*
 La funcion muestra la informacion de las promos que puede seleccionar la linea. 
 Tambien cumple el objetivo de validar la linea.
*/




FUNCTION getPromos(P_NIM        IN VARCHAR2,
                   P_cellularNumber OUT cellulars.clu_cellular_number%TYPE,
                     P_ERR_CODE   OUT NUMBER, 
                     P_ERR_TEXT   OUT VARCHAR2, 
                     P_SQL_CODE   OUT VARCHAR2, 
                     P_RESPONSE   OUT VARCHAR2,
                     P_COD_PAIS   OUT VARCHAR2) RETURN NUMBER 
IS

  V_STATUS            cellulars.clu_status%TYPE;
  V_PLAN              cellular_plans.cpl_rpl_id%TYPE; 
  V_CANAL             Promotions.Prm_Ff_Module%TYPE; 
  V_ACC_ID            cellulars.clu_acc_id%TYPE;
  V_LINE_TYPE         cellulars.clu_cbt_id%TYPE;
  V_NIM               cellulars.clu_cellular_number%TYPE;
  V_flag              VARCHAR2(5);
  V_pais              VARCHAR2(10);
  V_packLlamadasI     NUMBER:= -1;
  V_result            NUMBER;
  v_servicesubtype    NUMBER;
  v_Pedescription     VARCHAR2(100);
  v_Tecno_Operator_Id NUMBER;
  v_Servicetype       NUMBER;
  v_servicestatus     NUMBER;
  v_accountstatus     NUMBER;
  v_tariffplanid      NUMBER;
  v_activationdate    DATE;
  v_servicefeedate    DATE;
  v_suspendeddate     DATE;
  v_frozendate        DATE;
  v_prefdestlist0     VARCHAR2(100);
  v_prefdestexpiry0   DATE;
  v_prefdestlist1     VARCHAR2(100);
  v_prefdestexpiry1   DATE;
  v_Tecno_Subid       VARCHAR2(30);
  featuresPLI         VARCHAR2(10);
  v_response          VARCHAR2(100);
  v_flag_contenido    boolean;
  V_fechaMsjePP VARCHAR2(100); 

-- Cursor para obtener promociones FF disponibles en la linea                                                    
  CURSOR C_GET_PROMOS (P_NIM_C   IN VARCHAR2,
                       P_PLAN_C  IN VARCHAR2,
                       P_CANAL_C IN VARCHAR2)
  IS

  SELECT DISTINCT NVL(prm_web_description, prm_description) AS PROMODESCRIPTION,--DES
                    prm_type AS type,
                    DECODE(prm_type,
                           'F',
                           'VOZ',
                           'S',
                           'SMS',
                           'P',
                           'SMS',
                           prm_type) AS TYPEDESCRIPTION,
                    prm_id AS PROMOID,
                    NVL('Y', 'Y') AS VIGENTE,
                    
    prm_quantity_numbers AS quantityNumbers, -- Cantidad de nros disponibles para configurar (fijos e internos)
    NVL(prm_quantity_fixed,0) AS quantityFixed, -- Cant nro fijos
    NVL(prm_quantity_numbers_bf,0) AS quantityBF, -- Cantidad BF
    prm_quantity_insert AS quantityInserts, -- Cant movimientos realizados
    CASE 
          WHEN NVL(prm_quantity_fixed,0) > 0 
          THEN(prm_quantity_numbers) - prm_quantity_fixed 
        ELSE
           prm_quantity_numbers  
      END AS quantityOnNet -- Cant nro internos
     
      FROM Cellular_special_numbers/*cellular_Packages cp*/ , promotions , special_number_promotions
     WHERE csn_prm_id = prm_id
  
      /* cp.cpk_pkt_id= prm_id*/ AND
       snp_prm_id = prm_id 
       AND prm_pmt_id = 'FF' -- TIPO DE PROMOCION
       AND prm_type <> 'V' 
       AND /*cp.cpk_clu_cellular_number*/ csn_start_cellular_number = P_NIM_C 
       AND snp_rpl_id = P_PLAN_C -- PARAMETRO PLAN 
       AND NVL(snp_end_date, SYSDATE + 1) > SYSDATE -- VERIFICA SI LA FECHA DE PROMOCION ESTA VIGENTE
    UNION --ALL
      SELECT DISTINCT NVL(prm_web_description, prm_description) AS promoDescription,
                    prm_type AS type,
                    DECODE(prm_type,
                           'F',
                           'VOZ',
                           'S',
                           'SMS',
                           'P',
                           'SMS',
                           prm_type) AS typeDescription,
                    prm_id AS promoId,
                    NVL('Y', 'Y') AS vigente,
                    
    prm_quantity_numbers AS quantityNumbers, -- Cantidad de nros disponibles para configurar (fijos e internos)
    NVL(prm_quantity_fixed,0) AS quantityFixed, -- Cant nro fijos
    NVL(prm_quantity_numbers_bf,0) AS quantityBF, -- Cantidad BF
    prm_quantity_insert AS quantityInserts, -- Cant movimientos realizados
    CASE 
          WHEN NVL(prm_quantity_fixed,0) > 0 
          THEN(prm_quantity_numbers) - prm_quantity_fixed 
        ELSE
           prm_quantity_numbers  
      END AS quantityOnNet    -- Cant nro internos
      FROM special_number_promotions, Promotions 
         
       WHERE snp_prm_id = prm_id
         AND prm_pmt_id = 'FF'
         AND prm_type <> 'V'
         AND snp_start_date < SYSDATE
         AND NVL(snp_end_date, SYSDATE + 1) > SYSDATE
         AND prm_start_date < SYSDATE
         AND NVL(prm_end_date, SYSDATE + 1) > SYSDATE
         AND (prm_ff_module IS NULL OR prm_ff_module = P_CANAL_C) -- Canal
       AND snp_rpl_id = P_PLAN_C -- Plan
       AND prm_type NOT IN (SELECT DISTINCT prm_type
                            FROM cellular_special_numbers, promotions
                            WHERE prm_id = csn_prm_id
                            AND csn_start_date < SYSDATE
                            AND NVL(csn_end_date, sysdate + 1) > SYSDATE
                            AND csn_start_cellular_number = P_NIM_C
                            );
                            
    -- REGISTRO PARA PODER ITERAR CURSOR Y VALIDAR CONTENIDO
    V_C_GET_PROMOS_RECORD C_GET_PROMOS%ROWTYPE;
BEGIN
 
  V_NIM:= Pa_Ussd_Common.GET_CELLULAR_NUMBER(BILL_NUMBER => Pa_Ussd_Common.GET_BILL_NUMBER(MSISDN => P_NIM));
  P_COD_PAIS:= SUBSTR(P_NIM, 1, 3);
  P_cellularNumber:= V_NIM;
  



-- Obtiene el plan de la linea, id de la cuenta y tipo de linea
BEGIN 
  
  SELECT cpl.cpl_rpl_id, clu.clu_acc_id, clu.clu_cbt_id,clu.clu_status
  INTO   V_PLAN, V_ACC_ID, V_LINE_TYPE,V_STATUS
  FROM   cellulars clu, cellular_plans cpl
     
  WHERE  clu.CLU_CELLULAR_NUMBER = V_NIM
  --AND    clu.clu_status = 'A'
  AND clu.clu_stg_id = cpl.cpl_stg_id
  AND cpl.cpl_clu_cellular_number = clu.clu_cellular_number
  AND cpl.cpl_stg_id = clu.clu_stg_id  
  AND SYSDATE BETWEEN cpl.cpl_start_date AND NVL(cpl.cpl_end_date, SYSDATE + 1);

if(V_STATUS<>'A') then
P_RESPONSE:= 'Para utilizar el servicio tu linea debe estar activa.';
return 1;
end if;

p_response := p_response || '<accountId>' || V_ACC_ID || '</accountId>';
p_response := p_response || '<ratePlanId>' || V_PLAN || '</ratePlanId>';
p_response := p_response || '<lineType>' || V_LINE_TYPE || '</lineType>';
 
  
  EXCEPTION
     WHEN OTHERS THEN
      P_ERR_CODE := 99;
      P_SQL_CODE := SQLCODE || ' ' || SQLERRM;
      P_ERR_TEXT := 'Error Generico';
      P_RESPONSE:= PA_USSD_COMMON.GET_MESSAGE_USSD('USSDERRGEN');
      raise_application_error (-20025,'FALLO PA_USSD_FRIENDS_AND_FAMILY.getPromos: '||SQLCODE || ' ' || SQLERRM);
      RETURN - 1;
END;
 
/* Si la linea es PP y el flag esta habilitado, obtiene la fecha de caducidad de las promos FF, y en base 
   ha si ya caducaron o no, se muestra un mensaje parametrizado con la informacion */
 
-- Obtengo valor del flag stl parameter
SELECT stl_char_value
INTO V_flag
FROM stl_parameters
WHERE stl_id ='USDNIC';       
-- 
if V_LINE_TYPE = 'PP' and V_flag = 'Y' then
       v_Tecno_Operator_Id:= 0;
       v_servicesubtype:= 1;
       v_Tecno_Subid:= P_NIM;
       V_result := PP_PP_SERVER.Get_Subscriber_Service@ccard(pedescription     => v_Pedescription,
                                                                         operatorid        => v_Tecno_Operator_Id, 
                                                                         subid             => v_Tecno_Subid,  -- msisdn
                                                                         servicesubtype    => v_servicesubtype, -- 1
                                                                         servicetype       => v_Servicetype,
                                                                         servicestatus     => v_servicestatus,
                                                                         accountstatus     => v_accountstatus,
                                                                         tariffplanid      => v_tariffplanid,
                                                                         activationdate    => v_activationdate,
                                                                         servicefeedate    => v_servicefeedate,
                                                                         suspendeddate     => v_suspendeddate,
                                                                         frozendate        => v_frozendate,
                                                                         prefdestlist0     => v_prefdestlist0,
                                                                         prefdestexpiry0   => v_prefdestexpiry0,
                                                                         prefdestlist1     => v_prefdestlist1,
         
                                                                       prefdestexpiry1   => v_prefdestexpiry1);
       
      -- v_prefdestexpiry1:='20-OCT-17';--HC
      -- v_prefdestexpiry0:='20-OCT-17';--HC
       
       
          if(V_result <> 0) then 
              P_ERR_CODE := 97;
              P_SQL_CODE := SQLCODE || ' ' || SQLERRM;
              P_ERR_TEXT := 'Error en PP_PP_SERVER.Get_Subscriber_Service';
              P_RESPONSE:= PA_USSD_COMMON.GET_MESSAGE_USSD('USSDERRGEN');
              return -1;
          end if;

v_prefDestExpiry0 :=v_prefDestExpiry0 -1;
         if ( v_prefDestExpiry0 > SYSDATE) then  -- si la promocion no ha vencido:
            V_fechaMsjePP := to_char(v_prefDestExpiry0, 'dd/mm/yy'); 
            P_RESPONSE:= P_RESPONSE || '<msjePP>' || replace(PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILPAPP'), '$(dd/mm/aa)', V_fechaMsjePP) || '</msjePP>';
          else                                   -- si la promocion ha vencido:
            P_RESPONSE:= P_RESPONSE || '<msjePP>' || PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILPVPP') || '</msjePP>';
          end if;
          
end if;

 -- v_canal: parametro fijo stl parameter
  SELECT stl_char_value 
  INTO V_CANAL
  FROM stl_parameters
  
  WHERE stl_id = 'NICNL';
  
  /* validacion contenido cursor para utilizar v_flag_contenido en caso de que el curso no traiga filas*/
     OPEN C_GET_PROMOS (V_NIM, V_PLAN, V_CANAL);
     LOOP
     FETCH C_GET_PROMOS INTO V_C_GET_PROMOS_RECORD;
     IF (C_GET_PROMOS%ROWCOUNT > 0 ) THEN
         v_flag_contenido := true;
     else
        v_flag_contenido := false;
        
        exit;
     end if;
     
     EXIT WHEN C_GET_PROMOS%NOTFOUND;
     END LOOP;
     CLOSE C_GET_PROMOS;  
     
  if not (v_flag_contenido) THEN
    
      Select DECODE(SUBSTR(P_NIM, 0, 3), '549', 'ar', '595', 'py', '598', 'uy')
      Into V_pais
      From dual;
      
    
      
      --linea pp, sin promo
      if(V_LINE_TYPE = 'PP') then
    
      -- busca los features q referencian al pack de llamadas ilimitadas
        SELECT stl_char_value INTO featuresPLI

       FROM stl_parameters
       
        WHERE stl_id = 'PLLI';
       -- consulto si la linea tiene algun pack de llamadas ilimitadas
        SELECT count(*) INTO V_packLlamadasI
        
       FROM cellular_packages cp, feature_packages fp
       
        WHERE cp.cpk_clu_cellular_number = V_NIM 
        AND cp.cpk_pkt_id =  fp.pks_pkt_id
        AND INSTR(featuresPLI, '#' || fp.pks_ftr_id || '#') > 0;
        
        
        -- linea pp sin promo con paquetes de llamadas ilimitadas
    
        if(V_packLlamadasI > 0) then
           P_RESPONSE:= PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILCPLI');--SIN PROMO CON PAQUETE
          else
        --linea pp sin promo, sin pack de llamadas ilimitadas
            P_RESPONSE:= replace(PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILSNI'), '$(codigoDelPais)', V_pais);--msj sin promo y sin paquete
          end if; 
       
      else
        -- busca los features q referencian al pack de llamadas ilimitadas
        SELECT stl_char_value INTO featuresPLI
        FROM stl_parameters
        WHERE stl_id = 'PLLI';

        -- consulto si la linea tiene algun pack de llamadas ilimitadas
        SELECT count(*) INTO V_packLlamadasI
        
        FROM cellular_packages cp, feature_packages fp
        
        WHERE cp.cpk_clu_cellular_number = V_NIM 
        AND cp.cpk_pkt_id =  fp.pks_pkt_id
        AND INSTR(featuresPLI, '#' || fp.pks_ftr_id || '#') > 0;
        
        --linea co o cr, sin promo, con pack de llamadas ilimitadas
        if(V_packLlamadasI > 0) then
          --co o cr, sin promo, con pack de llamadas ilimitadas
            P_RESPONSE:= PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILCPLI');
        else
       --CO O CR, SIN PROMO SIN PAQUETE
            P_RESPONSE:= PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILSPLI');  
            
        end if;
        
      end if;
      
      RETURN 1;
 ELSE   
     
     /*EN CASO DE TRAER ALGO CARGAR LOS DATOS A P_RESPONSE*/
     FOR C IN C_GET_PROMOS (V_NIM, V_PLAN, V_CANAL) LOOP
             
         
      P_RESPONSE:= p_response||'<promoN>';
      P_RESPONSE:= P_RESPONSE||'<promoDescription>'||C.PROMODESCRIPTION||'</promoDescription>';     
      P_RESPONSE:= P_RESPONSE||'<typeDescription>'||C.TYPEDESCRIPTION||'</typeDescription>';
      P_RESPONSE:= P_RESPONSE||'<promoId>'||C.PROMOID||'</promoId>'; 
      P_RESPONSE:= P_RESPONSE||'<vigente>'||C.VIGENTE||'</vigente>';
      P_RESPONSE:= P_RESPONSE||'<quantityNumbers>'||C.Quantitynumbers||'</quantityNumbers>';     
      P_RESPONSE:= P_RESPONSE||'<quantityFixed>'||C.Quantityfixed||'</quantityFixed>';
      P_RESPONSE:= P_RESPONSE||'<quantityBF>'||C.Quantitybf||'</quantityBF>';
      P_RESPONSE:= P_RESPONSE||'<quantityInserts>'||C.Quantityinserts||'</quantityInserts>'; 
      P_RESPONSE:= P_RESPONSE||'<quantityOnNet>'||C.Quantityonnet||'</quantityOnNet>';   
      P_RESPONSE:= P_RESPONSE||'<promoType>'||C.TYPE||'</promoType>';   
      P_RESPONSE:= P_RESPONSE||'</promoN>';
     
             
     
  END LOOP;
 
END IF;
  
  
  
  RETURN 0;
      



EXCEPTION 
 WHEN NO_DATA_FOUND THEN
      P_ERR_CODE := 98;
      P_SQL_CODE := SQLCODE || ' ' || SQLERRM;
      P_ERR_TEXT := 'La linea no posee Numeros Ilimitados';
      
      Select DECODE(SUBSTR(P_NIM, 0, 3), '549', 'ar', '595', 'py', '598', 'uy')
      Into V_pais
      From dual;
      
      P_RESPONSE:= replace(PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILSNI'), '$(codigoDelPais)', V_pais);
      
      --linea pp, sin promo
      if(V_LINE_TYPE = 'PP') then
        P_RESPONSE:= replace(PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILSNI'), '$(codigoDelPais)', V_pais);
      else
        -- busca los features q referencian al pack de llamadas ilimitadas
        SELECT stl_char_value INTO featuresPLI
        
        FROM stl_parameters
         
        WHERE stl_id = 'PLLI';

        -- consulto si la linea tiene algun pack de llamadas ilimitadas
        SELECT count(*) INTO V_packLlamadasI
       
        FROM cellular_packages cp, feature_packages fp
        
        WHERE cp.cpk_clu_cellular_number = V_NIM 
        AND cp.cpk_pkt_id =  fp.pks_pkt_id
        AND INSTR(featuresPLI, '#' || fp.pks_ftr_id || '#') > 0;
        
        --linea co o cr, sin promo, con pack de llamadas ilimitadas
        if(V_packLlamadasI > 0) then
          P_RESPONSE:= PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILCPLI');
        else
        --linea co o cr, sin promo, sin pack de llamadas ilimitadas
          P_RESPONSE:= PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILSPLI'); 
        end if;
        
      end if;
      
      RETURN 1;
 WHEN OTHERS THEN
      P_ERR_CODE := 99;
      P_SQL_CODE := SQLCODE || ' ' || SQLERRM;
      P_ERR_TEXT := 'Error Generico';
      P_RESPONSE:= PA_USSD_COMMON.GET_MESSAGE_USSD('USSDERRGEN');
      raise_application_error (-20025,'FALLO PA_USSD_FRIENDS_AND_FAMILY.getPromos: '||SQLCODE || ' ' || SQLERRM);
      RETURN - 1;

END getPromos;








/*
 El metodo trae la informacion relacionada con la promo de la linea, dicha informacion es la descripcion 
 cantidad de numero claro, cantidad de numeros externos, cantidad de movimientos disponibles, cantidad de movimientos. 
*/
 FUNCTION getPromoData(P_cellularNumber IN VARCHAR2,--IN cellulars.clu_cellular_number%TYPE,
                       P_PROMID     IN VARCHAR2,
                       P_QuantityInserts IN NUMBER, -- Cantidad total de movimientos disponibles
                       P_QuantityNumbers IN NUMBER, -- Cantidad total de numeros disponibles para configurar
                       P_QuantityBF IN NUMBER, -- Cantidad total de disp. numeros mej. amigos
                       P_QuantityOnNet IN NUMBER, -- Cantidad total de disp. numeros claros
                       P_QuantityFixed IN NUMBER, -- Cantidad total de disp. numeros externos
                       P_ERR_CODE   OUT NUMBER, 
                       P_ERR_TEXT   OUT VARCHAR2, 
                       P_SQL_CODE   OUT VARCHAR2, 
                       P_RESPONSE   OUT VARCHAR2,
                       P_QuantityMovDisp OUT NUMBER,
                       P_QuantityNumbersConfig OUT NUMBER) RETURN NUMBER 
 IS

  V_NUMCLARO         NUMBER;
  V_BESTFRIEND       cellular_special_numbers.csn_best_friend%TYPE;
  V_NUMEXTERN         cellular_special_numbers.csn_flag_fixed%TYPE;
  V_MOVDISP          cellular_special_numbers_quant.csq_quantity_insert%TYPE;
  movCount           cellular_special_numbers_quant.csq_quantity_insert%TYPE;
  V_RESULTADO        NUMBER;
  p_end              DATE;
  fechaComienzo      DATE;
  fechaFin           DATE;
  v_validar_numero   NUMBER;
  v_cantNrosConfigurados NUMBER;
  v_cantLugaresAdd NUMBER;
  v_nim varchar2(10);

-- Cursor para obtener lineas configuradas 
  CURSOR c_getPromoData(C_PROMID IN VARCHAR2, 
                        C_NIM    IN VARCHAR2)
  IS
  
    SELECT prm_id AS promo, 
           csn_pais AS country,
           DECODE(csn_pais,'AR','Argentina','UY','Uruguay','PY','Paraguay',NULL) AS countryAb,
           csn_start_dialed_number AS dialedNumber, -- Nro amigo
           NVL(csn_best_friend,'N') AS bestFriend, -- ?Es BF?
           NVL(csn_flag_fixed,'N') AS numExtern  -- ?Es externo?
    
    FROM promotions , cellular_special_numbers
    
    WHERE csn_prm_id = C_PROMID
    AND csn_prm_id = prm_id
    AND csn_start_cellular_number = C_NIM
    AND csn_start_date < SYSDATE
    AND NVL(csn_end_date,SYSDATE+1) > SYSDATE;

BEGIN
  
   V_BESTFRIEND:=0;   
   V_NUMEXTERN:=0;
   V_NUMCLARO:=0;
   movCount := 0;
   v_cantNrosConfigurados:=0;
   v_cantLugaresAdd:=0;
   v_nim:= Pa_Ussd_Common.GET_CELLULAR_NUMBER(BILL_NUMBER => Pa_Ussd_Common.GET_BILL_NUMBER(MSISDN => P_cellularNumber));
--CANTIDAD DE NROC CONFIGURADOS

SELECT COUNT (1)
INTO v_cantNrosConfigurados
FROM CELLULAR_SPECIAL_NUMBERS CSN
WHERE CSN.CSN_PRM_ID = P_PROMID
AND CSN.CSN_START_CELLULAR_NUMBER = v_nim || SUBSTR(UID, 1, 0)
AND CSN.CSN_START_DATE < SYSDATE
AND NVL (CSN.CSN_END_DATE, SYSDATE + 1) > SYSDATE;
       

P_QuantityNumbersConfig:=v_cantNrosConfigurados;-- retorna la cantidad de nros configurados que presente la linea para mostrar o no opciones en el flow axml.



if (P_QuantityNumbers>=0 and v_cantNrosConfigurados>=0) then 
  
v_cantLugaresAdd:= P_QuantityNumbers - v_cantNrosConfigurados;
P_RESPONSE:= P_RESPONSE||'<cantLugaresAdd>'||v_cantLugaresAdd||'</cantLugaresAdd>';

end if;

begin

-- Obtiene movimientos realizados y fechas de vigencia.
    SELECT  csq_start_date, --fecha de inicio de ciclo 
    csq_end_date+1,
    csq_quantity_insert -- Movimientos realizados
    INTO fechaComienzo, fechaFin, movCount
    FROM cellular_special_numbers_quant
    
    WHERE csq_start_cellular_number =v_nim
    AND csq_prm_id = P_PROMID
    AND csq_start_date < SYSDATE
    AND NVL(csq_end_date+1,SYSDATE+1) >= SYSDATE;
    
    EXCEPTION 
        WHEN NO_DATA_FOUND THEN 
             movCount:=0; 
        END;
    
-- Verifica si tiene movimientos disponibles
V_MOVDISP := P_QuantityInserts - movCount;
P_QuantityMovDisp:= V_MOVDISP; 
P_RESPONSE:= P_RESPONSE || '<movDisp>'|| V_MOVDISP ||'</movDisp>';

-- Arma el titulo de la promo segun disponibilidad de movimientos
if (V_MOVDISP > 0) then
    P_RESPONSE:= P_RESPONSE || '<titlePromo>'|| replace(PA_USSD_COMMON.GET_MESSAGE_USSD('USSDFFCM'), '$(disponiblesModificacion)', V_MOVDISP) || '</titlePromo>';
else
    P_RESPONSE:= P_RESPONSE || '<titlePromo>'|| PA_USSD_COMMON.GET_MESSAGE_USSD('USSDFFSM') || '</titlePromo>';
end if;

-- Recorre los numeros configurados y los carga en el p_response:xml
 FOR C IN c_getPromoData(P_PROMID, v_nim) LOOP
      P_RESPONSE:= P_RESPONSE||'<nroConfigurado>'; 
      P_RESPONSE:= P_RESPONSE||'<dialedNumber>'||C.dialedNumber||'</dialedNumber>';
      P_RESPONSE:= P_RESPONSE||'<country>'||C.country||'</country>';     
      P_RESPONSE:= P_RESPONSE||'<countryAb>'||C.countryAb||'</countryAb>';
     
                                    
-- Calcula cantidad de numeros configurados por tipo (num claro, num externos, num bf)      
      if(C.bestFriend = 'Y') then
        V_BESTFRIEND:= V_BESTFRIEND + 1;
        P_RESPONSE:= P_RESPONSE||'<type>Nro. Ilimitado</type>';
     elsif (C.NUMEXTERN = 'Y') then
        V_NUMEXTERN:= V_NUMEXTERN + 1;
        P_RESPONSE:= P_RESPONSE||'<type>Nro. Externo</type>';
      else
        V_NUMCLARO:= V_NUMCLARO + 1;
        P_RESPONSE:= P_RESPONSE||'<type>Nro. Claro</type>';
      end if;
        P_RESPONSE:= P_RESPONSE||'</nroConfigurado>';
 
 END LOOP;
 
-- Guarda cantidad de numeros configurados por tipo (num claro, num externos, num bf) 
-- y arma el mensaje a mostrar en la opcion Mas Info
  P_RESPONSE:= P_RESPONSE || '<claro>'|| V_NUMCLARO ||'</claro>';
  P_RESPONSE:= P_RESPONSE || '<bestFriend>'|| V_BESTFRIEND ||'</bestFriend>';
  P_RESPONSE:= P_RESPONSE || '<externo>'|| V_NUMEXTERN ||'</externo>'; 
  P_RESPONSE:= P_RESPONSE || '<titleInfo>Tenes disponible para configurar (';
  
  P_RESPONSE:= P_RESPONSE || (P_QuantityOnNet - V_BESTFRIEND - V_NUMCLARO) ||') nros. Claro';
  
  if(P_QuantityFixed > 0) then
     P_RESPONSE:= P_RESPONSE || ', (' || (P_QuantityFixed - V_NUMEXTERN)||') nros. Externos';
  end if;
  
  if(P_QuantityBF > 0) then
     P_RESPONSE:= P_RESPONSE || ', (' || (P_QuantityBF - V_BESTFRIEND)||') nros. Ilimitados'; 
  end if;
 
  P_RESPONSE:= P_RESPONSE || '.';
 
  P_RESPONSE:= P_RESPONSE || 'Te quedan ' || V_MOVDISP;
  
  if(V_MOVDISP <> P_QuantityInserts) then
     P_RESPONSE:= P_RESPONSE || ' de ' || P_QuantityInserts;
  end if;
  
  P_RESPONSE:= P_RESPONSE || ' cambios'; 


 
 if(fechaFin is not null) then 
    P_RESPONSE:= P_RESPONSE || ' y se renuevan el ' || to_char(fechaFin, 'dd/mm/yy') || '.</titleInfo>'; 
  else 
  P_RESPONSE:= P_RESPONSE ||'.</titleInfo>';
  end if;
RETURN 0;
  
 EXCEPTION 
 WHEN OTHERS THEN
      P_ERR_CODE := 99;
      P_SQL_CODE := SQLCODE || ' ' || SQLERRM;
      P_ERR_TEXT := 'Error Generico';
      P_RESPONSE:= PA_USSD_COMMON.GET_MESSAGE_USSD('USSDEGEN');
      raise_application_error (-20025,'FALLO PA_USSD_FRIENDS_AND_FAMILY.getPromoData: '||SQLCODE || ' ' || SQLERRM);
      RETURN - 1;

 END getPromoData;

/* 
Validaciones antes de realizar la insercion de un nuevo numero 
retorno 1: numero invalido
retorno 2: sin disponibilidad offnet
retorno 3: sin disponibilidad onnet
*/
FUNCTION validateNewFriend(P_cellularNumber IN cellulars.clu_cellular_number%TYPE, 
                       P_PROMID        IN VARCHAR2,
                       P_DESCRIPTION   IN VARCHAR2,
                       P_friendNumber IN cellulars.clu_cellular_number%TYPE, -- Numero a agregar
                       P_account IN VARCHAR2, -- Id de la cuenta
                       P_plan   IN VARCHAR2, -- Plan de la cuenta
                       P_canBeBF OUT VARCHAR2, -- Dice si puede ser best friend
                       P_prefix IN VARCHAR2, -- Codigo del pais
                       P_Response OUT VARCHAR2, -- Mensaje de salida
                       P_offnet out varchar2, -- indica si el valor de P_friendNumber es offnet
                       P_QuantityMovDisp IN NUMBER,--Cantidad disponible para modificar nros cargados
                       P_ERR_CODE   OUT NUMBER, 
                       P_ERR_TEXT   OUT VARCHAR2, 
                       P_SQL_CODE   OUT VARCHAR2) RETURN NUMBER
                     
 IS
 
P_retorno              NUMBER;
V_quantity             NUMBER;
V_endDate              DATE;
P_pais                 VARCHAR2(5);
v_nim_digits           NUMBER;
V_quantityFixed        NUMBER;
v_newFriend            VARCHAR2(75);--cellulars.clu_cellular_number%TYPE;
V_longitud       NUMBER;
v_cantNrosConfiguradosFixed NUMBER;
v_cantNrosConfiguradosOnnet NUMBER;
V_cantFixed NUMBER;
V_cantOnnet NUMBER;
V_cantTotal NUMBER;
V_numPY varchar2(5);-- Se utiliza para comprobar SOLO EN PY que el nro amigo comience con 0

CURSOR c_controlo_numeros IS
      SELECT csn_start_dialed_number, csn_end_date
        FROM cellular_special_numbers
       WHERE (csn_end_date >= SYSDATE OR csn_end_date IS NULL)
         AND csn_start_cellular_number = P_cellularNumber
         AND csn_prm_id = P_PROMID
         AND csn_start_dialed_number=P_friendNumber;


BEGIN
 
V_endDate:= null;
P_canBeBF:= 'Y';
P_offnet:='N';


Select DECODE(P_prefix, '549', 'AR', '598', 'UY', '595', 'PY')
Into P_pais
From dual;



--Valida si el pais es PY, trunca el primer cero 
--Modificaci?n 
/*
if (P_pais='PY' and P_friendNumber <> null) then
  
    select TRUNC(P_friendNumber,1) INTO v_newFriend FROM DUAL;--nvo 
   */
   
   if (P_pais='PY' and P_friendNumber is not null) then
  --fix PY
           V_numPY:=SUBSTR(P_friendNumber,1,1);
           if(V_numPY<>0) then
            P_ERR_TEXT := 'Formato de numero incorrecto, el nro amigo debe comenzar con 0';
            P_Response := PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILNI' || P_pais);
            P_ERR_CODE := -1;
            return 1;
            end if;
            
  --End FIX PY          
    select TRUNC(P_friendNumber,1) INTO v_newFriend FROM DUAL;--nvo
    
    if(v_newFriend=P_cellularNumber) then
      -- El numero es el mismo numero de celular que el del beneficiario.
     P_Response:= PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILCELP');
     return 1;
    
    End if;
    
   
   
   
ELSE
    v_newFriend:=P_friendNumber;

end  if;


   
-- Valida el package
P_retorno:= pa_promo_ff.valida_package(p_nim => v_newFriend,
                                       p_prm_id => P_PROMID, 
                                       p_err_no => P_ERR_CODE, 
                                       p_errtxt => P_ERR_TEXT);
  
  if (P_retorno <> 0) then
     -- Si el package no existe, lo agrega
     P_retorno:= pa_promo_ff.validate_package(p_nim => v_newFriend,
                                              p_prm_id => P_PROMID, 
                                              p_start_date => SYSDATE, 
                                              p_end_date => V_endDate, 
                                              p_err_no => P_ERR_CODE, 
                                              p_errtxt => P_ERR_TEXT);
   
  
  
    if(P_retorno <> 0) then
       P_Response:= PA_USSD_COMMON.GET_MESSAGE_USSD('USSDERRGEN');
       return - 1;
     end if;
  end if;

-- Valida que el formato del numero sea correcto
    SELECT DECODE(P_pais, 'AR', 10, 'UY', 8, 'PY', 9, 10) INTO v_nim_digits FROM DUAL;
    -- Si es distinto, ingreso un celular erroneo
    
    V_longitud:=LENGTH(v_newFriend);
    
    if  V_longitud <> v_nim_digits then
      
      P_ERR_TEXT := 'Formato de numero incorrecto';
      P_Response := PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILNI' || P_pais);
      P_ERR_CODE := -1;
      
      return 1;
    end if;
    
    FOR v_numrep IN c_controlo_numeros LOOP
     
          IF to_number(v_numrep.csn_start_dialed_number) =to_number(v_newFriend) then
             IF (v_numrep.csn_end_date > trunc(SYSDATE) OR v_numrep.csn_end_date IS NULL) THEN
            P_Response:= PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILCELC');
            return 1;
            END IF;

         
          END IF;
        END LOOP;



-- Valida el numero a agregar
P_retorno:= f_validate_dialed_number(p_cellular => P_cellularNumber, 
                                     p_prm_id => P_PROMID, 
                                     p_dialed => P_friendNumber, 
                                     p_acc_id => P_account, 
                                     p_rpl_id => P_plan, 
                                     p_start_date => SYSDATE, 
                                     p_end_date => V_endDate,
                                     p_description => P_DESCRIPTION,
                                     p_country => P_pais,
                                     p_err_number => P_ERR_CODE,
                                     p_err_message => P_ERR_TEXT);

       



if(P_retorno <> 0) then
  
  if(P_ERR_CODE = -12) then
     -- El numero no pertenece a Claro. 
     P_Response:= PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILCELNC');
     return 1;
  elsif(P_ERR_CODE = -38) then
             select NVL(PRM_QUANTITY_FIXED,0)
             into V_quantityFixed-- cantidad de nros offnet permitidos
             FROM promotions
             where prm_id= P_PROMID;
                   if(V_quantityFixed>=1) then
                       -- No se permiten nros. celulares de otras compa?ias.
                       P_Response:= PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILNOFFN');
                       return 1;
                   end if;
                    P_Response:= SUBSTR(PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILNOFFN'), 1, 94);
                    return 1;
                                          
                     
  elsif(P_ERR_CODE = -39) then
     -- No tenes disponibilidad para mas numeros de otras compa?ias
     P_Response:= PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILSDOFF');
     return 1;
  elsif(P_ERR_CODE = -24) then
     -- El numero ya se encuentra cargado
     P_Response:= PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILCELC');
     return 1;
      elsif(P_ERR_CODE = -29) then
     -- El numero ya se encuentra cargado
     P_Response:= P_ERR_TEXT;--PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILCELC');
     return 1;
  elsif(P_ERR_CODE = -2) then
     -- El numero es el mismo numero de celular que el del beneficiario.
     P_Response:= PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILCELP');
     return 1;
  end if;
  
  
  P_Response:= PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILNI');
  return P_retorno;
end if;



-- Valida si el numero es un numero claro
 P_retorno:= f_validate_number_onnet(P_CELLULAR => v_newFriend,
                                    P_ERR_NUMBER => P_ERR_CODE, 
                                    P_ERR_MESSAGE => P_ERR_TEXT);



--FIX 
select NVL(PRM_QUANTITY_FIXED,0)
into V_quantityFixed-- cantidad de nros offnet permitidos
FROM promotions
where prm_id= P_PROMID;
             
 --CANTIDAD DE NRO fixed CONFIGURADOS
if V_quantityFixed > 0 then
  
SELECT COUNT (1)
INTO v_cantNrosConfiguradosFixed
FROM CELLULAR_SPECIAL_NUMBERS CSN
WHERE CSN.CSN_PRM_ID = P_PROMID
AND CSN.CSN_START_CELLULAR_NUMBER = P_cellularNumber
AND NVL(CSN.CSN_FLAG_FIXED, 'N') = 'Y'
AND CSN.CSN_START_DATE < SYSDATE
AND NVL (CSN.CSN_END_DATE, SYSDATE + 1) > SYSDATE;

if v_cantNrosConfiguradosFixed is null then
   v_cantNrosConfiguradosFixed:=0;
end if;

V_cantFixed:=V_quantityFixed-v_cantNrosConfiguradosFixed;

--FIX 2
if P_ERR_TEXT is null and  V_cantFixed=0 then
      P_Response:= PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILNOFFN');
      return 1;
      end if;
      
end if;
if P_ERR_TEXT = 'El numero ingresado es de tipo OFFNET' and  V_cantFixed=0 and P_QuantityMovDisp=0 then
      P_Response:= PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILSDOFF');
      return 1;
      
      
end if;


--/FIX



 if ((P_ERR_TEXT = 'El numero ingresado es de tipo OFFNET') and (P_retorno = 1))THEN
 P_offnet:='Y';
 end if ;     
 
select NVL(a.prm_quantity_numbers,0),NVL(a.prm_quantity_fixed,0)
into V_cantTotal,V_quantityFixed -- cantidad de nros offnet permitidos
FROM promotions a
where prm_id= P_PROMID;
V_cantOnnet:=V_cantTotal-V_quantityFixed; --cantidad total de numeros onnet que puedo cargar.

SELECT COUNT (1)
INTO v_cantNrosConfiguradosOnnet
FROM CELLULAR_SPECIAL_NUMBERS CSN
WHERE CSN.CSN_PRM_ID = P_PROMID
AND CSN.CSN_START_CELLULAR_NUMBER = P_cellularNumber
AND NVL(CSN.CSN_FLAG_FIXED, 'N') = 'N'
AND CSN.CSN_START_DATE < SYSDATE
AND NVL (CSN.CSN_END_DATE, SYSDATE + 1) > SYSDATE;
                           
V_cantOnnet:=V_cantOnnet-v_cantNrosConfiguradosOnnet;

  if ((P_ERR_TEXT = 'El numero ingresado es de tipo ONNET') and (P_retorno = 0) and V_cantOnnet<=0 and P_QuantityMovDisp=0) then
      P_Response:= PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILSDON');
      return 1;
  end if;


if(P_retorno = 0) then

    -- Valida disponibilidad y posibilidad de cargar un best friend
    P_retorno:= f_validate_available_bests(P_CELLULAR => P_cellularNumber,
                                           P_PRM_ID => P_PROMID, 
                                           P_QUANTITY => V_quantity, 
                                           P_ERR_NUMBER => P_ERR_CODE,
                                           P_ERR_MESSAGE => P_ERR_TEXT);

      if (P_ERR_TEXT = 'La promocion no posee disponibilidad de Mejor Amigo.') then
          P_Response:= PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILSPBF');
          P_canBeBF:= 'N';
      elsif (P_ERR_TEXT ='La linea no posee disponibilidad de Mejor Amigo.' and V_quantity = 0) then
          P_Response:= PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILSDBF');
          P_canBeBF:= 'N';
      end if;

    -- Valida disponibilidad de cargar un numero claro
    P_retorno:= f_validate_available_onnet(P_CELLULAR => P_cellularNumber, 
                                           P_PRM_ID => P_PROMID, 
                                           P_ERR_NUMBER => P_ERR_CODE, 
                                           P_ERR_MESSAGE => P_ERR_TEXT);


  

      if (P_retorno = 1 and P_QuantityMovDisp=0 and P_ERR_TEXT = 'No posee disponibilidad para numeros Claro') then
        P_Response:= PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILSDON');
        return 3;
      end if;
      
      P_Response:= replace(PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILMCFON'), '${friendNumber}', v_newFriend);

elsif (P_retorno = 1) then

   P_canBeBF:= 'N';
   -- Valida disponibilidad de cargar un numero offnet  
   P_retorno:= f_validate_available_offnet(P_CELLULAR => P_cellularNumber, 
                                           P_PRM_ID => P_PROMID,
                                           P_ERR_NUMBER => P_ERR_CODE, 
                                           P_ERR_MESSAGE => P_ERR_TEXT);
    
    if ((P_ERR_TEXT = 'No posee disponibilidad para numeros Externos') and (P_retorno = 1)and P_QuantityMovDisp=0) then
       P_Response:= PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILSDOF');
       return 2;
    end if;
    
    P_Response:= replace(PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILMCFOF'), '${friendNumber}', v_newFriend);
    
end if;

return 0;

EXCEPTION 
 WHEN OTHERS THEN
      P_ERR_CODE := 99;
      P_SQL_CODE := SQLCODE || ' ' || SQLERRM;
      P_Response := PA_USSD_COMMON.GET_MESSAGE_USSD('USSDEGEN');
      raise_application_error (-20025,'FALLO PA_USSD_FRIENDS_AND_FAMILY.validateNewFriend: '||SQLCODE || ' ' || SQLERRM);
      RETURN - 1;

END validateNewFriend;

/* Validaciones antes de realizar el cambio del numero mejor amigo */
FUNCTION validateAvailableChangeBF(P_cellularNumber IN cellulars.clu_cellular_number%TYPE, 
                       P_PROMID        IN VARCHAR2,
                       P_Response OUT VARCHAR2, -- Mensaje de salida
                       P_ERR_CODE   OUT NUMBER, 
                       P_ERR_TEXT   OUT VARCHAR2, 
                       P_SQL_CODE   OUT VARCHAR2,
                       P_BF_CARGADO OUT VARCHAR2,
                       P_CANTIDAD_NROS OUT NUMBER) RETURN NUMBER-- indica si tiene configurado algun nro como BF
                       
 IS
 
P_retorno              NUMBER;
V_quantity             NUMBER;
V_date_av             DATE;
v_hayNrosBF varchar2(5);
v_contadorNros number;
V_fechaMsje varchar2(30);

CURSOR c_getBfCargado(P_PROMID IN VARCHAR2, 
                      P_cellularNumber   IN VARCHAR2)
  IS
  
   SELECT csn_start_dialed_number AS dialedNumber -- Nro amigo BF
             
    FROM promotions , cellular_special_numbers
    
    WHERE csn_prm_id = P_PROMID
    AND csn_prm_id = prm_id
    AND csn_start_cellular_number = P_cellularNumber
    AND csn_start_date < SYSDATE
    AND NVL(csn_end_date,SYSDATE+1) > SYSDATE
    AND NVL(csn_best_friend, 'N') = 'Y';

BEGIN
  v_contadorNros:=0;
  
FOR C IN c_getBfCargado(P_PROMID, P_cellularNumber) LOOP
      P_RESPONSE:= P_RESPONSE||'<nroConfigurado>'; 
      P_RESPONSE:= P_RESPONSE||'<dialedNumber>'||C.dialedNumber||'</dialedNumber>';
      P_RESPONSE:= P_RESPONSE||'</nroConfigurado>';
      v_hayNrosBF:='Y';
      v_contadorNros:= v_contadorNros+1;
 END LOOP;
 
 if v_hayNrosBF='Y' then
 P_BF_CARGADO:='Y';
 else 
 P_BF_CARGADO:='N';
   end if;
   
P_CANTIDAD_NROS:=v_contadorNros;

P_retorno:=  f_validate_available_change_bf(P_CELLULAR => P_cellularNumber, 
                                            P_PRM_ID => P_PROMID,
                                            P_TIME_VALIDATE => 'PER',
                                            P_TYPE => 'ALL', 
                                            P_DATE_AVAILABLE => V_date_av,
                                            P_QUANTITY => V_quantity, 
                                            P_ERR_NUMBER => P_ERR_CODE, 
                                            P_ERR_MESSAGE => P_ERR_TEXT);
                                            
                                            

  if(V_quantity = 0) then
   V_fechaMsje :=  to_char(V_date_av, 'dd/mm/yy');
    P_response:= replace(PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILCDBF'), '$(dd/mm/aa)',V_fechaMsje);
    return 1;
  end if;

  if(P_retorno <> 0) then
   P_response:= PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILFALLA'); 
   return - 1;
  end if;  

return 0;

EXCEPTION 
 WHEN OTHERS THEN
      P_ERR_CODE := 99;
      P_SQL_CODE := SQLCODE || ' ' || SQLERRM;
      P_Response := PA_USSD_COMMON.GET_MESSAGE_USSD('USSDERRGEN');
      raise_application_error (-20025,'PA_USSD_FRIENDS_AND_FAMILY.validateAvailableChangeBF: '||SQLCODE || ' ' || SQLERRM);
      RETURN - 1;

END validateAvailableChangeBF;

/* 
Inserta un nuevo numero a la promocion de la linea.
*/
 FUNCTION insertNewFriend(P_cellularNumber IN cellulars.clu_cellular_number%TYPE,
                       P_PROMID IN VARCHAR2,
                       P_friendNumber  IN cellulars.clu_cellular_number%TYPE, -- Numero a agregar
                       P_account IN VARCHAR2, -- Id de la cuenta
                       P_isBF IN VARCHAR2, -- Dice si es best friend
                       P_prefix IN VARCHAR2, -- Codigo del pais
                       P_Response OUT VARCHAR2,
                       P_ERR_CODE   OUT NUMBER, 
                       P_ERR_TEXT   OUT VARCHAR2, 
                       P_SQL_CODE   OUT VARCHAR2) RETURN NUMBER
                       
 IS

P_pais               VARCHAR2(5);
P_retorno            NUMBER;
V_numPY cellulars.clu_cellular_number%TYPE;
v_numeroFriend cellulars.clu_cellular_number%TYPE;
v_tipoPromo varchar2(5);

BEGIN

v_numeroFriend:=P_friendNumber;

Select DECODE(P_prefix, '549', 'AR', '598', 'UY', '595', 'PY')
Into P_pais
From dual;

select PRM_TYPE 
into v_tipoPromo
from promotions a 
where a.prm_id=P_PROMID;


--FIX carga de nros con 0 en PY
if P_pais='PY' and v_tipoPromo='S' then
V_numPY:=SUBSTR(P_friendNumber,2);
v_numeroFriend:=V_numPY;
end if;
--/FIX




-- Funcion que inserta el nuevo numero 
P_retorno := f_insert_special_number(P_CELLULAR => P_cellularNumber,
                                     P_PRM_ID => P_PROMID, 
                                     P_START_DIALED_NUMBER =>v_numeroFriend, --P_friendNumber, 
                                     P_START_DATE => null, 
                                     P_END_DATE => null, 
                                     P_OBSERVATIONS => null, 
                                     P_ACT_ID => P_account, 
                                     P_BEST_FRIEND => 'N', 
                                     P_COUNTRY => P_pais, 
                                     P_PREFIX => P_prefix, 
                                     P_ERR_NUMBER => P_ERR_CODE, 
                                     P_ERR_MESSAGE => P_ERR_TEXT); 



  if(P_retorno <> 0) then
    P_Response:= PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILFALLA');
    return - 1;
  end if; 

  if(P_isBF = 'Y') then
     P_Response:= PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILOKBF');
  else 
     P_Response:= PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILOKEY');
  end if;

  commit;
  
return 0;

EXCEPTION 
 WHEN OTHERS THEN
      P_ERR_CODE := 99;
      P_SQL_CODE := SQLCODE || ' ' || SQLERRM;
      P_ERR_TEXT := PA_USSD_COMMON.GET_MESSAGE_USSD('USSDERRGEN');
      raise_application_error (-20025,'FALLO PA_USSD_FRIENDS_AND_FAMILY.insertNewFriend: '||SQLCODE || ' ' || SQLERRM);
      RETURN - 1;

END insertNewFriend;

/*            
 Permite cambiar un numero marcado como mejor amigo por otro, el nuevo numero ingresado debera ser del
 ONNET para poder ser marcado como mejor amigo. Ademas permite marcar un nuevo claro como mejor amigo.
*/
FUNCTION changeFriendBF(P_cellularNumber IN cellulars.clu_cellular_number%TYPE,
                       P_PROMID IN VARCHAR2,
                       P_friendNumberOld IN cellulars.clu_cellular_number%TYPE,-- Numero a cambiar
                       P_friendNumber IN cellulars.clu_cellular_number%TYPE, -- Numero a agregar
                       P_response OUT VARCHAR2,
                       P_ERR_CODE   OUT NUMBER, 
                       P_ERR_TEXT   OUT VARCHAR2, 
                       P_SQL_CODE   OUT VARCHAR2,
                       P_prefix IN VARCHAR2) RETURN NUMBER
                       
 IS

P_retorno            NUMBER;
P_pais  VARCHAR2(5);
V_numPY cellulars.clu_cellular_number%TYPE;
v_numeroFriend cellulars.clu_cellular_number%TYPE;
v_tipoPromo varchar2(5);

BEGIN 
  
v_numeroFriend:=P_friendNumber;

Select DECODE(P_prefix, '549', 'AR', '598', 'UY', '595', 'PY')
Into P_pais
From dual;

select PRM_TYPE 
into v_tipoPromo
from promotions a 
where a.prm_id=P_PROMID;

--FIX carga de nros con 0 en PY
if P_pais='PY' and v_tipoPromo='S' then
V_numPY:=SUBSTR(P_friendNumber,2);
v_numeroFriend:=V_numPY;
end if;
--/FIX


/* Valida que no exista un numero ilimitado configurado, 
   si no lo hay solo marca el nuevo numero como ilimitado */
if(P_friendNumberOld is null) then

  P_retorno:= f_mark_best_special_number(P_CELLULAR => P_cellularNumber, 
                                         P_PRM_ID => P_PROMID, 
                                         P_CELLULAR_MARK => v_numeroFriend, --P_friendNumber, 
                                         P_ERR_NUMBER => P_ERR_CODE, 
                                         P_ERR_MESSAGE => P_ERR_TEXT);                   
  
  if(P_retorno <> 0) then
   P_response:= PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILFALLA'); 
   return 1;
  end if;
   
  commit;

  P_Response:= PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILOKEY'); 
  
  return 0;
end if;

-- Cambia el numero mejor amigo por otro mejor amigo
  P_retorno:= f_change_best_special_number(P_CELLULAR => P_cellularNumber, 
                                           P_PRM_ID => P_PROMID, 
                                           P_CELLULAR_NEW => v_numeroFriend, --P_friendNumber, 
                                           P_CELLULAR_OLD => P_friendNumberOld, 
                                           P_ERR_NUMBER => P_ERR_CODE, 
                                           P_ERR_MESSAGE => P_ERR_TEXT);

  if(P_retorno <> 0) then
       P_response:= PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILFALLA');
       return - 1;
  end if; 

  commit;

P_Response:= PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILOKEY');
return 0;

EXCEPTION 
 WHEN OTHERS THEN
      P_ERR_CODE := 99;
      P_SQL_CODE := SQLCODE || ' ' || SQLERRM;
      P_ERR_TEXT := 'Error Generico';
      P_response := PA_USSD_COMMON.GET_MESSAGE_USSD('USSDERRGEN');
      raise_application_error (-20025,'FALLO PA_USSD_FRIENDS_AND_FAMILY.changeFriendBF: '||SQLCODE || ' ' || SQLERRM);
      RETURN - 1;

END changeFriendBF;

/*            
 Permite realizar cambios en los numeros que se cargan en la promocion, 
 estos cambios pueden ser ONNET por ONNET, ONNET 
 por OFFNET, OFFNET por ONNET, OFFNET por OFFNET. Estos cambios dependen de el tipo de promocion que posea cargada la linea.
 */
FUNCTION changeFF(P_cellularNumber IN cellulars.clu_cellular_number%TYPE,
                       P_PROMID IN VARCHAR2,
                       P_friendNumberOld IN cellulars.clu_cellular_number%TYPE, -- Numero a cambiar
                       P_friendNumber IN cellulars.clu_cellular_number%TYPE, -- Numero a agregar
                       P_account IN VARCHAR2, -- Id de la cuenta
                       P_prefix IN VARCHAR2, -- Codigo del pais
                       P_response OUT VARCHAR2,
                       P_ERR_CODE   OUT NUMBER, 
                       P_ERR_TEXT   OUT VARCHAR2, 
                       P_SQL_CODE   OUT VARCHAR2) RETURN NUMBER
                       
 IS

P_pais               VARCHAR2(5);
P_retorno            NUMBER;  
V_numPY cellulars.clu_cellular_number%TYPE;
v_numeroFriend cellulars.clu_cellular_number%TYPE;
v_tipoPromo varchar2(5);

BEGIN

v_numeroFriend:=P_friendNumber;

Select DECODE(P_prefix, '549', 'AR', '598', 'UY', '595', 'PY')
Into P_pais
From dual;

select PRM_TYPE 
into v_tipoPromo
from promotions a 
where a.prm_id=P_PROMID;

--FIX carga de nros con 0 en PY
if P_pais='PY' and v_tipoPromo='S' then
V_numPY:=SUBSTR(P_friendNumber,2);
v_numeroFriend:=V_numPY;
end if;
--/FIX





  -- Cambia el numero
  P_retorno:= f_change_special_number(P_CELLULAR => P_cellularNumber, 
                                      P_PRM_ID => P_PROMID, 
                                      P_START_DIALED_NUMBER_OLD => P_friendNumberOld, 
                                      P_START_DIALED_NUMBER_NEW => v_numeroFriend, --P_friendNumber, 
                                      P_START_DATE => SYSDATE, 
                                      P_END_DATE => null, 
                                      P_OBSERVATIONS => null, 
                                      P_ACT_ID => P_account, 
                                      P_BEST_FRIEND => null, 
                                      P_COUNTRY => P_pais, 
                                      P_PREFIX => P_prefix, 
                                      -- P_CC_SC => null, 
                                      -- P_CARGO => null, 
                                      P_ERR_NUMBER => P_ERR_CODE, 
                                      P_ERR_MESSAGE => P_ERR_TEXT); 
            
  if(P_retorno <> 0) then
       P_response:= PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILFALLA');
       return - 1;
  end if; 

  commit;

P_Response:= PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILOKEY');
return 0;

EXCEPTION 
 WHEN OTHERS THEN
      P_ERR_CODE := 99;
      P_SQL_CODE := SQLCODE || ' ' || SQLERRM;
      P_ERR_TEXT := 'Error Generico';
      P_Response:= PA_USSD_COMMON.GET_MESSAGE_USSD('USSDERRGEN');
      raise_application_error (-20025,'FALLO PA_USSD_FRIENDS_AND_FAMILY.changeFF: '||SQLCODE || ' ' || SQLERRM);
      RETURN - 1;

END changeFF;


--Se agrega a la funcion

FUNCTION listarNrosConfig(P_cellularNumber IN cellulars.clu_cellular_number%TYPE, 
                          P_PROMID     IN VARCHAR2, --id de la promo
                          P_RESPONSE OUT VARCHAR2, -- Mensaje de salida
                          P_ERR_CODE   OUT NUMBER, 
                          P_ERR_TEXT   OUT VARCHAR2, 
                          P_SQL_CODE   OUT VARCHAR2,
                          P_tieneBF out varchar2) RETURN NUMBER
                       
 IS
v_hayNros varchar2(5);
v_hayNrosBF varchar2(5);
v_promoConBF varchar2(5);

 
 --ESTE CURSOR SE UTILIZA PARA LISTAR NROS CONFIGURADOS
   CURSOR c_getPromoData(C_PROMID IN VARCHAR2, 
                        P_cellularNumber    IN VARCHAR2)
  IS
  
    SELECT prm_id AS promo, 
           csn_pais AS country,
           DECODE(csn_pais,'AR','Argentina','UY','Uruguay','PY','Paraguay',NULL) AS countryAb,
           csn_start_dialed_number AS dialedNumber, -- Nro amigo
           NVL(csn_best_friend,'N') AS bestFriend, -- ?Es BF?
           NVL(csn_flag_fixed,'N') AS numExtern  -- ?Es externo?
    
    FROM promotions , cellular_special_numbers
    
    WHERE csn_prm_id = C_PROMID
    AND csn_prm_id = prm_id
    AND csn_start_cellular_number = P_cellularNumber
    AND csn_start_date < SYSDATE
    AND NVL(csn_end_date,SYSDATE+1) > SYSDATE
    AND NVL(csn_flag_fixed, 'N') = 'N';
    
    
    --ESTE CURSOR SE UTILIZA PARA VALIDAR MENSAJES EN FLOW, SI LA LINEA CUENTA CON NROS BF CARGADOS
  CURSOR c_getPromoDataBF(C_PROMID IN VARCHAR2, 
                        P_cellularNumber    IN VARCHAR2)
  IS
  
  SELECT prm_id AS promo, 
           csn_pais AS country,
           DECODE(csn_pais,'AR','Argentina','UY','Uruguay','PY','Paraguay',NULL) AS countryAb,
           csn_start_dialed_number AS dialedNumber, -- Nro amigo
           NVL(csn_best_friend,'N') AS bestFriend, -- ?Es BF?
           NVL(csn_flag_fixed,'N') AS numExtern  -- ?Es externo?
    
    FROM promotions , cellular_special_numbers
    
    WHERE csn_prm_id = C_PROMID
    AND csn_prm_id = prm_id
    AND csn_start_cellular_number = P_cellularNumber
    AND csn_start_date < SYSDATE
    AND NVL(csn_end_date,SYSDATE+1) > SYSDATE
    AND NVL(csn_flag_fixed, 'N') = 'N'
    AND NVL(csn_best_friend, 'N') = 'Y';
    
BEGIN
v_hayNros:='N';
v_hayNrosBF:='N';


select  NVL(PRM_FF_BEST_FRIEND, 'N')
into v_promoConBF--Indica si la promocion que tiene la linea, permite nros ilimitados o BF
from PROMOTIONS 
where prm_id =P_PROMID;

--primero consulta si tiene nros bf cargados. si la promo permite bf y no tiene ninguno cargado, P_tieneBF le indicara al flow que mensaje utilizar
FOR C IN c_getPromoDataBF(P_PROMID, P_cellularNumber) LOOP
       v_hayNrosBF:='Y';
           
 END LOOP;

 if (v_hayNrosBF='N' and v_promoConBF='Y') then
P_tieneBF:='Y';-- si la promo permite bf, pero no tiene ningun nro cargado, mostrara el  mensaje  particular de este caso en el flow axml
else 
 P_tieneBF:='N';--mostrara el mensaje generico en el flow
end if;
     
-- Recorre los numeros configurados y los carga en el p_response:xml
FOR C IN c_getPromoData(P_PROMID, P_cellularNumber) LOOP
      P_RESPONSE:= P_RESPONSE||'<nroConfigurado>'; 
      P_RESPONSE:= P_RESPONSE||'<dialedNumber>'||C.dialedNumber||'</dialedNumber>';
      P_RESPONSE:= P_RESPONSE||'<country>'||C.country||'</country>';     
      P_RESPONSE:= P_RESPONSE||'<countryAb>'||C.countryAb||'</countryAb>';
      P_RESPONSE:= P_RESPONSE||'</nroConfigurado>';
      v_hayNros:='Y';
            
 END LOOP;

 if v_hayNros='Y' then
return 0;
else 
   P_ERR_TEXT:= PA_USSD_COMMON.GET_MESSAGE_USSD('USSDERRGEN');
   return 1;
   end if;

EXCEPTION 
 WHEN OTHERS THEN
      P_ERR_CODE := 99;
      P_SQL_CODE := SQLCODE || ' ' || SQLERRM;
      P_ERR_TEXT := 'Error Generico';
      P_Response:= PA_USSD_COMMON.GET_MESSAGE_USSD('USSDERRGEN');
      raise_application_error (-20025,'FALLO PA_USSD_FRIENDS_AND_FAMILY.listarNrosConfig: '||SQLCODE || ' ' || SQLERRM);
      RETURN - 1;

END listarNrosConfig;



FUNCTION setFriendBF(P_cellularNumber IN cellulars.clu_cellular_number%TYPE, 
                       P_PROMID     IN VARCHAR2, --id de la promo
                       P_friendNumber IN cellulars.clu_cellular_number%TYPE, -- numero a agregar  
                       P_response OUT VARCHAR2,
                       P_ERR_CODE   OUT NUMBER, 
                       P_ERR_TEXT   OUT VARCHAR2, 
                       P_SQL_CODE   OUT VARCHAR2,
                        P_prefix IN VARCHAR2) RETURN NUMBER
                       IS

P_retorno            NUMBER;
P_pais varchar2(5);
v_numeroFriend cellulars.clu_cellular_number%TYPE;
V_numPY cellulars.clu_cellular_number%TYPE;
v_tipoPromo varchar2(5);


BEGIN
  
v_numeroFriend:=P_friendNumber;
  
Select DECODE(P_prefix, '549', 'AR', '598', 'UY', '595', 'PY')
Into P_pais
From dual;


select PRM_TYPE 
into v_tipoPromo
from promotions a 
where a.prm_id=P_PROMID;

--FIX carga de nros con 0 en PY
if P_pais='PY' and v_tipoPromo='S' then
V_numPY:=SUBSTR(P_friendNumber,2);
v_numeroFriend:=V_numPY;
end if;
--/FIX



  P_retorno:= f_mark_best_special_number(P_CELLULAR => P_cellularNumber, 
                                         P_PRM_ID => P_PROMID, 
                                         P_CELLULAR_MARK => v_numeroFriend, --P_friendNumber, 
                                         P_ERR_NUMBER => P_ERR_CODE, 
                                         P_ERR_MESSAGE => P_ERR_TEXT);                   
  
  if(P_retorno <> 0) then
   P_response:= PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILFALLA'); 
   return 1;
  end if;
   
  commit;

  P_Response:= PA_USSD_COMMON.GET_MESSAGE_USSD('NUMILOKEY'); 
  
  return 0;


EXCEPTION
WHEN OTHERS THEN
P_ERR_CODE := 99;
P_SQL_CODE := SQLCODE || ' ' || SQLERRM;
P_ERR_TEXT := 'Error Generico';
P_response := PA_USSD_COMMON.GET_MESSAGE_USSD('USSDERRGEN');
raise_application_error (-20025,'FALLO PA_USSD_FRIENDS_AND_FAMILY.setFriendBF: '||SQLCODE || ' ' || SQLERRM);
RETURN -1;
END setFriendBF;




FUNCTION listarNrosClaro(P_cellularNumber IN cellulars.clu_cellular_number%TYPE, 
                          P_PROMID     IN VARCHAR2, --id de la promo
                          P_RESPONSE OUT VARCHAR2, -- Mensaje de salida
                          P_ERR_CODE   OUT NUMBER, 
                          P_ERR_TEXT   OUT VARCHAR2, 
                          P_SQL_CODE   OUT VARCHAR2) RETURN NUMBER
                       
 IS
v_hayNros varchar2(5);


 
 --ESTE CURSOR SE UTILIZA PARA LISTAR NROS CONFIGURADOS
   CURSOR c_getPromoData(C_PROMID IN VARCHAR2, 
                        P_cellularNumber    IN VARCHAR2)
  IS
  
    SELECT prm_id AS promo, 
           csn_pais AS country,
           DECODE(csn_pais,'AR','Argentina','UY','Uruguay','PY','Paraguay',NULL) AS countryAb,
           csn_start_dialed_number AS dialedNumber, -- Nro amigo
           NVL(csn_best_friend,'N') AS bestFriend, -- ?Es BF?
           NVL(csn_flag_fixed,'N') AS numExtern  -- ?Es externo?
    
    FROM promotions , cellular_special_numbers
    
    WHERE csn_prm_id = C_PROMID
    AND csn_prm_id = prm_id
    AND csn_start_cellular_number = P_cellularNumber
    AND csn_start_date < SYSDATE
    AND NVL(csn_end_date,SYSDATE+1) > SYSDATE
    AND NVL(csn_flag_fixed, 'N') = 'N'
    AND NVL(csn_best_friend,'N')= 'N';
    BEGIN
v_hayNros:='N';


FOR C IN c_getPromoData(P_PROMID, P_cellularNumber) LOOP
      P_RESPONSE:= P_RESPONSE||'<nroConfigurado>'; 
      P_RESPONSE:= P_RESPONSE||'<dialedNumber>'||C.dialedNumber||'</dialedNumber>';
      P_RESPONSE:= P_RESPONSE||'<country>'||C.country||'</country>';     
      P_RESPONSE:= P_RESPONSE||'<countryAb>'||C.countryAb||'</countryAb>';
      P_RESPONSE:= P_RESPONSE||'</nroConfigurado>';
      v_hayNros:='Y';
            
 END LOOP;

 if v_hayNros='Y' then
return 0;
else 
   P_ERR_TEXT:= PA_USSD_COMMON.GET_MESSAGE_USSD('USSDERRGEN');
   return 1;
   end if;

EXCEPTION 
 WHEN OTHERS THEN
      P_ERR_CODE := 99;
      P_SQL_CODE := SQLCODE || ' ' || SQLERRM;
      P_ERR_TEXT := PA_USSD_COMMON.GET_MESSAGE_USSD('USSDERRGEN');
      P_Response:= PA_USSD_COMMON.GET_MESSAGE_USSD('USSDERRGEN');
      raise_application_error (-20025,'FALLO PA_USSD_FRIENDS_AND_FAMILY.listarNrosConfig: '||SQLCODE || ' ' || SQLERRM);
      RETURN - 1;

END listarNrosClaro;


FUNCTION listarNrosClaroBF(P_cellularNumber IN cellulars.clu_cellular_number%TYPE, 
                          P_PROMID     IN VARCHAR2, --id de la promo
                          P_RESPONSE OUT VARCHAR2, -- Mensaje de salida
                          P_ERR_CODE   OUT NUMBER, 
                          P_ERR_TEXT   OUT VARCHAR2, 
                          P_SQL_CODE   OUT VARCHAR2) RETURN NUMBER
                       
 IS
v_hayNros varchar2(5);


 
 --ESTE CURSOR SE UTILIZA PARA LISTAR NROS CONFIGURADOS
   CURSOR c_getPromoData(C_PROMID IN VARCHAR2, 
                        P_cellularNumber    IN VARCHAR2)
  IS
  
    SELECT prm_id AS promo, 
           csn_pais AS country,
           DECODE(csn_pais,'AR','Argentina','UY','Uruguay','PY','Paraguay',NULL) AS countryAb,
           csn_start_dialed_number AS dialedNumber, -- Nro amigo
           NVL(csn_best_friend,'N') AS bestFriend, -- ?Es BF?
           NVL(csn_flag_fixed,'N') AS numExtern  -- ?Es externo?
    
    FROM promotions , cellular_special_numbers
    
    WHERE csn_prm_id = C_PROMID
    AND csn_prm_id = prm_id
    AND csn_start_cellular_number = P_cellularNumber
    AND csn_start_date < SYSDATE
    AND NVL(csn_end_date,SYSDATE+1) > SYSDATE
    AND NVL(csn_flag_fixed, 'N') = 'N'
    AND NVL(csn_best_friend,'N')= 'Y';
    BEGIN
v_hayNros:='N';


FOR C IN c_getPromoData(P_PROMID, P_cellularNumber) LOOP
      P_RESPONSE:= P_RESPONSE||'<nroConfigurado>'; 
      P_RESPONSE:= P_RESPONSE||'<dialedNumber>'||C.dialedNumber||'</dialedNumber>';
      P_RESPONSE:= P_RESPONSE||'<country>'||C.country||'</country>';     
      P_RESPONSE:= P_RESPONSE||'<countryAb>'||C.countryAb||'</countryAb>';
      P_RESPONSE:= P_RESPONSE||'</nroConfigurado>';
      v_hayNros:='Y';
            
 END LOOP;

 if v_hayNros='Y' then
return 0;
else 
   P_ERR_TEXT:= PA_USSD_COMMON.GET_MESSAGE_USSD('USSDERRGEN');
   return 1;
   end if;

EXCEPTION 
 WHEN OTHERS THEN
      P_ERR_CODE := 99;
      P_SQL_CODE := SQLCODE || ' ' || SQLERRM;
      P_ERR_TEXT := PA_USSD_COMMON.GET_MESSAGE_USSD('USSDERRGEN');
      P_Response:= PA_USSD_COMMON.GET_MESSAGE_USSD('USSDERRGEN');
      raise_application_error (-20025,'FALLO PA_USSD_FRIENDS_AND_FAMILY.listarNrosClaroBF: '||SQLCODE || ' ' || SQLERRM);
      RETURN - 1;

END listarNrosClaroBF;

END PA_USSD_FRIENDS_AND_FAMILY;
/

