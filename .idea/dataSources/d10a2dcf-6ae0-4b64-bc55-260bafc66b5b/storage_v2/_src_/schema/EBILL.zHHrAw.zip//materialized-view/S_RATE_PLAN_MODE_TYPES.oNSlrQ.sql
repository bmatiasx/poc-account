create materialized view S_RATE_PLAN_MODE_TYPES
refresh complete on demand
  as
    SELECT rmt_rpl_id,
rmt_mode_type,
rmt_start_date,
rmt_end_date
FROM STL.rate_plan_mode_types@PROD
  WHERE rmt_start_date <  GET_DATE
AND NVL(rmt_end_date,GET_DATE+1) > GET_DATE

/

