create FUNCTION F_CONSULTAR_ORDENES
 (P_NIM IN VARCHAR2
 ,P_TIPO IN VARCHAR2
 ,P_NRO_ORDEN IN OUT VARCHAR2
 ,P_FEC_ING_ORDEN OUT DATE
 ,P_DESC_ORDEN OUT VARCHAR2
 ,P_ESTADO OUT VARCHAR2
 ,P_IMP_ORDEN OUT NUMBER
 ,P_ESTADO_ORDEN OUT VARCHAR2
 ,P_DESC_EQUIPO OUT VARCHAR2
 ,P_CATEGORY OUT VARCHAR2
 ,P_ERROR OUT VARCHAR2
 )
 RETURN NUMBER
 IS
  V_RESULT    NUMBER;
  V_CELLULAR  VARCHAR2(10);
  V_NRO_ORDEN VARCHAR2(20);
BEGIN

  IF P_NRO_ORDEN IS NOT NULL THEN
  
    BEGIN
      SELECT CLU_CELLULAR_NUMBER, CLT_CATEGORY
        INTO V_CELLULAR, P_CATEGORY
        FROM CELLULARS, ACCOUNTS, CLIENT
       WHERE CLU_BILL_NUMBER = P_NIM
         AND CLU_ACC_ID = ACC_ID
         AND ACC_CLT_ID = CLT_ID;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        P_ERROR := 'No se encuentran datos para el número de línea ingresado.';
        RETURN 1;
    END;
  
    V_RESULT := PKG_SERVICIO_TECNICO.CONSULTAR_ORDENES_NIM(V_CELLULAR,
                                                           P_TIPO,
                                                           V_NRO_ORDEN,
                                                           P_DESC_ORDEN,
                                                           P_ESTADO,
                                                           P_ERROR);
    IF V_RESULT <> 0 THEN
      RETURN V_RESULT;
    END IF;
  
    IF P_NRO_ORDEN != V_NRO_ORDEN THEN
      P_ERROR := 'No se encuentra el número de órden para el número de línea ingresado.';
      RETURN 1;
    ELSE
      V_RESULT := PKG_SERVICIO_TECNICO.CONSULTAR_ESTADO_ORDEN(P_NRO_ORDEN,
                                                              P_FEC_ING_ORDEN,
                                                              P_IMP_ORDEN,
                                                              P_ESTADO_ORDEN,
                                                              P_DESC_EQUIPO,
                                                              P_ERROR);
      IF V_RESULT <> 0 THEN
        RETURN V_RESULT;
      END IF;
    
      RETURN 0;
    
    END IF;
  
  ELSE
    V_RESULT := PKG_SERVICIO_TECNICO.CONSULTAR_ORDENES_NIM(P_NIM,
                                                           P_TIPO,
                                                           P_NRO_ORDEN,
                                                           P_DESC_ORDEN,
                                                           P_ESTADO,
                                                           P_ERROR);
    IF V_RESULT <> 0 THEN
      RETURN V_RESULT;
    END IF;
  
    V_RESULT := PKG_SERVICIO_TECNICO.CONSULTAR_ESTADO_ORDEN(P_NRO_ORDEN,
                                                            P_FEC_ING_ORDEN,
                                                            P_IMP_ORDEN,
                                                            P_ESTADO_ORDEN,
                                                            P_DESC_EQUIPO,
                                                            P_ERROR);
  
    IF V_RESULT <> 0 THEN
      RETURN V_RESULT;
    END IF;
  
    RETURN 0;
  
  END IF;

EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Error ' || SQLERRM);
    P_ERROR := 'Error ' || SQLERRM;
    RETURN - 1;
END;
/

