create FUNCTION       F_CREATE_CALL_VIEW
 (P_CALL_1 IN VARCHAR2
 ,P_CALL_2 IN VARCHAR2
 ,P_ERR_NUM OUT NUMBER
 ,P_ERR_MSG OUT VARCHAR2
 )
 RETURN NUMBER
 IS
/*
Luciano Namur 09/2014 version 1.0
Luciano Namur 02/2015 version 1.1
*/

/*
esta funcion recrea las vistas sobre las dos ultimas CALLS y es usada para la consulta de consumo
se crean dos vistas, una para AppMobile y otra para WEB
*/
  
/*
p_call_1 in VARCHAR2 --> Parametro que recibe la CALLS anterior a la nueva
p_call_2 in VARCHAR2 --> Parametro que recibe la CALLS mas actual
p_err_num OUT NUMBER --> numero de error
p_err_msg OUT VARCHAR --> mensaje de error
*/
v_calls_1 VARCHAR2(15);
l_stmp      VARCHAR2(3000);
l_stmp_w VARCHAR2(4000);

PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
/*Se agrega la calls mas antigua a la vista que se utiliza en la web, CALL_WEB, debido que no se estan mostrando registros que deberian mostrarse*/
v_calls_1 := 'CALLS_'||to_char(to_date(substr(p_call_1,7),'yyyymm')-1,'yyyymm');

/*asigno a la variable la sentencia de creacion de vista para luego ejecutarla por execute immediate*/
l_stmp := 'create or replace view ebill.call_des as
            select /*+ INDEX_DESC(calls) */ "CAL_TAP_LABEL","CAL_ID","CAL_CLU_CELLULAR_NUMBER","CAL_ESN","CAL_DIALED_NUMBER",
                   "CAL_DATE","CAL_DIRECTION","CAL_CALL_STATUS","CAL_CELL_TYPE","CAL_DURATION","CAL_EXTENDED_DURATION",
                   "CAL_OUTGOING_TRUNK","CAL_RATING_STATUS","CAL_ORIGINATING_NUMBER","CAL_TRANSFERED_NUMBER","CAL_FEATURES",
                   "CAL_AIR_CHARGE","CAL_AIR_PERIODS","CAL_LAND_CHARGE","CAL_LAND_PERIODS","CAL_LOCATION","CAL_TPT_ID_AIR",
                   "CAL_CEL_ID","CAL_GRP_ID_CELL","CAL_SRT_ID_AIR","CAL_DSC_ID_LAND","CAL_RPL_ID_AIR","CAL_ERR_ID","CAL_CAT_ID",
                   "CAL_RPL_ID_LAND","CAL_DSC_ID_AIR","CAL_GRP_ID_DIALED_NUMBER","CAL_TPT_ID_LAND","CAL_RAT_ID","CAL_DST_ID",
                   "CAL_SRT_ID_LAND","CAL_PRP_ID_AIR","CAL_PRP_ID_LAND","CAL_GRP_ID_CELLULAR","CAL_RAWCALL_ID","CAL_SCH_ID",
                   "CAL_CPT_ID","CAL_ACC_ID","CAL_CYC_ID","CAL_TAX","CAL_RATED_DATE","CAL_FREE_INCLUDED_AIR","CAL_FREE_INCLUDED_LAND",
                   "CAL_SERIAL_NUMBER","CAL_CTY_ID","CAL_TPT_ID_CPP","CAL_CPP_CHARGE","CAL_DEI_INDEX_VALUE","CAL_IMSI","CAL_IMEI","CAL_MSISDN",
                   "CAL_ADD_DATE"
              from stl.'||p_call_2||'@prod calls
             where cal_date between sysdate - 15 and sysdate
      union all
            select /*+ INDEX_DESC(calls) */ "CAL_TAP_LABEL","CAL_ID","CAL_CLU_CELLULAR_NUMBER","CAL_ESN","CAL_DIALED_NUMBER",
                   "CAL_DATE","CAL_DIRECTION","CAL_CALL_STATUS","CAL_CELL_TYPE","CAL_DURATION","CAL_EXTENDED_DURATION",
                   "CAL_OUTGOING_TRUNK","CAL_RATING_STATUS","CAL_ORIGINATING_NUMBER","CAL_TRANSFERED_NUMBER","CAL_FEATURES",
                   "CAL_AIR_CHARGE","CAL_AIR_PERIODS","CAL_LAND_CHARGE","CAL_LAND_PERIODS","CAL_LOCATION","CAL_TPT_ID_AIR",
                   "CAL_CEL_ID","CAL_GRP_ID_CELL","CAL_SRT_ID_AIR","CAL_DSC_ID_LAND","CAL_RPL_ID_AIR","CAL_ERR_ID","CAL_CAT_ID",
                   "CAL_RPL_ID_LAND","CAL_DSC_ID_AIR","CAL_GRP_ID_DIALED_NUMBER","CAL_TPT_ID_LAND","CAL_RAT_ID","CAL_DST_ID",
                   "CAL_SRT_ID_LAND","CAL_PRP_ID_AIR","CAL_PRP_ID_LAND","CAL_GRP_ID_CELLULAR","CAL_RAWCALL_ID","CAL_SCH_ID",
                   "CAL_CPT_ID","CAL_ACC_ID","CAL_CYC_ID","CAL_TAX","CAL_RATED_DATE","CAL_FREE_INCLUDED_AIR","CAL_FREE_INCLUDED_LAND",
                   "CAL_SERIAL_NUMBER","CAL_CTY_ID","CAL_TPT_ID_CPP","CAL_CPP_CHARGE","CAL_DEI_INDEX_VALUE","CAL_IMSI","CAL_IMEI","CAL_MSISDN",
                   "CAL_ADD_DATE"
              from stl.'||p_call_1||'@prod calls
            where cal_date between sysdate - 15 and sysdate';

l_stmp_w := 'create or replace view ebill.call_web as
            select /*+ INDEX_DESC(calls) */ "CAL_TAP_LABEL","CAL_ID","CAL_CLU_CELLULAR_NUMBER","CAL_ESN","CAL_DIALED_NUMBER",
                   "CAL_DATE","CAL_DIRECTION","CAL_CALL_STATUS","CAL_CELL_TYPE","CAL_DURATION","CAL_EXTENDED_DURATION",
                   "CAL_OUTGOING_TRUNK","CAL_RATING_STATUS","CAL_ORIGINATING_NUMBER","CAL_TRANSFERED_NUMBER","CAL_FEATURES",
                   "CAL_AIR_CHARGE","CAL_AIR_PERIODS","CAL_LAND_CHARGE","CAL_LAND_PERIODS","CAL_LOCATION","CAL_TPT_ID_AIR",
                   "CAL_CEL_ID","CAL_GRP_ID_CELL","CAL_SRT_ID_AIR","CAL_DSC_ID_LAND","CAL_RPL_ID_AIR","CAL_ERR_ID","CAL_CAT_ID",
                   "CAL_RPL_ID_LAND","CAL_DSC_ID_AIR","CAL_GRP_ID_DIALED_NUMBER","CAL_TPT_ID_LAND","CAL_RAT_ID","CAL_DST_ID",
                   "CAL_SRT_ID_LAND","CAL_PRP_ID_AIR","CAL_PRP_ID_LAND","CAL_GRP_ID_CELLULAR","CAL_RAWCALL_ID","CAL_SCH_ID",
                   "CAL_CPT_ID","CAL_ACC_ID","CAL_CYC_ID","CAL_TAX","CAL_RATED_DATE","CAL_FREE_INCLUDED_AIR","CAL_FREE_INCLUDED_LAND",
                   "CAL_SERIAL_NUMBER","CAL_CTY_ID","CAL_TPT_ID_CPP","CAL_CPP_CHARGE","CAL_DEI_INDEX_VALUE","CAL_IMSI","CAL_IMEI","CAL_MSISDN",
                   "CAL_ADD_DATE"
              from stl.'||p_call_2||'@prod calls
      union all
            select /*+ INDEX_DESC(calls) */ "CAL_TAP_LABEL","CAL_ID","CAL_CLU_CELLULAR_NUMBER","CAL_ESN","CAL_DIALED_NUMBER",
                   "CAL_DATE","CAL_DIRECTION","CAL_CALL_STATUS","CAL_CELL_TYPE","CAL_DURATION","CAL_EXTENDED_DURATION",
                   "CAL_OUTGOING_TRUNK","CAL_RATING_STATUS","CAL_ORIGINATING_NUMBER","CAL_TRANSFERED_NUMBER","CAL_FEATURES",
                   "CAL_AIR_CHARGE","CAL_AIR_PERIODS","CAL_LAND_CHARGE","CAL_LAND_PERIODS","CAL_LOCATION","CAL_TPT_ID_AIR",
                   "CAL_CEL_ID","CAL_GRP_ID_CELL","CAL_SRT_ID_AIR","CAL_DSC_ID_LAND","CAL_RPL_ID_AIR","CAL_ERR_ID","CAL_CAT_ID",
                   "CAL_RPL_ID_LAND","CAL_DSC_ID_AIR","CAL_GRP_ID_DIALED_NUMBER","CAL_TPT_ID_LAND","CAL_RAT_ID","CAL_DST_ID",
                   "CAL_SRT_ID_LAND","CAL_PRP_ID_AIR","CAL_PRP_ID_LAND","CAL_GRP_ID_CELLULAR","CAL_RAWCALL_ID","CAL_SCH_ID",
                   "CAL_CPT_ID","CAL_ACC_ID","CAL_CYC_ID","CAL_TAX","CAL_RATED_DATE","CAL_FREE_INCLUDED_AIR","CAL_FREE_INCLUDED_LAND",
                   "CAL_SERIAL_NUMBER","CAL_CTY_ID","CAL_TPT_ID_CPP","CAL_CPP_CHARGE","CAL_DEI_INDEX_VALUE","CAL_IMSI","CAL_IMEI","CAL_MSISDN",
                   "CAL_ADD_DATE"
              from stl.'||p_call_1||'@prod calls
      union all
            select /*+ INDEX_DESC(calls) */ "CAL_TAP_LABEL","CAL_ID","CAL_CLU_CELLULAR_NUMBER","CAL_ESN","CAL_DIALED_NUMBER",
                   "CAL_DATE","CAL_DIRECTION","CAL_CALL_STATUS","CAL_CELL_TYPE","CAL_DURATION","CAL_EXTENDED_DURATION",
                   "CAL_OUTGOING_TRUNK","CAL_RATING_STATUS","CAL_ORIGINATING_NUMBER","CAL_TRANSFERED_NUMBER","CAL_FEATURES",
                   "CAL_AIR_CHARGE","CAL_AIR_PERIODS","CAL_LAND_CHARGE","CAL_LAND_PERIODS","CAL_LOCATION","CAL_TPT_ID_AIR",
                   "CAL_CEL_ID","CAL_GRP_ID_CELL","CAL_SRT_ID_AIR","CAL_DSC_ID_LAND","CAL_RPL_ID_AIR","CAL_ERR_ID","CAL_CAT_ID",
                   "CAL_RPL_ID_LAND","CAL_DSC_ID_AIR","CAL_GRP_ID_DIALED_NUMBER","CAL_TPT_ID_LAND","CAL_RAT_ID","CAL_DST_ID",
                   "CAL_SRT_ID_LAND","CAL_PRP_ID_AIR","CAL_PRP_ID_LAND","CAL_GRP_ID_CELLULAR","CAL_RAWCALL_ID","CAL_SCH_ID",
                   "CAL_CPT_ID","CAL_ACC_ID","CAL_CYC_ID","CAL_TAX","CAL_RATED_DATE","CAL_FREE_INCLUDED_AIR","CAL_FREE_INCLUDED_LAND",
                   "CAL_SERIAL_NUMBER","CAL_CTY_ID","CAL_TPT_ID_CPP","CAL_CPP_CHARGE","CAL_DEI_INDEX_VALUE","CAL_IMSI","CAL_IMEI","CAL_MSISDN",
                   "CAL_ADD_DATE"
              from stl.'||v_calls_1||'@prod calls';


EXECUTE IMMEDIATE l_stmp;

EXECUTE IMMEDIATE l_stmp_w;

COMMIT;

RETURN 0;


EXCEPTION
  WHEN OTHERS THEN
   p_err_num := SQLCODE;
   p_err_msg := 'Error al crear las vistas: '||SQLERRM;
  ROLLBACK;
   RETURN -1;
END;
/

