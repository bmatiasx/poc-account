create materialized view S_CEL_BUSINESS_TYPES_PACKAGES
refresh complete on demand
  as
    SELECT cpa_cbt_id,
cpa_pkt_id,
cpa_default_flag,
cpa_start_date,
cpa_end_date,
cpa_canceled_flag,
cpa_mode_type
FROM stl.cel_business_types_packages@PROD

/

