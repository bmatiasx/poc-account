create FUNCTION F_INSERTA_CELLMILEAGE

 (P_CLU_CELLULAR_NUMBER IN VARCHAR2
 ,P_QUANTITY IN NUMBER
 ,P_ERR_NUMBER OUT NUMBER
 ,P_ERR_MESSAGE OUT VARCHAR2
 )
 RETURN NUMBER
 IS
v_mip_id    NUMBER(10,0);
v_result    NUMBER(10,0);
fallar      exception;
BEGIN

  -- Busco el concepto para incentivo
  BEGIN
    SELECT  mip.mip_id
    INTO    v_mip_id
    FROM    mileage_points mip,
            stl_parameters par
    WHERE   mip.mip_mpp_id = par.stl_char_value
    and     par.stl_id = 'AUT014';
  EXCEPTION
        WHEN OTHERS THEN
            p_err_number := SQLCODE;
            p_err_message := SQLERRM;
            RETURN -1;
  END;

  BEGIN
      v_result := PA_MILEAGE.Inserta_Cellmileage(P_NIM    => p_clu_cellular_number,
                                              P_CEM_ID => v_mip_id,
                                              P_ERRTXT => p_err_message,
                                              p_quantity => p_quantity);

    IF v_result = -1 THEN
      raise fallar;
    ELSE
      IF v_result <> 0 THEN
      p_err_message := p_err_message;
      P_ERR_NUMBER  := v_result;
      RETURN 1;
      END IF;
    END IF;

    RETURN 0;

  EXCEPTION
    WHEN fallar THEN
      p_err_number := -1;
      p_err_message:= p_err_message||sqlerrm;
      RETURN -1;
   WHEN OTHERS THEN
      p_err_number := -2;
      p_err_message:= sqlerrm;
      RETURN -1;
  END;

  RETURN v_result;
END F_INSERTA_CELLMILEAGE;
/

