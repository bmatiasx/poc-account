create view SCHEDULERS as
  select
 SCH_CYC_ID                     ,
 SCH_DUE_DAYS                   ,
 SCH_BST_ID                     ,
 SCH_SECOND_DUE_DAYS            ,
 SCH_BILL_DATE                  ,
 SCH_START_DATE                 ,
 SCH_SECOND_DUE_PERCENT         ,
 SCH_END_DATE                   ,
 SCH_ID                         ,
 SCH_DEBIT_DATE                 ,
 SCH_EQP_ID
from SCHEDULERS@prod
/

