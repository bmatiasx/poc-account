create FUNCTION F_VALIDATE_CELLULAR_LOCAL
(P_CELLULAR IN VARCHAR2
,P_STATUS IN VARCHAR2
,P_CPR_PRF_ID OUT NUMBER
,P_CPR_TRY_FAILED OUT NUMBER
,P_CPR_BLOCKED OUT VARCHAR2
,P_ERR_NUMBER OUT NUMBER
,P_ERR_MESSAGE OUT VARCHAR2
)
RETURN NUMBER
IS
v_prf_id_blk VARCHAR2(255);
v_max_try_failed NUMBER;
BEGIN
  
  IF P_STATUS = 'N' THEN
    BEGIN
      SELECT cpr_prf_id, cpr_try_failed, cpr_blocked
        INTO p_cpr_prf_id, p_cpr_try_failed, p_cpr_blocked
        FROM cellular_profiles
       WHERE cpr_clu_cellular_number = p_cellular
         AND cpr_start_date < SYSDATE
         AND NVL(cpr_end_date, SYSDATE + 1) > SYSDATE;
 
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        INSERT INTO cellular_profiles
          (cpr_id,
           cpr_clu_cellular_number,
           cpr_prf_id,
           cpr_start_date,
           cpr_try_failed,
           cpr_blocked)
        VALUES
          (seq_cpr_id.NEXTVAL, p_cellular, NULL, SYSDATE, 1, 'N');
        p_cpr_prf_id     := NULL;
        p_cpr_try_failed := 1;
        p_cpr_blocked    := 'N';
        p_err_number     := -1002;
        RETURN 0;
      WHEN OTHERS THEN
        p_err_number  := SQLCODE;
        p_err_message := 'Error al intentar actualizar la tabla cellular_profiles.';
        RETURN - 1;
    END;
 
    SELECT stl_value
      INTO v_max_try_failed
      FROM s_stl_parameters
     WHERE stl_id = 'AMMXTF';
 
    SELECT stl_value
      INTO v_prf_id_blk
      FROM s_stl_parameters
     WHERE stl_id = 'AMPRLK';
 
    IF p_cpr_blocked = 'N' THEN
 
      UPDATE cellular_profiles
         SET cpr_try_failed = (cpr_try_failed + 1)
       WHERE cpr_clu_cellular_number = p_cellular
         AND cpr_start_date < SYSDATE
         AND NVL(cpr_end_date, SYSDATE + 1) > SYSDATE;
 
      IF p_cpr_try_failed + 1 = v_max_try_failed THEN
        UPDATE cellular_profiles
           SET cpr_blocked = 'Y', cpr_prf_id = v_prf_id_blk
         WHERE cpr_clu_cellular_number = p_cellular
           AND cpr_start_date < SYSDATE
           AND NVL(cpr_end_date, SYSDATE + 1) > SYSDATE;
 
       p_cpr_prf_id     := v_prf_id_blk;
        p_cpr_try_failed := v_max_try_failed;
        p_cpr_blocked    := 'Y';
        p_err_number     := -1003;
        p_err_message    := 'La linea se encuentra bloqueada.';
        RETURN 1;
      END IF;
 
      p_cpr_prf_id     := NULL;
      p_cpr_try_failed := p_cpr_try_failed + 1;
      p_cpr_blocked    := 'N';
      p_err_number     := -1002;
      RETURN 0;
 
    ELSE
      p_cpr_prf_id     := v_prf_id_blk;
      p_cpr_try_failed := v_max_try_failed;
      p_cpr_blocked    := 'Y';
      p_err_number     := -1003;
      p_err_message    := 'La linea se encuentra bloqueada.';
      RETURN 1;
    END IF;
 
  ELSIF P_STATUS = 'Y' THEN
    BEGIN
      SELECT cpr_prf_id, cpr_try_failed, cpr_blocked
        INTO p_cpr_prf_id, p_cpr_try_failed, p_cpr_blocked
        FROM cellular_profiles
       WHERE cpr_clu_cellular_number = p_cellular
         AND cpr_start_date < SYSDATE
         AND NVL(cpr_end_date, SYSDATE + 1) > SYSDATE;
 
      IF p_cpr_blocked = 'Y' THEN
        p_cpr_blocked := 'Y';
        p_err_number  := -1003;
        p_err_message := 'La linea se encuentra bloqueada.';
        RETURN 1;
      ELSE
                             --RESETEO LA CONTRASENA
 
                                                 UPDATE cellular_profiles
                                                             SET cpr_try_failed = 0, cpr_blocked = 'N'
                                                WHERE cpr_clu_cellular_number = p_cellular
                                                             AND cpr_start_date < SYSDATE
                                                             AND NVL(cpr_end_date, SYSDATE + 1) > SYSDATE;
 
        p_cpr_blocked := 'N';
        p_err_number  := -1000;
        RETURN 0;
      END IF;
 
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
                             --RESETEO LA CONTRASENA
 
                                               UPDATE cellular_profiles
                                                             SET cpr_try_failed = 0, cpr_blocked = 'N'
                                                WHERE cpr_clu_cellular_number = p_cellular
                                                             AND cpr_start_date < SYSDATE
                                                             AND NVL(cpr_end_date, SYSDATE + 1) > SYSDATE;
 
        p_cpr_blocked := 'N';
        p_err_number  := -1000;
        RETURN 0;
      WHEN OTHERS THEN
        p_err_number  := SQLCODE;
        p_err_message := 'Error al intentar consultar la tabla cellular_profiles.';
        RETURN - 1;
    END;
  ELSE
    p_err_message := 'El parametro P_STATUS debe ser igual a ''Y'' o ''N''';
    RETURN 1;
  END IF;
END;
/

