create materialized view S_WEB_CREDIT_CARDS
refresh force on demand
  as
    SELECT wcc_id, wcc_acc_id, wcc_clu_cellular_number,  wcc_crd_id, wcc_coe_id, wcc_card_number, wcc_security_code, wcc_expiration_date, wcc_status, wcc_last_updated_date, wcc_user, wcc_expiration_date_e
from web_credit_cards@PROD


/

