create view V_GEOLOC_CELLULAR_GROUPS_DETAI as
  select "GGD_ID","GGD_GCG_ID","GGD_CLU_BILL_NUMBER" from stl.geoloc_cellular_groups_details@prod
/

