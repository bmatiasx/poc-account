create PACKAGE WEB_CONCEPTS_DETAILS IS

-- evento: 49592 Factura Electrónica en Ar
      -- autor : Gallardo Fabián
      -- Proposito: Se modificó la parametrización FC en AR por una consulta
      -- Fecha modificación:  29/05/2007
Function Get_Output_Path( P_Output_Path OUT Varchar2,
                          P_Error_Msg   OUT Varchar2 ) Return Number;


--Crea un archivo xml en el Directory DIR_DETAIL con toda la informacion de los conceptos
--para todas las líneas de una cuenta. Por cada línea detalla también los conceptos agrupados
--en Servicios y Varios
--Retorna: 0: Si se crea el archivo ok
--         1: error utilizando el cursor Cur_Lines. No se crea el archivo
--         2: error utilizando el cursor Cur_Details. No se crea el archivo
--         3: error buscando detalles para Servicios. No se crea el archivo
--         4: error buscando detalles para Varios. No se crea el archivo
--         5: error consolidando datos. No se crea el archivo
--         6: error guardando datos. Verificar si se creo el archivo
--         7: no hay datos para la cuenta. No se crea el archivo

--Reemplaza caracteres especiales de XML para evitar errores.                          
Function replaceSpecialChars(cadena in varchar2) Return varchar2;

Function Get_Concepts_Details( P_Acc_Id          IN  Varchar2,
                               P_Doc_Id          IN  Varchar2,
                               P_SCH_ID          IN  Varchar2,
                               P_FileName        IN  Varchar2,
                               P_Separator       IN  Varchar2,
                               P_Error_Msg       OUT Varchar2 ) Return Number;


Function Get_Handset_Financing_Details( P_Sch_Id    IN  Number,
                                        P_Acc_Id    IN  Varchar2,
                                        P_FileName  IN  Varchar2,
                                        P_Separator IN  Varchar2,
                                        P_Error_Msg OUT Varchar2 ) Return Number;


--Devuelve la lista de periodos disponibles y la lista de documents id´s
--Retorna: 0: si no hay errores
--         1: si no encuentra datos
--         2: por cualquier otro error
Function Get_Available_Periods( P_Account        In  Varchar2,
                                p_Separator      In  Varchar2,
                                P_Periods_list   Out Varchar2,
                                P_Documents_list Out Varchar2,
                                P_Shedulers_list Out Varchar2,
                                P_Error_Text     Out Varchar2 ) Return Number;


--Valida el celular que se esta logueando.
--Chequea que tenga los packs de factura electrónica y que el password sea correcto
--Retorna: 0: cuando se loguea ok
--         1: no existe el celular
--         2: no tiene el pack
--         3: el password es incorrecto
--         4: la linea no esta activa
Function Validate_Cellular( p_Bill_Number   in  Varchar2,
                            p_Clt_Password  in  Varchar2,
                            p_Clt_Id        out Varchar2,
                            p_Clt_Name      out Varchar2,
                            p_Error_Text    out Varchar2 ) Return Number;


--Devuelve la lista de cuentas de un cliente
--Retorna: 0: Si encuentra la(s) cuanta(s)
--         1: Sin ocurre algun error
Function Get_Client_Accounts( p_Clt_Id        in  Varchar2,
                              p_Separator     in  Varchar2,
                              p_List_Accounts out Varchar2,
                              p_Error_Text    out Varchar2 ) Return Number;


--Devuelve la lista de cuentas de un cliente
--Retorna: 0: Si encuentra la(s) línea(s)
--         1: Sin ocurre algun error
--         2: No se encontraron datos
Function Get_Client_Lines( p_Acc_Id        in  Varchar2,
                           p_Separator     in  Varchar2,
                           p_bill_List     out Varchar2,
                           p_cellular_List out Varchar2,
                           p_Names_List    out Varchar2,
                           p_Error_Text    out Varchar2 ) Return Number;
END WEB_CONCEPTS_DETAILS;
/

