create FUNCTION F_VALIDATE_SIMLOCK
 (P_ACC_ID IN VARCHAR2
 ,P_IMEI IN VARCHAR2
 ,P_MONTO_SR OUT VARCHAR2
 ,P_SIMLOCK OUT VARCHAR2
 ,P_CELLULAR_NUMBER OUT VARCHAR2
 ,P_AMMOUNT OUT NUMBER
 ,P_ERR_NUMBER OUT NUMBER
 ,P_MSG OUT VARCHAR2
 )
 RETURN NUMBER
 IS
 -- 0 = OK
   -- -1 = ERROR
--13/11/2017 Se agrega validación de RSN_ID. Se búsca RSN en STL_PARAMETERS por migración PY.

   V_MSG                      VARCHAR2 (500);
   V_FECHA_INICIO             CELLULAR_TERMINALS.CET_START_DATE%TYPE;
   P_VALUE                    STL_PARAMETERS.STL_CHAR_VALUE%TYPE;
   V_FECHA_GENERATION_CARGO   STL_PARAMETERS.STL_CHAR_VALUE%TYPE;
   V_TRANSCURRIDOS            NUMBER;
   V_RESULT                   NUMBER;
   V_SIMLOCK                  VARCHAR2 (3);
   V_EXIST                    VARCHAR2 (20);
   V_TEXTO_TICKLER            VARCHAR2 (300);
   V_IPHONE                   VARCHAR2 (20);
   V_PIN_BB                   VARCHAR2 (20);
   V_SCK                      VARCHAR2 (30);
   V_SPCK                     VARCHAR2 (30);
   V_AMOUNT                   NUMBER;
   V_EXISTA                   VARCHAR2(1);
  V_RSN_SIMLOCK            S_REASONS.RSN_ID%TYPE;
  V_STL_ID_RSN_SIMLOCK     S_STL_PARAMETERS.STL_ID%TYPE := 'WCSLRS';
BEGIN
  SELECT /*+ leading(C) index(ct cet_clu_cellular_number_idx10) index(P PRO_PK1) use_nl(P) use_nl(CT)*/
   CET_CLU_CELLULAR_NUMBER
  ,P.PRO_CLASS
  ,CT.CET_START_DATE
  ,CT.CET_AMMOUNT
    INTO P_CELLULAR_NUMBER
        ,V_IPHONE
        ,V_FECHA_INICIO
        ,P_AMMOUNT
    FROM S_CELLULAR_TERMINALS CT
        ,S_PRODUCTS           P
        ,S_CELLULARS          C
   WHERE 1 = 1
     AND C.CLU_STATUS = 'A'
     AND CT.CET_PRO_ID = P.PRO_ID
     AND P.PRO_CLASS IS NOT NULL
     AND CT.CET_CLU_CELLULAR_NUMBER = C.CLU_CELLULAR_NUMBER
     AND CT.CET_EST_ID IN ('DIST',
                           'HOMO')
     AND CT.CET_IMEI = P_IMEI
     AND C.CLU_ACC_ID = P_ACC_ID;
  BEGIN
    SELECT 'Y'
      INTO V_SIMLOCK
      FROM SIMLOCKS S
     WHERE S.SLO_IMEI = P_IMEI;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      BEGIN
        IF V_IPHONE != 'IPHONE' THEN
          SELECT DECODE(COUNT(1),
                        0,
                        'N',
                        1,
                        'Y')
            INTO V_EXISTA
            FROM ORDER_SIMLOCKS
           WHERE ORS_IMEI = P_IMEI;
          IF V_EXISTA = 'N' THEN
            V_TEXTO_TICKLER := 'IMEI:' || P_IMEI;
            BEGIN
              SELECT STL_CHAR_VALUE
                INTO V_RSN_SIMLOCK
                FROM S_STL_PARAMETERS
               WHERE 1 = 1
                 AND STL_ID = V_STL_ID_RSN_SIMLOCK;
            END;
            ----- TICKLER PARA GENERAR SIMLOCK----------------
            V_RESULT := INSERT_TICKLER(ACT_ID          => 'EQUIPO',
                                       RSN_ID          => V_RSN_SIMLOCK,
                                       CELLULAR_NUMBER => P_CELLULAR_NUMBER,
                                       DESCRIPCION     => V_TEXTO_TICKLER,
                                       STATUS          => V_MSG);
            BEGIN
              INSERT INTO ORDER_SIMLOCKS
                (ORS_IMEI
                ,ORS_OPENED_DATE
                ,ORS_STATUS
                ,ORS_ENDED_DATE)
              VALUES
                (P_IMEI
                ,SYSDATE
                ,'P'
                ,NULL);
            EXCEPTION
              WHEN OTHERS THEN
                P_ERR_NUMBER := 'ERROR AL INSERTAR EL REGISTRO EN LA TABLA ORDER_SIMLOCKS';
                P_ERR_NUMBER := 1002;
                RETURN - 1;
            END;
            IF V_RESULT = -1 THEN
              P_ERR_NUMBER := 1001;
              P_MSG        := 'NO SE PUDO INSERTAR EL TICKLER ' || V_MSG;
              RETURN 1;
            END IF;
            P_ERR_NUMBER := 1002;
            P_MSG        := 'SE ENVIO EL TICKLER PARA LA GENERACION DEL SIMLOCK';
            RETURN 0;
          ELSIF V_EXISTA = 'Y' THEN
            P_ERR_NUMBER := 1011;
            P_MSG        := 'SU SIMLOCK ESTA SIENDO GENERADO';
            RETURN 1;
          END IF;
        ELSE
          P_ERR_NUMBER := 1003;
          P_MSG        := 'EL IMEI PERTENECE A UN IPHONE';
          RETURN 1;
        END IF;
      END;
  END;
  BEGIN
    SELECT 'Y'
      INTO V_EXIST
      FROM DELIVERY_SIMLOCKS DS
     WHERE DS.DSL_IMEI = P_IMEI
       AND DS.DSL_ACC_ID = P_ACC_ID;
    IF V_EXIST = 'Y' THEN
      --SE ENTREGA EL SIMLOCK
      PA_SIMLOCK.DECRYPT(P_IMEI   => P_IMEI,
                         P_STR    => P_SIMLOCK,
                         P_PIN_BB => V_PIN_BB,
                         P_SCK    => V_SCK,
                         P_SPCK   => V_SPCK,
                         P_MSG    => P_MSG);
      P_ERR_NUMBER := 1004;
      RETURN 0;
    END IF;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      --------------------------------------------------------------------
      ----------------------- VALIDACIÓN DE FECHAS -----------------------
      --------------------------------------------------------------------
      --- OBTENGO LA FECHA DESDE LA CUAL CORRE LA GENERACION DEL CARGO ---
      SELECT STL_CHAR_VALUE
        INTO P_VALUE
        FROM S_STL_PARAMETERS
       WHERE STL_ID = 'SIMLO2'
         AND SYSDATE BETWEEN STL_START_DATE AND
             NVL(STL_END_DATE,
                 SYSDATE);
      V_FECHA_GENERATION_CARGO := P_VALUE;
      V_FECHA_GENERATION_CARGO := TO_DATE(V_FECHA_GENERATION_CARGO,
                                          'DD/MM/YYYY');
      P_MSG                    := 'CONTROLANDO LA FECHA DE GENERACIÓN DEL CARGO.';
      IF V_FECHA_INICIO < V_FECHA_GENERATION_CARGO THEN
        P_MSG := 'NO SE COBRA SIMLOCK PORQUE LA FECHA DE ALTA DEL IMEI ES ANTERIOR AL ' ||
                 TO_DATE(V_FECHA_GENERATION_CARGO,
                         'DD/MM/YYYY');
        PA_SIMLOCK.DECRYPT(P_IMEI   => P_IMEI,
                           P_STR    => P_SIMLOCK,
                           P_PIN_BB => V_PIN_BB,
                           P_SCK    => V_SCK,
                           P_SPCK   => V_SPCK,
                           P_MSG    => P_MSG);
        P_ERR_NUMBER := 1005;
        RETURN 0;
      END IF;
      ----- CONTROLO LOS MESES TRANSCURRIDOS DESDE LA VENTA DEL EQUIPO -----
      DECLARE
        V_MESES NUMBER;
      BEGIN
        --- OBTENGO LA CANTIDAD MÁXIMA DE MESES PERMITIDOS PARA LA ENTREGA DEL SIMLOCK ---
        P_MSG := 'OBTENGO LA CANTIDAD MÁXIMA DE MESES PERMITIDOS PARA LA ENTREGA DEL SIMLOCK';
        SELECT STL_VALUE
          INTO V_MESES
          FROM S_STL_PARAMETERS
         WHERE STL_ID = 'MESSLO';
        --- OBTENGO LOS MESES TRANSCURRIDOS DESDE EL ALTA DEL IMEI ---
        P_MSG := 'OBTENGO LOS MESES TRANSCURRIDOS DESDE EL ALTA DEL IMEI';
        SELECT MONTHS_BETWEEN(SYSDATE,
                              V_FECHA_INICIO)
          INTO V_TRANSCURRIDOS
          FROM DUAL;
        --- CONTROLO QUE LA DIFERENCIA DE MESES DESDE LA FECHA DE ALTA DEL IMEI ---
        --- A HOY SEA LA PERMITIDA -----------------------------------------------
        P_MSG := 'CONTROLO QUE LA DIFERENCIA DE MESES DESDE LA FECHA DE ALTA DEL IMEI';
        IF V_TRANSCURRIDOS > V_MESES THEN
          PA_SIMLOCK.DECRYPT(P_IMEI   => P_IMEI,
                             P_STR    => P_SIMLOCK,
                             P_PIN_BB => V_PIN_BB,
                             P_SCK    => V_SCK,
                             P_SPCK   => V_SPCK,
                             P_MSG    => P_MSG);
          P_ERR_NUMBER := 1006;
          P_MSG        := 'NO SE COBRA SR PORQUE EL IMEI SE DIO DE ALTA HACE MÁS DE ' ||
                          V_MESES || ' MESES.';
          RETURN 0;
        ELSE
          V_RESULT     := PKG_SURPLUS_SUBSIDY.
                          GET_AMOUNT_SR(P_CLU_CELLULAR_NUMBER => P_CELLULAR_NUMBER,
                                        P_RSN_ID              => NULL,
                                        P_AMOUNT              => V_AMOUNT,
                                        P_ERR_TXT             => P_MSG,
                                        P_MODULE              => NULL);
          P_MSG        := 'SE DEBE COBRAR EL SR';
          P_ERR_NUMBER := 1007;
          IF V_RESULT != 0 THEN
            P_MSG        := 'PKG_SURPLUS_SUBSIDY.GET_AMOUNT_SR. ' || P_MSG;
            P_ERR_NUMBER := 1008;
            RETURN 1;
          END IF;
          IF V_AMOUNT = 0 THEN
            PA_SIMLOCK.DECRYPT(P_IMEI   => P_IMEI,
                               P_STR    => P_SIMLOCK,
                               P_PIN_BB => V_PIN_BB,
                               P_SCK    => V_SCK,
                               P_SPCK   => V_SPCK,
                               P_MSG    => P_MSG);
            P_MSG        := 'EL SUBSIDIO REMANENTE ES IGUAL A 0.';
            P_ERR_NUMBER := 1009;
            P_MONTO_SR   := V_AMOUNT;
            RETURN 0;
          END IF;
          P_MONTO_SR := V_AMOUNT;
          RETURN 0;
        END IF;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          P_MSG        := 'ERROR EN VALIDACION DE FECHA';
          P_ERR_NUMBER := 1010;
          RETURN 1;
        WHEN OTHERS THEN
          P_MSG        := V_MSG || SQLERRM;
          P_ERR_NUMBER := 1011;
          RETURN - 1;
      END;
  END;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    P_MSG        := 'NO EXISTE LINEA ACTIVA ASOCIADA AL IMEI O NO ES DISTRIBUIDO U HOMOLOGADO O NO CONTIENE IDENTIFICADOR DE EQUIPO';
    P_ERR_NUMBER := 1012;
    RETURN 1;
  WHEN OTHERS THEN
    P_MSG        := V_MSG || SQLERRM;
    P_ERR_NUMBER := 1013;
    RETURN - 1;
END;

/

