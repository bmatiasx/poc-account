create PACKAGE BODY IVR_PREPAGO IS

FUNCTION area_numero
        (p_clu_cellular_number IN S_CELLULARS.clu_cellular_number%TYPE,
         p_cod_area OUT VARCHAR2,
         p_numero OUT VARCHAR2,
         p_mensaje OUT VARCHAR2)
    RETURN NUMBER IS
    v_clu_bill_number   S_CELLULARS.clu_cellular_number%TYPE;
    v_clu_npa_digits    S_CELLULARS.clu_npa_digits%TYPE;
    v_cod_pais          S_STL_PARAMETERS.STL_VALUE%TYPE; --10/12/2004 Jorge
BEGIN
    SELECT clu_bill_number,clu_npa_digits
    INTO v_clu_bill_number,v_clu_npa_digits
    FROM S_CELLULARS
    WHERE clu_cellular_number = p_clu_cellular_number;
    p_cod_area := '0' || SUBSTR(v_clu_bill_number,0,v_clu_npa_digits);
    --10/12/2004 Jorge, para que solo anteponga el 15 si se activa en Argentina y mantener CORE
    SELECT STL_VALUE
    INTO   v_cod_pais
    FROM   S_STL_PARAMETERS
    WHERE  STL_ID = 'FCTRY';
    IF LTRIM(RTRIM(v_cod_pais)) = 'AR' THEN
       p_numero := '15' ||  SUBSTR(v_clu_bill_number,v_clu_npa_digits + 1, LENGTH(v_clu_bill_number)-v_clu_npa_digits);
    ELSIF LTRIM(RTRIM(v_cod_pais)) = 'UY' THEN
       p_numero := '0'||v_clu_bill_number;
    ELSE
  p_numero := v_clu_bill_number;  -- 18/08/2005 Ev.39218 Mariana B. corregido por Marce
    END IF;
    p_mensaje:= 'OK';
    RETURN 0;
EXCEPTION
    WHEN OTHERS THEN
        RETURN SQLCODE;
END;
end IVR_PREPAGO;
/

