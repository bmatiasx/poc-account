create materialized view S_GENERAL_PLAN_MESSAGES
refresh fast on demand
  as
    SELECT GPM_ID,
       GPM_IVA,
       GPM_IMP_INTERNO,
       GPM_MSG_WEB,
       GPM_MSG_USSD,
       GPM_PROV_SIN_IMP,
       GPM_FLAG_SMS,
       GPM_FLAG_DATOS,
       GPM_FLAG_CONSUMO,
       GPM_MSG_SMS
  FROM GENERAL_PLAN_MESSAGES@ardstl.world
/

