create materialized view S_CEL_INACTIVE_FEATURES1
on prebuilt table
refresh complete on demand
  as
    select * from (
SELECT pif_clu_cellular_number,
       pif_ftr_id,
       pif_start_date,
       pif_end_date,
       pif_usr_id
  FROM STL.CEL_INACTIVE_FEATURES@PROD)
/

