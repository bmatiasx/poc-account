create materialized view GET_VIASDECOMUNICACION
refresh force on demand
  as
    SELECT nmc_id, nmc_description
FROM notification_media_combineds@PROD
 
/

