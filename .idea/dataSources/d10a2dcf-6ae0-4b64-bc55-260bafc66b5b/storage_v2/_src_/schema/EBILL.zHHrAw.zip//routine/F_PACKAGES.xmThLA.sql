create FUNCTION F_PACKAGES  (P_CELLULAR_NUMBER IN VARCHAR2
 ,P_PKT_ID IN VARCHAR2
 ,P_CANCEL_DATE IN DATE
 ,P_TCK_ID IN VARCHAR2
 ,P_PRM_ID IN VARCHAR2
 ,P_ACT_DATE IN DATE
 ,P_USER_DELETED IN VARCHAR2
 ,P_AUDIOTEL_FLAG IN VARCHAR2
 ,P_INSERT_SWITCH IN VARCHAR2
 ,P_PACK_ISI OUT VARCHAR2
 ,P_PROCESS IN VARCHAR2
 ,P_CHECK_TASK IN VARCHAR2
 ,P_RAZON IN VARCHAR2
 ,P_LOGIC IN VARCHAR2
 ,P_ERR_NUMBER OUT NUMBER
 ,P_ERR_MESSAGE OUT VARCHAR2
 ) RETURN NUMBER
 IS

BEGIN

TEST.pa_packages.cancel_cellular_packages@PROD.WORLD(
        pkt => p_pkt_id,
        can_date => SYSDATE,
        cellular => p_cellular_number,
        tck_id => p_tck_id,
        prm_id => p_prm_id,
        act_date => P_ACT_DATE,
        usr_deleted => USER,
        audiotel_flag => p_audiotel_flag,
        err_code => p_err_number,
        err_txt => p_err_message,
        p_insert_switch => p_insert_switch,
        p_pack_isi => p_pack_isi,
        p_process => p_process,
        check_task => p_check_task,
        p_razon => p_razon ,
        p_logic=> p_logic );

        IF p_err_number =0 THEN
           RETURN 0;
         
        ELSE
          RETURN -1;
        END IF;

END;
/

