create view V_L_TABLE as
  SELECT id from l_table
/

