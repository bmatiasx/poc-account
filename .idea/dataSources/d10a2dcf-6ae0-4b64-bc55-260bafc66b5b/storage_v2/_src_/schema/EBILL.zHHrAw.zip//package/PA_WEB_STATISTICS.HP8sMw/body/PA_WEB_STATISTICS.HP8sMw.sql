create PACKAGE BODY PA_WEB_STATISTICS IS
function set_stat(pSessionID in varchar2,pStat in number,pUC in number,pApp in number,pCluCellularNumber in varchar2,pAccId in varchar2) return number is
  CantFilasUpdate number;
  Begin
       if (pStat>0) then
         update WEB_STATISTICS WS1 set WS1.WST_STAT = pStat
           where WS1.WST_SESSION_ID = pSessionID and WS1.WST_STAT = 0
             and WS1.WST_UC = pUC and WS1.WST_APP = pApp
             and WS1.WST_DATE = (select max(WS2.WST_DATE) from WEB_STATISTICS WS2
             where WS2.WST_SESSION_ID = pSessionID);
         CantFilasUpdate := sql%rowcount;
         if (CantFilasUpdate>0) then
            return 0;
         end if;
       end if;
       insert into WEB_STATISTICS (WST_DATE,WST_SESSION_ID,WST_STAT,WST_UC,WST_APP,WST_CLU_CELLULAR_NUMBER,WST_ACC_ID)
           values (sysdate,pSessionID,pStat,pUC,pApp,pCluCellularNumber,pAccId);
       return 0;
  Exception
   WHEN OTHERS then
     return sqlcode;
  End;
END PA_WEB_STATISTICS;
/

