create materialized view S_SWP_PROVISIONING_ACTIONS
refresh force on demand
  as
    SELECT spa_crm_action, spa_crm_service, spa_ne_action, spa_ne_service
from SWP_PROVISIONING_ACTIONS@PROD
where SPA_CRM_ACTION = 'ACT'
 
/

