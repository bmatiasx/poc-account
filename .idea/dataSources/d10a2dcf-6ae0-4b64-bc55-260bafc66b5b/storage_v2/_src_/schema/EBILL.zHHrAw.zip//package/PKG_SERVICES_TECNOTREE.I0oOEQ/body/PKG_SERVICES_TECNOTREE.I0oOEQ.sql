create PACKAGE BODY PKG_SERVICES_TECNOTREE IS
  FUNCTION F_GET_FROZEN_BALANCE_DAYS(P_FECHA_EXPIRACION_MAIN IN VARCHAR2,
                                     P_FECHA_EXPIRACION_CONG OUT DATE,
                                     P_ERROR_MSG             OUT VARCHAR2)
  
   RETURN NUMBER AS
  
    v_l_frozen_days  NUMBER := 0;
    v_par_name       VARCHAR2(256) := 'FROZEN_BALANCE_DAYS';
    fecha_expiracion DATE;
  
  BEGIN
    fecha_expiracion := TO_DATE(P_FECHA_EXPIRACION_MAIN, 'yyyy-mm-dd');
  
    IF (fecha_expiracion < SYSDATE) THEN
      SELECT par_value
        INTO v_l_frozen_days
        FROM s_parameters
       WHERE par_name = v_par_name;
    
      P_FECHA_EXPIRACION_CONG := fecha_expiracion + v_l_frozen_days;
      RETURN 0;
    
    END IF;
  
  EXCEPTION
    WHEN OTHERS THEN
      P_ERROR_MSG := 'Error al calcular el saldo congelado para la fecha ingresada.';
      RETURN - 1;
    
  END;

  FUNCTION F_GET_PKG_INFO(P_CADENA       IN VARCHAR2,
                          P_CELLULAR     IN VARCHAR2,
                          P_SEPARADOR    IN VARCHAR2,
                          P_SALIDA       OUT VARCHAR2,
                          P_ERROR        OUT VARCHAR2,
                          P_ERROR_NUMBER OUT NUMBER) RETURN VARCHAR2 IS
    v_param   varchar2(10) := P_SEPARADOR;
    v_total   varchar2(2000);
    v_total_1 varchar2(2000);
    v_valor   number;
    v_date    varchar2(2000);
    v_fin     varchar2(2000);
    EXCEP exception;
  
    /*
    P_CADENA: string que se envia desde la aplicacion, el string debe tener el siguiente formato: 3#52#25
    (# es un ejemplo de separador, puede ser cualquier otro).
    P_CELLULAR: cellular_number.
    P_SEPARADOR: es el separador que se devulve en el string.
    --En los casos que se pasen un solo valor en la cadena de entrada, unicamente se debera pasar el numero
    sin el separador.
    --En los casos en que la query no devuelva datos, a los valores v_valor, v_date se le asigna el valor -1 y
    01/01/1970 de acuerdo a lo pedido por gente de webservice.
    */
    CURSOR CUR(v_element VARCHAR2) is
      SELECT nvl(sep_units_in, '-1'),
             TO_CHAR(cpk_activation_date, 'dd/mm/yyyy HH24:MI:SS')
        FROM S_SERVICE_PACK_PARAMETERS spp, S_CELLULAR_PACKAGES cpk
       where spp.sep_pkt_tecnomen = v_element
         and nvl(spp.sep_end_date, sysdate + 1) > sysdate
         and nvl(cpk.cpk_canceled_date, sysdate + 1) > sysdate
         and spp.sep_pkt_id = cpk.cpk_pkt_id
         and cpk.cpk_clu_cellular_number = P_CELLULAR;
  
  BEGIN
    BEGIN
      IF P_CADENA IS NULL OR P_CELLULAR IS NULL OR P_SEPARADOR IS NULL THEN
        RAISE EXCEP;
      END IF;
    END;
    FOR R IN (SELECT SUBSTR(str,
                            INSTR(str, v_param, 1, LEVEL) + 1,
                            INSTR(str, v_param, 1, LEVEL + 1) -
                            INSTR(str, v_param, 1, LEVEL) - 1) element
                FROM (SELECT v_param || P_CADENA || v_param str FROM DUAL)
              CONNECT BY LEVEL <=
                         LENGTH(str) - LENGTH(REPLACE(str, v_param)) - 1)
    
     LOOP
      BEGIN
      
        OPEN CUR(R.element);
      
        FETCH CUR
          INTO v_valor, v_date;
      
        IF CUR%ROWCOUNT = 0 THEN
          v_valor := -1;
          v_date  := TO_CHAR(TO_DATE('01/01/1970', 'dd/mm/yyyy HH24:MI:SS'),
                             'dd/mm/yyyy HH24:MI:SS');
        END IF;
      
        v_total_1 := v_valor || v_param || v_date || v_param;
        v_total   := v_total || v_total_1;
      
        CLOSE CUR;
      
      EXCEPTION
        WHEN OTHERS THEN
          P_ERROR        := SQLERRM;
          P_ERROR_NUMBER := SQLCODE;
          P_SALIDA       := '';
          RETURN - 1;
      END;
    
    END LOOP;
    v_fin    := substr(v_total, 0, length(v_total) - 1);
    P_SALIDA := v_fin;
    RETURN 0;
  EXCEPTION
    WHEN EXCEP THEN
      P_SALIDA := 'Los valores P_CADENA, P_CELLULAR, P_SEPARADOR son obligatorios!';
      RETURN 1;
    WHEN OTHERS THEN
      P_ERROR        := SQLERRM;
      P_ERROR_NUMBER := SQLCODE;
      P_SALIDA       := '';
      RETURN - 1;
  END F_GET_PKG_INFO;
END PKG_SERVICES_TECNOTREE;
/

