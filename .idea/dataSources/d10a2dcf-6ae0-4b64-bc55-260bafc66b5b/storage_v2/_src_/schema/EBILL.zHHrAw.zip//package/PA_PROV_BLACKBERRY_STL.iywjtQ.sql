create package       Pa_prov_blackBerry_stl is
  -- Author  : CTI3474
  -- Created : 22/03/2006 01:46:11 p.m.
  -- Purpose : Interface entre Stealth y Servidor RIM de BlackBerry
  -- ACTION STATUS
  cPENDING_STATUS       CONSTANT VARCHAR2(1):= 'P';
  -- BLACKBERRY OPERATIONS
  cBB_ACTIVATE_SERVICE      CONSTANT BLACKBERRY_AVAILABLE_SERVICES.BBAS_ID%TYPE:= 'ACT';
  cBB_CHANGE_SERVICE        CONSTANT BLACKBERRY_AVAILABLE_SERVICES.BBAS_ID%TYPE:= 'CHS';
  cBB_CANCEL_SERVICE        CONSTANT BLACKBERRY_AVAILABLE_SERVICES.BBAS_ID%TYPE:= 'CAN';
  cBB_SUSPEND_SERVICE       CONSTANT BLACKBERRY_AVAILABLE_SERVICES.BBAS_ID%TYPE:= 'SUS';
  cBB_RESUME_SERVICE        CONSTANT BLACKBERRY_AVAILABLE_SERVICES.BBAS_ID%TYPE:= 'RES';
  cBB_CHANGE_BI             CONSTANT BLACKBERRY_AVAILABLE_SERVICES.BBAS_ID%TYPE:= 'CBI';
  cBB_CHANGE_NON_BI         CONSTANT BLACKBERRY_AVAILABLE_SERVICES.BBAS_ID%TYPE:= 'CNI';
  cBB_ASSIGN_SERVICES       CONSTANT BLACKBERRY_AVAILABLE_SERVICES.BBAS_ID%TYPE:= 'ASG';
  cBB_DISPLAY_SERVICES      CONSTANT BLACKBERRY_AVAILABLE_SERVICES.BBAS_ID%TYPE:= 'REV';
  -- ERRORS
  cERR_001 CONSTANT VARCHAR2(60):= 'Error insertando en blackberry_interfaces';
  cERR_002 CONSTANT VARCHAR2(60):= 'Error insertando en blackberry_assign_params';
  cERR_101 CONSTANT VARCHAR2(60):= 'Error de notifiacion al talker-update';
  cERR_102 CONSTANT VARCHAR2(60):= 'Error de notifiacion al talker-review';
  cERR_200 CONSTANT VARCHAR2(60):= 'Error de display';
  e_error                          exception;
/*
Proposito: Activa el servicio al imsi y al terminal que tiene asociado
Parametros Obligatorios:
   - p_imsi = IMSI
   - p_msisdn = MSISDN
   - p_service = cualquier servicio de la tabla BLACKBERRY_AVAILABLE_SERVICES
Parametros Opcionales:
   - p_pin = PIN del equipo blackberry
   - p_fecha = Si la accion es a futuro ingresar la fecha con este parametro
La funcion retorna:
   - '0' si esta todo bien
   - '-1' si hubo un error y p_message tiene el mensaje de error
*/
  function Bb_Activation(p_imsi BLACKBERRY_INTERFACES.BBI_PARAM1%TYPE,
                         p_msisdn BLACKBERRY_INTERFACES.BBI_PARAM2%TYPE,
                         p_service BLACKBERRY_INTERFACES.BBI_PARAM3%TYPE,
                         p_pin varchar2 default null,
                         p_fecha date default null,
                         p_message out varchar2) return number;
/*
Proposito: Cambia el servicio (excluyente con los existentes)
Parametros Obligatorios:
   - p_imsi = IMSI
   - p_service = solo los servicios BWC, BES o EPLUS
Parametros Opcionales:
   - p_pin = PIN del equipo blackberry
   - p_fecha = Si la accion es a futuro ingresar la fecha con este parametro
La funcion retorna:
   - '0' si esta todo bien
   - '-1' si hubo un error y p_message tiene el mensaje de error
*/
  function Bb_ChangeService(p_imsi BLACKBERRY_INTERFACES.BBI_PARAM1%TYPE,
                            p_service BLACKBERRY_INTERFACES.BBI_PARAM2%TYPE,
                            p_pin BLACKBERRY_INTERFACES.BBI_PARAM3%TYPE default null,
                            p_fecha date default null,
                            p_message out varchar2) return number;
/*
Proposito: Se cancela el servicio al imsi y al terminal.
Parametros Obligatorios:
   - p_imsi = IMSI
Parametros Opcionales:
   - p_pin = PIN del equipo blackberry
   - p_fecha = Si la accion es a futuro ingresar la fecha con este parametro
La funcion retorna:
   - '0' si esta todo bien
   - '-1' si hubo un error y p_message tiene el mensaje de error
*/
  function Bb_Cancelation(p_imsi BLACKBERRY_INTERFACES.BBI_PARAM1%TYPE,
                          p_pin BLACKBERRY_INTERFACES.BBI_PARAM2%TYPE default null,
                          p_fecha date default null,
                          p_message out varchar2) return number;
/*
Proposito: Se suspende el servicio al imsi y al terminal
Parametros Obligatorios:
   - p_imsi = IMSI
Parametros Opcionales:
   - p_pin = PIN del equipo blackberry
   - p_fecha = Si la accion es a futuro ingresar la fecha con este parametro
La funcion retorna:
   - '0' si esta todo bien
   - '-1' si hubo un error y p_message tiene el mensaje de error
*/
  function Bb_Suspend(p_imsi BLACKBERRY_INTERFACES.BBI_PARAM1%TYPE,
                      p_pin BLACKBERRY_INTERFACES.BBI_PARAM2%TYPE default null,
                      p_fecha date default null,
                      p_message out varchar2) return number;
/*
Proposito: Reactiva el servicio al imsi y al terminal
Parametros Obligatorios:
   - p_imsi = IMSI
Parametros Opcionales:
   - p_pin = PIN del equipo blackberry
   - p_fecha = Si la accion es a futuro ingresar la fecha con este parametro
La funcion retorna:
   - '0' si esta todo bien
   - '-1' si hubo un error y p_message tiene el mensaje de error
*/
  function Bb_Resume(p_imsi BLACKBERRY_INTERFACES.BBI_PARAM1%TYPE,
                     p_pin BLACKBERRY_INTERFACES.BBI_PARAM2%TYPE default null,
                     p_fecha date default null,
                     p_message OUT varchar2) return number;
/*
Proposito: Cambia el imsi que tiene el servicio BB.
Parametros Obligatorios:
   - p_imsi = IMSI viejo
   - p_newImsi = IMSI nuevo
   - p_newIccid = ICCID nuevo
Parametros Opcionales:
   - p_fecha = Si la accion es a futuro ingresar la fecha con este parametro
La funcion retorna:
   - '0' si esta todo bien
   - '-1' si hubo un error y p_message tiene el mensaje de error
*/
  function Bb_ChangeBI  (p_imsi  BLACKBERRY_INTERFACES.BBI_PARAM1%TYPE,
                         p_newImsi  BLACKBERRY_INTERFACES.BBI_PARAM2%TYPE,
                         p_fecha date default null,
                         p_message out varchar2) return number;
/*
Proposito: Cambia los valores MSISDN o ICCID de un determinado IMSI activo
Parametros Obligatorios:
   - p_imsi = IMSI viejo
   - p_identifier = El identificador que se va a cambiar (MSISDN,ICCID)
   - p_newValue = Nuevo valor del identificador
Parametros Opcionales:
   - p_fecha = Si la accion es a futuro ingresar la fecha con este parametro
La funcion retorna:
   - '0' si esta todo bien
   - '-1' si hubo un error y p_message tiene el mensaje de error
*/
  function Bb_ChangeNBI (p_imsi BLACKBERRY_INTERFACES.BBI_PARAM1%TYPE,
                         p_identifier BLACKBERRY_INTERFACES.BBI_PARAM2%TYPE,
                         p_newValue BLACKBERRY_INTERFACES.BBI_PARAM3%TYPE,
                         p_fecha date default null,
                         p_message OUT varchar2) return number;
/*
Proposito: Administrar servicios de un handheld
Parametros Obligatorios:
   - p_pin = PIN del equipo blackberry
   - p_services = Servicio (o servicios separados por coma)
Parametros Opcionales:
   - p_fecha = Si la accion es a futuro ingresar la fecha con este parametro
La funcion retorna:
   - '0' si esta todo bien
   - '-1' si hubo un error y p_message tiene el mensaje de error
NOTA: Sobreescribe los servicios existentes, y si no se pone ningun servicio vuelve al estado virgen inicial
*/
  function Bb_AssignService(p_pin BLACKBERRY_INTERFACES.BBI_PARAM1%TYPE,
                            p_services BLACKBERRY_INTERFACES.BBI_PARAM2%TYPE default NULL,
                            p_fecha date default null,
                            p_message OUT varchar2) return number;
/*
Proposito: Envia peticion de display
Parametros Obligatorios:
   - p_imsi = IMSI
Parametros de Salida:
   - p_bbi_id = Devuelve el Id para ir a buscarlo. Error: blackberry_interface_errors
                                                      OK: blackberry_status_replies
La funcion retorna:
   - '0' si esta todo bien
   - '-1' si hubo un error y p_message tiene el mensaje de error
*/
  function Bb_SendDisplay (p_imsi BLACKBERRY_INTERFACES.BBI_PARAM1%TYPE,
                           p_bbi_id out BLACKBERRY_INTERFACES.BBI_ID%TYPE,
                           p_message out varchar2) return number;
/*
Proposito: Busca el estado de la transaccion de Display
Parametros Obligatorios:
   - p_bbi_id = Id de la transaccion de Display
Parametros de Salida:
   - p_bbi_status = Devuelve el estado de la transaccion de Bb_SendDisplay asociada (O,E)
   - p_bie_code = en caso de error, devuelve el codigo (sino nada)
   - p_bie_description = en caso de error, devuelve la descripcion (sino nada)
La funcion retorna:
   - '0' si esta todo bien
   - '-1' si hubo un error y p_message tiene el mensaje de error
*/
  function Bb_GetStatus (p_bbi_id BLACKBERRY_INTERFACES.BBI_ID%TYPE,
                         p_bbi_status out BLACKBERRY_INTERFACES.BBI_STATUS%TYPE,
                         p_bie_code out BLACKBERRY_INTERFACES_ERRORS.BIE_CODE%TYPE,
                         p_bie_description out BLACKBERRY_INTERFACES_ERRORS.BIE_DESCRIPTION%TYPE,
                         p_message out varchar2) return number;
/*
Proposito: Notifica al talker de bb que viene un comando
La funcion retorna:
   - '0' si esta todo bien
   - '-1' si hubo un error y p_message tiene el mensaje de error
NOTA: Esta notificacion debe usarse para cualquier comando, menos el de display
*/
  function Bb_NotifyUpdate (p_message OUT varchar2) return number;
/*
Proposito: Notifica al talker de bb que viene un comando de display
La funcion retorna:
   - '0' si esta todo bien
   - '-1' si hubo un error y p_message tiene el mensaje de error
NOTA: Esta notificacion debe usarse solo para comandos de display
*/
  function Bb_NotifyReview (p_message OUT varchar2) return number;
end Pa_prov_blackBerry_stl;
/

