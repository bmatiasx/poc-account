create FUNCTION f_call_insert_acc_serv_detail (p_asd_ars_id IN VARCHAR2,
                                                          p_package_cellular IN TY_ARRAY_OBJ_MAP,
                                                          p_err_txt    OUT VARCHAR2,
                                                          p_err_number OUT NUMBER) 
RETURN NUMBER 
IS
    record_map pa_utils.ty_rec_obj_map;
    i pls_integer := 0;
BEGIN        
    FOR r_package_cellular IN (SELECT clave AS cellular, valor AS package
                                            FROM TABLE(CAST(p_package_cellular AS TY_ARRAY_OBJ_MAP))) 
    LOOP
       record_map(i).clave := r_package_cellular.cellular;
       record_map (i).valor := r_package_cellular.package;
        i:=i+1;
    END LOOP;

    RETURN f_insert_acc_serv_detail@prod(p_asd_ars_id => p_asd_ars_id,
                                         p_record_map=> record_map,
                                         p_err_txt => p_err_txt,
                                         p_err_number => p_err_number);    
EXCEPTION
    WHEN OTHERS THEN 
        p_err_number := SQLCODE; 
        p_err_txt := SQLERRM; 
        RETURN - 1;
END f_call_insert_acc_serv_detail;
/

